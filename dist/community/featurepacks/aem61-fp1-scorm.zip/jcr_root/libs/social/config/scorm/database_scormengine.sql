CREATE SCHEMA IF NOT EXISTS `ScormEngineDB` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `ScormEngineDB` ;
            SET storage_engine=INNODB;

            DELIMITER //
            DROP PROCEDURE IF EXISTS `ensure_table`//
            CREATE PROCEDURE `ensure_table` (table_name varchar(255))
            BEGIN
                SET @add_table_sql = concat('CREATE TABLE IF NOT EXISTS `', table_name,
                        '` (update_by VARCHAR(32) CHARACTER SET utf8 NOT NULL DEFAULT "unknown", update_dt TIMESTAMP NOT NULL DEFAULT NOW())');
                PREPARE stmt FROM @add_table_sql;
                EXECUTE stmt;
            END;
            //

            DROP PROCEDURE IF EXISTS `ensure_column`//
            CREATE PROCEDURE `ensure_column` (table_name varchar(255), 
                                              column_name varchar(255), 
                                              column_def varchar(255))
            BEGIN
                IF NOT EXISTS (SELECT TRUE FROM information_schema.COLUMNS cols 
                               WHERE cols.column_name = column_name 
                                  AND cols.table_name = table_name 
                                  AND cols.table_schema = schema())
                THEN
                    SET @add_column_sql = concat('ALTER TABLE ', schema(), '.`', table_name, 
                                '` ADD COLUMN `', column_name, '` ', column_def);
                    PREPARE stmt FROM @add_column_sql;
                    EXECUTE stmt;
                END IF;
            END;
            //

            DROP PROCEDURE IF EXISTS `ensure_index`//
            CREATE PROCEDURE `ensure_index` (table_name varchar(255),
                                             index_name varchar(255),
                                             column_list varchar(2000))
            BEGIN
                IF NOT EXISTS (SELECT TRUE FROM INFORMATION_SCHEMA.STATISTICS stats
                               WHERE stats.table_name = table_name 
                                  AND stats.table_schema = schema()
                                  AND stats.index_name = index_name)
                THEN
                    SET @add_index_sql = concat('ALTER TABLE ', schema(), '.`', table_name,
                                '` ADD INDEX `', index_name, '` (', column_list, ')');
                    PREPARE stmt FROM @add_index_sql;
                    EXECUTE stmt;
                END IF;
            END;
            //

            DROP PROCEDURE IF EXISTS `ensure_primary_key`//
            CREATE PROCEDURE `ensure_primary_key` (table_name varchar(255),
                                             column_list varchar(2000))
            BEGIN
                IF NOT EXISTS (SELECT TRUE FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
                               WHERE tc.table_name = table_name 
                                  AND tc.constraint_schema = schema()
                                  AND tc.constraint_name = 'PRIMARY')
                THEN
                    SET @add_pk_sql = concat('ALTER TABLE ', schema(), '.`', table_name,
                                '` ADD PRIMARY KEY (', column_list, ')');
                    PREPARE stmt FROM @add_pk_sql;
                    EXECUTE stmt;
                END IF;
            END;
            //

            DROP PROCEDURE IF EXISTS `ensure_foreign_key`//
            CREATE PROCEDURE `ensure_foreign_key` (table_name varchar(255),
                                             key_name varchar(255),
                                             column_list varchar(2000),
                                             foreign_table_name varchar(255),
                                             foreign_column_list varchar(2000))
            BEGIN    
            	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION 
					SELECT 'Unable to create FK -- parent table is likely MyIASM';
                
				IF NOT EXISTS (SELECT TRUE FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
                               WHERE tc.table_name = table_name 
                                  AND tc.constraint_schema = schema()
                                  AND tc.constraint_name = key_name)
                THEN
                    SET @add_fk_sql = concat('ALTER TABLE ', schema(), '.`', table_name,
                                '` ADD CONSTRAINT `', key_name, '` FOREIGN KEY (', column_list, ')',
                                ' REFERENCES `', foreign_table_name, '` (', foreign_column_list, ')');
                    PREPARE stmt FROM @add_fk_sql;
                    EXECUTE stmt;
                END IF;
            END;
            // 

            DROP PROCEDURE IF EXISTS `ensure_db_update_id`//
            CREATE PROCEDURE `ensure_db_update_id` (db_update_id varchar(255))
            BEGIN    
				IF (SELECT count(*) FROM ScormEngineDbUpdates WHERE update_id = db_update_id)= 0  
                THEN   
					SET @add_id_sql = concat('INSERT INTO ScormEngineDbUpdates (update_id, update_dt, update_by) values (''', db_update_id,  ''', NOW(), ''script'')');   
                    PREPARE stmt FROM @add_id_sql;
                    EXECUTE stmt;
                END IF;
            END;
            // 

            DELIMITER ;
        



CALL ensure_table('PensCommand');




    CALL ensure_column('PensCommand','pens_command_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('PensCommand','pens_command_id');




    CALL ensure_column('PensCommand','pens_package_type',"CHAR(10)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('PensCommand','pens_package_id',"VARCHAR(2000)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('PensCommand','pens_client',"VARCHAR(100)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('PensCommand','pens_system_user_id',"VARCHAR(100)CHARACTER SET utf8 NULL");




    CALL ensure_column('PensCommand','pens_step',"VARCHAR(100)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('PensCommand','internal_step',"INT NOT NULL");




    CALL ensure_column('PensCommand','should_process',"INT NOT NULL");




    CALL ensure_column('PensCommand','pens_command',"CHAR(7)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('PensCommand','pens_serialized',"LONGTEXT CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('PensCommand','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('PensCommand','update_dt',"DATETIME NOT NULL");




    CALL ensure_column('PensCommand','failedCount',"INT NOT NULL");




    CALL ensure_column('PensCommand','processAfter',"DATETIME NOT NULL");




    CALL ensure_column('PensCommand','lock_id',"VARCHAR(50)CHARACTER SET utf8 NOT NULL DEFAULT ''''");




    CALL ensure_primary_key('PensCommand','`pens_command_id`');




    CALL ensure_index('PensCommand','IX_PensCommand','`internal_step`,`lock_id`,`should_process`');




  



CALL ensure_table('PensCommandScormPackage');




    CALL ensure_column('PensCommandScormPackage','pens_command_id',"INT NOT NULL");




    CALL ensure_column('PensCommandScormPackage','scorm_package_id',"INT NOT NULL");




    CALL ensure_column('PensCommandScormPackage','external_package_id',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL DEFAULT ''''");




    CALL ensure_column('PensCommandScormPackage','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('PensCommandScormPackage','update_dt',"DATETIME NOT NULL");




    CALL ensure_primary_key('PensCommandScormPackage','`pens_command_id`,`scorm_package_id`');




  



CALL ensure_table('ScormActivity');




    CALL ensure_column('ScormActivity','scorm_activity_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormActivity','scorm_activity_id');




    CALL ensure_column('ScormActivity','scorm_registration_id',"INT NOT NULL");




    CALL ensure_column('ScormActivity','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormActivity','activity_progress_status',"INT NOT NULL");




    CALL ensure_column('ScormActivity','activity_attempt_count',"INT NOT NULL");




    CALL ensure_column('ScormActivity','attempt_progress_status',"INT NOT NULL");




    CALL ensure_column('ScormActivity','attempt_completion_amount',"DECIMAL(10,7) NOT NULL");




    CALL ensure_column('ScormActivity','attempt_completion_status',"INT NOT NULL");




    CALL ensure_column('ScormActivity','active',"INT NOT NULL");




    CALL ensure_column('ScormActivity','suspended',"INT NOT NULL");




    CALL ensure_column('ScormActivity','included',"INT NOT NULL");




    CALL ensure_column('ScormActivity','ordinal',"INT NOT NULL");




    CALL ensure_column('ScormActivity','selected_children',"INT NOT NULL");




    CALL ensure_column('ScormActivity','randomized_children',"INT NOT NULL");




    CALL ensure_column('ScormActivity','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivity','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','first_completion_timestamp_utc',"DATETIME NULL");




    CALL ensure_column('ScormActivity','prev_attempt_progress_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','prev_attempt_completion_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','attempted_during_this_attempt',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','attempt_completion_amount_stat',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','activity_start_timestamp_utc',"DATETIME NULL");




    CALL ensure_column('ScormActivity','attempt_start_timestamp_utc',"DATETIME NULL");




    CALL ensure_column('ScormActivity','activity_absolute_dur',"BIGINT NOT NULL DEFAULT -1");




    CALL ensure_column('ScormActivity','attempt_absolute_dur',"BIGINT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','activity_exp_dur_tracked',"BIGINT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','attempt_exp_dur_tracked',"BIGINT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','activity_exp_dur_reported',"BIGINT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','attempt_exp_dur_reported',"BIGINT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivity','aicc_session_id',"VARCHAR(2000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivity','is_latest_attempt',"INT NOT NULL DEFAULT 1");




    CALL ensure_primary_key('ScormActivity','`scorm_activity_id`');




    CALL ensure_index('ScormActivity','IX_ScormActivity','`scorm_registration_id`');




  



CALL ensure_table('ScormActivityObjective');




    CALL ensure_column('ScormActivityObjective','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityObjective','scorm_activity_objective_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityObjective','objective_identifier',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityObjective','objective_progress_status',"INT NOT NULL");




    CALL ensure_column('ScormActivityObjective','objective_satisfied_status',"INT NOT NULL");




    CALL ensure_column('ScormActivityObjective','objective_measure_status',"INT NOT NULL");




    CALL ensure_column('ScormActivityObjective','objective_normalized_measure',"DECIMAL(10,7) NOT NULL");




    CALL ensure_column('ScormActivityObjective','primary_objective',"INT NOT NULL");




    CALL ensure_column('ScormActivityObjective','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityObjective','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','first_success_timestamp_utc',"DATETIME NULL");




    CALL ensure_column('ScormActivityObjective','first_obj_normalized_measure',"DECIMAL(10,7) NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','prev_obj_progress_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','prev_obj_satisfied_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','prev_obj_measure_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','prev_obj_normalized_measure',"DECIMAL(10,7) NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','completion_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','completion_status_value',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','score_raw',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityObjective','score_max',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityObjective','score_min',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityObjective','progress_measure_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityObjective','progress_measure',"DECIMAL(10,7) NULL");




    CALL ensure_primary_key('ScormActivityObjective','`scorm_activity_id`,`scorm_activity_objective_id`');




  



CALL ensure_table('ScormActivityRT');




    CALL ensure_column('ScormActivityRT','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','completion_status',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','credit',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','entry',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','exit_mode',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','location',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRT','location_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRT','lesson_mode',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','progress_measure',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormActivityRT','score_raw',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityRT','score_max',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityRT','score_min',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityRT','score_scaled',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormActivityRT','success_status',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','suspend_data',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRT','suspend_data_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRT','suspend_data_overflow',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRT','suspend_data_overflow_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRT','total_time',"BIGINT NOT NULL");




    CALL ensure_column('ScormActivityRT','total_time_tracked',"BIGINT NOT NULL");




    CALL ensure_column('ScormActivityRT','audio_level',"DECIMAL(38,7) NOT NULL");




    CALL ensure_column('ScormActivityRT','language_preference',"VARCHAR(255)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityRT','delivery_speed',"DECIMAL(38,7) NOT NULL");




    CALL ensure_column('ScormActivityRT','audio_captioning',"INT NOT NULL");




    CALL ensure_column('ScormActivityRT','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityRT','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormActivityRT','`scorm_activity_id`');




  



CALL ensure_table('ScormActivityRTComment');




    CALL ensure_column('ScormActivityRTComment','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTComment','comment_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTComment','from_lms',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTComment','comment_text',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTComment','comment_text_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTComment','language',"VARCHAR(260)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityRTComment','language_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTComment','location',"VARCHAR(250)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTComment','location_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTComment','timestamp_utc',"DATETIME NULL");




    CALL ensure_column('ScormActivityRTComment','timestamp_text',"VARCHAR(30)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityRTComment','timestamp_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTComment','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityRTComment','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormActivityRTComment','id',"VARCHAR(200)CHARACTER SET latin1 NULL");




    CALL ensure_primary_key('ScormActivityRTComment','`scorm_activity_id`,`comment_index`,`from_lms`');




  



CALL ensure_table('ScormActivityRTIntCorrectResp');




    CALL ensure_column('ScormActivityRTIntCorrectResp','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntCorrectResp','interaction_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntCorrectResp','interaction_correct_resp_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntCorrectResp','correct_response',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTIntCorrectResp','correct_response_overflow',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTIntCorrectResp','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityRTIntCorrectResp','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormActivityRTIntCorrectResp','`scorm_activity_id`,`interaction_index`,`interaction_correct_resp_index`');




  



CALL ensure_table('ScormActivityRTInteraction');




    CALL ensure_column('ScormActivityRTInteraction','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTInteraction','interaction_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTInteraction','interaction_id',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityRTInteraction','type',"INT NULL");




    CALL ensure_column('ScormActivityRTInteraction','timestamp_utc',"DATETIME NULL");




    CALL ensure_column('ScormActivityRTInteraction','timestamp_text',"VARCHAR(30)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityRTInteraction','timestamp_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTInteraction','weighting',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormActivityRTInteraction','result',"INT NULL");




    CALL ensure_column('ScormActivityRTInteraction','result_numeric',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormActivityRTInteraction','latency',"BIGINT NULL");




    CALL ensure_column('ScormActivityRTInteraction','description',"VARCHAR(510)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTInteraction','description_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTInteraction','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityRTInteraction','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormActivityRTInteraction','`scorm_activity_id`,`interaction_index`');




  



CALL ensure_table('ScormActivityRTIntLearnerResp');




    CALL ensure_column('ScormActivityRTIntLearnerResp','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntLearnerResp','interaction_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntLearnerResp','learner_response',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTIntLearnerResp','learner_response_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTIntLearnerResp','learner_response_overflow',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTIntLearnerResp','learner_response_overflow_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTIntLearnerResp','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityRTIntLearnerResp','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormActivityRTIntLearnerResp','`scorm_activity_id`,`interaction_index`');




  



CALL ensure_table('ScormActivityRTIntObjective');




    CALL ensure_column('ScormActivityRTIntObjective','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntObjective','interaction_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntObjective','interaction_objective_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTIntObjective','objective_id',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityRTIntObjective','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityRTIntObjective','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormActivityRTIntObjective','`scorm_activity_id`,`interaction_index`,`interaction_objective_index`');




  



CALL ensure_table('ScormActivityRTObjective');




    CALL ensure_column('ScormActivityRTObjective','scorm_activity_id',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTObjective','objective_index',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTObjective','objective_id',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormActivityRTObjective','objective_id_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTObjective','success_status',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTObjective','completion_status',"INT NOT NULL");




    CALL ensure_column('ScormActivityRTObjective','score_scaled',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormActivityRTObjective','score_raw',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityRTObjective','score_max',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityRTObjective','score_min',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormActivityRTObjective','progress_measure',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormActivityRTObjective','description',"VARCHAR(510)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormActivityRTObjective','description_null',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormActivityRTObjective','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormActivityRTObjective','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormActivityRTObjective','`scorm_activity_id`,`objective_index`');




  



CALL ensure_table('ScormAiccSession');




    CALL ensure_column('ScormAiccSession','aicc_session_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormAiccSession','legacy_aicc_session_id',"VARCHAR(2000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormAiccSession','scorm_registration_id',"INT NOT NULL");




    CALL ensure_column('ScormAiccSession','external_registration_id',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormAiccSession','external_configuration',"VARCHAR(2000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormAiccSession','is_tracking',"INT NOT NULL");




    CALL ensure_column('ScormAiccSession','launch_history_id',"INT NULL");




    CALL ensure_column('ScormAiccSession','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormAiccSession','update_dt',"DATETIME NOT NULL");




    CALL ensure_primary_key('ScormAiccSession','`aicc_session_id`');




    CALL ensure_index('ScormAiccSession','IX_ScormAiccSession','`scorm_registration_id`');




  



CALL ensure_table('ScormEngineDbUpdates');




    CALL ensure_column('ScormEngineDbUpdates','update_id',"VARCHAR(50)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormEngineDbUpdates','update_by',"VARCHAR(50)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormEngineDbUpdates','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormEngineDbUpdates','`update_id`');




  



CALL ensure_table('ScormExpirableObjectStore');




    CALL ensure_column('ScormExpirableObjectStore','id',"VARCHAR(255)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormExpirableObjectStore','value',"LONGTEXT CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormExpirableObjectStore','expiry',"DATETIME NULL");




    CALL ensure_column('ScormExpirableObjectStore','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormExpirableObjectStore','update_dt',"DATETIME NOT NULL");




    CALL ensure_primary_key('ScormExpirableObjectStore','`id`');




  



CALL ensure_table('ScormLaunchHistory');




    CALL ensure_column('ScormLaunchHistory','launch_history_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormLaunchHistory','launch_history_id');




    CALL ensure_column('ScormLaunchHistory','scorm_registration_id',"INT NOT NULL");




	CALL ensure_column('ScormLaunchHistory','launch_time',"DATETIME NOT NULL");




    CALL ensure_column('ScormLaunchHistory','launch_time_utc',"DATETIME NULL");




    CALL ensure_column('ScormLaunchHistory','exit_time',"DATETIME NULL");




    CALL ensure_column('ScormLaunchHistory','exit_time_utc',"DATETIME NULL");




    CALL ensure_column('ScormLaunchHistory','completion',"VARCHAR(20)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormLaunchHistory','satisfaction',"VARCHAR(20)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormLaunchHistory','measure_status',"INT NULL");




    CALL ensure_column('ScormLaunchHistory','normalized_measure',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormLaunchHistory','experienced_duration_tracked',"BIGINT NULL");




    CALL ensure_column('ScormLaunchHistory','history_log',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormLaunchHistory','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormLaunchHistory','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormLaunchHistory','update_dt_utc',"DATETIME NULL");




    CALL ensure_column('ScormLaunchHistory','last_runtime_update',"DATETIME NULL");




    CALL ensure_column('ScormLaunchHistory','last_runtime_update_utc',"DATETIME NULL");




    CALL ensure_primary_key('ScormLaunchHistory','`launch_history_id`');




    CALL ensure_index('ScormLaunchHistory','IX_ScormLaunchHistory','`scorm_registration_id`,`launch_time`');




  



CALL ensure_table('ScormMetadata');




    CALL ensure_column('ScormMetadata','scorm_metadata_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormMetadata','scorm_metadata_id');




    CALL ensure_column('ScormMetadata','scorm_package_id',"INT NOT NULL");




    CALL ensure_column('ScormMetadata','scorm_object_id',"INT NULL");




    CALL ensure_column('ScormMetadata','metadata_index',"INT NOT NULL");




    CALL ensure_column('ScormMetadata','metadata_xml',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormMetadata','identifier',"VARCHAR(1000)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormMetadata','title',"VARCHAR(1000)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormMetadata','description',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormMetadata','keywords',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormMetadata','language_code',"VARCHAR(100)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormMetadata','version',"VARCHAR(50)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormMetadata','duration',"VARCHAR(20)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormMetadata','typical_learning_time',"VARCHAR(20)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormMetadata','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormMetadata','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormMetadata','file_href',"VARCHAR(1000)CHARACTER SET utf8 NULL");




    CALL ensure_primary_key('ScormMetadata','`scorm_metadata_id`');




  



CALL ensure_table('ScormObject');




    CALL ensure_column('ScormObject','scorm_object_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormObject','scorm_object_id');




    CALL ensure_column('ScormObject','scorm_package_id',"INT NOT NULL");




    CALL ensure_column('ScormObject','scorm_object_type_id',"INT NOT NULL");




    CALL ensure_column('ScormObject','title',"VARCHAR(200)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormObject','href',"VARCHAR(2000)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormObject','parameters',"VARCHAR(1000)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormObject','data_from_lms',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormObject','mastery_score',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormObject','max_time_allowed',"BIGINT NULL");




    CALL ensure_column('ScormObject','time_limit_action',"INT NULL");




    CALL ensure_column('ScormObject','prerequisites',"VARCHAR(200)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormObject','visible',"INT NOT NULL");




    CALL ensure_column('ScormObject','completion_threshold',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormObject','persist_state',"INT NOT NULL");




    CALL ensure_column('ScormObject','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObject','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObject','file_list',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormObject','completed_by_measure',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObject','completion_progress_weight',"DECIMAL(10,7) NOT NULL DEFAULT 1.0");




    CALL ensure_column('ScormObject','letsi_rtws_secret',"VARCHAR(1000)CHARACTER SET latin1 NULL");




    CALL ensure_primary_key('ScormObject','`scorm_object_id`');




  



CALL ensure_table('ScormObjectHierarchy');




    CALL ensure_column('ScormObjectHierarchy','parent_scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectHierarchy','child_scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectHierarchy','ordinal',"INT NOT NULL");




    CALL ensure_column('ScormObjectHierarchy','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectHierarchy','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectHierarchy','`parent_scorm_object_id`,`child_scorm_object_id`');




  



CALL ensure_table('ScormObjectIdentifiers');




    CALL ensure_column('ScormObjectIdentifiers','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectIdentifiers','item_identifier',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormObjectIdentifiers','resource_identifier',"VARCHAR(2000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormObjectIdentifiers','external_identifier',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormObjectIdentifiers','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectIdentifiers','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectIdentifiers','`scorm_object_id`');




  



CALL ensure_table('ScormObjectSeqData');




    CALL ensure_column('ScormObjectSeqData','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','hide_previous',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','hide_continue',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','hide_exit',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','hide_abandon',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','control_choice',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','control_choice_exit',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','control_flow',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','control_forward_only',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','use_current_attempt_obj_info',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','use_current_attempt_prog_info',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','constrain_choice',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','prevent_activation',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','limit_cond_attempt_control',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','limit_cond_attempt_limit',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','limit_cond_attempt_dur_control',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','limit_cond_attempt_dur_limit',"VARCHAR(50)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormObjectSeqData','rollup_objective_satisfied',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','rollup_obj_measure_weight',"DECIMAL(5,4) NOT NULL");




    CALL ensure_column('ScormObjectSeqData','rollup_progress_completion',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','measure_satisfaction_if_active',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','required_for_satisfied',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','required_for_not_satisfied',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','required_for_completed',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','required_for_incomplete',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','selection_timing',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','selection_count_status',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','selection_count',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','randomization_timing',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','randomize_children',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','tracked',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','completion_set_by_content',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','objective_set_by_content',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqData','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectSeqData','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqData','hide_suspend_all',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqData','hide_abandon_all',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqData','hide_exit_all',"INT NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSeqData','`scorm_object_id`');




  



CALL ensure_table('ScormObjectSeqObjective');




    CALL ensure_column('ScormObjectSeqObjective','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjective','scorm_object_seq_objective_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjective','objective_identifier',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormObjectSeqObjective','satisfied_by_measure',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjective','min_normalized_measure',"DECIMAL(5,4) NOT NULL");




    CALL ensure_column('ScormObjectSeqObjective','primary_objective',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjective','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectSeqObjective','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSeqObjective','`scorm_object_id`,`scorm_object_seq_objective_id`');




  



CALL ensure_table('ScormObjectSeqObjectiveMap');




    CALL ensure_column('ScormObjectSeqObjectiveMap','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','scorm_object_seq_objective_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','scorm_object_seq_obj_map_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','target_objective_id',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','read_satisfied_status',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','read_normalized_measure',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','write_satisfied_status',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','write_normalized_measure',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectSeqObjectiveMap','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','read_score_raw',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','read_score_min',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','read_score_max',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','read_completion_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','read_progress_measure',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','write_score_raw',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','write_score_min',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','write_score_max',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','write_completion_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSeqObjectiveMap','write_progress_measure',"INT NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSeqObjectiveMap','`scorm_object_id`,`scorm_object_seq_objective_id`,`scorm_object_seq_obj_map_id`');




  



CALL ensure_table('ScormObjectSeqRollupRule');




    CALL ensure_column('ScormObjectSeqRollupRule','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','rollup_rule_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','condition_combination',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','child_activity_set',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','minimum_count',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','minimum_percent',"DECIMAL(5,4) NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','action',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRule','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSeqRollupRule','`scorm_object_id`,`rollup_rule_id`');




  



CALL ensure_table('ScormObjectSeqRollupRuleCond');




    CALL ensure_column('ScormObjectSeqRollupRuleCond','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRuleCond','rollup_rule_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRuleCond','rollup_rule_condition_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRuleCond','condition_operator',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRuleCond','rule_condition',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRuleCond','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectSeqRollupRuleCond','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSeqRollupRuleCond','`scorm_object_id`,`rollup_rule_id`,`rollup_rule_condition_id`');




  



CALL ensure_table('ScormObjectSeqRule');




    CALL ensure_column('ScormObjectSeqRule','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRule','seq_rule_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRule','condition_combination',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRule','action',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRule','rule_type',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRule','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectSeqRule','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSeqRule','`scorm_object_id`,`seq_rule_id`');




  



CALL ensure_table('ScormObjectSeqRuleCond');




    CALL ensure_column('ScormObjectSeqRuleCond','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','seq_rule_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','seq_rule_condition_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','rule_condition',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','referenced_objective',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','measure_threshold',"DECIMAL(5,4) NOT NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','condition_operator',"INT NOT NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormObjectSeqRuleCond','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSeqRuleCond','`scorm_object_id`,`seq_rule_id`,`seq_rule_condition_id`');




  



CALL ensure_table('ScormObjectSharedDataMap');




    CALL ensure_column('ScormObjectSharedDataMap','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSharedDataMap','scorm_obj_shared_data_map_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSharedDataMap','target_shared_data_id',"VARCHAR(4000)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormObjectSharedDataMap','read_shared_data',"INT NOT NULL");




    CALL ensure_column('ScormObjectSharedDataMap','write_shared_data',"INT NOT NULL");




    CALL ensure_column('ScormObjectSharedDataMap','update_by',"VARCHAR(50)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormObjectSharedDataMap','update_dt',"DATETIME NOT NULL");




    CALL ensure_primary_key('ScormObjectSharedDataMap','`scorm_object_id`,`scorm_obj_shared_data_map_id`');




  



CALL ensure_table('ScormObjectSSPBucket');




    CALL ensure_column('ScormObjectSSPBucket','scorm_object_id',"INT NOT NULL");




    CALL ensure_column('ScormObjectSSPBucket','bucket_index',"INT NOT NULL");




    CALL ensure_column('ScormObjectSSPBucket','bucket_identifier',"VARCHAR(4000)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormObjectSSPBucket','bucket_type',"VARCHAR(3000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormObjectSSPBucket','persistence',"INT NOT NULL");




    CALL ensure_column('ScormObjectSSPBucket','size_min',"BIGINT NOT NULL");




    CALL ensure_column('ScormObjectSSPBucket','size_requested',"BIGINT NOT NULL");




    CALL ensure_column('ScormObjectSSPBucket','reducible',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormObjectSSPBucket','update_by',"VARCHAR(32)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormObjectSSPBucket','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormObjectSSPBucket','`scorm_object_id`,`bucket_index`');




  



CALL ensure_table('ScormPackage');




    CALL ensure_column('ScormPackage','scorm_package_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormPackage','scorm_package_id');




    CALL ensure_column('ScormPackage','objectives_global_to_system',"INT NOT NULL");




    CALL ensure_column('ScormPackage','learning_standard_id',"INT NOT NULL");




    CALL ensure_column('ScormPackage','web_path',"VARCHAR(500)CHARACTER SET utf8 NULL DEFAULT ''''");




    CALL ensure_column('ScormPackage','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormPackage','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackage','version_id',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackage','shared_data_global_to_system',"INT NOT NULL DEFAULT 1");




    CALL ensure_primary_key('ScormPackage','`scorm_package_id`');




  



CALL ensure_table('ScormPackageProperties');




    CALL ensure_column('ScormPackageProperties','scorm_package_id',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','show_finish_button',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','show_course_structure',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','show_progress_bar',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','show_help',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','show_nav_bar',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','show_titlebar',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','enable_flow_nav',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','enable_choice_nav',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','course_structure_width',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','course_structure_starts_open',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','sco_launch_type',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','player_launch_type',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','prevent_right_click',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','prevent_window_resize',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','required_width',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','required_height',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','required_fullscreen',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','desired_width',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','desired_height',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','desired_fullscreen',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_sat_logout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_sat_normal_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_sat_suspend_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_sat_timeout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_not_sat_logout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_not_sat_normal_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_not_sat_suspend_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','int_not_sat_timeout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_sat_logout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_sat_normal_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_sat_suspend_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_sat_timeout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_not_sat_logout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_not_sat_normal_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_not_sat_suspend_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','final_not_sat_timeout_action',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','status_display',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','score_rollup_mode',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','number_of_scoring_objects',"INT NULL");




    CALL ensure_column('ScormPackageProperties','status_rollup_mode',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','threshold_score_for_completion',"DECIMAL(10,7) NULL");




    CALL ensure_column('ScormPackageProperties','first_sco_is_pretest',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','wrap_sco_window_with_api',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','finish_causes_immediate_commit',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_control_audit',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_control_detailed',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_rte_audit',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_rte_detailed',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_sequencing_audit',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_sequencing_detailed',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_lookahead_audit',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_lookahead_detailed',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','debug_include_timestamps',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','comm_max_failed_submissions',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','comm_commit_frequency',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','invalid_menu_item_action',"INT NOT NULL DEFAULT 2");




    CALL ensure_column('ScormPackageProperties','always_flow_to_first_sco',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','logout_causes_player_exit',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','reset_rt_timing',"INT NOT NULL");




    CALL ensure_column('ScormPackageProperties','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormPackageProperties','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','offline_synch_mode',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormPackageProperties','validate_interaction_responses',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormPackageProperties','lookahead_sequencer_mode',"INT NOT NULL DEFAULT 2");




    CALL ensure_column('ScormPackageProperties','show_close_item',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','score_overrides_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','scale_raw_score',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','rollup_empty_set_to_unknown',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','capture_history',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','capture_history_detailed',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','return_to_lms_action',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormPackageProperties','use_measure_progress_bar',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','use_quick_lookahead_seq',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormPackageProperties','force_disable_root_choice',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','rollup_runtime_at_sco_unload',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','force_obj_compl_set_by_content',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','invoke_rollup_at_suspendall',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','compl_stat_of_failed_suc_stat',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormPackageProperties','satisfied_causes_completion',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','student_prefs_global_to_course',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','debug_sequencing_simple',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','suspend_data_max_length',"INT NOT NULL DEFAULT 64000");




    CALL ensure_column('ScormPackageProperties','allow_complete_status_change',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','time_limit',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','launch_compl_regs_as_no_credit',"INT NOT NULL DEFAULT 1");




    CALL ensure_column('ScormPackageProperties','apply_status_to_success',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormPackageProperties','ie_compatibility_mode',"INT NOT NULL DEFAULT 1");



    
    CALL ensure_column('ScormPackageProperties','is_available_offline',"INT NOT NULL DEFAULT 0");



  
    CALL ensure_primary_key('ScormPackageProperties','`scorm_package_id`');




  



CALL ensure_table('ScormPackagePropertiesPresets');




    CALL ensure_column('ScormPackagePropertiesPresets','preset_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormPackagePropertiesPresets','preset_id');




    CALL ensure_column('ScormPackagePropertiesPresets','title',"VARCHAR(100)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormPackagePropertiesPresets','created_by',"VARCHAR(50)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormPackagePropertiesPresets','property_xml',"LONGTEXT CHARACTER SET latin1 NOT NULL");




    CALL ensure_primary_key('ScormPackagePropertiesPresets','`preset_id`');




  



CALL ensure_table('ScormRegistration');




    CALL ensure_column('ScormRegistration','scorm_registration_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormRegistration','scorm_registration_id');




    CALL ensure_column('ScormRegistration','scorm_package_id',"INT NOT NULL");




    CALL ensure_column('ScormRegistration','global_objective_scope',"VARCHAR(100)CHARACTER SET utf8 NOT NULL DEFAULT ''''");




    CALL ensure_column('ScormRegistration','suspended_activity_id',"INT NULL");




    CALL ensure_column('ScormRegistration','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormRegistration','update_dt',"DATETIME NOT NULL DEFAULT 0");




	CALL ensure_column('ScormRegistration','update_dt_utc',"DATETIME NULL");




    CALL ensure_column('ScormRegistration','instance_id',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormRegistration','converted_to_tincan',"INT NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormRegistration','`scorm_registration_id`');




    CALL ensure_index('ScormRegistration','IX_SR_gos','`global_objective_scope`');




  



CALL ensure_table('ScormRegistrationGlobalObj');




    CALL ensure_column('ScormRegistrationGlobalObj','scorm_registration_id',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','scorm_registration_obj_id',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','objective_identifier',"VARCHAR(4000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','objective_progress_status',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','objective_satisfied_status',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','objective_measure_status',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','objective_normalized_measure',"DECIMAL(5,4) NOT NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_column('ScormRegistrationGlobalObj','completion_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormRegistrationGlobalObj','completion_status_value',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormRegistrationGlobalObj','score_raw',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','score_max',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','score_min',"DECIMAL(38,7) NULL");




    CALL ensure_column('ScormRegistrationGlobalObj','progress_measure_status',"INT NOT NULL DEFAULT 0");




    CALL ensure_column('ScormRegistrationGlobalObj','progress_measure',"DECIMAL(10,7) NULL");




    CALL ensure_primary_key('ScormRegistrationGlobalObj','`scorm_registration_id`,`scorm_registration_obj_id`');




  



CALL ensure_table('ScormRegistrationSharedData');




    CALL ensure_column('ScormRegistrationSharedData','scorm_registration_id',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSharedData','scorm_registration_data_id',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSharedData','shared_data_id',"VARCHAR(4000)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormRegistrationSharedData','scorm_shared_data_value_id',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSharedData','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormRegistrationSharedData','update_dt',"DATETIME NOT NULL");




    CALL ensure_primary_key('ScormRegistrationSharedData','`scorm_registration_id`,`scorm_registration_data_id`');




  



CALL ensure_table('ScormRegistrationSharedDataVal');




    CALL ensure_column('ScormRegistrationSharedDataVal','scorm_shared_data_value_id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('ScormRegistrationSharedDataVal','scorm_shared_data_value_id');




    CALL ensure_column('ScormRegistrationSharedDataVal','data',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormRegistrationSharedDataVal','scorm_registration_id',"INT NULL");




    CALL ensure_column('ScormRegistrationSharedDataVal','global_objective_scope',"VARCHAR(100)CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormRegistrationSharedDataVal','shared_data_id',"VARCHAR(400)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormRegistrationSharedDataVal','update_by',"VARCHAR(50)CHARACTER SET utf8 NOT NULL");




    CALL ensure_column('ScormRegistrationSharedDataVal','update_dt',"DATETIME NOT NULL");




    CALL ensure_primary_key('ScormRegistrationSharedDataVal','`scorm_shared_data_value_id`');




  



CALL ensure_table('ScormRegistrationSSPBucket');




    CALL ensure_column('ScormRegistrationSSPBucket','scorm_registration_id',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','bucket_index',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','bucket_identifier',"VARCHAR(4000)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','bucket_type',"VARCHAR(3000)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','persistence',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','size_min',"BIGINT NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','size_requested',"BIGINT NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','reducible',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','local_activity_id',"VARCHAR(50)CHARACTER SET latin1 NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','allocation_success',"INT NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','data',"LONGTEXT CHARACTER SET utf8 NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','update_by',"VARCHAR(32)CHARACTER SET latin1 NOT NULL");




    CALL ensure_column('ScormRegistrationSSPBucket','update_dt',"DATETIME NOT NULL DEFAULT 0");




    CALL ensure_primary_key('ScormRegistrationSSPBucket','`scorm_registration_id`,`bucket_index`');




  



CALL ensure_table('ScormObjectStore');



CALL ensure_column('ScormObjectStore','object_key',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_column('ScormObjectStore','object_key_sha1',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");



CALL ensure_column('ScormObjectStore','object_value',"BLOB NOT NULL");



CALL ensure_column('ScormObjectStore','object_type',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");



CALL ensure_column('ScormObjectStore','expiry',"DATETIME NULL");



CALL ensure_column('ScormObjectStore','update_dt',"DATETIME NOT NULL DEFAULT 0");



CALL ensure_column('ScormObjectStore','update_by',"VARCHAR(36)CHARACTER SET latin1 NULL");



CALL ensure_primary_key('ScormObjectStore','`object_key_sha1`');




      CALL ensure_index('ScormObjectStore','IX_SOS_e','`expiry`');




  



CALL ensure_table('TinCanActivityProvider');



CALL ensure_column('TinCanActivityProvider','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanActivityProvider','`sdh_item_name`');




      CALL ensure_column('TinCanActivityProvider','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActivityProvider','info',"LONGTEXT CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanActivityProvider','name',"VARCHAR(100)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanActivityProvider','provider_id',"VARCHAR(100)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActivityProvider','public_key',"VARCHAR(1000)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanActivityProvider','secret',"VARCHAR(100)CHARACTER SET utf8 NULL");




  



CALL ensure_table('TinCanActivityProviderMap');



CALL ensure_column('TinCanActivityProviderMap','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanActivityProviderMap','`sdh_item_name`');




      CALL ensure_column('TinCanActivityProviderMap','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActivityProviderMap','provider_id',"VARCHAR(100)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActivityProviderMap','activity_id',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




  



CALL ensure_table('TinCanPermissions');



CALL ensure_column('TinCanPermissions','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanPermissions','`sdh_item_name`');




      CALL ensure_column('TinCanPermissions','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPermissions','owner_id',"VARCHAR(100)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPermissions','statement_read',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPermissions','statement_write',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPermissions','activity_write',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPermissions','actor_write',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPermissions','document_read',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPermissions','document_write',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




  



CALL ensure_table('TinCanStatementIndex');



CALL ensure_column('TinCanStatementIndex','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanStatementIndex','`sdh_item_name`');




      CALL ensure_column('TinCanStatementIndex','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanStatementIndex','statement_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");





      CALL ensure_column('TinCanStatementIndex','version',"VARCHAR(16)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanStatementIndex','version_family',"INT NULL");






      CALL ensure_column('TinCanStatementIndex','actor_id',"VARCHAR(40)CHARACTER SET latin1 NULL");





      
      CALL ensure_column('TinCanStatementIndex','verb',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");





      
      CALL ensure_column('TinCanStatementIndex','target_id',"VARCHAR(40)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanStatementIndex','target_type',"VARCHAR(32)CHARACTER SET latin1 NULL");





      CALL ensure_column('TinCanStatementIndex','asserter_id',"VARCHAR(82)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanStatementIndex','authoritative',"INT NULL");





      CALL ensure_column('TinCanStatementIndex','is_targeting',"INT NULL");




      CALL ensure_column('TinCanStatementIndex','voided',"INT NULL");





      CALL ensure_column('TinCanStatementIndex','stored',"VARCHAR(30)CHARACTER SET latin1 NOT NULL");





      CALL ensure_column('TinCanStatementIndex','ctx_instructor_id',"VARCHAR(40)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanStatementIndex','ctx_registration',"VARCHAR(36)CHARACTER SET latin1 NULL");





      
      CALL ensure_column('TinCanStatementIndex','sort_string',"VARCHAR(256)CHARACTER SET latin1 NOT NULL");






      CALL ensure_index('TinCanStatementIndex','IX_StatementIdx_ss','`sort_string`');




      CALL ensure_index('TinCanStatementIndex','IX_StatementIdx_id','`statement_id`');




      CALL ensure_index('TinCanStatementIndex','IX_StatementIdx_verb','`verb`');




      CALL ensure_index('TinCanStatementIndex','IX_StatementIdx_targetid','`target_id`');




      CALL ensure_index('TinCanStatementIndex','IX_StatementIdx_reg','`ctx_registration`');




  



CALL ensure_table('TinCanTargetStatement');



CALL ensure_column('TinCanTargetStatement','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanTargetStatement','app_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanTargetStatement','target_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanTargetStatement','targeting_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanTargetStatement','is_voiding',"INT NULL");




      CALL ensure_primary_key('TinCanTargetStatement','`target_id`,`targeting_id`');




  



CALL ensure_table('TinCanContextActivity');



CALL ensure_column('TinCanContextActivity','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanContextActivity','statement_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanContextActivity','ctx_activity_id_sha1',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");




      CALL ensure_primary_key('TinCanContextActivity','`statement_item_name`,`ctx_activity_id_sha1`');




  



CALL ensure_table('TinCanRelatedActivity');



CALL ensure_column('TinCanRelatedActivity','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanRelatedActivity','statement_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanRelatedActivity','related_actid_sha1',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");




      CALL ensure_primary_key('TinCanRelatedActivity','`statement_item_name`,`related_actid_sha1`');




  



CALL ensure_table('TinCanAgent');



CALL ensure_column('TinCanAgent','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanAgent','statement_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanAgent','agent_id',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");




      CALL ensure_primary_key('TinCanAgent','`statement_item_name`,`agent_id`');




  



CALL ensure_table('TinCanRelatedAgent');



CALL ensure_column('TinCanRelatedAgent','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanRelatedAgent','statement_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanRelatedAgent','related_agent_id',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");




      CALL ensure_primary_key('TinCanRelatedAgent','`statement_item_name`,`related_agent_id`');




  



CALL ensure_table('TinCanActorProperties');



CALL ensure_column('TinCanActorProperties','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanActorProperties','`sdh_item_name`');




      CALL ensure_column('TinCanActorProperties','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActorProperties','key',"VARCHAR(32)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActorProperties','value',"VARCHAR(1024)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActorProperties','actor_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanActorProperties','app_key_val_hash',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");





      CALL ensure_index('TinCanActorProperties','IX_ActorProp_ai','`actor_id`');




      CALL ensure_index('TinCanActorProperties','IX_ActorProp_aakey','`app_id`,`actor_id`,`key`');




  



CALL ensure_table('TinCanDocuments');



CALL ensure_column('TinCanDocuments','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanDocuments','`sdh_item_name`');




      CALL ensure_column('TinCanDocuments','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDocuments','version',"VARCHAR(16)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDocuments','registration_id',"VARCHAR(36)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDocuments','actor_id',"VARCHAR(40)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDocuments','activity_id',"VARCHAR(1024)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDocuments','document_id',"VARCHAR(255)CHARACTER SET latin1 NOT NULL");





      CALL ensure_column('TinCanDocuments','document_id_hash',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDocuments','document_ctx_hash',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");





      CALL ensure_column('TinCanDocuments','updated',"VARCHAR(30)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDocuments','content_length',"BIGINT NOT NULL");




      CALL ensure_column('TinCanDocuments','content_type',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDocuments','content_hash',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");




      
      CALL ensure_column('TinCanDocuments','asserter_id',"VARCHAR(82)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDocuments','asserter_json',"LONGTEXT CHARACTER SET latin1 NULL");





      CALL ensure_index('TinCanDocuments','IX_Documents_id','`document_id_hash`');




      CALL ensure_index('TinCanDocuments','IX_Documents_ctx','`document_ctx_hash`');




  



CALL ensure_table('TinCanSandboxAppIds');



CALL ensure_column('TinCanSandboxAppIds','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanSandboxAppIds','`sdh_item_name`');




      CALL ensure_column('TinCanSandboxAppIds','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanSandboxAppIds','sandbox_app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanSandboxAppIds','deleted',"INT NOT NULL");




  



CALL ensure_table('TinCanPredicateLog');



CALL ensure_column('TinCanPredicateLog','sdh_item_name',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_primary_key('TinCanPredicateLog','`sdh_item_name`');




      CALL ensure_column('TinCanPredicateLog','predicates',"VARCHAR(512)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPredicateLog','count',"INT NOT NULL");




  



CALL ensure_table('TinCanObjectStore');



CALL ensure_column('TinCanObjectStore','object_key',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");



CALL ensure_column('TinCanObjectStore','object_key_sha1',"VARCHAR(40)CHARACTER SET latin1 NOT NULL");



CALL ensure_column('TinCanObjectStore','object_value',"BLOB NOT NULL");



CALL ensure_column('TinCanObjectStore','object_type',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");



CALL ensure_column('TinCanObjectStore','expiry',"DATETIME NULL");



CALL ensure_column('TinCanObjectStore','update_dt',"DATETIME NOT NULL DEFAULT 0");



CALL ensure_column('TinCanObjectStore','update_by',"VARCHAR(36)CHARACTER SET latin1 NULL");



CALL ensure_primary_key('TinCanObjectStore','`object_key_sha1`');




      CALL ensure_index('TinCanObjectStore','IX_TCOS_e','`expiry`');




  



CALL ensure_table('TinCanPackage');




      CALL ensure_column('TinCanPackage','scorm_package_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPackage','tincan_activity_id',"VARCHAR(1024)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanPackage','update_by',"VARCHAR(32)CHARACTER SET latin1 NOT NULL");




      CALL ensure_primary_key('TinCanPackage','`scorm_package_id`');




  



CALL ensure_table('TinCanRegistration');




      CALL ensure_column('TinCanRegistration','scorm_registration_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanRegistration','tincan_registration_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanRegistration','completion',"VARCHAR(20)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanRegistration','success',"VARCHAR(20)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanRegistration','score_is_known',"INT NOT NULL DEFAULT 0");




      CALL ensure_column('TinCanRegistration','score',"DECIMAL(10,7) NOT NULL DEFAULT 0");




      CALL ensure_column('TinCanRegistration','total_seconds_tracked',"BIGINT NOT NULL DEFAULT 0");




      CALL ensure_column('TinCanRegistration','comp_of_failed_success',"VARCHAR(20)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanRegistration','update_by',"VARCHAR(32)CHARACTER SET latin1 NOT NULL");




      CALL ensure_primary_key('TinCanRegistration','`scorm_registration_id`');




  



CALL ensure_table('TinCanDataCabinetResults');




      CALL ensure_column('TinCanDataCabinetResults','statement_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDataCabinetResults','actor_id',"VARCHAR(50)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDataCabinetResults','actor_obj',"BLOB NOT NULL");




      CALL ensure_column('TinCanDataCabinetResults','activity_id',"VARCHAR(255)CHARACTER SET utf8 NOT NULL");




      CALL ensure_column('TinCanDataCabinetResults','completion',"VARCHAR(20)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDataCabinetResults','success',"VARCHAR(20)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDataCabinetResults','score',"DECIMAL(10,7) NULL DEFAULT 0");




      CALL ensure_column('TinCanDataCabinetResults','duration',"VARCHAR(20)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanDataCabinetResults','date',"DATETIME NULL");




      CALL ensure_column('TinCanDataCabinetResults','app_id',"VARCHAR(64)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDataCabinetResults','update_by',"VARCHAR(32)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanDataCabinetResults','sort_string',"VARCHAR(295)CHARACTER SET latin1 NOT NULL");




      CALL ensure_index('TinCanDataCabinetResults','IX_Result_ss','`sort_string`');




      CALL ensure_primary_key('TinCanDataCabinetResults','`actor_id`,`activity_id`');




  



CALL ensure_table('TinCanLaunchToken');




      CALL ensure_column('TinCanLaunchToken','token_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanLaunchToken','external_registration_id',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanLaunchToken','external_configuration',"VARCHAR(2000)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanLaunchToken','expiry',"DATETIME NULL");




      CALL ensure_primary_key('TinCanLaunchToken','`token_id`');




  



CALL ensure_table('TinCanContentToken');




      CALL ensure_column('TinCanContentToken','token_id',"VARCHAR(36)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanContentToken','external_id',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanContentToken','external_configuration',"VARCHAR(2000)CHARACTER SET latin1 NULL");




      CALL ensure_column('TinCanContentToken','expiry',"DATETIME NULL");




      CALL ensure_column('TinCanContentToken','expiry',"DATETIME NULL");




      CALL ensure_column('TinCanContentToken','preview_token',"INT NOT NULL DEFAULT 0");




      CALL ensure_primary_key('TinCanContentToken','`token_id`');




  



CALL ensure_table('TinCanForwardingMap');




      CALL ensure_column('TinCanForwardingMap','id',"INT AUTO_INCREMENT PRIMARY KEY NOT NULL");



CALL ensure_primary_key('TinCanForwardingMap','id');




      CALL ensure_column('TinCanForwardingMap','sourceUrl',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanForwardingMap','sourceUsername',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanForwardingMap','sourcePW',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanForwardingMap','targetUrl',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanForwardingMap','targetUsername',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanForwardingMap','targetPW',"VARCHAR(2000)CHARACTER SET latin1 NOT NULL");




      CALL ensure_column('TinCanForwardingMap','moreLink',"VARCHAR(2000)CHARACTER SET latin1 NULL");




      CALL ensure_primary_key('TinCanForwardingMap','`id`');




  



CALL ensure_table('ScormRegistration');




      CALL ensure_column('ScormRegistration','converted_to_tincan',"INT NOT NULL DEFAULT 0");




  



CALL ensure_foreign_key('PensCommandScormPackage','FK_PensCommandScormPackage_1','`pens_command_id`','PensCommand','`pens_command_id`');



CALL ensure_foreign_key('PensCommandScormPackage','FK_PensCommandScormPackage_2','`scorm_package_id`','ScormPackage','`scorm_package_id`');



CALL ensure_foreign_key('ScormActivity','FK_ScormActivity_ScormObject','`scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormActivity','FK_ScormActivity_ScormRegis_1','`scorm_registration_id`','ScormRegistration','`scorm_registration_id`');



CALL ensure_foreign_key('ScormActivityObjective','FK_ScormActivityObjective_S_1','`scorm_activity_id`','ScormActivity','`scorm_activity_id`');



CALL ensure_foreign_key('ScormActivityRT','FK_ScormActivityRT_ScormAct_1','`scorm_activity_id`','ScormActivity','`scorm_activity_id`');



CALL ensure_foreign_key('ScormActivityRTComment','FK_ScormActivityRTComment_S_1','`scorm_activity_id`','ScormActivityRT','`scorm_activity_id`');



CALL ensure_foreign_key('ScormActivityRTIntCorrectResp','FK_ScormActivityRTIntCorrec_1','`scorm_activity_id`,`interaction_index`','ScormActivityRTInteraction','`scorm_activity_id`,`interaction_index`');



CALL ensure_foreign_key('ScormActivityRTInteraction','FK_ScormActivityRTInteracti_1','`scorm_activity_id`','ScormActivityRT','`scorm_activity_id`');



CALL ensure_foreign_key('ScormActivityRTIntLearnerResp','FK_ScormActivityRTIntLearne_1','`scorm_activity_id`,`interaction_index`','ScormActivityRTInteraction','`scorm_activity_id`,`interaction_index`');



CALL ensure_foreign_key('ScormActivityRTIntObjective','FK_ScormActivityRTIntObject_1','`scorm_activity_id`,`interaction_index`','ScormActivityRTInteraction','`scorm_activity_id`,`interaction_index`');



CALL ensure_foreign_key('ScormActivityRTObjective','FK_ScormActivityRTObjective_1','`scorm_activity_id`','ScormActivityRT','`scorm_activity_id`');



CALL ensure_foreign_key('ScormAiccSession','FK_ScormAiccSession_ScormRe_1','`scorm_registration_id`','ScormRegistration','`scorm_registration_id`');



CALL ensure_foreign_key('ScormLaunchHistory','FK_ScormLaunchHistory_Scorm_1','`scorm_registration_id`','ScormRegistration','`scorm_registration_id`');



CALL ensure_foreign_key('ScormMetadata','FK_ScormMetadata_ScormObject','`scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormMetadata','FK_ScormMetadata_ScormPackage','`scorm_package_id`','ScormPackage','`scorm_package_id`');



CALL ensure_foreign_key('ScormObject','FK_ScormObject_ScormPackage','`scorm_package_id`','ScormPackage','`scorm_package_id`');



CALL ensure_foreign_key('ScormObjectHierarchy','FK_ScormObjectHierarchyChil_1','`child_scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectHierarchy','FK_ScormObjectHierarchyPare_1','`parent_scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectIdentifiers','FK_ScormObjectIdentifiers_S_1','`scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectSeqData','FK_ScormObjectSeqData_Scorm_1','`scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectSeqObjective','FK_ScormObjectSeqObjective_1','`scorm_object_id`','ScormObjectSeqData','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectSeqObjectiveMap','FK_ScormObjectSeqObjectiveM_1','`scorm_object_id`,`scorm_object_seq_objective_id`','ScormObjectSeqObjective','`scorm_object_id`,`scorm_object_seq_objective_id`');



CALL ensure_foreign_key('ScormObjectSeqRollupRule','FK_ScormObjectSeqRollupRule_1','`scorm_object_id`','ScormObjectSeqData','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectSeqRollupRuleCond','FK_ScormObjectSeqRollupRule_2','`scorm_object_id`,`rollup_rule_id`','ScormObjectSeqRollupRule','`scorm_object_id`,`rollup_rule_id`');



CALL ensure_foreign_key('ScormObjectSeqRule','FK_ScormObjectSeqRule_Scorm_1','`scorm_object_id`','ScormObjectSeqData','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectSeqRuleCond','FK_ScormObjectSeqRuleCond_S_1','`scorm_object_id`,`seq_rule_id`','ScormObjectSeqRule','`scorm_object_id`,`seq_rule_id`');



CALL ensure_foreign_key('ScormObjectSharedDataMap','FK_ScormObjectSharedDataMap_1','`scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormObjectSSPBucket','FK_ScormObjectSSPBucket_Sco_1','`scorm_object_id`','ScormObject','`scorm_object_id`');



CALL ensure_foreign_key('ScormPackageProperties','FK_ScormPackageProperties_S_1','`scorm_package_id`','ScormPackage','`scorm_package_id`');



CALL ensure_foreign_key('ScormRegistration','FK_ScormRegistration_ScormA_1','`suspended_activity_id`','ScormActivity','`scorm_activity_id`');



CALL ensure_foreign_key('ScormRegistration','FK_ScormRegistration_ScormP_1','`scorm_package_id`','ScormPackage','`scorm_package_id`');



CALL ensure_foreign_key('ScormRegistrationGlobalObj','FK_ScormRegistrationGlobalO_1','`scorm_registration_id`','ScormRegistration','`scorm_registration_id`');



CALL ensure_foreign_key('ScormRegistrationSharedData','FK_ScormRegistrationSharedD_1','`scorm_registration_id`','ScormRegistration','`scorm_registration_id`');



CALL ensure_foreign_key('ScormRegistrationSharedData','FK_ScormRegistrationSharedD_2','`scorm_shared_data_value_id`','ScormRegistrationSharedDataVal','`scorm_shared_data_value_id`');



CALL ensure_foreign_key('ScormRegistrationSSPBucket','FK_ScormRegistrationSSPBuck_1','`scorm_registration_id`','ScormRegistration','`scorm_registration_id`');



CALL ensure_foreign_key('TinCanContextActivity','FK_TinCanContextActivity_1','`statement_item_name`','TinCanStatementIndex','`sdh_item_name`');



CALL ensure_foreign_key('TinCanRelatedActivity','FK_TinCanRelatedActivity_1','`statement_item_name`','TinCanStatementIndex','`sdh_item_name`');



CALL ensure_foreign_key('TinCanAgent','FK_TinCanAgent_1','`statement_item_name`','TinCanStatementIndex','`sdh_item_name`');



CALL ensure_foreign_key('TinCanRelatedAgent','FK_TinCanRelatedAgent_1','`statement_item_name`','TinCanStatementIndex','`sdh_item_name`');



CALL ensure_db_update_id('2013.2');




		DROP PROCEDURE IF EXISTS `ensure_table`;
		DROP PROCEDURE IF EXISTS `ensure_column`;
		DROP PROCEDURE IF EXISTS `ensure_index`;
		DROP PROCEDURE IF EXISTS `ensure_primary_key`;
		DROP PROCEDURE IF EXISTS `ensure_foreign_key`;  
		DROP PROCEDURE IF EXISTS `ensure_db_update_id`;      
        



