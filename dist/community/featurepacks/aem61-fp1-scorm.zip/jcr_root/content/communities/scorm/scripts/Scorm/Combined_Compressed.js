var SCORM_TRUE="true";
var SCORM_FALSE="false";
var SCORM_ERROR_NONE=0;
var SCORM_ERROR_GENERAL=101;
var SCORM_ERROR_INVALID_ARG=201;
var SCORM_ERROR_NO_CHILDREN=202;
var SCORM_ERROR_NO_COUNT=203;
var SCORM_ERROR_NOT_INITIALIZED=301;
var SCORM_ERROR_NOT_IMPLEMENTED=401;
var SCORM_ERROR_ELEMENT_IS_KEYWORD=402;
var SCORM_ERROR_READ_ONLY=403;
var SCORM_ERROR_WRITE_ONLY=404;
var SCORM_ERROR_INCORRECT_DATA_TYPE=405;
var SCORM_ErrorStrings=new Array(11);
SCORM_ErrorStrings[SCORM_ERROR_NONE]="No Error";
SCORM_ErrorStrings[SCORM_ERROR_GENERAL]="General exception";
SCORM_ErrorStrings[SCORM_ERROR_INVALID_ARG]="Invalid argument error";
SCORM_ErrorStrings[SCORM_ERROR_NO_CHILDREN]="Element cannot have children";
SCORM_ErrorStrings[SCORM_ERROR_NO_COUNT]="Element not an array - cannot have count";
SCORM_ErrorStrings[SCORM_ERROR_NOT_INITIALIZED]="Not Initialized";
SCORM_ErrorStrings[SCORM_ERROR_NOT_IMPLEMENTED]="Not implemented error";
SCORM_ErrorStrings[SCORM_ERROR_ELEMENT_IS_KEYWORD]="Invalid set value, element is a keyword";
SCORM_ErrorStrings[SCORM_ERROR_READ_ONLY]="Element is read only";
SCORM_ErrorStrings[SCORM_ERROR_WRITE_ONLY]="Element is write only";
SCORM_ErrorStrings[SCORM_ERROR_INCORRECT_DATA_TYPE]="Incorrect Data Type";
function DataModelSupport(_1,_2,_3){
this.Supported=_1;
this.SupportsRead=_2;
this.SupportsWrite=_3;
}
var arySupportedElements=new Array(50);
arySupportedElements["cmi._version"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core._children"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.student_id"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.student_name"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.lesson_location"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.core.credit"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.lesson_status"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.core.entry"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.score._children"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.score.raw"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.core.total_time"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.lesson_mode"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.core.exit"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.core.session_time"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.suspend_data"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.launch_data"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.objectives._children"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.objectives._count"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.objectives.n.id"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.objectives.n.score._children"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.objectives.n.score.raw"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.objectives.n.score.max"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.objectives.n.score.min"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.objectives.n.status"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.core.score.max"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.core.score.min"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.comments"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.comments_from_lms"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.student_data._children"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.student_data.mastery_score"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.student_data.max_time_allowed"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.student_data.time_limit_action"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.student_preference._children"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.student_preference.audio"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.student_preference.language"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.student_preference.speed"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.student_preference.text"]=new DataModelSupport(true,true,true);
arySupportedElements["cmi.interactions._children"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.interactions._count"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.interactions.n.id"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.objectives._count"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.interactions.n.objectives.n.id"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.time"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.type"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.correct_responses._count"]=new DataModelSupport(true,true,false);
arySupportedElements["cmi.interactions.n.correct_responses.n.pattern"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.weighting"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.student_response"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.result"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.latency"]=new DataModelSupport(true,false,true);
arySupportedElements["cmi.interactions.n.text"]=new DataModelSupport(true,false,true);
var aryVocabularies=new Array(4);
aryVocabularies["exit"]=new Array(SCORM_EXIT_TIME_OUT,SCORM_EXIT_SUSPEND,SCORM_EXIT_LOGOUT,SCORM_EXIT_UNKNOWN);
aryVocabularies["status"]=new Array(SCORM_STATUS_PASSED,SCORM_STATUS_COMPLETED,SCORM_STATUS_FAILED,SCORM_STATUS_INCOMPLETE,SCORM_STATUS_BROWSED,SCORM_STATUS_NOT_ATTEMPTED);
aryVocabularies["interaction"]=new Array(SCORM_TRUE_FALSE,SCORM_CHOICE,SCORM_FILL_IN,SCORM_MATCHING,SCORM_PERFORMANCE,SCORM_SEQUENCING,SCORM_LIKERT,SCORM_NUMERIC);
aryVocabularies["result"]=new Array(SCORM_CORRECT,SCORM_WRONG,SCORM_UNANTICIPATED,SCORM_NEUTRAL);
var SCORM_CORE_CHILDREN="student_id,student_name,lesson_location,credit,lesson_status,entry,total_time,lesson_mode,exit,session_time,score";
var SCORM_CORE_SCORE_CHILDREN="raw,min,max";
var SCORM_STUDENT_DATA_CHILDREN="mastery_score,max_time_allowed,time_limit_action";
var SCORM_STUDENT_PREFERENCE_CHILDREN="audio,language,speed,text";
var SCORM_OBJECTIVES_CHILDREN="id,score,status";
var SCORM_OBJECTIVES_SCORE_CHILDREN="raw,min,max";
var SCORM_INTERACTIONS_CHILDREN="id,objectives,time,type,correct_responses,weighting,student_response,result,latency";
var SCORM_CMI_VERSION="3.4";
function RunTimeApi(_4,_5){
this.LearnerId=_4;
this.LearnerName=_5;
this.ErrorNumber=SCORM_ERROR_NONE;
this.ErrorString="";
this.ErrorDiagnostic="";
this.TrackedStartDate=null;
this.TrackedEndDate=null;
this.Initialized=false;
this.ScoCalledFinish=false;
this.CloseOutSessionCalled=false;
this.RunTimeData=null;
this.LearningObject=null;
this.Activity=null;
this.StatusSetInCurrentSession=false;
this.LearnerPrefsArray=new Object();
this.IsLookAheadSequencerDataDirty=false;
this.IsLookAheadSequencerRunning=false;
}
RunTimeApi.prototype.GetNavigationRequest=RunTimeApi_GetNavigationRequest;
RunTimeApi.prototype.ResetState=RunTimeApi_ResetState;
RunTimeApi.prototype.InitializeForDelivery=RunTimeApi_InitializeForDelivery;
RunTimeApi.prototype.SetDirtyData=RunTimeApi_SetDirtyData;
RunTimeApi.prototype.WriteHistoryLog=RunTimeApi_WriteHistoryLog;
RunTimeApi.prototype.WriteHistoryReturnValue=RunTimeApi_WriteHistoryReturnValue;
RunTimeApi.prototype.WriteAuditLog=RunTimeApi_WriteAuditLog;
RunTimeApi.prototype.WriteAuditReturnValue=RunTimeApi_WriteAuditReturnValue;
RunTimeApi.prototype.WriteDetailedLog=RunTimeApi_WriteDetailedLog;
RunTimeApi.prototype.CloseOutSession=RunTimeApi_CloseOutSession;
RunTimeApi.prototype.NeedToCloseOutSession=RunTimeApi_NeedToCloseOutSession;
RunTimeApi.prototype.AccumulateTotalTimeTracked=RunTimeApi_AccumulateTotalTimeTracked;
RunTimeApi.prototype.InitTrackedTimeStart=RunTimeApi_InitTrackedTimeStart;
RunTimeApi.prototype.LookAheadSessionClose=RunTimeApi_LookAheadSessionClose;
RunTimeApi.prototype.SetLookAheadDirtyDataFlagIfNeeded=RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded;
RunTimeApi.prototype.RunLookAheadSequencerIfNeeded=RunTimeApi_RunLookAheadSequencerIfNeeded;
RunTimeApi.prototype.ImmediateRollup=RunTimeApi_ImmediateRollup;
RunTimeApi.prototype.GetCombinedCompletionSuccessStatus=RunTimeApi_GetCombinedCompletionSuccessStatus;
function RunTimeApi_GetNavigationRequest(){
return null;
}
function RunTimeApi_ResetState(){
this.ErrorNumber=SCORM_ERROR_NONE;
this.ErrorString="";
this.ErrorDiagnostic="";
this.TrackedStartDate=null;
this.TrackedEndDate=null;
this.Initialized=false;
this.Terminated=false;
this.RunTimeData=null;
this.LearningObject=null;
this.Activity=null;
this.StatusSetInCurrentSession=false;
this.ScoCalledFinish=false;
}
function RunTimeApi_InitializeForDelivery(_6){
this.ErrorNumber=SCORM_ERROR_NONE;
this.ErrorString="";
this.ErrorDiagnostic="";
this.TrackedStartDate=null;
this.TrackedEndDate=null;
this.Initialized=false;
this.StatusSetInCurrentSession=false;
this.ScoCalledFinish=false;
this.RunTimeData=_6.RunTime;
this.LearningObject=_6.LearningObject;
this.Activity=_6;
this.InitialTotalTimeTracked=this.RunTimeData.TotalTimeTracked;
this.InitialSessionTimeTracked=this.RunTimeData.SessionTimeTracked;
this.InitialActivityExperiencedDurationTracked=this.Activity.GetActivityExperiencedDurationTracked();
this.InitialActivityExperiencedDurationReported=this.Activity.GetActivityExperiencedDurationReported();
this.InitialAttemptExperiencedDurationTracked=this.Activity.GetAttemptExperiencedDurationTracked();
this.InitialAttemptExperiencedDurationReported=this.Activity.GetAttemptExperiencedDurationReported();
var _7=this.RunTimeData.Exit!=SCORM_EXIT_SUSPEND&&this.RunTimeData.Exit!=SCORM_EXIT_LOGOUT;
if(_7){
this.Activity.SetAttemptStartTimestampUtc(ConvertDateToIso8601String(new Date()));
this.Activity.SetAttemptAbsoluteDuration("PT0H0M0S");
this.Activity.SetAttemptExperiencedDurationTracked("PT0H0M0S");
this.Activity.SetAttemptExperiencedDurationReported("PT0H0M0S");
if(Control.Package.Properties.ResetRunTimeDataTiming==RESET_RT_DATA_TIMING_WHEN_EXIT_IS_NOT_SUSPEND||Control.Package.Properties.ResetRunTimeDataTiming==RESET_RT_DATA_TIMING_ON_EACH_NEW_SEQUENCING_ATTEMPT){
var _8={ev:"ResetRuntime",ai:this.Activity.ItemIdentifier,at:this.Activity.LearningObject.Title};
this.WriteHistoryLog("",_8);
this.RunTimeData.ResetState();
}
}
}
function RunTimeApi_SetDirtyData(){
this.Activity.DataState=DATA_STATE_DIRTY;
}
function RunTimeApi_WriteAuditLog(_9){
Debug.WriteRteAudit(_9);
}
function RunTimeApi_WriteAuditReturnValue(_a){
Debug.WriteRteAuditReturnValue(_a);
}
function RunTimeApi_WriteDetailedLog(_b){
Debug.WriteRteDetailed(_b);
}
function RunTimeApi_WriteHistoryLog(_c,_d){
HistoryLog.WriteEventDetailed(_c,_d);
}
function RunTimeApi_WriteHistoryReturnValue(_e,_f){
HistoryLog.WriteEventDetailedReturnValue(_e,_f);
}
function RunTimeApi_NeedToCloseOutSession(){
return !this.CloseOutSessionCalled;
}
RunTimeApi.prototype.LMSInitialize=RunTimeApi_Initialize;
RunTimeApi.prototype.LMSFinish=RunTimeApi_Finish;
RunTimeApi.prototype.LMSSetValue=RunTimeApi_SetValue;
RunTimeApi.prototype.LMSGetValue=RunTimeApi_GetValue;
RunTimeApi.prototype.LMSCommit=RunTimeApi_Commit;
RunTimeApi.prototype.LMSGetLastError=RunTimeApi_GetLastError;
RunTimeApi.prototype.LMSGetErrorString=RunTimeApi_GetErrorString;
RunTimeApi.prototype.LMSGetDiagnostic=RunTimeApi_GetDiagnostic;
function RunTimeApi_Initialize(arg){
this.WriteAuditLog("`1695`"+arg+"')");
var _11={ev:"ApiInitialize"};
if(this.Activity){
_11.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_11);
_11={};
if(this.Activity){
_11.activityIdentifier=this.Activity.ItemIdentifier;
}
var _12;
var _13;
arg=CleanExternalString(arg);
this.ClearErrorState();
_12=this.CheckForInitializeError(arg);
if(!_12){
_13=SCORM_FALSE;
}else{
if(this.TrackedStartDate==null){
this.TrackedStartDate=new Date();
}
if(this.StartSessionTotalTime==null&&this.Activity){
this.StartSessionTotalTime=this.Activity.RunTime.TotalTime;
}
this.Initialized=true;
_13=SCORM_TRUE;
}
Control.ScoLoader.ScoLoaded=true;
this.WriteAuditReturnValue(_13);
return _13;
}
function RunTimeApi_Finish(arg){
this.WriteAuditLog("`1726`"+arg+"')");
var _15;
arg=CleanExternalString(arg);
this.ClearErrorState();
_15=this.CheckForFinishError(arg);
var _16=(_15&&(this.ScoCalledFinish===false));
if(_15===false){
returnValue=SCORM_FALSE;
}else{
var _17={ev:"ApiTerminate"};
if(this.Activity){
_17.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_17);
this.LookAheadSessionClose();
this.CloseOutSession("Api.Finish()");
this.SetDirtyData();
this.Initialized=false;
this.ScoCalledFinish=true;
returnValue=SCORM_TRUE;
}
if(_16===true&&Control.IsThereAPendingNavigationRequest()===false){
var _18=Control.Sequencer.GetExitAction(this.Activity,true,Control.Sequencer.LogSeqAudit("`1424`"));
if(_18!=EXIT_ACTION_DO_NOTHING&&!this.DeliverFramesetUnloadEventCalled){
window.setTimeout("Control.ScoHasTerminatedSoUnload();",150);
}
}
Control.SignalTerminated();
this.WriteAuditReturnValue(returnValue);
return returnValue;
}
function RunTimeApi_SetValue(_19,_1a){
this.WriteAuditLog("`1715`"+_19+"`1745`"+_1a+"')");
var _1b;
var _1c;
this.ClearErrorState();
_19=CleanExternalString(_19);
_1a=CleanExternalString(_1a);
var _1d=RemoveIndiciesFromCmiElement(_19);
var _1e=ExtractIndex(_19);
var _1f=ExtractSecondaryIndex(_19);
_1b=this.CheckForSetValueError(_19,_1a,_1d,_1e,_1f);
if(!_1b){
_1c=SCORM_FALSE;
}else{
this.StoreValue(_19,_1a,_1d,_1e,_1f);
this.SetDirtyData();
_1c=SCORM_TRUE;
}
this.WriteAuditReturnValue(_1c);
return _1c;
}
function RunTimeApi_GetValue(_20){
this.WriteAuditLog("`1714`"+_20+"')");
var _21;
var _22;
this.ClearErrorState();
_20=CleanExternalString(_20);
var _23=RemoveIndiciesFromCmiElement(_20);
var _24=ExtractIndex(_20);
var _25=ExtractSecondaryIndex(_20);
_22=this.CheckForGetValueError(_20,_23,_24,_25);
if(!_22){
_21="";
}else{
_21=this.RetrieveGetValueData(_20,_23,_24,_25);
if(_21===null){
_21="";
}
}
this.WriteAuditReturnValue(_21);
return _21;
}
function RunTimeApi_Commit(arg){
this.WriteAuditLog("`1725`"+arg+"')");
var _27;
arg=CleanExternalString(arg);
this.ClearErrorState();
_27=this.CheckForCommitError(arg);
if(_27===false){
returnValue=SCORM_FALSE;
}else{
returnValue=SCORM_TRUE;
}
this.RunLookAheadSequencerIfNeeded(true);
this.WriteAuditReturnValue(returnValue);
return returnValue;
}
function RunTimeApi_GetLastError(){
this.WriteAuditLog("`1658`");
var _28=this.ErrorNumber;
this.WriteAuditReturnValue(_28);
return _28;
}
function RunTimeApi_GetErrorString(_29){
this.WriteAuditLog("`1605`"+_29+"')");
var _2a;
_29=CleanExternalString(_29);
if(SCORM_ErrorStrings[_29]===undefined||SCORM_ErrorStrings[_29]===null){
_2a="";
}else{
_2a=SCORM_ErrorStrings[_29];
}
this.WriteAuditReturnValue(_2a);
return _2a;
}
function RunTimeApi_GetDiagnostic(_2b){
this.WriteAuditLog("`1635`"+_2b+"')");
var _2c;
_2b=CleanExternalString(_2b);
if(_2b==this.ErrorNumber||_2b===""||_2b===null){
if(this.ErrorDiagnostic.length>0){
_2c=this.ErrorDiagnostic;
}else{
_2c="No diagnostic information is available.";
}
}else{
_2c="No diagnostic information available for error number ("+_2b+") ";
}
this.WriteAuditReturnValue(_2c);
return _2c;
}
RunTimeApi.prototype.SetErrorState=RunTimeApi_SetErrorState;
RunTimeApi.prototype.ClearErrorState=RunTimeApi_ClearErrorState;
RunTimeApi.prototype.CheckForInitializeError=RunTimeApi_CheckForInitializeError;
RunTimeApi.prototype.CheckForFinishError=RunTimeApi_CheckForFinishError;
RunTimeApi.prototype.CheckForCommitError=RunTimeApi_CheckForCommitError;
RunTimeApi.prototype.CheckForSetValueError=RunTimeApi_CheckForSetValueError;
RunTimeApi.prototype.StoreValue=RunTimeApi_StoreValue;
RunTimeApi.prototype.CheckForGetValueError=RunTimeApi_CheckForGetValueError;
RunTimeApi.prototype.RetrieveGetValueData=RunTimeApi_RetrieveGetValueData;
RunTimeApi.prototype.GetCombinedCompletionSuccessStatus=RunTimeApi_GetCombinedCompletionSuccessStatus;
RunTimeApi.prototype.JoinCommentsArray=RunTimeApi_JoinCommentsArray;
RunTimeApi.prototype.IsValidVocabElement=RunTimeApi_IsValidVocabElement;
RunTimeApi.prototype.ImmediateRollup=RunTimeApi_ImmediateRollup;
function RunTimeApi_SetErrorState(_2d,_2e){
if(_2d!=SCORM_ERROR_NONE){
this.WriteDetailedLog("`1285`"+_2d+" - "+_2e);
}
this.ErrorNumber=_2d;
this.ErrorDiagnostic=_2e;
}
function RunTimeApi_ClearErrorState(){
this.ErrorNumber=SCORM_ERROR_NONE;
this.ErrorDiagnostic="";
}
function RunTimeApi_CheckForInitializeError(arg){
this.WriteDetailedLog("`1411`");
if(arg!==""){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"Invalid argument to LMSInitialize (arg="+arg+")");
return false;
}
if(this.Initialized===true){
this.SetErrorState(SCORM_ERROR_GENERAL,"LMSInitialize has already been called.");
return false;
}
this.WriteDetailedLog("`1601`");
return true;
}
function RunTimeApi_CheckForFinishError(arg){
this.WriteDetailedLog("`1495`");
if(this.Initialized===false){
this.SetErrorState(SCORM_ERROR_NOT_INITIALIZED,"Finished called when not initialized.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"Invalid argument to LMSFinish (arg="+arg+")");
return false;
}
this.WriteDetailedLog("`1601`");
return true;
}
function RunTimeApi_CheckForCommitError(arg){
this.WriteDetailedLog("`1494`");
if(this.Initialized===false){
this.SetErrorState(SCORM_ERROR_NOT_INITIALIZED,"Commit called when not initialized.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"Invalid argument to LMSCommit (arg="+arg+")");
return false;
}
this.WriteDetailedLog("`1601`");
return true;
}
function RunTimeApi_CheckForSetValueError(_32,_33,_34,_35,_36){
this.WriteDetailedLog("`1535`"+_32+", "+_33+", "+_34+", "+_35+", "+_36+") ");
if(this.Initialized===false){
this.SetErrorState(SCORM_ERROR_NOT_INITIALIZED,"SetValue called when not initialized. strElement-"+_32+" strValue-"+_33);
return false;
}
if(!(arySupportedElements[_34]===undefined||arySupportedElements[_34]===null)){
if(arySupportedElements[_34].Supported===false){
Debug.AssertError("Should not have any un-implemented vocab elements");
this.SetErrorState(SCORM_ERROR_NOT_IMPLEMENTED,"The parameter '"+_32+"' is not implemented.");
return false;
}
if(_34.search(/_children$/)>0||_34.search(/_count$/)>0){
this.SetErrorState(SCORM_ERROR_ELEMENT_IS_KEYWORD,"The parameter '"+_32+"' is a keyword and cannot be written to.");
return false;
}
if(arySupportedElements[_34].SupportsWrite===false){
this.SetErrorState(SCORM_ERROR_READ_ONLY,"The parameter '"+_32+"' is read-only.");
return false;
}
}else{
if(_34.search(/._children$/)>0){
_34=_34.replace("._children","");
if(arySupportedElements[_34]!==undefined&&arySupportedElements[_34]!==null){
this.SetErrorState(SCORM_ERROR_NO_CHILDREN,"The parameter '"+_34+"' does not support the _children keyword.");
return false;
}
}else{
if(_34.search(/._count$/)>0){
_34=_34.replace("._count","");
if(arySupportedElements[strBaseElement]!==undefined&&arySupportedElements[strBaseElement]!==null){
this.SetErrorState(SCORM_ERROR_NO_COUNT,"The parameter '"+_34+"' does not support the _count keyword.");
return false;
}
}
}
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The parameter '"+_32+"' is not recognized.");
return false;
}
var _37=null;
var _38;
switch(_34){
case "cmi.core.lesson_location":
this.WriteDetailedLog("`1464`");
if(_33.length>255){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.lesson_location may not be greater than 255 characters, your value ("+_33+") is "+_33.length+" characters.");
_37=false;
}
break;
case "cmi.core.lesson_status":
this.WriteDetailedLog("`1501`");
if(!this.IsValidVocabElement(_33,"status")){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value for cmi.core.lesson_status is not in the CMI vocabulary. Your value: "+_33);
_37=false;
}
if(_33==SCORM_STATUS_NOT_ATTEMPTED){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.lesson_status cannot be set to 'not attempted'.  This value may only be set by the LMS upon initialization.");
_37=false;
}
break;
case "cmi.core.exit":
this.WriteDetailedLog("`1681`");
if(!this.IsValidVocabElement(_33,"exit")){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value for cmi.core.exit is not in the CMI vocabulary. Your value: "+_33);
_37=false;
}
break;
case "cmi.core.session_time":
this.WriteDetailedLog("`1519`");
if(!IsValidCMITimeSpan(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value for cmi.core.session_time is not formatted properly. Your value: "+_33);
_37=false;
}
break;
case "cmi.core.score.raw":
this.WriteDetailedLog("`1572`");
if(_33!==""){
if(IsValidCMIDecimal(_33)){
_38=parseFloat(_33);
if(_38<0||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.score.raw must be a valid decimal between 0 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.score.raw must be a valid decimal.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.core.score.max":
this.WriteDetailedLog("`1570`");
if(_33!==""){
if(IsValidCMIDecimal(_33)){
_38=parseFloat(_33);
if(_38<0||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.score.max must be a valid decimal between 0 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.score.max must be a valid decimal.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.core.score.min":
this.WriteDetailedLog("`1571`");
if(_33!==""){
if(IsValidCMIDecimal(_33)){
_38=parseFloat(_33);
if(_38<0||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.score.min must be a valid decimal between 0 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.score.min must be a valid decimal.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1523`");
if(_33.length>Control.Package.Properties.SuspendDataMaxLength){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.core.suspend_data may not be greater than "+Control.Package.Properties.SuspendDataMaxLength+" characters, your value is "+_33.length+" characters. Your value\n"+_33);
_37=false;
}
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1503`");
if(!IsValidCMIIdentifier(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value '"+_33+"' is not a valid CMI Identifier");
_37=false;
}
if(!this.RunTimeData.IsValidObjectiveIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, objective indicies must be set sequentially starting with 0");
_37=false;
}
break;
case "cmi.objectives.n.status":
this.WriteDetailedLog("`1421`");
if(!this.RunTimeData.IsValidObjectiveIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, objective indicies must be set sequentially starting with 0");
_37=false;
}
if(!this.IsValidVocabElement(_33,"status")){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value for cmi.objectives.n.status is not in the CMI vocabulary. Your value: "+_33);
_37=false;
}
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1366`");
if(!this.RunTimeData.IsValidObjectiveIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, objective indicies must be set sequentially starting with 0");
_37=false;
}
if(_33!==""){
if(IsValidCMIDecimal(_33)){
_38=parseFloat(_33);
if(_38<0||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.objectives.n.score.raw must be a valid decimal between 0 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.objectives.score.raw must be a valid decimal.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1365`");
if(!this.RunTimeData.IsValidObjectiveIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, objective indicies must be set sequentially starting with 0");
_37=false;
}
if(_33!==""){
if(IsValidCMIDecimal(_33)){
_38=parseFloat(_33);
if(_38<0||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.objectives.n.score.min must be a valid decimal between 0 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.objectives.score.min must be a valid decimal.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1364`");
if(!this.RunTimeData.IsValidObjectiveIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, objective indicies must be set sequentially starting with 0");
_37=false;
}
if(_33!==""){
if(IsValidCMIDecimal(_33)){
_38=parseFloat(_33);
if(_38<0||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.objectives.n.score.max must be a valid decimal between 0 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.objectives.score.max must be a valid decimal.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.comments":
this.WriteDetailedLog("`1586`");
if(_33.length>4096){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.comments may not be greater than 4096 characters, your value ("+_33+") is "+_33.length+" characters.");
_37=false;
}
break;
case "cmi.student_preference.audio":
this.WriteDetailedLog("`1655`");
if(IsValidCMISInteger(_33)){
_38=parseInt(_33,10);
if(_38<-1||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.student_preference.audio must be a valid integer between -1 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.student_preference.audio must be a valid signed integer.  Your value is: "+_33);
_37=false;
}
break;
case "cmi.student_preference.language":
this.WriteDetailedLog("`1587`");
if(_33.length>255){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.student_preference.language may not be greater than 255 characters, your value ("+_33+") is "+_33.length+" characters.");
_37=false;
}
break;
case "cmi.student_preference.speed":
this.WriteDetailedLog("`1657`");
if(IsValidCMISInteger(_33)){
_38=parseInt(_33,10);
if(_38<-100||_38>100){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.student_preference.audio must be a valid integer between -100 and 100.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.student_preference.audio must be a valid signed integer.  Your value is: "+_33);
_37=false;
}
break;
case "cmi.student_preference.text":
this.WriteDetailedLog("`1683`");
if(IsValidCMISInteger(_33)){
_38=parseInt(_33,10);
if(_38<-1||_38>1){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.student_preference.audio must be a valid integer between -1 and 1.  Your value is: "+_38);
_37=false;
}
}else{
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.student_preference.audio must be a valid signed integer.  Your value is: "+_33);
_37=false;
}
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1462`");
if(!IsValidCMIIdentifier(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value '"+_33+"' is not a valid CMI Identifier");
_37=false;
}
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1263`");
if(!IsValidCMIIdentifier(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value '"+_33+"' is not a valid CMI Identifier");
_37=false;
}
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(!this.RunTimeData.IsValidInteractionObjectiveIndex(_35,_36)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_36+"' is not valid, interaction objective indicies must be set sequentially starting with 0");
_37=false;
}
break;
case "cmi.interactions.n.time":
this.WriteDetailedLog("`1418`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(!IsValidCMITime(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.time must be a valid time.  Your value is: "+_33);
_37=false;
}
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1415`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(!this.IsValidVocabElement(_33,"interaction")){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value for cmi.interactions.n.type is not in the CMI vocabulary. Your value: "+_33);
_37=false;
}
if(this.RunTimeData.Interactions[_35]!==undefined){
if(this.RunTimeData.Interactions[_35].LearnerResponse!==null){
if(!IsValidCMIFeedback(_33,this.RunTimeData.Interactions[_35].LearnerResponse)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.type must be consistent with previously recorded student response.  Your value is: "+_33);
_37=false;
}
}
for(var i=0;i<this.RunTimeData.Interactions[_35].CorrectResponses.length;i++){
if(!IsValidCMIFeedback(_33,this.RunTimeData.Interactions[_35].CorrectResponses[i])){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.type must be consistent with previously recorded correct response ("+i+" - "+this.RunTimeData.Interactions[_35].CorrectResponses[i]+").  Your value is: "+_33);
_37=false;
}
}
}
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`1017`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(!this.RunTimeData.IsValidInteractionCorrectResponseIndex(_35,_36)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_36+"' is not valid, interaction correct response indicies must be set sequentially starting with 0");
_37=false;
}
if(this.RunTimeData.Interactions[_35]!==undefined){
if(!IsValidCMIFeedback(this.RunTimeData.Interactions[_35].Type,_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.student_response must be a valid CMIFeedback - value must be consistent with interaction type.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1326`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(!IsValidCMIDecimal(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.weighting must be a valid decimal.  Your value is: "+_33);
_37=false;
}
break;
case "cmi.interactions.n.student_response":
this.WriteDetailedLog("`1209`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(this.RunTimeData.Interactions[_35]!==undefined){
if(!IsValidCMIFeedback(this.RunTimeData.Interactions[_35].Type,_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.student_response must be a valid CMIFeedback - value must be consistent with interaction type.  Your value is: "+_33);
_37=false;
}
}
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1381`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(!this.IsValidVocabElement(_33,"result")&&!IsValidCMIDecimal(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"The value for cmi.interactions.n.result is not in the CMI vocabulary. Your value: "+_33);
_37=false;
}
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1362`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(!IsValidCMITimeSpan(_33)){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.latency must be a valid timespan.  Your value is: "+_33);
_37=false;
}
break;
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1417`");
if(!this.RunTimeData.IsValidInteractionIndex(_35)){
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The index '"+_35+"' is not valid, interaction indicies must be set sequentially starting with 0");
_37=false;
}
if(_33.length>500){
this.SetErrorState(SCORM_ERROR_INCORRECT_DATA_TYPE,"cmi.interactions.n.text may not be greater than 500 characters, your value is "+_33.length+" characters. Your value\n"+_33);
_37=false;
}
break;
default:
this.WriteDetailedLog("`1603`");
this.SetErrorState(SCORM_ERROR_GENERAL,"Setting the data element you requested is not supported although it is listed as being supported, please contact technical support.  Element-"+_32);
_37=false;
break;
}
if(_37===null){
_37=true;
}else{
_37=false;
}
if(_37==true){
this.WriteDetailedLog("`1601`");
}
return _37;
}
function RunTimeApi_StoreValue(_3a,_3b,_3c,_3d,_3e){
this.WriteDetailedLog("`1722`"+_3a+", "+_3b+", "+_3c+", "+_3d+", "+_3e+") ");
switch(_3c){
case "cmi.core.lesson_location":
this.WriteDetailedLog("`1464`");
this.RunTimeData.Location=_3b;
break;
case "cmi.core.lesson_status":
this.WriteDetailedLog("`1501`");
this.WriteDetailedLog("`1446`"+this.StatusSetInCurrentSession+"`1600`"+this.RunTimeData.CompletionStatus);
var _3f;
if(this.StatusSetInCurrentSession||(this.RunTimeData.SuccessStatus==TranslateSingleStatusIntoSuccess(_3b)&&this.RunTimeData.CompletionStatus==TranslateSingleStatusIntoCompletion(_3b))||this.RunTimeData.CompletionStatus!=SCORM_STATUS_COMPLETED||(this.RunTimeData.CompletionStatus==SCORM_STATUS_COMPLETED&&this.RunTimeData.SuccessStatus==SCORM_STATUS_FAILED)||_3b=="passed"||Control.Package.Properties.AllowCompleteStatusChange===true){
this.WriteDetailedLog("`1554`");
this.StatusSetInCurrentSession=true;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
if(_3b=="passed"||_3b=="failed"){
this.RunTimeData.SuccessStatusChangedDuringRuntime=true;
}
var _40=this.RunTimeData.SuccessStatus;
var _41=this.RunTimeData.CompletionStatus;
this.RunTimeData.SuccessStatus=TranslateSingleStatusIntoSuccess(_3b);
this.RunTimeData.CompletionStatus=TranslateSingleStatusIntoCompletion(_3b);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.SuccessStatus,_40);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.CompletionStatus,_41);
this.RunLookAheadSequencerIfNeeded();
_3f={ev:"Set",v:_3b};
if(_3b=="passed"||_3b=="failed"){
_3f.k="success";
}else{
_3f.k="completion";
}
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
this.ImmediateRollup();
}
break;
case "cmi.core.exit":
this.WriteDetailedLog("`1681`");
_3f={ev:"Set",k:"cmi.exit",v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Exit=_3b;
break;
case "cmi.core.session_time":
this.WriteDetailedLog("`1518`");
this.RunTimeData.SessionTime=ConvertCmiTimeSpanToIso8601TimeSpan(_3b);
this.WriteDetailedLog("`1729`"+this.RunTimeData.SessionTime);
_3f={ev:"Set",k:"session time",vh:ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTime)};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
break;
case "cmi.core.score.raw":
this.WriteDetailedLog("`1572`");
_3f={ev:"Set",k:"score.raw",v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
if(_3b===""){
_3b=null;
}
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreRaw,_3b);
this.RunTimeData.ScoreRaw=_3b;
this.RunLookAheadSequencerIfNeeded();
this.RunTimeData.ScoreScaled=NormalizeRawScore(this.RunTimeData.ScoreRaw,this.RunTimeData.ScoreMin,this.RunTimeData.ScoreMax);
break;
case "cmi.core.score.max":
this.WriteDetailedLog("`1570`");
_3f={ev:"Set",k:"score.max",v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
if(_3b===""){
_3b=null;
}
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMax,_3b);
this.RunTimeData.ScoreMax=_3b;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.core.score.min":
this.WriteDetailedLog("`1571`");
_3f={ev:"Set",k:"score.min",v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
if(_3b===""){
_3b=null;
}
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMin,_3b);
this.RunTimeData.ScoreMin=_3b;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1522`");
this.RunTimeData.SuspendData=_3b;
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1503`");
if(this.RunTimeData.Objectives.length<=_3d){
this.WriteDetailedLog("`1390`"+_3d);
this.RunTimeData.AddObjective();
}
_3f={ev:"Set",k:"objectives id",i:_3d,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Objectives[_3d].Identifier=_3b;
break;
case "cmi.objectives.n.status":
this.WriteDetailedLog("`1421`");
if(this.RunTimeData.Objectives.length<=_3d){
this.WriteDetailedLog("`1390`"+_3d);
this.RunTimeData.AddObjective();
}
this.RunTimeData.Objectives[_3d].SuccessStatus=TranslateSingleStatusIntoSuccess(_3b);
this.RunTimeData.Objectives[_3d].CompletionStatus=TranslateSingleStatusIntoCompletion(_3b);
_3f={ev:"Set",k:"objectives success",i:_3d,v:TranslateSingleStatusIntoSuccess(_3b)};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Objectives[_3d].Identifier){
_3f.intid=this.RunTimeData.Objectives[_3d].Identifier;
}
this.WriteHistoryLog("",_3f);
_3f={ev:"Set",k:"objectives completion",i:_3d,v:TranslateSingleStatusIntoCompletion(_3b)};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Objectives[_3d].Identifier){
_3f.intid=this.RunTimeData.Objectives[_3d].Identifier;
}
this.WriteHistoryLog("",_3f);
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1366`");
if(this.RunTimeData.Objectives.length<=_3d){
this.WriteDetailedLog("`1390`"+_3d);
this.RunTimeData.AddObjective();
}
if(_3b===""){
_3b=null;
}
this.RunTimeData.Objectives[_3d].ScoreRaw=_3b;
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1365`");
if(this.RunTimeData.Objectives.length<=_3d){
this.WriteDetailedLog("`1390`"+_3d);
this.RunTimeData.AddObjective();
}
if(_3b===""){
_3b=null;
}
this.RunTimeData.Objectives[_3d].ScoreMin=_3b;
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1364`");
if(this.RunTimeData.Objectives.length<=_3d){
this.WriteDetailedLog("`1390`"+_3d);
this.RunTimeData.AddObjective();
}
if(_3b===""){
_3b=null;
}
this.RunTimeData.Objectives[_3d].ScoreMax=_3b;
break;
case "cmi.comments":
this.WriteDetailedLog("`1179`"+this.RunTimeData.Comments.length);
var _42=new ActivityRunTimeComment(null,null,null,null,null,null);
_42.SetCommentValue(_3b);
this.RunTimeData.Comments[this.RunTimeData.Comments.length]=_42;
break;
case "cmi.student_preference.audio":
this.WriteDetailedLog("`1655`");
this.RunTimeData.AudioLevel=_3b;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.AudioLevel=_3b;
}
break;
case "cmi.student_preference.language":
this.WriteDetailedLog("`1587`");
this.RunTimeData.LanguagePreference=_3b;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.LanguagePreference=_3b;
}
break;
case "cmi.student_preference.speed":
this.WriteDetailedLog("`1657`");
this.RunTimeData.DeliverySpeed=_3b;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.DeliverySpeed=_3b;
}
break;
case "cmi.student_preference.text":
this.WriteDetailedLog("`1683`");
this.RunTimeData.AudioCaptioning=_3b;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.AudioCaptioning=_3b;
}
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1462`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
_3f={ev:"Set",k:"interactions id",i:_3d,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].Id=_3b;
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1263`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
_3f={ev:"Set",k:"interactions objectives id",i:_3d,si:_3e,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].Objectives[_3e]=_3b;
break;
case "cmi.interactions.n.time":
this.WriteDetailedLog("`1418`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
var _43=ConvertCmiTimeToIso8601Time(_3b);
_3f={ev:"Set",k:"interactions timestamp",i:_3d,v:_43};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_3d].Id){
_3f.intid=this.RunTimeData.Interactions[_3d].Id;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].Timestamp=_43;
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1415`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
_3f={ev:"Set",k:"interactions type",i:_3d,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_3d].Id){
_3f.intid=this.RunTimeData.Interactions[_3d].Id;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].Type=_3b;
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`1018`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
_3f={ev:"Set",k:"interactions correct_responses pattern",i:_3d,si:_3e,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].CorrectResponses[_3e]=_3b;
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1326`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
this.RunTimeData.Interactions[_3d].Weighting=_3b;
break;
case "cmi.interactions.n.student_response":
this.WriteDetailedLog("`1209`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
_3f={ev:"Set",k:"interactions learner_response",i:_3d,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_3d].Id){
_3f.intid=this.RunTimeData.Interactions[_3d].Id;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].LearnerResponse=_3b;
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1381`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
if(_3b==SCORM_WRONG){
_3b=SCORM_INCORRECT;
}
_3f={ev:"Set",k:"interactions result",i:_3d,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_3d].Id){
_3f.intid=this.RunTimeData.Interactions[_3d].Id;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].Result=_3b;
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1362`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
var _44=ConvertCmiTimeSpanToIso8601TimeSpan(_3b);
_3f={ev:"Set",k:"interactions latency",i:_3d,vh:ConvertIso8601TimeSpanToHundredths(_44)};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_3d].Id){
_3f.intid=this.RunTimeData.Interactions[_3d].Id;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].Latency=_44;
break;
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1417`");
if(this.RunTimeData.Interactions.length<=_3d){
this.WriteDetailedLog("`1305`"+_3d);
this.RunTimeData.AddInteraction();
}
_3f={ev:"Set",k:"interactions description",i:_3d,v:_3b};
if(this.Activity){
_3f.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_3d].Id){
_3f.intid=this.RunTimeData.Interactions[_3d].Id;
}
this.WriteHistoryLog("",_3f);
this.RunTimeData.Interactions[_3d].Description=_3b;
break;
default:
Debug.AssertError("Unrecognized data model element in StoreData");
this.SetErrorState(SCORM_ERROR_GENERAL,"Setting the data element you requested is not supported although it is listed as being supported, please contact technical support.  Element-"+strElement);
return false;
}
return true;
}
function RunTimeApi_CheckForGetValueError(_45,_46,_47,_48){
this.WriteDetailedLog("`1534`"+_45+", "+_46+", "+_47+", "+_48+") ");
if(this.Initialized===false){
this.SetErrorState(SCORM_ERROR_NOT_INITIALIZED,"GetValue called when not initialized. element-"+_45);
return false;
}
if(arySupportedElements[_46]!==undefined&&arySupportedElements[_46]!==null){
if(!arySupportedElements[_46].Supported){
this.SetErrorState(SCORM_ERROR_NOT_IMPLEMENTED,"The parameter '"+_45+"' is not implemented.");
return false;
}
if(!arySupportedElements[_46].SupportsRead){
this.SetErrorState(SCORM_ERROR_WRITE_ONLY,"The parameter '"+_45+"' is write-only.");
return false;
}
}else{
if(_46.search(/._children$/)>0){
strBaseElement=_46.replace("._children","");
if(arySupportedElements[strBaseElement]!==undefined&&arySupportedElements[_45]!==null){
this.SetErrorState(SCORM_ERROR_NO_CHILDREN,"The parameter '"+_45+"' does not support the _children keyword.");
return false;
}
}else{
if(_46.search(/._count$/)>0){
strBaseElement=_46.replace("._count","");
if(arySupportedElements[strBaseElement]!==undefined&&arySupportedElements[_45]!==null){
this.SetErrorState(SCORM_ERROR_NO_COUNT,"The parameter '"+_45+"' does not support the _count keyword.");
return false;
}
}
}
this.SetErrorState(SCORM_ERROR_INVALID_ARG,"The parameter '"+_45+"' is not recognized.");
return false;
}
this.WriteDetailedLog("`1601`");
return true;
}
function RunTimeApi_RetrieveGetValueData(_49,_4a,_4b,_4c){
this.WriteDetailedLog("`1563`"+_49+", "+_4a+", "+_4b+", "+_4c+") ");
var _4d="";
switch(_4a){
case "cmi.core._children":
this.WriteDetailedLog("`1479`");
_4d=SCORM_CORE_CHILDREN;
break;
case "cmi.core.student_id":
this.WriteDetailedLog("`1560`");
_4d=this.LearnerId;
break;
case "cmi.core.student_name":
this.WriteDetailedLog("`1521`");
_4d=this.LearnerName;
break;
case "cmi.core.lesson_location":
this.WriteDetailedLog("`1463`");
_4d=this.RunTimeData.Location;
var _4e={ev:"Get",k:"location",v:(_4d==null?"<null>":_4d)};
if(this.Activity){
_4e.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_4e);
break;
case "cmi.core.credit":
this.WriteDetailedLog("`1634`");
_4d=this.RunTimeData.Credit;
break;
case "cmi.core.lesson_status":
this.WriteDetailedLog("`1500`");
_4d=TranslateDualStausToSingleStatus(this.RunTimeData.CompletionStatus,this.RunTimeData.SuccessStatus);
break;
case "cmi.core.entry":
this.WriteDetailedLog("`1656`");
_4d=this.RunTimeData.Entry;
break;
case "cmi.core.score._children":
this.WriteDetailedLog("`1466`");
_4d=SCORM_CORE_SCORE_CHILDREN;
break;
case "cmi.core.score.raw":
this.WriteDetailedLog("`1572`");
_4d=this.RunTimeData.ScoreRaw;
break;
case "cmi.core.score.max":
this.WriteDetailedLog("`1570`");
_4d=this.RunTimeData.ScoreMax;
break;
case "cmi.core.score.min":
this.WriteDetailedLog("`1571`");
_4d=this.RunTimeData.ScoreMin;
break;
case "cmi.core.total_time":
this.WriteDetailedLog("`1561`");
_4d=ConvertIso8601TimeSpanToCmiTimeSpan(this.RunTimeData.TotalTime);
break;
case "cmi.core.lesson_mode":
this.WriteDetailedLog("`1543`");
_4d=this.RunTimeData.Mode;
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1522`");
_4d=this.RunTimeData.SuspendData;
break;
case "cmi.launch_data":
this.WriteDetailedLog("`1541`");
_4d=this.LearningObject.DataFromLms;
break;
case "cmi.objectives._children":
this.WriteDetailedLog("`1363`");
_4d=SCORM_OBJECTIVES_CHILDREN;
break;
case "cmi.objectives._count":
this.WriteDetailedLog("`1420`");
_4d=this.RunTimeData.Objectives.length;
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1503`");
if(this.RunTimeData.Objectives[_4b]===null||this.RunTimeData.Objectives[_4b]===undefined||this.RunTimeData.Objectives[_4b].Identifier===null){
this.WriteDetailedLog("`954`");
_4d="";
}else{
_4d=this.RunTimeData.Objectives[_4b].Identifier;
}
break;
case "cmi.objectives.n.status":
this.WriteDetailedLog("`1421`");
if(this.RunTimeData.Objectives.length<(_4b+1)||this.RunTimeData.Objectives[_4b]===null||this.RunTimeData.Objectives[_4b]===undefined||this.RunTimeData.Objectives[_4b].CompletionStatus===null||this.RunTimeData.Objectives[_4b].SuccessStatus===null){
this.WriteDetailedLog("`954`");
_4d="";
}else{
_4d=TranslateDualStausToSingleStatus(this.RunTimeData.Objectives[_4b].CompletionStatus,this.RunTimeData.Objectives[_4b].SuccessStatus);
}
break;
case "cmi.objectives.n.score._children":
this.WriteDetailedLog("`1264`");
_4d=SCORM_OBJECTIVES_SCORE_CHILDREN;
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1366`");
if(this.RunTimeData.Objectives.length<(_4b+1)||this.RunTimeData.Objectives[_4b]===null||this.RunTimeData.Objectives[_4b]===undefined||this.RunTimeData.Objectives[_4b].ScoreRaw===null){
this.WriteDetailedLog("`954`");
_4d="";
}else{
_4d=this.RunTimeData.Objectives[_4b].ScoreRaw;
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1364`");
if(this.RunTimeData.Objectives.length<(_4b+1)||this.RunTimeData.Objectives[_4b]===null||this.RunTimeData.Objectives[_4b]===undefined||this.RunTimeData.Objectives[_4b].ScoreMax===null){
this.WriteDetailedLog("`954`");
_4d="";
}else{
_4d=this.RunTimeData.Objectives[_4b].ScoreMax;
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1365`");
if(this.RunTimeData.Objectives.length<(_4b+1)||this.RunTimeData.Objectives[_4b]===null||this.RunTimeData.Objectives[_4b]===undefined||this.RunTimeData.Objectives[_4b].ScoreMin===null){
this.WriteDetailedLog("`954`");
_4d="";
}else{
_4d=this.RunTimeData.Objectives[_4b].ScoreMin;
}
break;
case "cmi.comments":
this.WriteDetailedLog("`1586`");
_4d=this.JoinCommentsArray(this.RunTimeData.Comments);
break;
case "cmi.comments_from_lms":
this.WriteDetailedLog("`1413`");
_4d=this.JoinCommentsArray(this.RunTimeData.CommentsFromLMS);
break;
case "cmi.student_data._children":
this.WriteDetailedLog("`1331`");
_4d=SCORM_STUDENT_DATA_CHILDREN;
break;
case "cmi.student_data.mastery_score":
this.WriteDetailedLog("`1502`");
if(this.LearningObject.MasteryScore===null){
_4d="";
}else{
_4d=this.LearningObject.MasteryScore;
}
break;
case "cmi.student_data.max_time_allowed":
this.WriteDetailedLog("`1435`");
_4d=ConvertIso8601TimeSpanToCmiTimeSpan(this.LearningObject.MaxTimeAllowed);
break;
case "cmi.student_data.time_limit_action":
this.WriteDetailedLog("`1422`");
_4d=this.LearningObject.TimeLimitAction;
break;
case "cmi.student_preference._children":
this.WriteDetailedLog("`1231`");
_4d=SCORM_STUDENT_PREFERENCE_CHILDREN;
break;
case "cmi.student_preference.audio":
this.WriteDetailedLog("`1655`");
if(this.RunTimeData.AudioLevel===null){
_4d="";
}else{
_4d=Math.round(this.RunTimeData.AudioLevel);
}
break;
case "cmi.student_preference.language":
this.WriteDetailedLog("`1587`");
_4d=this.RunTimeData.LanguagePreference;
break;
case "cmi.student_preference.speed":
this.WriteDetailedLog("`1657`");
if(this.RunTimeData.DeliverySpeed===null){
_4d="";
}else{
_4d=Math.round(this.RunTimeData.DeliverySpeed);
}
break;
case "cmi.student_preference.text":
this.WriteDetailedLog("`1683`");
_4d=this.RunTimeData.AudioCaptioning;
break;
case "cmi.interactions._children":
this.WriteDetailedLog("`1323`");
_4d=SCORM_INTERACTIONS_CHILDREN;
break;
case "cmi.interactions._count":
this.WriteDetailedLog("`1379`");
_4d=this.RunTimeData.Interactions.length;
break;
case "cmi.interactions.n.objectives._count":
this.WriteDetailedLog("`1183`");
if(this.RunTimeData.Interactions.length<(_4b+1)||this.RunTimeData.Interactions[_4b]===null||this.RunTimeData.Interactions[_4b]===undefined){
this.WriteDetailedLog("`1636`"+_4b+"`1713`");
_4d=0;
}else{
_4d=this.RunTimeData.Interactions[_4b].Objectives.length;
}
break;
case "cmi.interactions.n.correct_responses._count":
this.WriteDetailedLog("`1032`");
if(this.RunTimeData.Interactions.length<(_4b+1)||this.RunTimeData.Interactions[_4b]===null||this.RunTimeData.Interactions[_4b]===undefined){
this.WriteDetailedLog("`1636`"+_4b+"`1713`");
_4d=0;
}else{
_4d=this.RunTimeData.Interactions[_4b].CorrectResponses.length;
}
break;
case "cmi._version":
this.WriteDetailedLog("`1498`");
_4d=SCORM_CMI_VERSION;
break;
default:
Debug.AssertError("An unsupported data model element \""+_4a+"\" slipped through GetValue error detection.");
SetErrorInfo(SCORM_ERROR_GENERAL,"Getting the data element you requested is not supported although it is listed as being supported, please contact technical support.  Element-"+strElement);
_4d="";
break;
}
return _4d;
}
function RunTimeApi_CloseOutSession(_4f){
this.WriteDetailedLog("`1654`");
var _50=this.LearningObject.MasteryScore;
this.WriteDetailedLog("`1739`"+this.RunTimeData.Mode);
this.WriteDetailedLog("`1736`"+this.RunTimeData.Credit);
this.WriteDetailedLog("`1602`"+this.RunTimeData.CompletionStatus);
this.WriteDetailedLog("`1686`"+this.RunTimeData.SuccessStatus);
this.WriteDetailedLog("`1696`"+_50);
this.WriteDetailedLog("`1738`"+this.RunTimeData.ScoreRaw);
if(this.RunTimeData.Mode==SCORM_MODE_REVIEW){
this.WriteDetailedLog("`1397`");
}else{
if(this.RunTimeData.Mode==SCORM_MODE_BROWSE&&this.RunTimeData.Credit==SCORM_CREDIT_NO){
}else{
if(this.RunTimeData.Credit==SCORM_CREDIT){
this.WriteDetailedLog("`1528`");
var _51=this.GetCombinedCompletionSuccessStatus();
var _52=_51.CompletionStatus;
if(_52!=this.RunTimeData.CompletionStatus){
this.RunTimeData.CompletionStatus=_52;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
}
var _53=_51.SuccessStatus;
if(_53!=this.RunTimeData.SuccessStatus){
this.RunTimeData.SuccessStatus=_53;
this.RunTimeData.SuccessStatusChangedDuringRuntime=true;
}
}
}
}
if(this.RunTimeData.ScoreRaw!==null&&this.RunTimeData.ScoreRaw!==""){
this.RunTimeData.ScoreScaled=NormalizeRawScore(this.RunTimeData.ScoreRaw,this.RunTimeData.ScoreMin,this.RunTimeData.ScoreMax);
}
if(this.RunTimeData.CompletionStatus==SCORM_STATUS_COMPLETED&&this.RunTimeData.SuccessStatus!=SCORM_STATUS_FAILED){
this.WriteDetailedLog("`810`");
if(Control.Package.Properties.LaunchCompletedRegsAsNoCredit){
this.RunTimeData.Credit=SCORM_CREDIT_NO;
}
this.RunTimeData.Mode=SCORM_MODE_REVIEW;
}
if(this.RunTimeData.CompletionStatus==SCORM_STATUS_COMPLETED||this.RunTimeData.Exit!=SCORM_EXIT_SUSPEND){
this.WriteDetailedLog("`1591`");
this.RunTimeData.Entry=SCORM_ENTRY_NORMAL;
}else{
this.WriteDetailedLog("`1592`");
this.RunTimeData.Entry=SCORM_ENTRY_RESUME;
}
if(this.RunTimeData.Exit==SCORM_EXIT_SUSPEND){
this.Activity.SetSuspended(true);
}else{
this.Activity.SetSuspended(false);
}
var _54=this.RunTimeData.Objectives;
for(var i=0;i<_54.length;i++){
var _56=_54[i];
if(_56.ScoreRaw!==null&&_56.ScoreRaw!==""){
_56.ScoreScaled=NormalizeRawScore(_56.ScoreRaw,_56.ScoreMin,_56.ScoreMax);
}
}
var _57=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTime);
var _58=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime);
var _59=_57+_58;
var _5a=ConvertHundredthsToIso8601TimeSpan(_59);
this.WriteDetailedLog("`1712`"+this.RunTimeData.SessionTime+" ("+_57+"`1717`");
this.WriteDetailedLog("`1697`"+this.RunTimeData.TotalTime+" ("+_58+"`1717`");
this.WriteDetailedLog("`1685`"+_5a+" ("+_59+"`1717`");
this.RunTimeData.TotalTime=_5a;
this.RunTimeData.SessionTime="";
this.AccumulateTotalTimeTracked();
this.WriteDetailedLog("`1525`"+this.RunTimeData.TotalTimeTracked);
this.CloseOutSessionCalled=true;
}
function RunTimeApi_JoinCommentsArray(_5b){
var _5c="";
for(var i=0;i<_5b.length;i++){
_5c+=_5b[i].GetCommentValue();
}
return _5c;
}
function RunTimeApi_IsValidVocabElement(_5e,_5f){
var _60;
var i;
_60=aryVocabularies[_5f];
if(_60===undefined||_60===null){
return false;
}else{
for(i=0;i<_60.length;i++){
if(_60[i]==_5e){
return true;
}
}
return false;
}
}
function RunTimeApi_InitTrackedTimeStart(_62){
this.TrackedStartDate=new Date();
this.StartSessionTotalTime=_62.RunTime.TotalTime;
}
function RunTimeApi_AccumulateTotalTimeTracked(){
this.TrackedEndDate=new Date();
var _63=Math.round((this.TrackedEndDate-this.TrackedStartDate)/10);
var _64=ConvertIso8601TimeSpanToHundredths(this.InitialTotalTimeTracked);
var _65=_63+_64;
this.RunTimeData.TotalTimeTracked=ConvertHundredthsToIso8601TimeSpan(_65);
var _66=ConvertIso8601TimeSpanToHundredths(this.InitialSessionTimeTracked);
var _67=_63+_66;
this.RunTimeData.SessionTimeTracked=ConvertHundredthsToIso8601TimeSpan(_67);
this.Activity.ActivityEndedDate=this.TrackedEndDate;
var _68=GetDateFromUtcIso8601Time(this.Activity.GetActivityStartTimestampUtc());
var _69=GetDateFromUtcIso8601Time(this.Activity.GetAttemptStartTimestampUtc());
this.Activity.SetActivityAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate-_68)/10));
this.Activity.SetAttemptAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate-_69)/10));
var _6a=ConvertIso8601TimeSpanToHundredths(this.InitialActivityExperiencedDurationTracked);
var _6b=ConvertHundredthsToIso8601TimeSpan(_6a+_63);
this.Activity.SetActivityExperiencedDurationTracked(_6b);
var _6c=ConvertIso8601TimeSpanToHundredths(this.InitialActivityExperiencedDurationReported);
var _6d=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime)-ConvertIso8601TimeSpanToHundredths(this.StartSessionTotalTime);
var _6e=ConvertHundredthsToIso8601TimeSpan(_6c+_6d);
this.Activity.SetActivityExperiencedDurationReported(_6e);
var _6f=ConvertIso8601TimeSpanToHundredths(this.InitialAttemptExperiencedDurationTracked);
var _70=ConvertHundredthsToIso8601TimeSpan(_6f+_63);
this.Activity.SetAttemptExperiencedDurationTracked(_70);
var _71=ConvertIso8601TimeSpanToHundredths(this.InitialAttemptExperiencedDurationReported);
var _72=ConvertHundredthsToIso8601TimeSpan(_71+_6d);
this.Activity.SetAttemptExperiencedDurationReported(_72);
}
function RunTimeApi_LookAheadSessionClose(){
var _73=this.GetCombinedCompletionSuccessStatus();
this.RunTimeData.LookAheadCompletionStatus=_73.CompletionStatus;
this.RunTimeData.LookAheadSuccessStatus=_73.SuccessStatus;
}
function RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded(_74,_75){
if(this.IsLookAheadSequencerDataDirty==false&&_74!=_75){
this.IsLookAheadSequencerDataDirty=true;
}
}
function RunTimeApi_GetCombinedCompletionSuccessStatus(){
var _76={CompletionStatus:this.RunTimeData.CompletionStatus,SuccessStatus:this.RunTimeData.SuccessStatus};
var _77=this.LearningObject.MasteryScore;
if(this.RunTimeData.CompletionStatus==SCORM_STATUS_UNKNOWN){
this.WriteDetailedLog("`909`");
if(_77===null||this.RunTimeData.ScoreRaw===null||this.RunTimeData.ScoreRaw===""){
if(Control.Package.Properties.ForceObjectiveCompletionSetByContent==false){
this.WriteDetailedLog("`943`");
_76.CompletionStatus=SCORM_STATUS_COMPLETED;
}else{
this.WriteDetailedLog("`276`");
}
}else{
if(this.RunTimeData.ScoreRaw>=_77){
this.WriteDetailedLog("`1235`");
_76.SuccessStatus=SCORM_STATUS_PASSED;
_76.CompletionStatus=SCORM_STATUS_COMPLETED;
}else{
this.WriteDetailedLog("`1188`");
_76.SuccessStatus=SCORM_STATUS_FAILED;
_76.CompletionStatus=SCORM_STATUS_COMPLETED;
}
}
}else{
if(Control.Package.Properties.ScoreOverridesStatus){
this.WriteDetailedLog("`754`");
if(_77!==null&&_77!==""&&this.RunTimeData.ScoreRaw!==null&&this.RunTimeData.ScoreRaw!==""){
if(this.RunTimeData.ScoreRaw>=_77){
this.WriteDetailedLog("`1235`");
_76.SuccessStatus=SCORM_STATUS_PASSED;
_76.CompletionStatus=SCORM_STATUS_COMPLETED;
}else{
this.WriteDetailedLog("`1188`");
if(Control.Package.Properties.CompletionStatOfFailedSuccessStat===SCORM_STATUS_COMPLETED||Control.Package.Properties.CompletionStatOfFailedSuccessStat===SCORM_STATUS_INCOMPLETE){
_76.CompletionStatus=Control.Package.Properties.CompletionStatOfFailedSuccessStat;
}else{
_76.CompletionStatus=SCORM_STATUS_COMPLETED;
}
_76.SuccessStatus=SCORM_STATUS_FAILED;
}
}
}
}
return _76;
}
function RunTimeApi_RunLookAheadSequencerIfNeeded(_78){
if((Control.Package.Properties.LookaheadSequencerMode!=LOOKAHEAD_SEQUENCER_MODE_REALTIME&&_78!==true)||Control.Package.Properties.LookaheadSequencerMode==LOOKAHEAD_SEQUENCER_MODE_DISABLE){
return;
}
if(this.RunTimeData!=null){
this.LookAheadSessionClose();
}
if(this.IsLookAheadSequencerDataDirty===true&&!this.IsLookAheadSequencerRunning){
this.IsLookAheadSequencerDataDirty=false;
this.IsLookAheadSequencerRunning=true;
window.setTimeout("Control.EvaluatePossibleNavigationRequests(true);",150);
}
}
function RunTimeApi_ImmediateRollup(){
try{
this.WriteDetailedLog("`1352`");
var _79=this.RunTimeData.CompletionStatus;
var _7a=this.RunTimeData.SuccessStatus;
var _7b=this.RunTimeData.CompletionStatusChangedDuringRuntime;
var _7c=this.RunTimeData.SuccessStatusChangedDuringRuntime;
var _7d=this.GetCombinedCompletionSuccessStatus();
this.RunTimeData.CompletionStatus=_7d.CompletionStatus;
this.RunTimeData.SuccessStatus=_7d.SuccessStatus;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
this.RunTimeData.SuccessStatusChangedDuringRuntime=true;
this.AccumulateTotalTimeTracked();
if(this.RunTimeData.ScoreRaw!==null&&this.RunTimeData.ScoreRaw!==""){
this.RunTimeData.ScoreScaled=NormalizeRawScore(this.RunTimeData.ScoreRaw,this.RunTimeData.ScoreMin,this.RunTimeData.ScoreMax);
}
this.WriteDetailedLog("`1270`");
Control.Sequencer.CurrentActivity.TransferRteDataToActivity();
this.WriteDetailedLog("`1526`");
Control.Sequencer.RollupData(Control.Sequencer.CurrentActivity);
this.RunTimeData.CompletionStatus=_79;
this.RunTimeData.SuccessStatus=_7a;
this.RunTimeData.CompletionStatusChangedDuringRuntime=_7b;
this.RunTimeData.SuccessStatusChangedDuringRuntime=_7c;
}
catch(error){
var _7e="RunTimeApi_ImmediateRollup Error: ";
if(typeof RegistrationToDeliver!="undefined"&&typeof RegistrationToDeliver.Id!="undefined"){
_7e=_7e+"RegistrationId: "+RegistrationToDeliver.Id+", ";
}
Control.Comm.LogOnServer(_7e,error);
throw error;
}
}
function Sequencer(_7f,_80){
this.LookAhead=_7f;
this.Activities=_80;
this.NavigationRequest=null;
this.SuspendedActivity=null;
this.CurrentActivity=null;
this.ExceptionText="";
this.AtEndOfCourse=false;
this.AtStartOfCourse=false;
this.PrerequisitesEvaluator=new PrerequisitesEvaluator(this);
}
Sequencer.prototype.OverallSequencingProcess=Sequencer_OverallSequencingProcess;
Sequencer.prototype.SetSuspendedActivity=Sequencer_SetSuspendedActivity;
Sequencer.prototype.GetSuspendedActivity=Sequencer_GetSuspendedActivity;
Sequencer.prototype.Start=Sequencer_Start;
Sequencer.prototype.InitialRandomizationAndSelection=Sequencer_InitialRandomizationAndSelection;
Sequencer.prototype.GetCurrentActivity=Sequencer_GetCurrentActivity;
Sequencer.prototype.GetExceptionText=Sequencer_GetExceptionText;
Sequencer.prototype.GetExitAction=Sequencer_GetExitAction;
Sequencer.prototype.IsActivityLastOverall=Sequencer_IsActivityLastOverall;
Sequencer.prototype.IsActivityFirstOverall=Sequencer_IsActivityFirstOverall;
Sequencer.prototype.EvaluatePossibleNavigationRequests=Sequencer_EvaluatePossibleNavigationRequests;
Sequencer.prototype.InitializePossibleNavigationRequestAbsolutes=Sequencer_InitializePossibleNavigationRequestAbsolutes;
Sequencer.prototype.ContentDeliveryEnvironmentActivityDataSubProcess=Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess;
Sequencer.prototype.LogSeq=Sequencer_LogSeq;
Sequencer.prototype.LogSeqAudit=Sequencer_LogSeqAudit;
Sequencer.prototype.LogSeqReturn=Sequencer_LogSeqReturn;
Sequencer.prototype.WriteHistoryLog=Sequencer_WriteHistoryLog;
Sequencer.prototype.WriteHistoryReturnValue=Sequencer_WriteHistoryReturnValue;
function Sequencer_OverallSequencingProcess(){
try{
var _81=this.LogSeqAudit("`1022`");
this.ExceptionText="";
this.LogSeq("`1270`",_81);
this.CurrentActivity.TransferRteDataToActivity();
if((this.CurrentActivity.LearningObject.ScormType===SCORM_TYPE_ASSET)&&this.CurrentActivity.WasLaunchedThisSession()){
this.LogSeq("`775`",_81);
this.CurrentActivity.SetAttemptProgressStatus(true);
this.CurrentActivity.SetAttemptCompletionStatus(true);
}
this.LogSeq("`1526`",_81);
this.RollupData(this.CurrentActivity);
this.LogSeq("`1392`",_81);
if(Control.Package.Properties.FirstScoIsPretest===true){
if(this.IsActivityFirstOverall(this.CurrentActivity)){
if(this.CurrentActivity.IsSatisfied()===true){
this.LogSeq("`1023`",_81);
this.MarkAllActivitiesComplete();
}
}
}
if(this.NavigationRequest===null){
var _82=this.GetExitAction(this.GetCurrentActivity(),false,_81);
this.LogSeq("`1234`"+_82,_81);
var _83="";
if(_82==EXIT_ACTION_EXIT_CONFIRMATION||_82==EXIT_ACTION_DISPLAY_MESSAGE){
var _84=Control.Activities.GetRootActivity();
var _85=(_84.IsCompleted()||_84.IsSatisfied());
if(_85===true){
_83=IntegrationImplementation.GetString("The course is now complete. Please make a selection to continue.");
}else{
_83=IntegrationImplementation.GetString("Please make a selection to continue.");
}
}
switch(_82){
case (EXIT_ACTION_EXIT_NO_CONFIRMATION):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
break;
case (EXIT_ACTION_EXIT_CONFIRMATION):
if(confirm(IntegrationImplementation.GetString("Would you like to exit the course now?"))){
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
}else{
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_83);
}
break;
case (EXIT_ACTION_GO_TO_NEXT_SCO):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_CONTINUE,null,"");
break;
case (EXIT_ACTION_DISPLAY_MESSAGE):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_83);
break;
case (EXIT_ACTION_DO_NOTHING):
this.NavigationRequest=null;
break;
case (EXIT_ACTION_REFRESH_PAGE):
Control.RefreshPage();
break;
}
}
if(this.NavigationRequest==null){
this.LogSeqReturn("`1398`",_81);
return;
}
switch(this.NavigationRequest.Type){
case NAVIGATION_REQUEST_CONTINUE:
this.DoContinue();
break;
case NAVIGATION_REQUEST_PREVIOUS:
this.DoPrevious();
break;
case NAVIGATION_REQUEST_CHOICE:
this.DoChoice(this.NavigationRequest.TargetActivity);
break;
case NAVIGATION_REQUEST_EXIT:
break;
case NAVIGATION_REQUEST_EXIT_ALL:
Control.ExitScormPlayer("Sequencer");
break;
case NAVIGATION_REQUEST_SUSPEND_ALL:
Control.ExitScormPlayer("Sequencer");
break;
case NAVIGATION_REQUEST_ABANDON:
break;
case NAVIGATION_REQUEST_ABANDON_ALL:
Control.ExitScormPlayer("Sequencer");
break;
case NAVIGATION_REQUEST_DISPLAY_MESSAGE:
break;
case NAVIGATION_REQUEST_EXIT_PLAYER:
Control.ExitScormPlayer("Sequencer");
break;
default:
Debug.AssertError("Recieved an unrecognized navigation request - "+this.NavigationRequest);
break;
}
this.LogSeqReturn("",_81);
}
catch(error){
var _86="Error in OverallSequencingProcess for SCORM 1.1 / SCORM 1.2: ";
if(typeof RegistrationToDeliver!="undefined"&&typeof RegistrationToDeliver.Id!="undefined"){
_86=_86+"RegistrationId: "+RegistrationToDeliver.Id+", ";
}
Control.Comm.LogOnServer(_86,error);
throw error;
}
}
function Sequencer_SetSuspendedActivity(_87){
this.SuspendedActivity=_87;
}
function Sequencer_GetSuspendedActivity(){
return this.SuspendedActivity;
}
function Sequencer_Start(){
var _88;
if(this.SuspendedActivity!==null){
_88=this.SuspendedActivity;
}else{
_88=this.GetFirstIncompleteActivity(this.Activities.SortedActivityList);
}
if(Control.Package.Properties.AlwaysFlowToFirstSco===true||Control.Package.Properties.ShowCourseStructure==false){
this.DeliverThisActivity(_88);
}else{
var _89=IntegrationImplementation.GetString("Please make a selection to continue.");
this.CurrentActivity=_88;
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_89);
}
}
function Sequencer_InitialRandomizationAndSelection(){
}
function Sequencer_GetCurrentActivity(){
return this.CurrentActivity;
}
function Sequencer_GetExceptionText(){
return this.ExceptionText;
}
function Sequencer_GetExitAction(_8a,_8b,_8c){
var _8d=_8a.RunTime.Exit;
if(_8d==SCORM_EXIT_UNKNOWN){
_8d=SCORM_EXIT_NORMAL;
}
var _8e=this.IsActivityLastOverall(_8a,_8c);
var _8f;
if(_8b){
_8f=((_8a.RunTime.CompletionStatus==SCORM_STATUS_COMPLETED)||(_8a.RunTime.SuccessStatus==SCORM_STATUS_PASSED));
}else{
_8f=(_8a.IsCompleted()==true||_8a.IsSatisfied()==true);
}
var _90=Control.Activities.GetRootActivity();
var _91=(_90.IsCompleted()==true||_90.IsSatisfied()==true);
var _92;
if(_8e){
if(_91===true){
switch(_8d){
case SCORM_EXIT_NORMAL:
_8c.write("Using finalScoCourseSatisfiedNormalExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseSatisfiedNormalExitAction;
break;
case SCORM_EXIT_SUSPEND:
_8c.write("Using finalScoCourseSatisfiedSuspendExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseSatisfiedSuspendExitAction;
break;
case SCORM_EXIT_TIME_OUT:
_8c.write("Using finalScoCourseSatisfiedTimeoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseSatisfiedTimeoutExitAction;
break;
case SCORM_EXIT_LOGOUT:
_8c.write("Using finalScoCourseSatisfiedLogoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseSatisfiedLogoutExitAction;
break;
}
}else{
switch(_8d){
case SCORM_EXIT_NORMAL:
_8c.write("Using finalScoCourseNotSatisfiedNormalExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseNotSatisfiedNormalExitAction;
break;
case SCORM_EXIT_SUSPEND:
_8c.write("Using finalScoCourseNotSatisfiedSuspendExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseNotSatisfiedSuspendExitAction;
break;
case SCORM_EXIT_TIME_OUT:
_8c.write("Using finalScoCourseNotSatisfiedTimeoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseNotSatisfiedTimeoutExitAction;
break;
case SCORM_EXIT_LOGOUT:
_8c.write("Using finalScoCourseNotSatisfiedLogoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.FinalScoCourseNotSatisfiedLogoutExitAction;
break;
}
}
}else{
if(_8f===true){
switch(_8d){
case SCORM_EXIT_NORMAL:
_8c.write("Using intermediateScoSatisfiedNormalExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoSatisfiedNormalExitAction;
break;
case SCORM_EXIT_SUSPEND:
_8c.write("Using intermediateScoSatisfiedSuspendExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoSatisfiedSuspendExitAction;
break;
case SCORM_EXIT_TIME_OUT:
_8c.write("Using intermediateScoSatisfiedTimeoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoSatisfiedTimeoutExitAction;
break;
case SCORM_EXIT_LOGOUT:
_8c.write("Using intermediateScoSatisfiedLogoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoSatisfiedLogoutExitAction;
break;
}
}else{
switch(_8d){
case SCORM_EXIT_NORMAL:
_8c.write("Using intermediateScoNotSatisfiedNormalExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoNotSatisfiedNormalExitAction;
break;
case SCORM_EXIT_SUSPEND:
_8c.write("Using intermediateScoNotSatisfiedSuspendExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoNotSatisfiedSuspendExitAction;
break;
case SCORM_EXIT_TIME_OUT:
_8c.write("Using intermediateScoNotSatisfiedTimeoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoNotSatisfiedTimeoutExitAction;
break;
case SCORM_EXIT_LOGOUT:
_8c.write("Using intermediateScoNotSatisfiedLogoutExitAction parameter");
_92=RegistrationToDeliver.Package.Properties.IntermediateScoNotSatisfiedLogoutExitAction;
break;
}
}
}
return _92;
}
Sequencer.prototype.LogSeq=Sequencer_LogSeq;
Sequencer.prototype.LogSeqAudit=Sequencer_LogSeqAudit;
Sequencer.prototype.CanDeliverThisActivity=Sequencer_CanDeliverThisActivity;
Sequencer.prototype.DeliverThisActivity=Sequencer_DeliverThisActivity;
Sequencer.prototype.GetFirstIncompleteActivity=Sequencer_GetFirstIncompleteActivity;
Sequencer.prototype.DoContinue=Sequencer_DoContinue;
Sequencer.prototype.DoPrevious=Sequencer_DoPrevious;
Sequencer.prototype.DoChoice=Sequencer_DoChoice;
Sequencer.prototype.RollupData=Sequencer_RollupData;
Sequencer.prototype.ActivityRollupProcess=Sequencer_ActivityRollupProcess;
Sequencer.prototype.MarkAllActivitiesComplete=Sequencer_MarkAllActivitiesComplete;
function Sequencer_CanDeliverThisActivity(_93,_94){
if(!this.PrerequisitesEvaluator.Evaluate(_93,_94)){
return false;
}
return true;
}
function Sequencer_DeliverThisActivity(_95){
if(Control.Package.Properties.ScoLaunchType!==LAUNCH_TYPE_POPUP_AFTER_CLICK&&Control.Package.Properties.ScoLaunchType!==LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR){
this.ContentDeliveryEnvironmentActivityDataSubProcess(_95);
}
this.CurrentActivity=_95;
var i;
var _97=this.Activities.SortedActivityList;
for(i=0;i<_97.length;i++){
_97[i].SetActive(false);
}
var _98=this.Activities.GetActivityPath(_95,true);
for(i=0;i<_98.length;i++){
_98[i].SetActive(true);
}
Control.DeliverActivity(_95);
}
function Sequencer_GetFirstIncompleteActivity(_99){
var _9a=null;
var _9b;
var _9c;
for(var i=0;i<_99.length;i++){
if(_99[i].IsDeliverable()===true){
if(_9a===null){
_9a=_99[i];
}
_9b=_99[i].IsSatisfied();
_9c=_99[i].IsCompleted();
if(_9c==false||_9c==RESULT_UNKNOWN||(_9c==true&&_9b==false)){
if(_99[i].RunTime!==null&&_99[i].RunTime.CompletionStatus!=SCORM_STATUS_BROWSED){
return _99[i];
}
}
}
}
if(_9a!==null){
return _9a;
}else{
Debug.AssertError("No Deliverable Activities Found");
}
return true;
}
function Sequencer_DoContinue(){
if(this.AtEndOfCourse===true){
return;
}
var _9e;
if(this.AtStartOfCourse===true){
_9e=-1;
}else{
_9e=this.Activities.GetSortedIndexOfActivity(this.CurrentActivity);
}
var _9f=null;
for(var i=(_9e+1);i<this.Activities.SortedActivityList.length;i++){
if(this.Activities.SortedActivityList[i].IsDeliverable()===true){
_9f=this.Activities.SortedActivityList[i];
break;
}
}
if(_9f!==null){
if(!this.CanDeliverThisActivity(_9f)){
this.ExceptionText=this.PrerequisitesEvaluator.GetMissingPrerequisitesHtml();
return;
}
this.AtEndOfCourse=false;
this.AtStartOfCourse=false;
this.DeliverThisActivity(_9f);
}else{
this.AtEndOfCourse=true;
this.ExceptionText=IntegrationImplementation.GetString("You have reached the end of the course.");
}
}
function Sequencer_DoPrevious(){
if(this.AtStartOfCourse===true){
return;
}
var _a1;
if(this.AtEndOfCourse===true){
_a1=this.Activities.SortedActivityList.length;
}else{
_a1=this.Activities.GetSortedIndexOfActivity(this.CurrentActivity);
}
var _a2=null;
for(var i=(_a1-1);i>=0;i--){
if(this.Activities.SortedActivityList[i].IsDeliverable()===true){
_a2=this.Activities.SortedActivityList[i];
break;
}
}
if(_a2!==null){
if(!this.CanDeliverThisActivity(_a2)){
this.ExceptionText=this.PrerequisitesEvaluator.GetMissingPrerequisitesHtml();
return;
}
this.AtEndOfCourse=false;
this.AtStartOfCourse=false;
this.DeliverThisActivity(_a2);
}else{
this.AtStartOfCourse=true;
this.ExceptionText=IntegrationImplementation.GetString("You have reached the beginning of the course.");
}
}
function Sequencer_DoChoice(_a4){
var _a5=null;
_a5=this.Activities.GetActivityFromIdentifier(_a4);
if(_a5!==null){
if(_a5.IsDeliverable()===true){
if(!this.CanDeliverThisActivity(_a5)){
this.ExceptionText=this.PrerequisitesEvaluator.GetMissingPrerequisitesHtml();
return;
}
this.AtEndOfCourse=false;
this.AtStartOfCourse=false;
this.DeliverThisActivity(_a5);
}else{
Debug.AssertError("Chosen activity is not deliverable.");
}
}else{
}
}
function Sequencer_RollupData(_a6){
var _a7=this.Activities.GetActivityPath(_a6);
for(var i=0;i<_a7.length;i++){
this.ActivityRollupProcess(_a7[i]);
}
}
function Sequencer_ActivityRollupProcess(_a9){
var _aa=_a9.GetChildren();
var _ab=false;
var _ac=true;
var _ad=true;
var _ae=true;
var _af=true;
var _b0=true;
var _b1;
var _b2;
var _b3;
var _b4;
var _b5;
var _b6;
var _b7=0;
var _b8=0;
var _b9=null;
var _ba;
var _bb=0;
var _bc;
var _bd;
var _be;
var _bf;
var _c0;
var _c1;
var _c2;
var _c3;
var i;
var _c5=_a9.GetPrimaryObjective();
if(!this.LookAhead&&_a9.IsTheRoot()){
_bc=_c5.GetProgressStatus(_a9,false);
_bd=_c5.GetSatisfiedStatus(_a9,false);
_be=_a9.GetAttemptProgressStatus();
_bf=_a9.GetAttemptCompletionStatus();
}
_c5.SetProgressStatus(false,false,_a9);
_c5.SetSatisfiedStatus(false,false,_a9);
_c5.SetMeasureStatus(false,_a9);
_a9.SetAttemptProgressStatus(false);
_a9.SetAttemptCompletionStatus(false);
var _c6;
for(i=0;i<_aa.length;i++){
_b1=(_aa[i].IsAttempted()===true);
_b2=_aa[i].IsSatisfied();
_b3=(_b2===false&&_b1===true);
_b4=_aa[i].IsCompleted();
_b5=(_b4===false||_b1===true);
_b6=(_b4===true&&(_b3!==true));
_ab=(_ab===true||_b1===true);
_ad=(_ad===true&&(_b2===true));
_ac=(_ac===true&&_b3===true);
_af=(_af===true&&(_b4===true));
_ae=(_ae===true&&_b5===true);
_b0=(_b0===true&&(_b6===true));
_c6=_aa[i].GetPrimaryObjective();
if(_c6.GetMeasureStatus(_aa[i],false)===true){
var _c7=_c6.GetNormalizedMeasure(_aa[i],false);
_bb=_c7;
_b7++;
if(_c7>0){
_b8++;
}
if(_b9===null&&Control.Package.Properties.ScoreRollupMode!=SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS_WITH_NONZERO_SCORES){
_b9=0;
}
if(_c7>0){
_b9=_b9+_c7;
}
}else{
_bb=0;
}
}
if(!_a9.IsALeaf()){
_a9.RollupDurations();
}
if(_b9!==null){
switch(Control.Package.Properties.ScoreRollupMode){
case (SCORE_ROLLUP_METHOD_SCORE_PROVIDED_BY_COURSE):
_ba=_b9;
break;
case (SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS):
_ba=(_b9/_aa.length);
break;
case (SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS_WITH_SCORES):
_ba=(_b9/_b7);
break;
case (SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS_WITH_NONZERO_SCORES):
_ba=(_b9/_b8);
break;
case (SCORE_ROLLUP_METHOD_FIXED_AVERAGE):
if(_a9.IsTheRoot()){
_b9=0;
for(i=0;i<Control.Activities.ActivityList.length;i++){
var rt=Control.Activities.ActivityList[i].RunTime;
if(rt!==null&&rt!==undefined&&rt.ScoreScaled!==null){
_b9+=rt.ScoreScaled;
}
}
}
_ba=(_b9/Control.Package.Properties.NumberOfScoringObjects);
break;
case (SCORE_ROLLUP_METHOD_LAST_SCO_SCORE):
_ba=_bb;
break;
default:
Debug.AssertError("Invalid Score Rollup Mode Detected-"+Control.Package.Properties.ScoreRollupMode);
break;
}
_ba=RoundToPrecision(_ba,7);
_c5.SetMeasureStatus(true,_a9);
_c5.SetNormalizedMeasure(_ba,_a9);
}
if(_ab){
_a9.SetAttemptProgressStatus(true);
_a9.SetActivityProgressStatus(true);
}
if(_ae===true||_ab){
_a9.SetAttemptProgressStatus(true);
_a9.SetAttemptCompletionStatus(false);
}
var _c9=(Control.Package.Properties.ApplyRollupStatusToSuccess===true);
switch(Control.Package.Properties.StatusRollupMode){
case (STATUS_ROLLUP_METHOD_STATUS_PROVIDED_BY_COURSE):
if(_af===true){
_a9.SetAttemptProgressStatus(true);
_a9.SetAttemptCompletionStatus(true);
if(_c9){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}
}
break;
case (STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_COMPLETE):
if(_af===true||_ad===true||_ac===true){
_a9.SetAttemptProgressStatus(true);
if(_ac===true&&Control.Package.Properties.CompletionStatOfFailedSuccessStat!==SCORM_STATUS_UNKNOWN){
_a9.SetAttemptCompletionStatus(_af);
if(_c9){
if(_af){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}else{
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(false,false,_a9);
}
}
}else{
_a9.SetAttemptCompletionStatus(true);
if(_c9){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}
}
}
break;
case (STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_COMPLETE_AND_NOT_FAILED):
if(_b0===true){
_a9.SetAttemptProgressStatus(true);
_a9.SetAttemptCompletionStatus(true);
if(_c9){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}
}
break;
case (STATUS_ROLLUP_METHOD_COMPLETE_WHEN_THRESHOLD_SCORE_IS_MET):
if(_ba>=Control.Package.Properties.ThresholdScore){
_a9.SetAttemptProgressStatus(true);
_a9.SetAttemptCompletionStatus(true);
if(_c9){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}
}
break;
case (STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_COMPLETE_AND_THRESHOLD_SCORE_IS_MET):
if((_af===true||_ad===true||_ac===true)&&(_ba>=Control.Package.Properties.ThresholdScore)){
_a9.SetAttemptProgressStatus(true);
if(_ac===true&&Control.Package.Properties.CompletionStatOfFailedSuccessStat!==SCORM_STATUS_UNKNOWN){
_a9.SetAttemptCompletionStatus(_af);
if(_c9){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(false,false,_a9);
}
}else{
_a9.SetAttemptCompletionStatus(true);
if(_c9){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}
}
}
break;
case (STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_ARE_PASSED):
if(_ad===true){
_a9.SetAttemptProgressStatus(true);
_a9.SetAttemptCompletionStatus(true);
if(_c9){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}
}
break;
default:
Debug.AssertError("Invalid Status Rollup Mode Detected-"+Control.Package.Properties.StatusRollupMode);
break;
}
if(!_c9){
if(_ac===true){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(false,false,_a9);
}
if(_ad===true){
_c5.SetProgressStatus(true,false,_a9);
_c5.SetSatisfiedStatus(true,false,_a9);
}
}
if(!this.LookAhead&&_a9.IsTheRoot()){
_c0=_c5.GetProgressStatus(_a9,false);
_c1=_c5.GetSatisfiedStatus(_a9,false);
_c2=_a9.GetAttemptProgressStatus();
_c3=_a9.GetAttemptCompletionStatus();
if(_c2!=_be||_c3!=_bf){
var _ca=(_c2?(_c3?SCORM_STATUS_COMPLETED:SCORM_STATUS_INCOMPLETE):SCORM_STATUS_NOT_ATTEMPTED);
this.WriteHistoryLog("",{ev:"Rollup Completion",v:_ca,ai:_a9.ItemIdentifier});
}
if(_c0!=_bc||_c1!=_bd){
var _cb=(_c0?(_c1?SCORM_STATUS_PASSED:SCORM_STATUS_FAILED):SCORM_STATUS_UNKNOWN);
this.WriteHistoryLog("",{ev:"Rollup Satisfaction",v:_cb,ai:_a9.ItemIdentifier});
}
}
}
function Sequencer_IsActivityLastOverall(_cc){
if(this.Activities.SortedActivityList[this.Activities.SortedActivityList.length-1]==_cc){
return true;
}else{
return false;
}
}
function Sequencer_IsActivityFirstOverall(_cd){
var _ce;
var _cf=this.Activities.SortedActivityList;
for(var i=0;i<_cf.length;i++){
if(_cf[i].IsDeliverable()===true){
if(_cd==_cf[i]){
_ce=true;
}else{
_ce=false;
}
}
}
return _ce;
}
function Sequencer_EvaluatePossibleNavigationRequests(_d1){
var _d2=Control.Package.Properties;
this.CurrentActivity.TransferRteDataToActivity();
this.RollupData(this.CurrentActivity);
var _d3=false;
var _d4=false;
var _d5=this.CurrentActivity.GetPreviousActivityPreorder();
if(_d5!=null){
_d4=this.PrerequisitesEvaluator.Evaluate(_d5,PREREQ_USE_LOOKAHEAD);
}
var _d6=this.CurrentActivity.GetNextActivityPreorder();
if(_d6!=null){
_d3=this.PrerequisitesEvaluator.Evaluate(_d6,PREREQ_USE_LOOKAHEAD);
}
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_START].WillSucceed=true;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_RESUME_ALL].WillSucceed=true;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed=(this.AtEndOfCourse===false&&_d2.EnableFlowNav===true)&&_d3;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed=(this.AtStartOfCourse===false&&_d2.EnableFlowNav===true)&&_d4;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed=true;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT_ALL].WillSucceed=true;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_SUSPEND_ALL].WillSucceed=true;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON].WillSucceed=true;
_d1[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON_ALL].WillSucceed=true;
var _d7;
var _d8;
for(var i=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;i<_d1.length;i++){
_d7=this.Activities.GetActivityFromIdentifier(_d1[i].TargetActivityItemIdentifier);
_d8=this.PrerequisitesEvaluator.Evaluate(_d7,PREREQ_USE_LOOKAHEAD);
_d1[i].WillSucceed=(_d7.IsDeliverable()&&_d2.EnableChoiceNav===true)&&_d8;
}
return _d1;
}
function Sequencer_InitializePossibleNavigationRequestAbsolutes(_da,_db,_dc){
}
function Sequencer_MarkAllActivitiesComplete(){
var _dd=this.Activities.SortedActivityList;
var _de;
for(var i=0;i<_dd.length;i++){
_de=_dd[i].GetPrimaryObjective();
_dd[i].SetAttemptProgressStatus(true);
_dd[i].SetAttemptCompletionStatus(true);
_de.SetProgressStatus(true,false,_dd[i]);
_de.SetSatisfiedStatus(true,false,_dd[i]);
}
}
function Sequencer_LogSeq(str,_e1){
str=str+"";
if(this.LookAhead===true){
return Debug.WriteLookAheadDetailed(str,_e1);
}else{
return Debug.WriteSequencingDetailed(str,_e1);
}
}
function Sequencer_LogSeqAudit(str,_e3){
str=str+"";
if(this.LookAhead===true){
return Debug.WriteLookAheadAudit(str,_e3);
}else{
return Debug.WriteSequencingAudit(str,_e3);
}
}
function Sequencer_LogSeqReturn(str,_e5){
if(_e5===null||_e5===undefined){
Debug.AssertError("`1551`");
}
str=str+"";
if(this.LookAhead===true){
return _e5.setReturn(str);
}else{
return _e5.setReturn(str);
}
}
function Sequencer_WriteHistoryLog(str,_e7){
HistoryLog.WriteEventDetailed(str,_e7);
}
function Sequencer_WriteHistoryReturnValue(str,_e9){
HistoryLog.WriteEventDetailedReturnValue(str,_e9);
}
function Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess(_ea){
var _eb=ConvertDateToIso8601String(new Date());
var _ec;
if(_ea.IsSuspended()===false){
_ea.IncrementAttemptCount();
_ea.SetActivityProgressStatus(true);
_ec={ev:"AttemptStart",an:_ea.GetAttemptCount(),ai:_ea.ItemIdentifier,at:_ea.LearningObject.Title};
this.WriteHistoryLog("",_ec);
_ea.SetAttemptStartTimestampUtc(_eb);
_ea.SetAttemptAbsoluteDuration("PT0H0M0S");
_ea.SetAttemptExperiencedDurationTracked("PT0H0M0S");
_ea.SetAttemptExperiencedDurationReported("PT0H0M0S");
}
this.SuspendedActivity=null;
var _ed=this.Activities.GetActivityPath(_ea,true);
for(var i=0;i<_ed.length;i++){
if(_ed[i].GetAttemptCount()==0){
_ed[i].SetActivityProgressStatus(true);
_ed[i].IncrementAttemptCount();
_ec={ev:"AttemptStart",an:_ed[i].GetAttemptCount(),ai:_ed[i].ItemIdentifier,at:_ed[i].LearningObject.Title};
this.WriteHistoryLog("",_ec);
_ed[i].SetAttemptStartTimestampUtc(_eb);
_ed[i].SetAttemptAbsoluteDuration("PT0H0M0S");
_ed[i].SetAttemptExperiencedDurationTracked("PT0H0M0S");
_ed[i].SetAttemptExperiencedDurationReported("PT0H0M0S");
}
}
}
function PrerequisitesEvaluator(_ef){
this.Sequencer=_ef;
this.activityMap={};
this.cachedActivityStatus={};
this.currentLookAhead=false;
this.currentLog=null;
this.missingPrerequisites=[];
var _f0={};
var _f1={};
function walkActivityTree(_f2){
_f0[_f2.ItemIdentifier]=_f2;
_f1[_f2.ItemIdentifier]=null;
var _f3=_f2.GetChildren();
for(var i=0;i<_f3.length;i++){
walkActivityTree(_f3[i]);
}
}
walkActivityTree(_ef.Activities.ActivityTree);
this.activityMap=_f0;
this.cachedActivityStatus=_f1;
}
var PREREQ_USE_LOOKAHEAD=true;
PrerequisitesEvaluator.prototype.IsLeftAssociative=PrerequisitesEvaluator_IsLeftAssociative;
PrerequisitesEvaluator.prototype.OperatorPrecedence=PrerequisitesEvaluator_OperatorPrecedence;
PrerequisitesEvaluator.prototype.ArgCount=PrerequisitesEvaluator_ArgCount;
PrerequisitesEvaluator.prototype.IsOperator=PrerequisitesEvaluator_IsOperator;
PrerequisitesEvaluator.prototype.IsBoolean=PrerequisitesEvaluator_IsBoolean;
PrerequisitesEvaluator.prototype.IsIdentifier=PrerequisitesEvaluator_IsIdentifier;
PrerequisitesEvaluator.prototype.IsSet=PrerequisitesEvaluator_IsSet;
PrerequisitesEvaluator.prototype.EvaluateOperand=PrerequisitesEvaluator_EvaluateOperand;
PrerequisitesEvaluator.prototype.EvaluateOperation=PrerequisitesEvaluator_EvaluateOperation;
PrerequisitesEvaluator.prototype.TokenizeExpression=PrerequisitesEvaluator_TokenizeExpression;
PrerequisitesEvaluator.prototype.DistributeNotOperator=PrerequisitesEvaluator_DistributeNotOperator;
PrerequisitesEvaluator.prototype.ToPostfix=PrerequisitesEvaluator_ToPostfix;
PrerequisitesEvaluator.prototype.Compute=PrerequisitesEvaluator_Compute;
PrerequisitesEvaluator.prototype.ClearActivityStatusCache=PrerequisitesEvaluator_ClearActivityStatusCache;
PrerequisitesEvaluator.prototype.Evaluate=PrerequisitesEvaluator_Evaluate;
PrerequisitesEvaluator.prototype.CheckActivityStatus=PrerequisitesEvaluator_CheckActivityStatus;
PrerequisitesEvaluator.prototype.ComputeActivityStatus=PrerequisitesEvaluator_ComputeActivityStatus;
PrerequisitesEvaluator.prototype.GetMissingPrerequisitesHtml=PrerequisitesEvaluator_GetMissingPrerequisitesHtml;
function PrerequisitesEvaluator_IsLeftAssociative(c){
switch(c){
case "&":
case "|":
case "*":
case "=":
case "<>":
return true;
case "~":
return false;
}
return false;
}
function PrerequisitesEvaluator_OperatorPrecedence(c){
switch(c){
case "~":
return 4;
case "*":
return 3;
case "=":
case "<>":
return 2;
case "&":
case "|":
return 1;
}
return 0;
}
function PrerequisitesEvaluator_ArgCount(c){
switch(c){
case "&":
case "|":
case "*":
case "=":
return 2;
case "~":
return 1;
}
return 0;
}
function PrerequisitesEvaluator_IsOperator(c){
switch(c){
case "&":
case "|":
case "~":
case "=":
case "*":
return true;
}
return false;
}
function PrerequisitesEvaluator_IsBoolean(val){
return val===true||val===false;
}
function PrerequisitesEvaluator_IsIdentifier(val){
if(typeof val=="string"){
return val.match(new RegExp("[-.:_A-Za-z0-9]+"));
}else{
return false;
}
}
function PrerequisitesEvaluator_IsSet(c){
return c=="{";
}
function PrerequisitesEvaluator_EvaluateOperand(_fc,_fd){
if(this.IsBoolean(_fc)){
return _fc;
}else{
if(this.IsIdentifier(_fc)){
if(this.cachedActivityStatus[_fc]===undefined){
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Operand \"`1692`\" of operator "+_fd+" is neither a boolean value, nor a known activity identifier",this.currentLog);
}
return this.CheckActivityStatus(_fc,null);
}else{
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Operand \"`1692`\" of operator "+_fd+" is neither a boolean value, nor a known activity identifier",this.currentLog);
}
}
return false;
}
function PrerequisitesEvaluator_EvaluateOperation(_fe,_ff,_100){
var op1=null;
var op2=null;
var _103;
var _104;
var _105;
switch(_100){
case "&":
op1=this.EvaluateOperand(_fe,"&");
op2=this.EvaluateOperand(_ff,"&");
if(!(op1&&op2)){
if(!op1&&this.IsIdentifier(_fe)&&!this.IsBoolean(_fe)){
this.missingPrerequisites.push("Activity \""+this.activityMap[_fe].GetTitle()+"\" must be completed or passed.");
}
if(!op2&&this.IsIdentifier(_ff)&&!this.IsBoolean(_ff)){
this.missingPrerequisites.push("Activity \""+this.activityMap[_ff].GetTitle()+"\" must be completed or passed.");
}
}
return op1&&op2;
case "|":
op1=this.EvaluateOperand(_fe,"|");
op2=this.EvaluateOperand(_ff,"|");
if(!(op1||op2)){
if((this.IsIdentifier(_fe)&&!this.IsBoolean(_fe))&&(this.IsIdentifier(_ff)&&!this.IsBoolean(_ff))){
this.missingPrerequisites.push("Either activity \""+this.activityMap[_fe].GetTitle()+"\" or activity \""+this.activityMap[_ff].GetTitle()+"\" must be completed or passed.");
return false;
}
if(this.IsIdentifier(_fe)&&!this.IsBoolean(_fe)){
this.missingPrerequisites.push("Activity \""+this.activityMap[_fe].GetTitle()+"\" may also be required to be completed or passed.");
}
if(this.IsIdentifier(_ff)&&!this.IsBoolean(_ff)){
this.missingPrerequisites.push("Activity \""+this.activityMap[_ff].GetTitle()+"\" may also be required to be completed or passed.");
}
}
return op1||op2;
case "*":
return _fe>=_ff;
case "=":
_103=null;
_104=null;
if(this.cachedActivityStatus[_fe]!==undefined){
_103=_fe;
_104=_ff;
}else{
if(this.cachedActivityStatus[_ff]!==undefined){
_103=_ff;
_104=_fe;
}else{
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Neither operand of equals operator in prerequisites expression is a known activity identifier.",this.currentLog);
}
}
_105=this.CheckActivityStatus(_103,_104);
if(!_105){
this.missingPrerequisites.push("Activity \""+this.activityMap[_103].GetTitle()+"\" must be "+_104+".");
}
return _105;
case "<>":
_103=null;
_104=null;
if(this.cachedActivityStatus[_fe]!==undefined){
_103=_fe;
_104=_ff;
}else{
if(this.cachedActivityStatus[_ff]!==undefined){
_103=_ff;
_104=_fe;
}else{
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Neither operand of equals operator in prerequisites expression is a known activity identifier.",this.currentLog);
}
}
_105=this.CheckActivityStatus(_103,_104);
if(_105){
this.missingPrerequisites.push("Activity \""+this.activityMap[_103].GetTitle()+"\" must not be "+_104+".");
}
return !_105;
case "~":
op1=this.EvaluateOperand(_fe,"~");
return !op1;
}
return false;
}
function PrerequisitesEvaluator_TokenizeExpression(_106){
var _107=[];
var _108="";
var _109=false;
for(var i=0;i<_106.length;i++){
var c=_106.charAt(i);
if(c=="\""){
_109=!_109;
}
if(_109&&c!="\""){
_108+=c;
continue;
}
if(!this.IsIdentifier(c)&&_108!=""){
_107.push(_108);
_108="";
}
if(this.IsIdentifier(c)){
_108+=c;
}else{
if(this.IsOperator(c)||c=="("||c==")"||c=="{"||c=="}"||c==","){
_107.push(c);
}else{
if(c=="<"){
if(_106.charAt(i+1)==">"){
_107.push("<>");
i++;
}else{
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Mismatched \"<\" character.",this.currentLog);
}
}
}
}
}
if(_108!=""){
_107.push(_108);
}
return _107;
}
function PrerequisitesEvaluator_DistributeNotOperator(_10c,_10d,prev){
var t=_10c.pop();
if(t=="&"){
_10d.push("|");
this.DistributeNotOperator(_10c,_10d,t);
this.DistributeNotOperator(_10c,_10d,t);
}else{
if(t=="|"){
_10d.push("&");
this.DistributeNotOperator(_10c,_10d,t);
this.DistributeNotOperator(_10c,_10d,t);
}else{
if(t=="="){
_10d.push("<>");
this.DistributeNotOperator(_10c,_10d,t);
this.DistributeNotOperator(_10c,_10d,t);
}else{
if(t=="<>"){
_10d.push("=");
this.DistributeNotOperator(_10c,_10d,t);
this.DistributeNotOperator(_10c,_10d,t);
}else{
if(t=="~"){
var tmp=[];
this.DistributeNotOperator(_10c,tmp,t);
while(tmp.length>0){
_10c.push(tmp.pop());
}
this.DistributeNotOperator(_10c,_10d,t);
}else{
if(prev!="~"&&prev!="="&&prev!="<>"){
_10d.push("~");
}
_10d.push(t);
}
}
}
}
}
}
function PrerequisitesEvaluator_ToPostfix(_111){
var _112=[];
var _113=[];
var _114=[];
var c;
var cur;
for(var i=0;i<_111.length;i++){
cur=_111[i];
if(this.IsIdentifier(cur)){
_112.push(cur);
}else{
if(this.IsSet(cur)){
_113.push(cur);
_114.push(1);
}else{
if(cur==","){
var _118=false;
while(_113.length>0){
c=_113[_113.length-1];
if(c=="{"){
_118=true;
break;
}else{
_112.push(_113.pop());
}
}
if(!_118){
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Separator or set symbol mismatched.",this.currentLog);
}
_114[_114.length-1]++;
}else{
if(this.IsOperator(cur)){
while(_113.length>0){
var prev=_113[_113.length-1];
if(this.IsOperator(prev)&&((this.IsLeftAssociative(cur)&&(this.OperatorPrecedence(cur)<=this.OperatorPrecedence(prev)))||(!this.IsLeftAssociative(cur)&&(this.OperatorPrecedence(cur)<this.OperatorPrecedence(prev))))){
_112.push(_113.pop());
}else{
break;
}
}
_113.push(cur);
}else{
if(cur=="("){
_113.push(cur);
}else{
if(cur==")"){
while(_113[_113.length-1]!="("){
if(_113.length==0){
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Mismatched parentheses in expression.",this.currentLog);
}
_112.push(_113.pop());
}
_113.pop();
}else{
if(cur=="}"){
_112.push(_114.pop());
}
}
}
}
}
}
}
}
if(identifier!=""){
_112.push(identifier);
}
while(_113.length>0){
c=_113.pop();
if(c=="("||c==")"){
this.Sequencer.LogSeq("Error evaluating prerequisites, invalid syntax - Mismatched parentheses in expression.",this.currentLog);
}
_112.push(c);
}
return _112;
}
function PrerequisitesEvaluator_Compute(_11a){
var _11b=[];
for(var i=0;i<_11a.length;i++){
var c=_11a[i];
if(this.IsIdentifier(c)){
_11b.push(c);
}else{
if(this.IsOperator(c)){
var args=this.ArgCount(c);
var _11f="";
if(args==1){
_11f=this.EvaluateOperation(_11b.pop(),null,c);
}else{
_11f=this.EvaluateOperation(_11b.pop(),_11b.pop(),c);
}
_11b.push(_11f);
}else{
if(this.IsSet(c)){
var _120=_11b.pop();
var _121=0;
for(var j=0;j<_120;j++){
var _123=_11b.pop();
if(this.EvaluateOperand(_123)){
_121++;
}
}
_11b.push(_121);
}
}
}
}
var cur=_11b.pop();
if(this.IsIdentifier(cur)){
if(this.EvaluateOperand(cur)){
return true;
}else{
if(this.activityMap[cur]===undefined){
this.Sequencer.LogSeq("Error evaluating prerequisites - Unknown activity "+cur,this.currentLog);
}else{
this.missingPrerequisites.push("Activity \""+this.activityMap[cur].LearningObject.Title+"\" must be completed or passed.");
}
return false;
}
}
return cur;
}
function PrerequisitesEvaluator_ClearActivityStatusCache(){
this.cachedActivityStatus={};
for(var id in this.activityMap){
this.cachedActivityStatus[id]=null;
}
}
function PrerequisitesEvaluator_Evaluate(_126,_127){
this.currentLog=this.Sequencer.LogSeqAudit("Beginning prerequisites evaluation of activity "+_126.ItemIdentifier);
this.missingPrerequisites=[];
this.currentLookAhead=_127;
if(_127===undefined||_127===null){
this.currentLookAhead=false;
}
var _128=_126.LearningObject;
if(_128==null){
this.Sequencer.LogSeq("Error evaluating prerequisites - The activity is missing an associated Learning Object.",this.currentLog);
return false;
}
if(_128.Prerequisites===""){
this.Sequencer.LogSeq("No prerequisites defined for activity.",this.currentLog);
return true;
}
this.ClearActivityStatusCache();
var _129=_128.Prerequisites;
var _12a=this.TokenizeExpression(_129);
var _12b=this.ToPostfix(_12a);
var _12c=[];
while(_12b.length>0){
var c=_12b.pop();
if(c=="~"){
this.DistributeNotOperator(_12b,_12c);
}else{
_12c.push(c);
}
}
_12c.reverse();
var _12e=this.Compute(_12c);
if(this.missingPrerequisites.length>0){
for(var i=0;i<this.missingPrerequisites.length;i++){
this.Sequencer.LogSeq(this.missingPrerequisites[i],this.currentLog);
}
}
return _12e;
}
function PrerequisitesEvaluator_CheckActivityStatus(_130,_131){
if(this.cachedActivityStatus[_130]===undefined){
this.Sequencer.LogSeq("Error evaluating prerequisites - Unknown activity "+_130,this.currentLog);
return false;
}
var _132=null;
if(this.cachedActivityStatus[_130]==null){
_132=this.ComputeActivityStatus(this.activityMap[_130]);
this.cachedActivityStatus[_130]=_132;
}else{
_132=this.cachedActivityStatus[_130];
}
var _133=false;
if(_131==null){
_133=_132=="passed"||_132=="completed";
if(!_133){
this.Sequencer.LogSeq("Expected activity "+_130+" to be passed or completed (was: "+_132+").",this.currentLog);
}
}else{
_133=_132==_131;
if(!_133){
this.Sequencer.LogSeq("Expected activity "+_130+" to be "+_131+" (was: "+_132+").",this.currentLog);
}
}
return _133;
}
function PrerequisitesEvaluator_ComputeActivityStatus(_134){
if(_134.IsDeliverable()){
if(this.currentLookAhead){
return TranslateDualStausToSingleStatus(_134.RunTime.LookAheadCompletionStatus,_134.RunTime.LookAheadSuccessStatus);
}else{
return TranslateDualStausToSingleStatus(_134.RunTime.CompletionStatus,_134.RunTime.SuccessStatus);
}
}else{
if(_134.IsSatisfied()===true){
return "passed";
}
if(_134.IsCompleted()===true){
return "completed";
}
if(_134.IsCompleted()==RESULT_UNKNOWN&&_134.IsSatisfied()==RESULT_UNKNOWN){
return "not attempted";
}
if(_134.IsSatisfied()===false){
return "failed";
}
if(_134.IsCompleted()===false){
return "incomplete";
}
if(_134.GetAttemptCount()>0){
return "browsed";
}
}
return false;
}
function PrerequisitesEvaluator_GetMissingPrerequisitesHtml(){
var text=IntegrationImplementation.GetString("You have not completed the prerequisites for this activity. Additional Information:<ul>");
for(var i=0;i<this.missingPrerequisites.length;i++){
text+="<li>"+this.missingPrerequisites[i]+"</li>";
}
text+="</ul>";
return text;
}

