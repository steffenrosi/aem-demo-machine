function ActivityRepository(){
this.ActivityList=new Array();
this.ActivityTree=null;
this.SortedActivityList=new Array();
this.ActivityListByIdentifier=new Array();
}
ActivityRepository.prototype.InitializeFromRegistration=ActivityRepository_InitializeFromRegistration;
ActivityRepository.prototype.BuildActivity=ActivityRepository_BuildActivity;
ActivityRepository.prototype.GetActivityByDatabaseId=ActivityRepository_GetActivityByDatabaseId;
ActivityRepository.prototype.PreOrderTraversal=ActivityRepository_PreOrderTraversal;
ActivityRepository.prototype.GetSortedIndexOfActivity=ActivityRepository_GetSortedIndexOfActivity;
ActivityRepository.prototype.Clone=ActivityRepository_Clone;
ActivityRepository.prototype.TearDown=ActivityRepository_TearDown;
ActivityRepository.prototype.SetSequencer=ActivityRepository_SetSequencer;
ActivityRepository.prototype.GetActivityPath=ActivityRepository_GetActivityPath;
ActivityRepository.prototype.GetRootActivity=ActivityRepository_GetRootActivity;
ActivityRepository.prototype.DoesActivityExist=ActivityRepository_DoesActivityExist;
ActivityRepository.prototype.GetActivityFromIdentifier=ActivityRepository_GetActivityFromIdentifier;
ActivityRepository.prototype.GetParentActivity=ActivityRepository_GetParentActivity;
ActivityRepository.prototype.GetNumDeliverableActivities=ActivityRepository_GetNumDeliverableActivities;
function ActivityRepository_InitializeFromRegistration(_1,_2){
this.ActivityList=_1.Activities;
this.ActivityTree=this.BuildActivity(_1,_1.Package.LearningObjects[0],null,1);
this.PreOrderTraversal(this.ActivityTree,this.SortedActivityList);
var _3=_2[-1];
var _4="";
for(var i=0;i<this.ActivityList.length;i++){
_4="";
var _6=_2[this.ActivityList[i].DatabaseId];
if(_6!==null&&_6!==undefined){
_4=_6;
}else{
if(_3!==null&&_3!==undefined){
_4=_3;
}
}
if(_4!==""){
this.ActivityList[i].LearningObject.Parameters=MergeQueryStringParameters(_4,this.ActivityList[i].LearningObject.Parameters);
}
this.ActivityListByIdentifier[this.ActivityList[i].GetItemIdentifier()]=this.ActivityList[i];
}
}
function ActivityRepository_BuildActivity(_7,_8,_9,_a){
var _b=_7.FindActivityForThisScormObject(_8.DatabaseIdentifier);
_b.LearningObject=_8;
_b.ParentActivity=_9;
if(_b.Ordinal==0){
_b.Ordinal=_a;
}
var _c;
for(var _d in _b.ActivityObjectives){
_c=null;
for(var _e in _8.SequencingData.Objectives){
if(_8.SequencingData.Objectives[_e].Id==_b.ActivityObjectives[_d].Identifier){
_c=_8.SequencingData.Objectives[_e];
break;
}
}
if(_c===null){
if(_8.SequencingData.PrimaryObjective!==null&&_8.SequencingData.PrimaryObjective.Id==_b.ActivityObjectives[_d].Identifier){
_c=_8.SequencingData.PrimaryObjective;
}
}
if(_c!==null){
_b.ActivityObjectives[_d].SatisfiedByMeasure=_c.SatisfiedByMeasure;
_b.ActivityObjectives[_d].MinNormalizedMeasure=_c.MinNormalizedMeasure;
_b.ActivityObjectives[_d].Maps=_c.Maps;
}
identifier=_b.ActivityObjectives[_d].GetIdentifier();
if(_b.RunTime!==null&&identifier!==null&&identifier!==undefined&&identifier.length>0){
runTimeObjective=_b.RunTime.FindObjectiveWithId(identifier);
if(runTimeObjective===null){
_b.RunTime.AddObjective();
runTimeObjective=_b.RunTime.Objectives[_b.RunTime.Objectives.length-1];
runTimeObjective.Identifier=identifier;
}
}
}
for(var i=0;i<_8.Children.length;i++){
_b.ChildActivities[i]=this.BuildActivity(_7,_8.Children[i],_b,(i+1));
}
_b.StringIdentifier=_b.toString();
return _b;
}
function ActivityRepository_GetActivityByDatabaseId(_10){
if(_10===null){
return null;
}else{
for(var i=0;i<this.ActivityList.length;i++){
if(this.ActivityList[i].DatabaseId==_10){
return this.ActivityList[i];
}
}
}
Debug.AssertError("Searched for an activity by database id that did not exist.");
return null;
}
function ActivityRepository_PreOrderTraversal(_12,_13){
_13[_13.length]=_12;
for(var i=0;i<_12.ChildActivities.length;i++){
this.PreOrderTraversal(_12.ChildActivities[i],_13);
}
}
function ActivityRepository_GetSortedIndexOfActivity(_15){
for(var i=0;i<this.SortedActivityList.length;i++){
if(this.SortedActivityList[i]==_15){
return i;
}
}
Debug.AssertError("Activity not found in sorted list of activities");
return null;
}
function ActivityRepository_Clone(){
var _17=new ActivityRepository();
var _18;
var _19;
var _1a;
for(_1a=0;_1a<this.ActivityList.length;_1a++){
_18=this.ActivityList[_1a].Clone();
_17.ActivityList[_1a]=_18;
_17.ActivityListByIdentifier[_18.GetItemIdentifier()]=_18;
if(this.ActivityList[_1a].ParentActivity===null){
_17.ActivityTree=_17.ActivityList[_1a];
}
}
for(_1a=0;_1a<this.ActivityList.length;_1a++){
_19=this.ActivityList[_1a];
_18=_17.ActivityList[_1a];
if(_19.ParentActivity===null){
_18.ParentActivity=null;
}else{
_18.ParentActivity=_17.GetActivityFromIdentifier(_19.ParentActivity.GetItemIdentifier());
}
for(var _1b in _19.ChildActivities){
_18.ChildActivities[_1b]=_17.GetActivityFromIdentifier(_19.ChildActivities[_1b].GetItemIdentifier());
}
_18.AvailableChildren=new Array();
for(var _1c in _19.AvailableChildren){
_18.AvailableChildren[_1c]=_17.GetActivityFromIdentifier(_19.AvailableChildren[_1c].GetItemIdentifier());
}
}
_17.PreOrderTraversal(_17.ActivityTree,_17.SortedActivityList);
return _17;
}
function ActivityRepository_TearDown(){
for(var _1d in this.ActivityList){
this.ActivityList[_1d].TearDown();
this.ActivityList[_1d]=null;
}
this.ActivityList=null;
this.ActivityTree=null;
this.SortedActivityList=null;
}
function ActivityRepository_SetSequencer(_1e,_1f){
for(var _20 in this.ActivityList){
this.ActivityList[_20].SetSequencer(_1e,_1f);
}
}
function ActivityRepository_GetActivityPath(_21,_22){
var _23=new Array();
var _24=0;
if(_22){
_23[_24]=_21;
_24++;
}
while(_21.ParentActivity!==null){
_21=_21.ParentActivity;
_23[_24]=_21;
_24++;
}
return _23;
}
function ActivityRepository_GetRootActivity(){
var _25=null;
for(var i=0;i<this.SortedActivityList.length;i++){
if(this.SortedActivityList[i].ParentActivity===null){
_25=this.SortedActivityList[i];
break;
}
}
return _25;
}
function ActivityRepository_DoesActivityExist(_27){
if(this.ActivityListByIdentifier[_27]!==null&&this.ActivityListByIdentifier[_27]!==undefined){
return true;
}
return false;
}
function ActivityRepository_GetActivityFromIdentifier(_28){
if(this.ActivityListByIdentifier[_28]!==null&&this.ActivityListByIdentifier[_28]!==undefined){
return this.ActivityListByIdentifier[_28];
}
return null;
}
function ActivityRepository_GetParentActivity(_29){
var _2a=null;
if(_29!==null){
_2a=_29.ParentActivity;
}
return _2a;
}
function ActivityRepository_GetNumDeliverableActivities(){
var _2b=0;
for(var i=0;i<this.ActivityList.length;i++){
if(this.ActivityList[i].IsDeliverable()){
_2b++;
}
}
return _2b;
}
var CommandSentry;
(function(){
"use strict";
var tX1=0,tX2=0,tY1=0,tY2=0,_31=false,_32=false;
CommandSentry=function(){
this._keySequences=[];
this._touchSequences=[];
this._successCallbacks=[];
this._keySeqCounters=[];
this._touchSeqCounters=[];
};
CommandSentry.prototype={addCommand:function(_33,_34,_35){
this._keySequences.push(_34);
this._keySeqCounters.push(0);
this._touchSequences.push(_35);
this._touchSeqCounters.push(0);
this._successCallbacks.push(_33);
},addTargetElement:function(_36){
if(typeof _36==="undefined"){
_36=document;
}
var i;
for(i=0;i<this._keySequences.length;i++){
if(this._keySequences[i].length>0){
this._addEvent(_36,"keypress",this._keypressCallback);
break;
}
}
for(i=0;i<this._touchSequences.length;i++){
if(this._touchSequences[i].length>0){
this._addEvent(_36,"touchstart",this._touchstartCallback);
this._addEvent(_36,"touchmove",this._touchmoveCallback);
this._addEvent(_36,"touchend",this._touchendCallback);
break;
}
}
},enterKeyCode:function(_38){
var i;
for(i=0;i<this._keySequences.length;i++){
if(_38!==this._keySequences[i][this._keySeqCounters[i]]){
this._keySeqCounters[i]=0;
}
if(_38===this._keySequences[i][this._keySeqCounters[i]]){
this._keySeqCounters[i]++;
if(this._keySeqCounters[i]===this._keySequences[i].length&&this._keySeqCounters[i]>0){
this._keySeqCounters[i]=0;
this._successCallbacks[i]();
}
}
}
},_addEvent:function(_3a,_3b,_3c){
if(_3a.addEventListener){
_3a.addEventListener(_3b,CommandSentry.bind(this,_3c),false);
}else{
if(_3a.attachEvent){
_3a.attachEvent("on"+_3b,CommandSentry.bind(this,_3c,_3a.parentWindow.event));
}
}
},_evaluateTouchCommand:function(){
var dx=tX2-tX1;
var dy=tY2-tY1;
var _3f=(dx>0)?"r":"l";
var _40=(dy>0)?"d":"u";
var _41=(Math.abs(dx)>Math.abs(dy))?_3f:_40;
_41=(_31)?"t":_41;
var i;
for(i=0;i<this._touchSequences.length;i++){
if(_41!==this._touchSequences[i][this._touchSeqCounters[i]]){
this._touchSeqCounters[i]=0;
}
if(_41===this._touchSequences[i][this._touchSeqCounters[i]]){
this._touchSeqCounters[i]++;
if(this._touchSeqCounters[i]===this._touchSequences[i].length&&this._touchSeqCounters[i]>0){
this._touchSeqCounters[i]=0;
this._successCallbacks[i]();
}
}
}
},_keypressCallback:function(_43){
var _44=(_43.keyCode!==0)?_43.keyCode:_43.charCode;
this.enterKeyCode(_44);
},_touchstartCallback:function(_45){
tX1=_45.changedTouches[0].pageX;
tY1=_45.changedTouches[0].pageY;
_31=true;
_32=true;
},_touchmoveCallback:function(_46){
if(_32&&_46.touches.length===1){
tX2=_46.changedTouches[0].pageX;
tY2=_46.changedTouches[0].pageY;
_31=false;
_32=false;
this._evaluateTouchCommand();
}
},_touchendCallback:function(_47){
if(_31){
this._evaluateTouchCommand();
}
}};
CommandSentry.bind=function(_48,fn){
return function(){
fn.apply(_48,arguments);
};
};
}());
function Communications(){
this.IntervalFunctionID="";
this.FinalExitCalls=0;
this.FailedSubmissions=0;
this.Disabled=false;
this.MinimumCommitFrequency=5000;
this.StartPostDataProcess=Communications_StartPostDataProcess;
this.KillPostDataProcess=Communications_KillPostDataProcess;
this.SaveData=Communications_SaveData;
this.SaveDataNow=Communications_SaveDataNow;
this.SaveDataOnExit=Communications_SaveDataOnExit;
this.SaveDebugLog=Communications_SaveDebugLog;
this.SendDataToServer=Communications_SendDataToServer;
this.CheckServerResponse=Communications_CheckServerResponse;
this.CallFailed=Communications_CallFailed;
this.Disable=Communications_Disable;
this.LogOnServer=Communications_LogOnServer;
}
function Communications_StartPostDataProcess(){
if(this.Disabled){
return;
}
Control.WriteDetailedLog("`1307`");
if(RegistrationToDeliver.Package.Properties.CommCommitFrequency>this.MinimumCommitFrequency){
this.IntervalFunctionID=window.setInterval("Control.Comm.SaveData(false, false);",RegistrationToDeliver.Package.Properties.CommCommitFrequency);
}else{
this.IntervalFunctionID=window.setInterval("Control.Comm.SaveData(false, false);",this.MinimumCommitFrequency);
}
}
function Communications_KillPostDataProcess(){
if(this.Disabled){
return;
}
Control.WriteDetailedLog("`1321`");
if(this.IntervalFunctionID!==""){
window.clearInterval(this.IntervalFunctionID);
this.IntervalFunctionID="";
}
}
function Communications_SaveData(_4a,_4b){
if(this.Disabled){
return;
}
Control.WriteDetailedLog("`1257`"+_4a+"`1737`"+_4b);
if(typeof DispatchDriver!="undefined"){
var _4c=Control.Activities.GetRootActivity();
var _4d=null;
if(_4c.IsCompleted(null,false)!="unknown"&&_4c.IsCompleted(null,false)==true){
_4d="completed";
}
var _4e=null;
if(_4c.IsSatisfied(null,false)!="unknown"){
if(_4c.IsSatisfied(null,false)==true){
_4e="passed";
}else{
_4e="failed";
}
}
var _4f=_4c.GetPrimaryObjective().NormalizedMeasure;
var _50=_4c.GetPrimaryObjective().MeasureStatus;
var _51=_50==true?(_4f*100):"unknown";
var _52=0;
var _53=0;
var _54=Control.Activities.ActivityList;
for(var i=0;i<_54.length;i++){
var act=_54[i];
if(act.IsDeliverable()){
_52+=ConvertIso8601TimeSpanToHundredths(act.RunTime.SessionTimeTracked);
_53+=ConvertIso8601TimeSpanToHundredths(act.RunTime.SessionTime);
}
}
var _57=(_52>0)?_52:_53;
if(_57==null||isNaN(_57)){
_57=0;
}
DispatchDriver.SetSummary(_4d,_4e,_51,_57);
}
var _58;
if(_4b===true){
Control.WriteDetailedLog("`871`"+this.FinalExitCalls);
Control.MarkDirtyDataPosted();
_58=Control.GetXmlForDirtyData();
this.SendDataToServer(_4a,_58,true);
}else{
if(Control.IsThereDirtyData()){
Control.WriteDetailedLog("`1526`");
Control.MarkDirtyDataPosted();
_58=Control.GetXmlForDirtyData();
this.SendDataToServer(_4a,_58);
}
}
}
function Communications_SaveDataNow(_59){
if(this.Disabled){
return;
}
Control.WriteDetailedLog("`1476`");
this.KillPostDataProcess();
this.SaveData(true);
if(!_59){
this.StartPostDataProcess();
}
}
function Communications_SaveDataOnExit(){
if(this.Disabled){
return;
}
Control.WriteDetailedLog("`1413`");
this.KillPostDataProcess();
this.SaveData(true,true);
}
function Communications_SaveDebugLog(){
if(Debug.log.root&&Debug.log.root.childNodes.length>0){
var _5a=Debug.log.toXml();
$.ajax({url:DEBUG_LOG_PERSIST_PAGE,type:"POST",data:_5a,async:false});
}
}
function Communications_SendDataToServer(_5b,_5c,_5d){
if(this.Disabled){
return true;
}
var _5e;
if(_5d){
_5e=MergeQueryStringParameters(SCORM_RESULTS_PAGE,"isExitScormPlayer=true");
}else{
_5e=SCORM_RESULTS_PAGE;
}
_5b=!!_5b;
Control.WriteDetailedLog("`1348`"+_5b+"`1712`"+_5c);
$.ajax({type:"POST",url:_5e,cache:false,dataType:"text",contentType:"text/xml",data:_5c,async:!_5b,success:function(_5f,_60){
Control.WriteDetailedLog("`1566`"+_5f);
return Control.Comm.CheckServerResponse(_5f,true,_5b,_5d);
},error:function(req,_62,_63){
Control.WriteDetailedLogError("`562`"+req.status);
var _64=Control.Comm.CallFailed();
if(_64){
Control.Comm.SaveData(_5b,_5d);
}
}});
return true;
}
function Communications_CheckServerResponse(_65,_66,_67,_68){
if(this.Disabled){
return true;
}
var _69;
_65=String(_65);
var _6a=/\<error present\=\"(true|false)\"\>/;
var _6b=_65.match(_6a);
if(_6b===null||_6b.length!=2){
Control.WriteDetailedLogError("`966`");
_69=false;
}else{
var _6c=(_6b[1]=="false");
if(_6c===false){
Control.WriteDetailedLogError("`370`"+_65);
_69=false;
}else{
_69=true;
}
}
if(_69===false){
var _6d=this.CallFailed();
if(_66&&_6d){
this.SaveData(_67,_68);
}
}else{
this.FailedSubmissions=0;
Control.MarkPostedDataClean();
}
return _69;
}
function Communications_CallFailed(){
if(this.Disabled){
return false;
}
this.FailedSubmissions++;
Control.MarkPostedDataDirty();
Control.WriteDetailedLog("`1072`"+this.FailedSubmissions);
if(this.FailedSubmissions>=RegistrationToDeliver.Package.Properties.CommMaxFailedSubmissions){
this.KillPostDataProcess();
if(!Control.DeliverFramesetUnloadEventCalled){
Control.DisplayError("A fatal error has occurred, communication with the server has been lost.");
}
if(Control.Package.Properties.PlayerLaunchType==LAUNCH_TYPE_FRAMESET){
if(RedirectOnExitUrl!=="noop"){
window.location=RedirectOnExitUrl;
}
}else{
if(window.opener&&window.opener!==null&&window.opener.closed===false){
if(RedirectOnExitUrl!=="noop"){
window.opener.location=RedirectOnExitUrl;
}
}
window.close();
}
return false;
}
return true;
}
function Communications_Disable(){
this.Disabled=true;
}
function Communications_LogOnServer(msg,_6f){
var _70=msg;
if(_6f!=null){
_70=msg+GetErrorDetailString(_6f);
}
$.ajax({type:"POST",url:SERVER_LOGGER_PAGE,cache:false,data:{"msg":RegistrationToDeliver.Id+" - "+_70},async:false});
}
var DATA_STATE_CLEAN="C";
var DATA_STATE_DIRTY="D";
var DATA_STATE_POSTED="P";
var ASCII_QUESTION=63;
var ASCII_TILDA=126;
var ASCII_BANG=33;
var ASCII_PIPE=124;
var ASCII_SHIFT_IN=15;
var ASCII_0=48;
var ASCII_1=49;
var ASCII_2=50;
var ASCII_3=51;
var ASCII_4=52;
var ASCII_5=53;
var ASCII_6=54;
var ASCII_7=55;
var ASCII_8=56;
var ASCII_D=68;
var RESULT_UNKNOWN="unknown";
var EXIT_ACTION_EXIT_NO_CONFIRMATION="exit,no confirmation";
var EXIT_ACTION_EXIT_CONFIRMATION="exit,confirmation";
var EXIT_ACTION_GO_TO_NEXT_SCO="continue";
var EXIT_ACTION_DISPLAY_MESSAGE="message page";
var EXIT_ACTION_DO_NOTHING="do nothing";
var EXIT_ACTION_REFRESH_PAGE="refresh page";
var POSSIBLE_NAVIGATION_REQUEST_INDEX_START=0;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_RESUME_ALL=1;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE=2;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS=3;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT=4;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT_ALL=5;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_SUSPEND_ALL=6;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON=7;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON_ALL=8;
var POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE=9;
var LAUNCH_TYPE_FRAMESET="frameset";
var LAUNCH_TYPE_POPUP="new window";
var LAUNCH_TYPE_POPUP_AFTER_CLICK="new window,after click";
var LAUNCH_TYPE_POPUP_WITHOUT_BROWSER_TOOLBAR="new window without browser toolbar";
var LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR="new window,after click,without browser toolbar";
var LAUNCH_TYPE_POPUP_WITH_MENU="new window with menubar";
var STANDARD_SCORM_11="SCORM 1.1";
var STANDARD_SCORM_12="SCORM 1.2";
var STANDARD_SCORM_2004_2ND_EDITION="SCORM 2004 2nd Edition";
var STANDARD_SCORM_2004_3RD_EDITION="SCORM 2004 3rd Edition";
var STANDARD_SCORM_2004_4TH_EDITION="SCORM 2004 4th Edition";
var STANDARD_AICC="AICC";
var SCORM_2004_2ND_EDITION="SCORM 2004 2nd Edition";
var STANDARD_SCORM_2004="SCORM 2004 3rd Edition";
var SCORM_TYPE_SCO="SCO";
var SCORM_TYPE_ASSET="Asset";
var SCORM_TYPE_OBJECTIVE="Objective";
var SCORM_TYPE_AGGREGATION="Aggregation";
var STATUS_DISPLAY_SUCCESS_ONLY="success only";
var STATUS_DISPLAY_COMPELTION_ONLY="completion only";
var STATUS_DISPLAY_SEPERATE="separate";
var STATUS_DISPLAY_COMBINED="combined";
var STATUS_DISPLAY_NONE="none";
var STATUS_ROLLUP_METHOD_STATUS_PROVIDED_BY_COURSE="STATUS_PROVIDED_BY_COURSE";
var STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_COMPLETE="COMPLETE_WHEN_ALL_UNITS_COMPLETE";
var STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_COMPLETE_AND_NOT_FAILED="COMPLETE_WHEN_ALL_UNITS_COMPLETE_AND_NOT_FAILED";
var STATUS_ROLLUP_METHOD_COMPLETE_WHEN_THRESHOLD_SCORE_IS_MET="COMPLETE_WHEN_THRESHOLD_SCORE_IS_MET";
var STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_COMPLETE_AND_THRESHOLD_SCORE_IS_MET="COMPLETE_WHEN_ALL_UNITS_COMPLETE_AND_THRESHOLD_SCORE_IS_MET";
var STATUS_ROLLUP_METHOD_COMPLETE_WHEN_ALL_UNITS_ARE_PASSED="COMPLETE_WHEN_ALL_UNITS_ARE_PASSED";
var SCORE_ROLLUP_METHOD_SCORE_PROVIDED_BY_COURSE="SCORE_PROVIDED_BY_COURSE";
var SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS="AVERAGE_SCORE_OF_ALL_UNITS";
var SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS_WITH_SCORES="AVERAGE_SCORE_OF_ALL_UNITS_WITH_SCORES";
var SCORE_ROLLUP_METHOD_FIXED_AVERAGE="FIXED_AVERAGE";
var SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS_WITH_NONZERO_SCORES="AVERAGE_SCORE_OF_ALL_UNITS_WITH_NONZERO_SCORES";
var SCORE_ROLLUP_METHOD_LAST_SCO_SCORE="LAST_SCO_SCORE";
var RESET_RT_DATA_TIMING_NEVER="never";
var RESET_RT_DATA_TIMING_WHEN_EXIT_IS_NOT_SUSPEND="when exit is not suspend";
var RESET_RT_DATA_TIMING_ON_EACH_NEW_SEQUENCING_ATTEMPT="on each new sequencing attempt";
var INVALID_MENU_ITEM_ACTION_DISABLE="Disable";
var INVALID_MENU_ITEM_ACTION_HIDE="Hide";
var INVALID_MENU_ITEM_ACTION_SHOW_ENABLE="Show";
var LOOKAHEAD_SEQUENCER_MODE_DISABLE="DISABLED";
var LOOKAHEAD_SEQUENCER_MODE_ENABLE="ENABLED";
var LOOKAHEAD_SEQUENCER_MODE_REALTIME="REALTIME";
function Controller(){
this.ProcessedUnload=false;
this.MenuIsVisible=false;
this.Initialized=false;
this.ExitScormPlayerCalled=false;
this.SignalTerminatedPending=false;
this.PopupBlocked=false;
this.ExitDialogVisible=false;
this.Initialize=Controller_Initialize;
this.Unload=Controller_Unload;
this.CreateMenuItem=Controller_CreateMenuItem;
this.RenderMenuItem=Controller_RenderMenuItem;
this.RedrawChildren=Controller_RedrawChildren;
this.UpdateDisplay=Controller_UpdateDisplay;
this.RefreshPage=Controller_RefreshPage;
this.Activities=null;
this.CheckTimeLimitIntervalId=null;
this.IsUserOverTimeLimit=Controller_IsUserOverTimeLimit;
this.ExitIfTimeLimitExceeded=Controller_ExitIfTimeLimitExceeded;
this.BlockCourseEntryWithMessage=Controller_BlockCourseEntryWithMessage;
this.ScoLoader=null;
this.ScoUnloaded=Controller_ScoUnloaded;
this.ExitScormPlayer=Controller_ExitScormPlayer;
this.ExitSco=Controller_ExitSco;
this.MarkPostedDataDirty=Controller_MarkPostedDataDirty;
this.MarkPostedDataClean=Controller_MarkPostedDataClean;
this.MarkDirtyDataPosted=Controller_MarkDirtyDataPosted;
this.GetXmlForDirtyData=Controller_GetXmlForDirtyData;
this.IsThereDirtyData=Controller_IsThereDirtyData;
this.DisplayError=Controller_DisplayError;
this.GetExceptionText=Controller_GetExceptionText;
this.CheckForDebugCommand=Controller_CheckForDebugCommand;
this.CloseSco=Controller_CloseSco;
this.ReturnToLms=Controller_ReturnToLms;
this.GetReturnToLmsNavigationRequest=Controller_GetReturnToLmsNavigationRequest;
this.ToggleMenuVisibility=Controller_ToggleMenuVisibility;
this.TriggerReturnToLMS=Controller_TriggerReturnToLMS;
this.TriggerLegacyReturnToLMS=Controller_TriggerLegacyReturnToLMS;
this.HideExitDialog=Controller_HideExitDialog;
this.Next=Controller_Next;
this.Previous=Controller_Previous;
this.Abandon=Controller_Abandon;
this.AbandonAll=Controller_AbandonAll;
this.Suspend=Controller_Suspend;
this.Exit=Controller_Exit;
this.ExitAll=Controller_ExitAll;
this.ChoiceRequest=Controller_ChoiceRequest;
this.ScoHasTerminatedSoUnload=Controller_ScoHasTerminatedSoUnload;
this.SignalTerminated=Controller_SignalTerminated;
this.TranslateRunTimeNavRequest=Controller_TranslateRunTimeNavRequest;
this.FindPossibleNavRequestForRuntimeNavRequest=Controller_FindPossibleNavRequestForRuntimeNavRequest;
this.GetMessageText=Controller_GetMessageText;
this.ClearPendingNavigationRequest=Controller_ClearPendingNavigationRequest;
this.IsThereAPendingNavigationRequest=Controller_IsThereAPendingNavigationRequest;
this.PendingNavigationRequest=null;
this.GetPreferredReturnToLmsAction=Controller_GetPreferredReturnToLmsAction;
this.UpdateGlobalLearnerPrefs=Controller_UpdateGlobalLearnerPrefs;
this.Sequencer=null;
this.LookAheadSequencer=null;
this.DeliverActivity=Controller_DeliverActivity;
this.PerformDelayedDeliveryInitialization=Controller_PerformDelayedDeliveryInitialization;
this.PossibleNavigationRequests=new Array();
this.InitializePossibleNavigationRequests=Controller_InitializePossibleNavigationRequests;
this.EvaluatePossibleNavigationRequests=Controller_EvaluatePossibleNavigationRequests;
this.FindPossibleChoiceRequestForActivity=Controller_FindPossibleChoiceRequestForActivity;
this.GetPossibleContinueRequest=Controller_GetPossibleContinueRequest;
this.GetPossiblePreviousRequest=Controller_GetPossiblePreviousRequest;
this.IsTargetValid=Controller_IsTargetValid;
this.ParseTargetStringIntoActivity=Controller_ParseTargetStringIntoActivity;
this.IsChoiceRequestValid=Controller_IsChoiceRequestValid;
this.IsJumpRequestValid=Controller_IsJumpRequestValid;
this.IsContinueRequestValid=Controller_IsContinueRequestValid;
this.IsPreviousRequestValid=Controller_IsPreviousRequestValid;
this.ParseTargetStringFromChoiceRequest=Controller_ParseTargetStringFromChoiceRequest;
this.CloneSequencer=Controller_CloneSequencer;
this.TearDownSequencer=Controller_TearDownSequencer;
this.Api=null;
this.WriteAuditLog=Controller_WriteAuditLog;
this.WriteDetailedLog=Controller_WriteDetailedLog;
this.WriteDetailedLogError=Controller_WriteDetailedLogError;
this.WriteHistoryLog=Controller_WriteHistoryLog;
this.WriteHistoryReturnValue=Controller_WriteHistoryReturnValue;
this.GetLaunchHistoryId=Controller_GetLaunchHistoryId;
this.SSPBuckets=null;
}
function Controller_Initialize(){
try{
this.WriteAuditLog("`1634`");
this.Api=apiReference;
this.Package=RegistrationToDeliver.Package;
this.Activities=new ActivityRepository();
this.Activities.InitializeFromRegistration(RegistrationToDeliver,QuerystringAdditions);
this.Sequencer=new Sequencer(false,this.Activities);
this.Sequencer.GlobalObjectives=RegistrationToDeliver.GlobalObjectives;
this.Sequencer.SharedData=RegistrationToDeliver.SharedData;
this.Sequencer.Activities.SetSequencer(this.Sequencer,false);
this.SSPBuckets=RegistrationToDeliver.SSPBuckets;
this.SharedData=RegistrationToDeliver.SharedData;
this.DeliverFramesetUnloadEventCalled=false;
if(SSP_ENABLED&&this.Api.SSPApi!=null){
this.Api.SSPApi.InitializeBuckets();
}
this.InitializePossibleNavigationRequests();
var _71=this.Activities.GetActivityByDatabaseId(RegistrationToDeliver.SuspendedActivity);
this.Sequencer.SetSuspendedActivity(_71);
this.Sequencer.InitialRandomizationAndSelection();
this.CreateMenuItem(null,this.Activities.ActivityTree,IntegrationImplementation.GetDocumentObjectForMenu());
this.RenderMenuItem(this.Activities.ActivityTree);
IntegrationImplementation.SetMenuToggleVisibility(this.Package.Properties.ShowCourseStructure);
if(this.Package.Properties.ShowCourseStructure===true&&this.Package.Properties.CourseStructureStartsOpen===true){
this.ToggleMenuVisibility();
}else{
IntegrationImplementation.HideMenu();
}
this.LookAheadSequencer=new Sequencer(true,this.Sequencer.Activities.Clone());
this.Comm=new Communications();
var _72=ExternalRegistrationId=="";
if(_72||this.Package.LearningStandard.isAICC()){
this.Comm.Disable();
}
this.Comm.StartPostDataProcess();
var _73=window.location.toString();
IntermediatePage.PageHref=BuildFullUrl(IntermediatePage.PageHref,_73);
PopupLauncherPage.PageHref=BuildFullUrl(PopupLauncherPage.PageHref,_73);
this.ScoLoader=new ScoLoader(IntermediatePage,PopupLauncherPage,PathToCourse,RegistrationToDeliver.Package.Properties.ScoLaunchType,RegistrationToDeliver.Package.Properties.WrapScoWindowWithApi,RegistrationToDeliver.Package.LearningStandard);
this.Initialized=true;
if(this.Package.Properties.TimeLimit>0&&this.IsUserOverTimeLimit()){
this.WriteAuditLog("`1116`");
this.BlockCourseEntryWithMessage(IntegrationImplementation.GetString("The time limit for this course has been exceeded."));
}else{
this.Sequencer.Start();
this.EvaluatePossibleNavigationRequests();
if(this.Package.Properties.TimeLimit>0){
this.CheckTimeLimitIntervalId=setInterval("Control.ExitIfTimeLimitExceeded()",5000);
}
}
}
catch(error){
var _74="Controller_Initialize Error: ";
if(typeof RegistrationToDeliver!="undefined"&&typeof RegistrationToDeliver.Id!="undefined"){
_74=_74+"RegistrationId: "+RegistrationToDeliver.Id+", ";
}
try{
this.Comm.LogOnServer(_74,error);
}
catch(loggingError){
}
Control.DisplayError("A fatal error has occurred during player initialization.  Exiting.");
if(Control.Package.Properties.PlayerLaunchType==LAUNCH_TYPE_FRAMESET){
if(RedirectOnExitUrl!=="noop"){
window.location=RedirectOnExitUrl;
}
}else{
if(window.opener&&window.opener!==null&&window.opener.closed===false){
window.opener.location=RedirectOnExitUrl;
if(RedirectOnExitUrl!=="noop"){
window.opener.location=RedirectOnExitUrl;
}
}
window.close();
}
throw error;
}
}
function Controller_Unload(){
try{
this.WriteAuditLog("`1281`"+this.ProcessedUnload+"`1411`"+this.ExitScormPlayerCalled+"`1303`"+this.Api.NeedToCloseOutSession());
if(this.DeliverFramesetUnloadEventCalled||this.RefreshPageForAiccCalled){
return;
}
this.DeliverFramesetUnloadEventCalled=true;
if(this.Api!=null&&this.Api.RunTimeData!=null&&this.Api.RunTimeData.NavRequest==SCORM_RUNTIME_NAV_REQUEST_NONE){
this.Sequencer.ReturnToLmsInvoked=true;
}
this.ScoLoader.UnloadSco();
this.WriteHistoryLog("",{ev:"Unload"});
if(typeof GetCurrentRegistration!="undefined"){
localStorage.registrationJson=GetCurrentRegistration();
localStorage.runtimeXml=Control.GetXmlForDirtyData();
}
if(this.ScoLoader.ScoLoaded&&!this.PopupBlocked){
var _75=new Sequencer(false,this.Sequencer.Activities.Clone());
var _76=this.Sequencer.CurrentActivity;
var _77=this.Api.RunTimeData.SessionTime;
var _78=this.Api.RunTimeData.TotalTime;
var _79=this.Api.RunTimeData.TotalTimeTracked;
var _7a=this.Api.RunTimeData.Entry;
var _7b=this.Api.RunTimeData.CompletionStatus;
var _7c=this.Api.RunTimeData.CompletionStatusChangedDuringRuntime;
var _7d=this.Api.RunTimeData.SuccessStatus;
var _7e=this.Api.RunTimeData.SuccessStatusChangedDuringRuntime;
var _7f=this.Api.RunTimeData.NavRequest;
if(this.Activities.GetNumDeliverableActivities()==1){
this.PendingNavigationRequest=this.GetReturnToLmsNavigationRequest("exit_all");
}else{
this.PendingNavigationRequest=this.GetReturnToLmsNavigationRequest("suspend_all");
}
this.ScoUnloaded("Unload()");
this.Sequencer=_75;
this.Sequencer.CurrentActivity=_76;
this.Api.RunTimeData.SessionTime=_77;
this.Api.RunTimeData.TotalTime=_78;
this.Api.RunTimeData.TotalTimeTracked=_79;
this.Api.RunTimeData.Entry=_7a;
this.Api.RunTimeData.CompletionStatus=_7b;
this.Api.RunTimeData.CompletionStatusChangedDuringRuntime=_7c;
this.Api.RunTimeData.SuccessStatus=_7d;
this.Api.RunTimeData.SuccessStatusChangedDuringRuntime=_7e;
this.Api.RunTimeData.NavRequest=_7f;
this.Api.CloseOutSessionCalled=false;
this.ScoLoader.ScoLoaded=true;
if(this.SignalTerminatedPending){
this.Api.CloseOutSessionCalled=true;
this.SignalTerminated();
}
}
if(!this.ExitScormPlayerCalled){
this.ExitScormPlayer("Unload()");
}
this.ExitScormPlayerCalled=false;
this.ProcessedUnload=true;
}
catch(error){
var _80="Controller_Unload Error: ";
if(typeof RegistrationToDeliver!="undefined"&&typeof RegistrationToDeliver.Id!="undefined"){
_80=_80+"RegistrationId: "+RegistrationToDeliver.Id+", ";
}
this.Comm.LogOnServer(_80,error);
throw error;
}
}
function Controller_CreateMenuItem(_81,_82,_83){
_82.MenuItem=new MenuItem(_81,_82,_83);
if(_81!==null){
_81.Children[_81.Children.length]=_82.MenuItem;
}
var _84=_82.GetAvailableChildren();
for(var _85 in _84){
this.CreateMenuItem(_82.MenuItem,_84[_85],_83);
}
}
function Controller_RenderMenuItem(_86){
_86.MenuItem.Render(_86);
var _87=_86.GetAvailableChildren();
for(var _88 in _87){
this.RenderMenuItem(_87[_88]);
}
}
function Controller_RedrawChildren(_89){
_89.MenuItem.ResynchChildren(_89);
this.RenderMenuItem(_89);
}
function Controller_UpdateDisplay(_8a,_8b){
var _8c=this.WriteAuditLog("`1557`");
if(this.Package.Properties.LookaheadSequencerMode===LOOKAHEAD_SEQUENCER_MODE_DISABLE){
_8a=false;
_8b=false;
}else{
if(_8a===undefined||_8a===null){
_8a=false;
}
if(_8b===undefined||_8b===null){
_8b=false;
}
}
var _8d=0;
var _8e;
this.WriteDetailedLog("`1315`",_8c);
var _8f;
for(var _90 in this.Sequencer.Activities.ActivityList){
if(_8b){
_8f=this.LookAheadSequencer.Activities.ActivityList[_90];
}else{
_8f=this.Sequencer.Activities.ActivityList[_90];
}
if(_8a){
_8e=this.FindPossibleChoiceRequestForActivity(this.LookAheadSequencer.Activities.ActivityList[_90]);
}else{
_8e=this.FindPossibleChoiceRequestForActivity(this.Sequencer.Activities.ActivityList[_90]);
}
_8f.SetHiddenFromChoice(_8e.Hidden);
var _91=this.Sequencer.Activities.ActivityList[_90].MenuItem;
if(_91!==null){
_91.UpdateStateDisplay(_8f,this.Sequencer.CurrentActivity,_8e,_8b);
if(_91.Visible){
_8d++;
}
}
}
if(_8d>0&&this.Sequencer.CurrentActivity!=null){
var _92=this.Sequencer.CurrentActivity.MenuItem;
if(_92.Visible===false&&_92.CurrentDisplayState.ActiveDisplayed===true){
var _93=this.Sequencer.CurrentActivity.ParentActivity;
var _94=false;
while(_93!=null&&_94==false){
if(_93.MenuItem.Visible===true){
if(_8a){
_8e=this.FindPossibleChoiceRequestForActivity(this.LookAheadSequencer.Activities.ActivityList[_90]);
}else{
_8e=this.FindPossibleChoiceRequestForActivity(this.Sequencer.Activities.ActivityList[_90]);
}
_93.MenuItem.UpdateStateDisplay(_93,_93,_8e,_8b);
_94=true;
}else{
_93=_93.ParentActivity;
}
}
}
}
this.WriteDetailedLog("`965`",_8c);
IntegrationImplementation.UpdateControlState(IntegrationImplementation.GetDocumentObjectForControls(),this.PossibleNavigationRequests,this.Sequencer.GetCurrentActivity());
if(_8b){
IntegrationImplementation.UpdateProgressBar(IntegrationImplementation.GetDocumentObjectForControls(),this.LookAheadSequencer.GetCurrentActivity());
}else{
IntegrationImplementation.UpdateProgressBar(IntegrationImplementation.GetDocumentObjectForControls(),this.Sequencer.GetCurrentActivity());
}
if(_8d==0){
if(this.MenuIsVisible===true){
this.ToggleMenuVisibility();
}
}else{
if(this.Package.Properties.CourseStructureStartsOpen===true&&this.MenuIsVisible===false){
this.ToggleMenuVisibility();
}
}
if(typeof IntegrationImplementation.OverrideMenuLookAndFeel!="undefined"){
IntegrationImplementation.OverrideMenuLookAndFeel(IntegrationImplementation.GetDocumentObjectForMenu());
}
this.WriteDetailedLog("`1397`",_8c);
}
function Controller_RefreshPage(){
var _95=500;
var _96=0;
var win=window;
this.RefreshPageForAiccCalled=true;
while((win.Control===null)&&(win.parent!==null)&&(win.parent!=win)&&(_96<=_95)){
_96++;
win=win.parent;
}
if(win.Control===null){
Debug.AssertError("Could not locate the top level window.");
}else{
win.location.replace(win.location);
}
}
function Controller_ScoUnloaded(_98){
var _99=this.WriteAuditLog("`1394`"+_98);
this.WriteHistoryLog("",{ev:"ScoUnloaded"});
if(this.Initialized===false){
return;
}
this.ScoLoader.ScoLoaded=false;
if(this.Api.Activity!==null&&this.Api.NeedToCloseOutSession()){
if(this.Api.Initialized){
this.Api.CloseOutSession("ScoUnloaded() because apparently Finish/Terminate wasn't called");
this.Api.SetDirtyData();
}
}
if((this.Api.Activity!=null)&&(this.Api.Activity.LearningObject.ScormType===SCORM_TYPE_ASSET)&&this.Api.Activity.WasLaunchedThisSession()){
this.Api.AccumulateTotalTimeTracked();
this.WriteDetailedLog("`1334`"+this.Api.RunTimeData.TotalTimeTracked);
var _9a=this.Sequencer.Activities.GetActivityPath(this.Api.Activity,false);
for(var i=0;i<_9a.length;i++){
_9a[i].RollupDurations();
}
}
if(this.PendingNavigationRequest===null){
if((this.Api!==null)&&(this.Api.RunTimeData!=null)&&(this.Api.RunTimeData.NavRequest!=SCORM_RUNTIME_NAV_REQUEST_NONE)){
this.WriteDetailedLog("`1304`"+this.Api.RunTimeData.NavRequest,_99);
this.PendingNavigationRequest=this.TranslateRunTimeNavRequest(this.Api.RunTimeData.NavRequest);
}
}
this.Sequencer.NavigationRequest=this.PendingNavigationRequest;
this.ClearPendingNavigationRequest();
if(IntegrationImplementation.PreOverallSequencingProcess!="undefined"&&IntegrationImplementation.PreOverallSequencingProcess!=null&&IntegrationImplementation.PreOverallSequencingProcess){
IntegrationImplementation.PreOverallSequencingProcess();
}
this.Sequencer.OverallSequencingProcess();
if(this.ExitScormPlayerCalled===false&&!this.DeliverFramesetUnloadEventCalled){
this.EvaluatePossibleNavigationRequests();
this.Comm.KillPostDataProcess();
this.Comm.SaveData(true,false);
this.Comm.StartPostDataProcess();
}
}
function Controller_ExitScormPlayer(_9c){
this.ExitScormPlayerCalled=true;
if(Debug.ShowDebugLogAtExit){
if(Debug.DataIsAvailable()){
Debug.ShowAllAvailableData();
}
}
this.Comm.SaveDataOnExit();
if(SHOULD_SAVE_CLIENT_DEBUG_LOGS&&RegistrationToDeliver.TrackingEnabled){
this.Comm.SaveDebugLog(true);
}
if(!this.ProcessedUnload){
if(this.Package.Properties.PlayerLaunchType==LAUNCH_TYPE_FRAMESET){
try{
if(RedirectOnExitUrl!=="noop"){
window.location=RedirectOnExitUrl;
}
}
catch(e){
}
}else{
if(!this.PopupBlocked){
try{
if(window.opener&&window.opener!==null&&window.opener.closed===false){
if(RedirectOnExitUrl!=="noop"){
window.opener.location=RedirectOnExitUrl;
}
}
}
catch(e){
}
try{
window.close();
}
catch(e){
}
}
}
}
}
function Controller_ExitSco(){
this.ScoLoader.UnloadSco();
}
function Controller_MarkPostedDataDirty(){
this.WriteAuditLog("`1458`");
for(var _9d in this.Activities.ActivityList){
if(this.Activities.ActivityList[_9d].DataState==DATA_STATE_POSTED){
this.Activities.ActivityList[_9d].DataState=DATA_STATE_DIRTY;
}
this.Activities.ActivityList[_9d].MarkPostedObjectiveDataDirty();
}
if(this.Sequencer.GlobalObjectives!==null&&this.Sequencer.GlobalObjectives!==undefined){
for(var _9e in this.Sequencer.GlobalObjectives){
dataState=this.Sequencer.GlobalObjectives[_9e].DataState;
if(dataState==DATA_STATE_POSTED){
this.Sequencer.GlobalObjectives[_9e].DataState=DATA_STATE_DIRTY;
}
}
}
for(var _9f in this.SSPBuckets){
if(this.SSPBuckets[_9f].DataState==DATA_STATE_POSTED){
this.SSPBuckets[_9f].DataState=DATA_STATE_DIRTY;
}
}
}
function Controller_MarkPostedDataClean(){
this.WriteAuditLog("`1457`");
for(var _a0 in this.Activities.ActivityList){
if(this.Activities.ActivityList[_a0].DataState==DATA_STATE_POSTED){
this.Activities.ActivityList[_a0].DataState=DATA_STATE_CLEAN;
}
this.Activities.ActivityList[_a0].MarkPostedObjectiveDataClean();
}
if(this.Sequencer.GlobalObjectives!==null&&this.Sequencer.GlobalObjectives!==undefined){
for(var _a1 in this.Sequencer.GlobalObjectives){
dataState=this.Sequencer.GlobalObjectives[_a1].DataState;
if(dataState==DATA_STATE_POSTED){
this.Sequencer.GlobalObjectives[_a1].DataState=DATA_STATE_CLEAN;
}
}
}
for(var _a2 in this.SSPBuckets){
if(this.SSPBuckets[_a2].DataState==DATA_STATE_POSTED){
this.SSPBuckets[_a2].DataState=DATA_STATE_CLEAN;
}
}
}
function Controller_MarkDirtyDataPosted(){
this.WriteAuditLog("`1456`");
for(var _a3 in this.Activities.ActivityList){
if(this.Activities.ActivityList[_a3].IsAnythingDirty()){
this.Activities.ActivityList[_a3].DataState=DATA_STATE_POSTED;
}
this.Activities.ActivityList[_a3].MarkDirtyObjectiveDataPosted();
}
if(this.Sequencer.GlobalObjectives!==null&&this.Sequencer.GlobalObjectives!==undefined){
for(var _a4 in this.Sequencer.GlobalObjectives){
dataState=this.Sequencer.GlobalObjectives[_a4].DataState;
if(dataState==DATA_STATE_DIRTY){
this.Sequencer.GlobalObjectives[_a4].DataState=DATA_STATE_POSTED;
}
}
}
for(var _a5 in this.SSPBuckets){
if(this.SSPBuckets[_a5].DataState==DATA_STATE_DIRTY){
this.SSPBuckets[_a5].DataState=DATA_STATE_POSTED;
}
}
}
function Controller_GetXmlForDirtyData(){
this.WriteAuditLog("`1478`");
var _a6=new ServerFormater();
var xml=new XmlElement("RTD");
xml.AddAttribute("RI",RegistrationToDeliver.Id);
if(this.Sequencer.GetSuspendedActivity()!==null){
xml.AddAttribute("SAI",this.Sequencer.GetSuspendedActivity().GetDatabaseIdentifier());
}
if(this.GetLaunchHistoryId()!==null){
xml.AddAttribute("LH",this.GetLaunchHistoryId());
}
xml.AddAttribute("TR",RegistrationToDeliver.TrackingEnabled);
if(RegistrationToDeliver.TrackingEnabled){
for(var _a8 in this.Activities.ActivityList){
if(this.Activities.ActivityList[_a8].IsAnythingDirty()||this.Activities.ActivityList[_a8].DataState==DATA_STATE_POSTED){
xml.AddElement(this.Activities.ActivityList[_a8].GetXml());
}
}
if(this.Sequencer.GlobalObjectives!==null&&this.Sequencer.GlobalObjectives!==undefined){
for(var _a9 in this.Sequencer.GlobalObjectives){
dataState=this.Sequencer.GlobalObjectives[_a9].DataState;
if(dataState==DATA_STATE_DIRTY||dataState==DATA_STATE_POSTED){
xml.AddElement(this.Sequencer.GlobalObjectives[_a9].GetXml(RegistrationToDeliver.Id,_a9));
}
}
}
for(var _aa in this.SSPBuckets){
if(this.SSPBuckets[_aa].DataState==DATA_STATE_DIRTY||this.SSPBuckets[_aa].DataState==DATA_STATE_POSTED){
xml.AddElement(this.SSPBuckets[_aa].GetXml());
}
}
for(var _ab in this.SharedData){
if(this.SharedData[_ab].DataState==DATA_STATE_DIRTY||this.SharedData[_ab].DataState==DATA_STATE_POSTED){
xml.AddElement(this.SharedData[_ab].GetXml());
}
}
}
var _ac=HistoryLog.log.dom.getElementsByTagName("RTL")[0];
_ac.setAttribute("trackingEnabled",RegistrationToDeliver.TrackingEnabled.toString());
try{
xml.AddElement(HistoryLog.GetSerializedLog());
}
catch(error){
xml.AddElement("<RTL_ERROR>There was an error attaching the history log to this XML, see Controller_GetXmlForDirtyData</RTL_ERROR>");
}
var _ad=this.Activities.GetRootActivity();
var _ae=new XmlElement("RS");
var _af;
if(_ad.GetPrimaryObjective().ProgressStatus){
_af=_ad.GetPrimaryObjective().SatisfiedStatus?"passed":"failed";
}else{
_af="unknown";
}
_ae.AddAttribute("SS",_af);
var _b0;
if(_ad.AttemptProgressStatus){
_b0=_ad.AttemptCompletionStatus?"complete":"incomplete";
}else{
_b0="unknown";
}
_ae.AddAttribute("CS",_b0);
_ae.AddAttribute("MS",_a6.ConvertBoolean(_ad.GetPrimaryObjective().MeasureStatus));
_ae.AddAttribute("NM",_ad.GetPrimaryObjective().NormalizedMeasure);
_ae.AddAttribute("ED",_a6.ConvertTimeSpan(_ad.ActivityExperiencedDurationTracked));
xml.AddElement(_ae);
return "<?xml version=\"1.0\"?>"+xml.toString();
}
function Controller_IsThereDirtyData(){
this.WriteAuditLog("`1515`");
for(var _b1 in this.Activities.ActivityList){
if(this.Activities.ActivityList[_b1].IsAnythingDirty()||this.Activities.ActivityList[_b1].DataState==DATA_STATE_POSTED){
return true;
}
}
if(this.Sequencer.GlobalObjectives!==null&&this.Sequencer.GlobalObjectives!==undefined){
for(var _b2 in this.Sequencer.GlobalObjectives){
dataState=this.Sequencer.GlobalObjectives[_b2].DataState;
if(dataState==DATA_STATE_DIRTY||dataState==DATA_STATE_POSTED){
return true;
}
}
}
for(var _b3 in this.SSPBuckets){
if(this.SSPBuckets[_b3].DataState==DATA_STATE_DIRTY||this.SSPBuckets[_b3].DataState==DATA_STATE_POSTED){
return true;
}
}
return false;
}
function Controller_DisplayError(_b4){
this.WriteAuditLog("`1539`"+_b4);
if(Debug.DataIsAvailable()){
if(confirm(_b4+"\n\nPress 'OK' to display debug information to send to technical support, or press 'Cancel' to exit.")){
Debug.ShowAllAvailableData(true);
}
}else{
alert(_b4);
}
return;
}
function Controller_GetExceptionText(){
if(typeof Debug!="undefined"){
this.WriteAuditLog("`1514`");
}
if(this.Sequencer!=null&&this.Sequencer!=undefined){
return this.Sequencer.GetExceptionText();
}else{
return "";
}
}
function Controller_CheckForDebugCommand(_b5){
window.top.DebugCommandSentry.enterKeyCode(_b5);
}
function Controller_CloseSco(){
this.WriteAuditLog("`1308`");
if(this.PendingNavigationRequest===null){
if(this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed===true){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT,null,"");
}else{
if(this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON]===true){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_ABANDON,null,"");
}
}
}
this.WriteHistoryLog("",{ev:"GUI Close",ac:this.PendingNavigationRequest.Type});
this.ScoLoader.UnloadSco();
}
function Controller_ReturnToLms(_b6){
this.WriteAuditLog("`1240`");
this.Sequencer.ReturnToLmsInvoked=true;
if(_b6===null||_b6===undefined){
_b6=this.GetPreferredReturnToLmsAction();
}
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=this.GetReturnToLmsNavigationRequest(_b6);
}
this.WriteHistoryLog("",{ev:"GUI ReturnToLms",ac:this.PendingNavigationRequest.Type});
this.ScoLoader.UnloadSco();
}
function Controller_GetReturnToLmsNavigationRequest(_b7){
var _b8=false;
var _b9=false;
var _ba=false;
if(this.Sequencer.CurrentActivity!=null){
_b8=this.Sequencer.CurrentActivity.LearningObject.SequencingData.HideSuspendAll;
_b9=this.Sequencer.CurrentActivity.LearningObject.SequencingData.HideAbandonAll;
_ba=this.Sequencer.CurrentActivity.LearningObject.SequencingData.HideExitAll;
}
if(this.Activities.GetNumDeliverableActivities()==1){
if(_ba===false&&this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT_ALL].WillSucceed===true){
return new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
}else{
if(_b8===false&&this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_SUSPEND_ALL].WillSucceed===true){
return new NavigationRequest(NAVIGATION_REQUEST_SUSPEND_ALL,null,"");
}
}
}else{
if(_b7=="exit_all"){
if(_ba===false&&this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT_ALL].WillSucceed===true){
return new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
}
}else{
if(_b7=="suspend_all"){
if(_b8===false&&this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_SUSPEND_ALL].WillSucceed===true){
return new NavigationRequest(NAVIGATION_REQUEST_SUSPEND_ALL,null,"");
}
}
}
}
if(_b9===false&&this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON_ALL].WillSucceed===true){
return new NavigationRequest(NAVIGATION_REQUEST_ABANDON_ALL,null,"");
}else{
return new NavigationRequest(NAVIGATION_REQUEST_EXIT_PLAYER,null,"");
}
}
function Controller_ToggleMenuVisibility(){
this.WriteAuditLog("`1433`");
if(this.MenuIsVisible===true){
IntegrationImplementation.HideMenu();
this.MenuIsVisible=false;
}else{
IntegrationImplementation.ShowMenu(this.Package.Properties.CourseStructureWidth);
this.MenuIsVisible=true;
}
}
function Controller_HideExitDialog(){
IntegrationImplementation.HideExitDialog();
this.ExitDialogVisible=false;
}
function Controller_TriggerReturnToLMS(){
logParent=this.WriteAuditLog("`1479`");
var _bb=false;
var _bc=false;
var _bd=false;
if(this.Sequencer.CurrentActivity!=null){
_bb=this.Sequencer.CurrentActivity.LearningObject.SequencingData.HideSuspendAll;
_bc=this.Sequencer.CurrentActivity.LearningObject.SequencingData.HideExitAll;
_bd=this.Sequencer.CurrentActivity.LearningObject.SequencingData.HideAbandonAll;
}
if(_bb===true||_bc===true){
if(_bb===true){
if(_bc===true){
if(_bd===true){
this.WriteDetailedLog("`835`",logParent);
}else{
this.ReturnToLms("abandon_all");
}
}else{
this.ReturnToLms("exit_all");
}
}else{
this.ReturnToLms("suspend_all");
}
}else{
if(!this.Package.LearningStandard.is2004()){
if(this.Package.Properties.ReturnToLmsAction!="legacy"){
this.WriteDetailedLogError("`722`");
}
this.TriggerLegacyReturnToLMS();
}else{
if(this.Package.Properties.ReturnToLmsAction=="selectable"){
if(this.ExitDialogVisible===false){
IntegrationImplementation.ShowExitDialog();
this.ExitDialogVisible=true;
}
}else{
if(this.Package.Properties.ReturnToLmsAction=="legacy"){
this.TriggerLegacyReturnToLMS();
}else{
this.ReturnToLms(this.Package.Properties.ReturnToLmsAction);
}
}
}
}
}
function Controller_TriggerLegacyReturnToLMS(){
if(this.Activities.GetNumDeliverableActivities()==1){
this.ReturnToLms("exit_all");
}else{
this.ReturnToLms("suspend_all");
}
}
function Controller_Next(){
this.WriteAuditLog("`1259`");
this.WriteHistoryLog("",{ev:"GUI Continue"});
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_CONTINUE,null);
}
this.ScoLoader.UnloadSco();
}
function Controller_Previous(){
this.WriteAuditLog("`1173`");
this.WriteHistoryLog("",{ev:"GUI Previous"});
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_PREVIOUS,null,"");
}
this.ScoLoader.UnloadSco();
}
function Controller_Abandon(){
this.WriteAuditLog("`1204`");
this.WriteHistoryLog("",{ev:"GUI Abandon"});
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_ABANDON,null,"");
}
this.ScoLoader.UnloadSco();
}
function Controller_AbandonAll(){
this.WriteAuditLog("`1112`");
this.WriteHistoryLog("",{ev:"GUI AbandonAll"});
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_ABANDON_ALL,null,"");
}
this.ScoLoader.UnloadSco();
}
function Controller_Suspend(){
this.WriteAuditLog("`1205`");
this.WriteHistoryLog("",{ev:"GUI Suspend"});
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_SUSPEND_ALL,null,"");
}
this.ScoLoader.UnloadSco();
}
function Controller_Exit(){
this.WriteAuditLog("`1258`");
this.WriteHistoryLog("",{ev:"GUI Exit"});
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT,null,"");
}
this.ScoLoader.UnloadSco();
}
function Controller_ExitAll(){
this.WriteAuditLog("`1172`");
this.WriteHistoryLog("",{ev:"GUI ExitAll"});
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
}
this.ScoLoader.UnloadSco();
}
function Controller_ChoiceRequest(_be){
this.WriteAuditLog("`1280`"+_be+"`1733`");
var _bf={ev:"GUI Choice"};
var _c0=null;
if(this.Activities){
_c0=this.Activities.GetActivityFromIdentifier(_be);
if(_c0){
_bf.tai=_c0.ItemIdentifier;
_bf.tat=_c0.LearningObject.Title;
}
}
this.WriteHistoryLog("",_bf);
if(this.PendingNavigationRequest===null){
this.PendingNavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_CHOICE,_be,"");
}
this.ScoLoader.UnloadSco();
}
function Controller_ScoHasTerminatedSoUnload(){
var _c1=this.WriteAuditLog("`1472`");
this.ScoLoader.UnloadSco();
}
function Controller_SignalTerminated(){
if(this.DeliverFramesetUnloadEventCalled){
if(this.ScoLoader.ScoLoaded){
if(this.Activities.GetNumDeliverableActivities()==1){
this.PendingNavigationRequest=this.GetReturnToLmsNavigationRequest("exit_all");
}else{
this.PendingNavigationRequest=this.GetReturnToLmsNavigationRequest("suspend_all");
}
this.ScoUnloaded("SignalTerminated()");
if(!this.ExitScormPlayerCalled){
this.ExitScormPlayer("SignalTerminated()");
}
}else{
this.SignalTerminatedPending=true;
}
}
}
function Controller_GetPreferredReturnToLmsAction(){
var _c2="";
if(this.Package.Properties.ReturnToLmsAction=="selectable"){
if(confirm("Exiting Course.  Click 'OK' To save state and pick up where you left off or choose 'Cancel' to finish the Course.")){
_c2="suspend_all";
}else{
_c2="exit_all";
}
}else{
if(this.Package.Properties.ReturnToLmsAction=="legacy"){
if(this.Activities.GetNumDeliverableActivities()==1){
_c2="exit_all";
}else{
_c2="suspend_all";
}
}else{
_c2=this.Package.Properties.ReturnToLmsAction;
}
}
return _c2;
}
function Controller_TranslateRunTimeNavRequest(_c3){
if(_c3.substring(0,1)=="{"){
var _c4=this.ParseTargetStringFromChoiceRequest(_c3);
if(_c3.substr(_c3.indexOf("}")+1)=="choice"){
return new NavigationRequest(NAVIGATION_REQUEST_CHOICE,_c4,"");
}else{
if(_c3.substr(_c3.indexOf("}")+1)=="jump"){
return new NavigationRequest(NAVIGATION_REQUEST_JUMP,_c4,"");
}
}
}
switch(_c3){
case SCORM_RUNTIME_NAV_REQUEST_CONTINUE:
return new NavigationRequest(NAVIGATION_REQUEST_CONTINUE,null,"");
case SCORM_RUNTIME_NAV_REQUEST_PREVIOUS:
return new NavigationRequest(NAVIGATION_REQUEST_PREVIOUS,null,"");
case SCORM_RUNTIME_NAV_REQUEST_EXIT:
return new NavigationRequest(NAVIGATION_REQUEST_EXIT,null,"");
case SCORM_RUNTIME_NAV_REQUEST_EXITALL:
return new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
case SCORM_RUNTIME_NAV_REQUEST_ABANDON:
return new NavigationRequest(NAVIGATION_REQUEST_ABANDON,null,"");
case SCORM_RUNTIME_NAV_REQUEST_ABANDONALL:
return new NavigationRequest(NAVIGATION_REQUEST_ABANDON_ALL,null,"");
case SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL:
return new NavigationRequest(NAVIGATION_REQUEST_SUSPEND_ALL,null,"");
case SCORM_RUNTIME_NAV_REQUEST_NONE:
return null;
default:
Debug.AssertError("Unrecognized runtime navigation request");
break;
}
return null;
}
function Controller_FindPossibleNavRequestForRuntimeNavRequest(_c5){
if(_c5.substring(0,1)=="{"){
var _c6=this.ParseTargetStringFromChoiceRequest(_c5);
if(_c5.substr(_c5.indexOf("}")+1)=="choice"){
var _c7=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;
for(var i=_c7;i<this.PossibleNavigationRequests.length;i++){
if(this.PossibleNavigationRequests[i].TargetActivityItemIdentifier==_c6){
return this.PossibleNavigationRequests[i];
}
}
}else{
if(_c5.substr(_c5.indexOf("}")+1)=="jump"){
var _c9=new NavigationRequest(NAVIGATION_REQUEST_JUMP,_c6,"");
_c9.WillSucceed=this.IsJumpRequestValid(_c5);
return _c9;
}
}
}
switch(_c5){
case SCORM_RUNTIME_NAV_REQUEST_CONTINUE:
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE];
case SCORM_RUNTIME_NAV_REQUEST_PREVIOUS:
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS];
case SCORM_RUNTIME_NAV_REQUEST_EXIT:
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT];
case SCORM_RUNTIME_NAV_REQUEST_EXITALL:
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT_ALL];
case SCORM_RUNTIME_NAV_REQUEST_ABANDON:
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON];
case SCORM_RUNTIME_NAV_REQUEST_ABANDONALL:
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON_ALL];
case SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL:
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_SUSPEND_ALL];
case SCORM_RUNTIME_NAV_REQUEST_NONE:
return null;
default:
Debug.AssertError("Unrecognized runtime navigation request");
break;
}
return null;
}
function Controller_GetMessageText(){
var msg="";
try{
if(this.Sequencer.NavigationRequest!==null&&this.Sequencer.NavigationRequest!==undefined){
if(this.Sequencer.NavigationRequest.MessageToUser!==null&&this.Sequencer.NavigationRequest.MessageToUser!==undefined){
msg=this.Sequencer.NavigationRequest.MessageToUser;
}
}
}
catch(e){
}
return msg;
}
function Controller_ClearPendingNavigationRequest(){
this.WriteAuditLog("`1279`");
this.PendingNavigationRequest=null;
}
function Controller_IsThereAPendingNavigationRequest(){
return (this.PendingNavigationRequest!==null);
}
function Controller_DeliverActivity(_cb){
this.WriteAuditLog("`1256`");
this.WriteAuditLog("`1540`"+_cb);
this.WriteAuditLog("`1256`");
var _cc=this.WriteAuditLog("`1477`"+_cb);
if(_cb.IsDeliverable()===false){
Debug.AssertError("ERROR - Asked to deliver a non-leaf activity - "+_cb);
}
if((Control.Package.Properties.ScoLaunchType!==LAUNCH_TYPE_POPUP_AFTER_CLICK)&&(Control.Package.Properties.ScoLaunchType!==LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR)){
this.Api.ResetState();
this.Api.InitializeForDelivery(_cb);
}
this.ScoLoader.LoadSco(_cb);
this.UpdateDisplay(false,false);
this.WriteDetailedLog("`1370`",_cc);
}
function Controller_PerformDelayedDeliveryInitialization(_cd){
this.Sequencer.ContentDeliveryEnvironmentActivityDataSubProcess(_cd);
this.Api.ResetState();
this.Api.InitializeForDelivery(_cd);
this.EvaluatePossibleNavigationRequests();
}
function Controller_InitializePossibleNavigationRequests(){
var _ce=this.WriteAuditLog("`1212`");
var _cf;
if(Control.Package.Properties.LookaheadSequencerMode===LOOKAHEAD_SEQUENCER_MODE_DISABLE){
this.WriteDetailedLog("`1350`",_ce);
_cf=true;
}else{
this.WriteDetailedLog("`1371`",_ce);
_cf=RESULT_UNKNOWN;
}
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_START]=new PossibleRequest(NAVIGATION_REQUEST_START,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_RESUME_ALL]=new PossibleRequest(NAVIGATION_REQUEST_RESUME_ALL,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE]=new PossibleRequest(NAVIGATION_REQUEST_CONTINUE,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS]=new PossibleRequest(NAVIGATION_REQUEST_PREVIOUS,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT]=new PossibleRequest(NAVIGATION_REQUEST_EXIT,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT_ALL]=new PossibleRequest(NAVIGATION_REQUEST_EXIT_ALL,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_SUSPEND_ALL]=new PossibleRequest(NAVIGATION_REQUEST_SUSPEND_ALL,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON]=new PossibleRequest(NAVIGATION_REQUEST_ABANDON,null,_cf,"","");
this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON_ALL]=new PossibleRequest(NAVIGATION_REQUEST_ABANDON_ALL,null,_cf,"","");
var _d0=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;
for(var _d1 in this.Activities.SortedActivityList){
activity=this.Activities.SortedActivityList[_d1];
itemId=activity.GetItemIdentifier();
this.PossibleNavigationRequests[_d0]=new PossibleRequest(NAVIGATION_REQUEST_CHOICE,itemId,_cf,"","");
_d0++;
}
for(var id in this.PossibleNavigationRequests){
this.WriteDetailedLog("`1723`"+this.PossibleNavigationRequests[id].toString(),_ce);
}
this.Sequencer.InitializePossibleNavigationRequestAbsolutes(this.PossibleNavigationRequests,this.Activities.ActivityTree,this.Activities.SortedActivityList);
}
function Controller_EvaluatePossibleNavigationRequests(_d3,_d4){
if(_d4===undefined||_d4===null){
_d4=false;
}
if(this.Package.Properties.LookaheadSequencerMode!==LOOKAHEAD_SEQUENCER_MODE_DISABLE){
var _d5=this.WriteAuditLog("`1111`");
this.WriteDetailedLog("`1568`",_d5);
this.TearDownSequencer(this.LookAheadSequencer);
this.WriteDetailedLog("`1655`",_d5);
this.LookAheadSequencer=this.CloneSequencer(this.Sequencer);
this.LookAheadSequencer.LookAhead=true;
this.WriteDetailedLog("`1074`",_d5);
this.LookAheadSequencer.Activities.SetSequencer(this.LookAheadSequencer,true);
this.WriteDetailedLog("`1159`",_d5);
this.PossibleNavigationRequests=this.LookAheadSequencer.EvaluatePossibleNavigationRequests(this.PossibleNavigationRequests);
this.WriteDetailedLog("`1127`",_d5);
if(_d4===true){
if(this.PendingNavigationRequest===null){
if((this.Api!==null)&&(this.Api.RunTimeData!=null)&&(this.Api.RunTimeData.NavRequest!=SCORM_RUNTIME_NAV_REQUEST_NONE)){
var _d6=Control.FindPossibleNavRequestForRuntimeNavRequest(this.Api.RunTimeData.NavRequest);
this.WriteDetailedLog("`1291`"+_d6+"`744`",_d5);
if(_d6.WillSucceed===true){
this.WriteDetailedLog("`1233`",_d5);
Control.ScoHasTerminatedSoUnload();
}else{
this.WriteDetailedLog("`1034`",_d5);
}
}
}
}
if(_d3!==undefined&&_d3!==null&&_d3==true){
this.UpdateDisplay(true,true);
}else{
this.UpdateDisplay(true,false);
}
}else{
_d5=this.WriteAuditLog("`533`");
}
this.Api.IsLookAheadSequencerRunning=false;
this.Api.RunLookAheadSequencerIfNeeded();
}
function Controller_FindPossibleChoiceRequestForActivity(_d7){
var _d8=_d7.GetItemIdentifier();
var _d9=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;
for(var i=_d9;i<this.PossibleNavigationRequests.length;i++){
if(this.PossibleNavigationRequests[i].TargetActivityItemIdentifier==_d8){
return this.PossibleNavigationRequests[i];
}
}
Debug.AssertError("Could not locate possible choice request for activity-"+_d7);
return null;
}
function Controller_GetPossibleContinueRequest(){
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE];
}
function Controller_GetPossiblePreviousRequest(){
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS];
}
function Controller_IsTargetValid(_db){
var _dc=this.ParseTargetStringIntoActivity(_db);
if(_dc===null){
return false;
}else{
return true;
}
}
function Controller_IsChoiceRequestValid(_dd){
var _de=this.ParseTargetStringIntoActivity(_dd);
var _df=_de.GetItemIdentifier();
for(var i=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;i<this.PossibleNavigationRequests.length;i++){
if(this.PossibleNavigationRequests[i].TargetActivityItemIdentifier==_df){
return this.PossibleNavigationRequests[i].WillSucceed;
}
}
return false;
}
function Controller_IsJumpRequestValid(_e1){
var _e2=this.ParseTargetStringIntoActivity(_e1);
if(_e2!=null){
return _e2.IsAvailable();
}
return false;
}
function Controller_IsContinueRequestValid(){
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed;
}
function Controller_IsPreviousRequestValid(){
return this.PossibleNavigationRequests[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed;
}
function Controller_ParseTargetStringIntoActivity(_e3){
var _e4=this.ParseTargetStringFromChoiceRequest(_e3);
var _e5=this.Activities.GetActivityFromIdentifier(_e4);
return _e5;
}
function Controller_ParseTargetStringFromChoiceRequest(_e6){
return _e6.substring(_e6.indexOf("=")+1,_e6.indexOf("}"));
}
function Controller_CloneSequencer(_e7,_e8){
var _e9=new Sequencer(_e8,_e7.Activities.Clone());
if(_e7.SuspendedActivity===null){
_e9.SuspendedActivity=null;
}else{
_e9.SuspendedActivity=_e9.Activities.GetActivityFromIdentifier(_e7.SuspendedActivity.GetItemIdentifier());
}
if(_e7.CurrentActivity===null){
_e9.CurrentActivity=null;
}else{
_e9.CurrentActivity=_e9.Activities.GetActivityFromIdentifier(_e7.CurrentActivity.GetItemIdentifier());
}
_e9.GlobalObjectives=new Array();
for(var _ea in _e7.GlobalObjectives){
_e9.GlobalObjectives[_e9.GlobalObjectives.length]=_e7.GlobalObjectives[_ea].Clone();
}
if(_e7.AtEndOfCourse!==undefined){
_e9.AtEndOfCourse=_e7.AtEndOfCourse;
_e9.AtStartOfCourse=_e7.AtStartOfCourse;
}
_e9.NavigationRequest=null;
_e9.ChoiceTargetIdentifier=null;
_e9.Exception=null;
_e9.ExceptionText=null;
return _e9;
}
function Controller_TearDownSequencer(_eb){
_eb.LookAhead=null;
if(_eb.Activities!==null){
_eb.Activities.TearDown();
}
_eb.Activities=null;
_eb.NavigationRequest=null;
_eb.ChoiceTargetIdentifier=null;
_eb.SuspendedActivity=null;
_eb.CurrentActivity=null;
_eb.Exception=null;
_eb.ExceptionText=null;
_eb.GlobalObjectives=null;
}
function Controller_WriteAuditLog(str){
Debug.WriteControlAudit(str);
}
function Controller_WriteDetailedLog(str,_ee){
Debug.WriteControlDetailed(str,_ee);
}
function Controller_WriteDetailedLogError(str,_f0){
Debug.WriteControlDetailed(str,_f0,true);
}
function Controller_WriteHistoryLog(str,_f2){
HistoryLog.WriteEventDetailed(str,_f2);
}
function Controller_WriteHistoryReturnValue(str,_f4){
HistoryLog.WriteEventDetailedReturnValue(str,_f4);
}
function Controller_GetLaunchHistoryId(){
return LaunchHistoryId;
}
function BuildFullUrl(_f5,_f6){
var _f7;
if(_f6.indexOf("?")>-1){
_f7=_f6.substr(0,_f6.indexOf("?"));
}else{
_f7=_f6;
}
var _f8=_f6.substr(0,_f7.lastIndexOf("/"));
while(_f5.indexOf("../")>-1){
_f5=_f5.substr(3,_f5.length);
_f8=_f8.substr(0,_f8.lastIndexOf("/"));
}
return _f8+"/"+_f5;
}
function GetController(){
var _f9=500;
var _fa=0;
var win=window;
var _fc;
while((win.Control===null)&&(win.parent!==null)&&(win.parent!=win)&&(_fa<=_f9)){
_fa++;
win=win.parent;
}
if(win.Control===null){
Debug.AssertError("Could not locate the Control object.");
}else{
_fc=win.Control;
}
return _fc;
}
function Controller_UpdateGlobalLearnerPrefs(){
if(this.Api.LearnerPrefsArray!==null&&this.Api.LearnerPrefsArray!==undefined){
var _fd=this.Api.LearnerPrefsArray;
for(var _fe in _fd){
for(var _ff in this.Activities.ActivityList){
var _100=this.Activities.ActivityList[_ff];
if(_100.RunTime!==null&&_100.RunTime[_fe]!==_fd[_fe]){
_100.RunTime[_fe]=_fd[_fe];
_100.RunTime.SetDirtyData();
}
}
}
}
}
function Controller_IsUserOverTimeLimit(){
if(this.Package.Properties.TimeLimit<=0){
return false;
}
var _101=this.Activities.GetRootActivity();
if(_101===null){
return false;
}
var _102=ConvertIso8601TimeSpanToHundredths(_101.GetActivityExperiencedDurationTracked());
var _103;
if(this.Api.TrackedStartDate===null){
_103=0;
}else{
_103=Math.round((new Date()-this.Api.TrackedStartDate)/10);
}
var _104=_102+_103;
var _105=this.Package.Properties.TimeLimit*60*100;
return _104>_105;
}
function Controller_ExitIfTimeLimitExceeded(){
if(this.IsUserOverTimeLimit()==true){
this.WriteAuditLog("`845`");
if(this.MessageShown!==true){
alert("You have exceeded the time limit for this course, your session will now end.");
this.MessageShown=true;
}
this.TriggerReturnToLMS();
}
}
function Controller_BlockCourseEntryWithMessage(_106){
this.Sequencer.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_106);
for(var _107 in this.Sequencer.Activities.ActivityList){
activity.SetHiddenFromChoice(true);
var _108=this.Sequencer.Activities.ActivityList[_107].MenuItem;
if(_108!==null){
_108.Disable();
}
}
for(var i=0;i<this.PossibleNavigationRequests.length;i++){
this.PossibleNavigationRequests[i].WillSucceed=false;
}
IntegrationImplementation.UpdateControlState(IntegrationImplementation.GetDocumentObjectForControls(),this.PossibleNavigationRequests,null);
}
function Debugger(_10a,_10b,_10c,_10d,_10e,_10f,_110,_111,_112,_113,_114){
this.auditCount=0;
this.RecordControlAudit=_10a;
this.RecordControlDetailed=_10b;
if(this.RecordControlDetailed){
this.RecordControlAudit=true;
}
this.RecordRteAudit=_10c;
this.RecordRteDetailed=_10d;
if(this.RecordRteDetailed){
this.RecordRteAudit=true;
}
this.RecordSequencingAudit=_10e;
this.RecordSequencingDetailed=_10f;
if(this.RecordSequencingDetailed){
this.RecordSequencingAudit=true;
}
this.RecordLookAheadAudit=_111;
this.RecordLookAheadDetailed=_112;
if(this.RecordLookAheadDetailed){
this.RecordLookAheadAudit=true;
}
this.RecordSequencingSimple=_110;
this.Write=Debugger_Write;
this.AssertError=Debugger_AssertError;
this.DataIsAvailable=Debugger_DataIsAvailable;
this.ShowAllAvailableData=Debugger_ShowAllAvailableData;
this.WriteControlAudit=Debugger_WriteControlAudit;
this.WriteControlDetailed=Debugger_WriteControlDetailed;
this.WriteRteAudit=Debugger_WriteRteAudit;
this.WriteRteAuditReturnValue=Debugger_WriteRteAuditReturnValue;
this.WriteRteDetailed=Debugger_WriteRteDetailed;
this.WriteSequencingAudit=Debugger_WriteSequencingAudit;
this.WriteSequencingAuditReturnValue=Debugger_WriteSequencingAuditReturnValue;
this.WriteSequencingDetailed=Debugger_WriteSequencingDetailed;
this.WriteSequencingSimpleAudit=Debugger_WriteSequencingSimpleAudit;
this.WriteSequencingSimpleReturnValue=Debugger_WriteSequencingSimpleReturnValue;
this.WriteSequencingSimpleDetailed=Debugger_WriteSequencingSimpleDetailed;
this.WriteLookAheadAudit=Debugger_WriteLookAheadAudit;
this.WriteLookAheadAuditReturnValue=Debugger_WriteLookAheadAuditReturnValue;
this.WriteLookAheadDetailed=Debugger_WriteLookAheadDetailed;
this.GetErrors=Debugger_GetErrors;
this.log=new Log(_113,_114);
this.currentControlEntry=null;
this.currentRunTimeEntry=null;
this.currentSequencingEntry=null;
this.currentLookAheadEntry=null;
this.currentSequencingSimpleEntry=null;
this.ErrorDataExists=false;
this.ShowDebugLogAtExit=false;
this.version=_113;
this.includeTimestamps=_114;
}
function Debugger_Write(str){
this.AssertError("Debug.Write function is deprecated. Remove all calls.");
}
function Debugger_AssertError(arg,_117){
if(_117===undefined||_117===null||_117===true){
var _118="Code Asserted Error-"+arg;
Debug.WriteControlAudit(_118);
if(typeof console!=="undefined"){
console.log(_118);
}
}
}
function Debugger_DataIsAvailable(){
var _119=this.RecordControlAudit||this.RecordControlDetailed||this.RecordRteAudit||this.RecordRteDetailed||this.RecordSequencingAudit||this.RecordSequencingDetailed||this.RecordLookAheadAudit||this.RecordLookAheadDetailed||this.ErrorDataExists;
return _119;
}
function Debugger_ShowAllAvailableData(_11a){
if(_11a===undefined||_11a===null){
_11a=false;
}
this.log.display(_11a);
}
function Debugger_WriteControlAudit(args,_11c,_11d){
if(_11d){
this.ErrorDataExists=true;
}
if(this.RecordControlAudit||_11d){
if(_11c===undefined||_11c===null){
this.currentControlEntry=this.log.startNew("c",args);
}else{
this.currentControlEntry=_11c.startNew("c",args);
}
this.currentControlEntry.setAttribute("id",this.auditCount++);
return this.currentControlEntry;
}else{
return disabledLogEntry;
}
}
function Debugger_WriteControlAuditReturnValue(str,_11f,_120){
if(this.currentControlEntry==null){
return;
}
if(this.RecordControlAudit||_120){
this.currentControlEntry.setReturn(str);
}
if(_11f!==null&&_11f!==undefined){
this.currentControlEntry=_11f;
}else{
this.AssertError("Debugger_WriteControlAuditReturnValue() called without parentEntry");
}
}
function Debugger_WriteControlDetailed(str,_122,_123){
if(this.currentControlEntry==null){
return;
}
if(_123){
var _124=this.WriteControlAudit("Control ERROR",null,true);
_124.write(str);
}else{
if(this.RecordControlDetailed){
if(_122!==undefined&&_122!==null){
_122.write(str);
}else{
this.currentControlEntry.write(str);
}
}
}
}
function Debugger_WriteRteAudit(args,_126){
if(this.RecordRteAudit){
if(_126===undefined||_126===null){
this.currentRunTimeEntry=this.log.startNew("rt",args);
}else{
this.currentRunTimeEntry=_126.startNew("rt",args);
}
this.currentRunTimeEntry.setAttribute("id",this.auditCount++);
return this.currentRunTimeEntry;
}else{
return disabledLogEntry;
}
}
function Debugger_WriteRteAuditReturnValue(str,_128){
if(this.currentRunTimeEntry==null){
return;
}
if(this.RecordRteAudit){
this.currentRunTimeEntry.setReturn(str);
}
if(_128!==null&&_128!==undefined){
this.currentRunTimeEntry=_128;
}else{
}
}
function Debugger_WriteRteDetailed(str,_12a){
if(this.currentRunTimeEntry==null){
return;
}
if(this.RecordRteDetailed){
if(_12a===undefined||_12a===null){
this.currentRunTimeEntry.write(str);
}else{
_12a.write(str);
}
}
}
function Debugger_WriteSequencingAudit(args,_12c){
if(this.RecordSequencingAudit){
if(_12c===undefined||_12c===null){
this.currentSequencingEntry=this.log.startNew("s",args);
}else{
this.currentSequencingEntry=_12c.startNew("s",args);
}
this.currentSequencingEntry.setAttribute("id",this.auditCount++);
return this.currentSequencingEntry;
}else{
return disabledLogEntry;
}
}
function Debugger_WriteSequencingAuditReturnValue(str,_12e){
if(this.currentSequencingEntry==null){
return;
}
if(this.RecordSequencingAudit){
this.currentSequencingEntry.setReturn(str);
}
if(_12e!==null&&_12e!==undefined){
this.currentSequencingEntry=_12e;
}else{
this.AssertError("Debugger_WriteSequencingAuditReturnValue() called without parentEntry");
}
}
function Debugger_WriteSequencingDetailed(str,_130){
if(this.currentSequencingEntry==null){
return;
}
if(this.RecordSequencingDetailed){
if(_130===undefined||_130===null){
this.currentSequencingEntry.write(str);
}else{
_130.write(str);
}
}
}
function Debugger_WriteLookAheadAudit(args,_132){
if(this.RecordLookAheadAudit){
if(_132===undefined||_132===null){
this.currentLookAheadEntry=this.log.startNew("l",args);
}else{
this.currentLookAheadEntry=_132.startNew("l",args);
}
this.currentLookAheadEntry.setAttribute("id",this.auditCount++);
return this.currentLookAheadEntry;
}else{
return disabledLogEntry;
}
}
function Debugger_WriteLookAheadAuditReturnValue(str,_134){
if(this.currentLookAheadEntry==null){
return;
}
if(this.RecordLookAheadAudit){
this.currentLookAheadEntry.setReturn(str);
}
if(_134!==null&&_134!==undefined){
this.currentLookAheadEntry=_134;
}else{
this.AssertError("Debugger_WriteLookAheadAuditReturnValue() called without parentEntry");
}
}
function Debugger_WriteLookAheadDetailed(str,_136){
if(this.currentLookAheadEntry==null){
return;
}
if(this.RecordLookAheadDetailed){
if(_136===undefined||_136===null){
this.currentLookAheadEntry.write(str);
}else{
_136.write(str);
}
}
}
function Debugger_WriteSequencingSimpleAudit(args,_138){
if(this.RecordSequencingSimple){
if(_138===undefined||_138===null){
this.currentSequencingSimpleEntry=this.log.startNew("ss",args);
}else{
this.currentSequencingSimpleEntry=_138.startNew("ss",args);
}
this.currentSequencingSimpleEntry.setAttribute("id",this.auditCount++);
return this.currentSequencingSimpleEntry;
}else{
return disabledLogEntry;
}
}
function Debugger_WriteSequencingSimpleReturnValue(str,_13a){
if(this.currentSequencingSimpleEntry==null){
return;
}
if(this.RecordSequencingSimple){
this.currentSequencingSimpleEntry.setReturn(str);
}
if(_13a!==null&&_13a!==undefined){
this.currentSequencingSimpleEntry=_13a;
}else{
this.AssertError("Debugger_WriteLookAheadAuditReturnValue() called without parentEntry");
}
}
function Debugger_WriteSequencingSimpleDetailed(str,_13c){
if(this.currentSequencingSimpleEntry==null){
return;
}
if(this.RecordSequencingSimple){
if(_13c===undefined||_13c===null){
this.currentSequencingSimpleEntry.write(str);
}else{
_13c.write(str);
}
}
}
function Debugger_GetErrors(){
var _13d="//c[@f='Control ERROR']";
var _13e=this.log.dom.selectNodes(_13d);
var _13f=new Array();
for(var i=0;i<_13e.length;i++){
if(_13e[i].text!==undefined){
_13f[_13f.length]=_13e[i].text;
}else{
_13f[_13f.length]=_13e[i].textContent;
}
}
return _13f;
}
function DisabledLogEntry(){
}
DisabledLogEntry.prototype.write=function(){
};
DisabledLogEntry.prototype.error=function(){
};
DisabledLogEntry.prototype.startNew=function(){
return disabledLogEntry;
};
DisabledLogEntry.prototype.setAttribute=function(){
};
DisabledLogEntry.prototype.setReturn=function(){
};
disabledLogEntry=new DisabledLogEntry();
var objXmlHttp=null;
var Debug=null;
var ExternalConfig="";
var ExternalRegistrationId="";
var PathToCourse="";
var RedirectOnExitUrl="";
var LearnerName="";
var LearnerId="";
var IntermediatePage=null;
var PopupLauncherPage=null;
var RegistrationToDeliver=null;
var QueryStringAdditions=null;
var IntegrationImplementation=null;
var Control=null;
function HistoryLogger(_141,_142,_143){
this.auditCount=0;
this.RecordHistory=_141;
this.RecordHistoryDetailed=_142;
if(this.RecordHistoryDetailed){
this.RecordHistory=true;
}
this.DataIsAvailable=HistoryLogger_DataIsAvailable;
this.ShowAllAvailableData=HistoryLogger_ShowAllAvailableData;
this.WriteEvent=HistoryLogger_WriteEvent;
this.WriteEventReturnValue=HistoryLogger_WriteEventReturnValue;
this.WriteEventDetailed=HistoryLogger_WriteEventDetailed;
this.WriteEventDetailedReturnValue=HistoryLogger_WriteEventDetailedReturnValue;
this.GetSerializedLog=HistoryLogger_GetSerializedLog;
this.log=new Log(_143,true,"RTL");
this.currentEntry=null;
this.DataExists=false;
this.version=_143;
this.includeTimestamps=true;
}
function HistoryLogger_DataIsAvailable(){
return this.DataExists;
}
function HistoryLogger_ShowAllAvailableData(){
this.log.display();
}
function HistoryLogger_WriteEvent(args,atts,_146){
if(this.RecordHistory){
var _147=(atts!==undefined&&atts!==null&&atts.event?"":args);
if(_146===undefined||_146===null){
this.currentEntry=this.log.startNew("RT",_147);
}else{
this.currentEntry=_146.startNew("RT",_147);
}
this.currentEntry.setAttribute("id",this.auditCount++);
for(var _148 in atts){
this.currentEntry.setAttribute(_148,atts[_148]);
}
return this.currentEntry;
}else{
return disabledLogEntry;
}
}
function HistoryLogger_WriteEventReturnValue(str,atts,_14b){
if(this.currentEntry==null){
return;
}
if(this.RecordHistory){
this.currentEntry.setReturn(str);
for(var _14c in atts){
this.currentEntry.setAttribute(_14c,atts[_14c]);
}
}
if(_14b!==null&&_14b!==undefined){
this.currentEntry=_14b;
}else{
}
}
function HistoryLogger_WriteEventDetailed(args,atts,_14f){
if(this.RecordHistoryDetailed){
var _150=(atts!==undefined&&atts!==null&&atts.event?"":args);
if(_14f===undefined||_14f===null){
this.currentEntry=this.log.startNew("RT",_150);
}else{
this.currentEntry=_14f.startNew("RT",_150);
}
this.currentEntry.setAttribute("id",this.auditCount++);
for(var _151 in atts){
this.currentEntry.setAttribute(_151,atts[_151]);
}
return this.currentEntry;
}else{
return disabledLogEntry;
}
}
function HistoryLogger_WriteEventDetailedReturnValue(str,atts,_154){
if(this.currentEntry==null){
return;
}
if(this.RecordHistoryDetailed){
this.currentEntry.setReturn(str);
for(var _155 in atts){
this.currentEntry.setAttribute(_155,atts[_155]);
}
}
if(_154!==null&&_154!==undefined){
this.currentEntry=_154;
}else{
}
}
function HistoryLogger_GetSerializedLog(){
return this.log.serializeDomElement(this.log.dom.getElementsByTagName("RTL")[0]);
}
Iso639LangCodes_LangCodes.prototype["aa"]=true;
Iso639LangCodes_LangCodes.prototype["aar"]=true;
Iso639LangCodes_LangCodes.prototype["ab"]=true;
Iso639LangCodes_LangCodes.prototype["abk"]=true;
Iso639LangCodes_LangCodes.prototype["ace"]=true;
Iso639LangCodes_LangCodes.prototype["ach"]=true;
Iso639LangCodes_LangCodes.prototype["ada"]=true;
Iso639LangCodes_LangCodes.prototype["ady"]=true;
Iso639LangCodes_LangCodes.prototype["ae"]=true;
Iso639LangCodes_LangCodes.prototype["af"]=true;
Iso639LangCodes_LangCodes.prototype["afa"]=true;
Iso639LangCodes_LangCodes.prototype["afh"]=true;
Iso639LangCodes_LangCodes.prototype["afr"]=true;
Iso639LangCodes_LangCodes.prototype["ak"]=true;
Iso639LangCodes_LangCodes.prototype["aka"]=true;
Iso639LangCodes_LangCodes.prototype["akk"]=true;
Iso639LangCodes_LangCodes.prototype["alb"]=true;
Iso639LangCodes_LangCodes.prototype["alb"]=true;
Iso639LangCodes_LangCodes.prototype["ale"]=true;
Iso639LangCodes_LangCodes.prototype["alg"]=true;
Iso639LangCodes_LangCodes.prototype["am"]=true;
Iso639LangCodes_LangCodes.prototype["amh"]=true;
Iso639LangCodes_LangCodes.prototype["an"]=true;
Iso639LangCodes_LangCodes.prototype["ang"]=true;
Iso639LangCodes_LangCodes.prototype["apa"]=true;
Iso639LangCodes_LangCodes.prototype["ar"]=true;
Iso639LangCodes_LangCodes.prototype["ara"]=true;
Iso639LangCodes_LangCodes.prototype["arc"]=true;
Iso639LangCodes_LangCodes.prototype["arg"]=true;
Iso639LangCodes_LangCodes.prototype["arm"]=true;
Iso639LangCodes_LangCodes.prototype["arm"]=true;
Iso639LangCodes_LangCodes.prototype["arn"]=true;
Iso639LangCodes_LangCodes.prototype["arp"]=true;
Iso639LangCodes_LangCodes.prototype["art"]=true;
Iso639LangCodes_LangCodes.prototype["arw"]=true;
Iso639LangCodes_LangCodes.prototype["as"]=true;
Iso639LangCodes_LangCodes.prototype["asm"]=true;
Iso639LangCodes_LangCodes.prototype["ast"]=true;
Iso639LangCodes_LangCodes.prototype["ath"]=true;
Iso639LangCodes_LangCodes.prototype["aus"]=true;
Iso639LangCodes_LangCodes.prototype["av"]=true;
Iso639LangCodes_LangCodes.prototype["ava"]=true;
Iso639LangCodes_LangCodes.prototype["ave"]=true;
Iso639LangCodes_LangCodes.prototype["awa"]=true;
Iso639LangCodes_LangCodes.prototype["ay"]=true;
Iso639LangCodes_LangCodes.prototype["aym"]=true;
Iso639LangCodes_LangCodes.prototype["az"]=true;
Iso639LangCodes_LangCodes.prototype["aze"]=true;
Iso639LangCodes_LangCodes.prototype["ba"]=true;
Iso639LangCodes_LangCodes.prototype["bad"]=true;
Iso639LangCodes_LangCodes.prototype["bai"]=true;
Iso639LangCodes_LangCodes.prototype["bak"]=true;
Iso639LangCodes_LangCodes.prototype["bal"]=true;
Iso639LangCodes_LangCodes.prototype["bam"]=true;
Iso639LangCodes_LangCodes.prototype["ban"]=true;
Iso639LangCodes_LangCodes.prototype["baq"]=true;
Iso639LangCodes_LangCodes.prototype["baq"]=true;
Iso639LangCodes_LangCodes.prototype["bas"]=true;
Iso639LangCodes_LangCodes.prototype["bat"]=true;
Iso639LangCodes_LangCodes.prototype["be"]=true;
Iso639LangCodes_LangCodes.prototype["bej"]=true;
Iso639LangCodes_LangCodes.prototype["bel"]=true;
Iso639LangCodes_LangCodes.prototype["bem"]=true;
Iso639LangCodes_LangCodes.prototype["ben"]=true;
Iso639LangCodes_LangCodes.prototype["ber"]=true;
Iso639LangCodes_LangCodes.prototype["bg"]=true;
Iso639LangCodes_LangCodes.prototype["bh"]=true;
Iso639LangCodes_LangCodes.prototype["bho"]=true;
Iso639LangCodes_LangCodes.prototype["bi"]=true;
Iso639LangCodes_LangCodes.prototype["bih"]=true;
Iso639LangCodes_LangCodes.prototype["bik"]=true;
Iso639LangCodes_LangCodes.prototype["bin"]=true;
Iso639LangCodes_LangCodes.prototype["bis"]=true;
Iso639LangCodes_LangCodes.prototype["bla"]=true;
Iso639LangCodes_LangCodes.prototype["bm"]=true;
Iso639LangCodes_LangCodes.prototype["bn"]=true;
Iso639LangCodes_LangCodes.prototype["bnt"]=true;
Iso639LangCodes_LangCodes.prototype["bo"]=true;
Iso639LangCodes_LangCodes.prototype["bo"]=true;
Iso639LangCodes_LangCodes.prototype["bod"]=true;
Iso639LangCodes_LangCodes.prototype["bod"]=true;
Iso639LangCodes_LangCodes.prototype["bos"]=true;
Iso639LangCodes_LangCodes.prototype["br"]=true;
Iso639LangCodes_LangCodes.prototype["bra"]=true;
Iso639LangCodes_LangCodes.prototype["bre"]=true;
Iso639LangCodes_LangCodes.prototype["bs"]=true;
Iso639LangCodes_LangCodes.prototype["btk"]=true;
Iso639LangCodes_LangCodes.prototype["bua"]=true;
Iso639LangCodes_LangCodes.prototype["bug"]=true;
Iso639LangCodes_LangCodes.prototype["bul"]=true;
Iso639LangCodes_LangCodes.prototype["bur"]=true;
Iso639LangCodes_LangCodes.prototype["bur"]=true;
Iso639LangCodes_LangCodes.prototype["byn"]=true;
Iso639LangCodes_LangCodes.prototype["ca"]=true;
Iso639LangCodes_LangCodes.prototype["cad"]=true;
Iso639LangCodes_LangCodes.prototype["cai"]=true;
Iso639LangCodes_LangCodes.prototype["car"]=true;
Iso639LangCodes_LangCodes.prototype["cat"]=true;
Iso639LangCodes_LangCodes.prototype["cau"]=true;
Iso639LangCodes_LangCodes.prototype["ce"]=true;
Iso639LangCodes_LangCodes.prototype["ceb"]=true;
Iso639LangCodes_LangCodes.prototype["cel"]=true;
Iso639LangCodes_LangCodes.prototype["ces"]=true;
Iso639LangCodes_LangCodes.prototype["ces"]=true;
Iso639LangCodes_LangCodes.prototype["ch"]=true;
Iso639LangCodes_LangCodes.prototype["cha"]=true;
Iso639LangCodes_LangCodes.prototype["chb"]=true;
Iso639LangCodes_LangCodes.prototype["che"]=true;
Iso639LangCodes_LangCodes.prototype["chg"]=true;
Iso639LangCodes_LangCodes.prototype["chi"]=true;
Iso639LangCodes_LangCodes.prototype["chi"]=true;
Iso639LangCodes_LangCodes.prototype["chk"]=true;
Iso639LangCodes_LangCodes.prototype["chm"]=true;
Iso639LangCodes_LangCodes.prototype["chn"]=true;
Iso639LangCodes_LangCodes.prototype["cho"]=true;
Iso639LangCodes_LangCodes.prototype["chp"]=true;
Iso639LangCodes_LangCodes.prototype["chr"]=true;
Iso639LangCodes_LangCodes.prototype["chu"]=true;
Iso639LangCodes_LangCodes.prototype["chv"]=true;
Iso639LangCodes_LangCodes.prototype["chy"]=true;
Iso639LangCodes_LangCodes.prototype["cmc"]=true;
Iso639LangCodes_LangCodes.prototype["co"]=true;
Iso639LangCodes_LangCodes.prototype["cop"]=true;
Iso639LangCodes_LangCodes.prototype["cor"]=true;
Iso639LangCodes_LangCodes.prototype["cos"]=true;
Iso639LangCodes_LangCodes.prototype["cpe"]=true;
Iso639LangCodes_LangCodes.prototype["cpf"]=true;
Iso639LangCodes_LangCodes.prototype["cpp"]=true;
Iso639LangCodes_LangCodes.prototype["cr"]=true;
Iso639LangCodes_LangCodes.prototype["cre"]=true;
Iso639LangCodes_LangCodes.prototype["crh"]=true;
Iso639LangCodes_LangCodes.prototype["crp"]=true;
Iso639LangCodes_LangCodes.prototype["cs"]=true;
Iso639LangCodes_LangCodes.prototype["cs"]=true;
Iso639LangCodes_LangCodes.prototype["csb"]=true;
Iso639LangCodes_LangCodes.prototype["cu"]=true;
Iso639LangCodes_LangCodes.prototype["cus"]=true;
Iso639LangCodes_LangCodes.prototype["cv"]=true;
Iso639LangCodes_LangCodes.prototype["cy"]=true;
Iso639LangCodes_LangCodes.prototype["cy"]=true;
Iso639LangCodes_LangCodes.prototype["cym"]=true;
Iso639LangCodes_LangCodes.prototype["cym"]=true;
Iso639LangCodes_LangCodes.prototype["cze"]=true;
Iso639LangCodes_LangCodes.prototype["cze"]=true;
Iso639LangCodes_LangCodes.prototype["da"]=true;
Iso639LangCodes_LangCodes.prototype["dak"]=true;
Iso639LangCodes_LangCodes.prototype["dan"]=true;
Iso639LangCodes_LangCodes.prototype["dar"]=true;
Iso639LangCodes_LangCodes.prototype["day"]=true;
Iso639LangCodes_LangCodes.prototype["de"]=true;
Iso639LangCodes_LangCodes.prototype["de"]=true;
Iso639LangCodes_LangCodes.prototype["del"]=true;
Iso639LangCodes_LangCodes.prototype["den"]=true;
Iso639LangCodes_LangCodes.prototype["deu"]=true;
Iso639LangCodes_LangCodes.prototype["deu"]=true;
Iso639LangCodes_LangCodes.prototype["dgr"]=true;
Iso639LangCodes_LangCodes.prototype["din"]=true;
Iso639LangCodes_LangCodes.prototype["div"]=true;
Iso639LangCodes_LangCodes.prototype["doi"]=true;
Iso639LangCodes_LangCodes.prototype["dra"]=true;
Iso639LangCodes_LangCodes.prototype["dsb"]=true;
Iso639LangCodes_LangCodes.prototype["dua"]=true;
Iso639LangCodes_LangCodes.prototype["dum"]=true;
Iso639LangCodes_LangCodes.prototype["dut"]=true;
Iso639LangCodes_LangCodes.prototype["dut"]=true;
Iso639LangCodes_LangCodes.prototype["dv"]=true;
Iso639LangCodes_LangCodes.prototype["dyu"]=true;
Iso639LangCodes_LangCodes.prototype["dz"]=true;
Iso639LangCodes_LangCodes.prototype["dzo"]=true;
Iso639LangCodes_LangCodes.prototype["ee"]=true;
Iso639LangCodes_LangCodes.prototype["efi"]=true;
Iso639LangCodes_LangCodes.prototype["egy"]=true;
Iso639LangCodes_LangCodes.prototype["eka"]=true;
Iso639LangCodes_LangCodes.prototype["el"]=true;
Iso639LangCodes_LangCodes.prototype["el"]=true;
Iso639LangCodes_LangCodes.prototype["ell"]=true;
Iso639LangCodes_LangCodes.prototype["ell"]=true;
Iso639LangCodes_LangCodes.prototype["elx"]=true;
Iso639LangCodes_LangCodes.prototype["en"]=true;
Iso639LangCodes_LangCodes.prototype["eng"]=true;
Iso639LangCodes_LangCodes.prototype["enm"]=true;
Iso639LangCodes_LangCodes.prototype["eo"]=true;
Iso639LangCodes_LangCodes.prototype["epo"]=true;
Iso639LangCodes_LangCodes.prototype["es"]=true;
Iso639LangCodes_LangCodes.prototype["est"]=true;
Iso639LangCodes_LangCodes.prototype["et"]=true;
Iso639LangCodes_LangCodes.prototype["eu"]=true;
Iso639LangCodes_LangCodes.prototype["eu"]=true;
Iso639LangCodes_LangCodes.prototype["eus"]=true;
Iso639LangCodes_LangCodes.prototype["eus"]=true;
Iso639LangCodes_LangCodes.prototype["ewe"]=true;
Iso639LangCodes_LangCodes.prototype["ewo"]=true;
Iso639LangCodes_LangCodes.prototype["fa"]=true;
Iso639LangCodes_LangCodes.prototype["fa"]=true;
Iso639LangCodes_LangCodes.prototype["fan"]=true;
Iso639LangCodes_LangCodes.prototype["fao"]=true;
Iso639LangCodes_LangCodes.prototype["fas"]=true;
Iso639LangCodes_LangCodes.prototype["fas"]=true;
Iso639LangCodes_LangCodes.prototype["fat"]=true;
Iso639LangCodes_LangCodes.prototype["ff"]=true;
Iso639LangCodes_LangCodes.prototype["fi"]=true;
Iso639LangCodes_LangCodes.prototype["fij"]=true;
Iso639LangCodes_LangCodes.prototype["fil"]=true;
Iso639LangCodes_LangCodes.prototype["fin"]=true;
Iso639LangCodes_LangCodes.prototype["fiu"]=true;
Iso639LangCodes_LangCodes.prototype["fj"]=true;
Iso639LangCodes_LangCodes.prototype["fo"]=true;
Iso639LangCodes_LangCodes.prototype["fon"]=true;
Iso639LangCodes_LangCodes.prototype["fr"]=true;
Iso639LangCodes_LangCodes.prototype["fra"]=true;
Iso639LangCodes_LangCodes.prototype["fre"]=true;
Iso639LangCodes_LangCodes.prototype["frm"]=true;
Iso639LangCodes_LangCodes.prototype["fro"]=true;
Iso639LangCodes_LangCodes.prototype["fry"]=true;
Iso639LangCodes_LangCodes.prototype["ful"]=true;
Iso639LangCodes_LangCodes.prototype["fur"]=true;
Iso639LangCodes_LangCodes.prototype["fy"]=true;
Iso639LangCodes_LangCodes.prototype["ga"]=true;
Iso639LangCodes_LangCodes.prototype["gaa"]=true;
Iso639LangCodes_LangCodes.prototype["gay"]=true;
Iso639LangCodes_LangCodes.prototype["gba"]=true;
Iso639LangCodes_LangCodes.prototype["gd"]=true;
Iso639LangCodes_LangCodes.prototype["gem"]=true;
Iso639LangCodes_LangCodes.prototype["geo"]=true;
Iso639LangCodes_LangCodes.prototype["geo"]=true;
Iso639LangCodes_LangCodes.prototype["ger"]=true;
Iso639LangCodes_LangCodes.prototype["ger"]=true;
Iso639LangCodes_LangCodes.prototype["gez"]=true;
Iso639LangCodes_LangCodes.prototype["gil"]=true;
Iso639LangCodes_LangCodes.prototype["gl"]=true;
Iso639LangCodes_LangCodes.prototype["gla"]=true;
Iso639LangCodes_LangCodes.prototype["gle"]=true;
Iso639LangCodes_LangCodes.prototype["glg"]=true;
Iso639LangCodes_LangCodes.prototype["glv"]=true;
Iso639LangCodes_LangCodes.prototype["gmh"]=true;
Iso639LangCodes_LangCodes.prototype["gn"]=true;
Iso639LangCodes_LangCodes.prototype["goh"]=true;
Iso639LangCodes_LangCodes.prototype["gon"]=true;
Iso639LangCodes_LangCodes.prototype["gor"]=true;
Iso639LangCodes_LangCodes.prototype["got"]=true;
Iso639LangCodes_LangCodes.prototype["grb"]=true;
Iso639LangCodes_LangCodes.prototype["grc"]=true;
Iso639LangCodes_LangCodes.prototype["gre"]=true;
Iso639LangCodes_LangCodes.prototype["gre"]=true;
Iso639LangCodes_LangCodes.prototype["grn"]=true;
Iso639LangCodes_LangCodes.prototype["gu"]=true;
Iso639LangCodes_LangCodes.prototype["guj"]=true;
Iso639LangCodes_LangCodes.prototype["gv"]=true;
Iso639LangCodes_LangCodes.prototype["gwi"]=true;
Iso639LangCodes_LangCodes.prototype["ha"]=true;
Iso639LangCodes_LangCodes.prototype["hai"]=true;
Iso639LangCodes_LangCodes.prototype["hat"]=true;
Iso639LangCodes_LangCodes.prototype["hau"]=true;
Iso639LangCodes_LangCodes.prototype["haw"]=true;
Iso639LangCodes_LangCodes.prototype["he"]=true;
Iso639LangCodes_LangCodes.prototype["heb"]=true;
Iso639LangCodes_LangCodes.prototype["her"]=true;
Iso639LangCodes_LangCodes.prototype["hi"]=true;
Iso639LangCodes_LangCodes.prototype["hil"]=true;
Iso639LangCodes_LangCodes.prototype["him"]=true;
Iso639LangCodes_LangCodes.prototype["hin"]=true;
Iso639LangCodes_LangCodes.prototype["hit"]=true;
Iso639LangCodes_LangCodes.prototype["hmn"]=true;
Iso639LangCodes_LangCodes.prototype["hmo"]=true;
Iso639LangCodes_LangCodes.prototype["ho"]=true;
Iso639LangCodes_LangCodes.prototype["hr"]=true;
Iso639LangCodes_LangCodes.prototype["hr"]=true;
Iso639LangCodes_LangCodes.prototype["hrv"]=true;
Iso639LangCodes_LangCodes.prototype["hrv"]=true;
Iso639LangCodes_LangCodes.prototype["hsb"]=true;
Iso639LangCodes_LangCodes.prototype["ht"]=true;
Iso639LangCodes_LangCodes.prototype["hu"]=true;
Iso639LangCodes_LangCodes.prototype["hun"]=true;
Iso639LangCodes_LangCodes.prototype["hup"]=true;
Iso639LangCodes_LangCodes.prototype["hy"]=true;
Iso639LangCodes_LangCodes.prototype["hy"]=true;
Iso639LangCodes_LangCodes.prototype["hye"]=true;
Iso639LangCodes_LangCodes.prototype["hye"]=true;
Iso639LangCodes_LangCodes.prototype["hz"]=true;
Iso639LangCodes_LangCodes.prototype["ia"]=true;
Iso639LangCodes_LangCodes.prototype["iba"]=true;
Iso639LangCodes_LangCodes.prototype["ibo"]=true;
Iso639LangCodes_LangCodes.prototype["ice"]=true;
Iso639LangCodes_LangCodes.prototype["ice"]=true;
Iso639LangCodes_LangCodes.prototype["id"]=true;
Iso639LangCodes_LangCodes.prototype["ido"]=true;
Iso639LangCodes_LangCodes.prototype["ie"]=true;
Iso639LangCodes_LangCodes.prototype["ig"]=true;
Iso639LangCodes_LangCodes.prototype["ii"]=true;
Iso639LangCodes_LangCodes.prototype["iii"]=true;
Iso639LangCodes_LangCodes.prototype["ijo"]=true;
Iso639LangCodes_LangCodes.prototype["ik"]=true;
Iso639LangCodes_LangCodes.prototype["iku"]=true;
Iso639LangCodes_LangCodes.prototype["ile"]=true;
Iso639LangCodes_LangCodes.prototype["ilo"]=true;
Iso639LangCodes_LangCodes.prototype["ina"]=true;
Iso639LangCodes_LangCodes.prototype["inc"]=true;
Iso639LangCodes_LangCodes.prototype["ind"]=true;
Iso639LangCodes_LangCodes.prototype["ine"]=true;
Iso639LangCodes_LangCodes.prototype["inh"]=true;
Iso639LangCodes_LangCodes.prototype["io"]=true;
Iso639LangCodes_LangCodes.prototype["ipk"]=true;
Iso639LangCodes_LangCodes.prototype["ira"]=true;
Iso639LangCodes_LangCodes.prototype["iro"]=true;
Iso639LangCodes_LangCodes.prototype["is"]=true;
Iso639LangCodes_LangCodes.prototype["is"]=true;
Iso639LangCodes_LangCodes.prototype["isl"]=true;
Iso639LangCodes_LangCodes.prototype["isl"]=true;
Iso639LangCodes_LangCodes.prototype["it"]=true;
Iso639LangCodes_LangCodes.prototype["ita"]=true;
Iso639LangCodes_LangCodes.prototype["iu"]=true;
Iso639LangCodes_LangCodes.prototype["ja"]=true;
Iso639LangCodes_LangCodes.prototype["jav"]=true;
Iso639LangCodes_LangCodes.prototype["jbo"]=true;
Iso639LangCodes_LangCodes.prototype["jpn"]=true;
Iso639LangCodes_LangCodes.prototype["jpr"]=true;
Iso639LangCodes_LangCodes.prototype["jrb"]=true;
Iso639LangCodes_LangCodes.prototype["jv"]=true;
Iso639LangCodes_LangCodes.prototype["ka"]=true;
Iso639LangCodes_LangCodes.prototype["ka"]=true;
Iso639LangCodes_LangCodes.prototype["kaa"]=true;
Iso639LangCodes_LangCodes.prototype["kab"]=true;
Iso639LangCodes_LangCodes.prototype["kac"]=true;
Iso639LangCodes_LangCodes.prototype["kal"]=true;
Iso639LangCodes_LangCodes.prototype["kam"]=true;
Iso639LangCodes_LangCodes.prototype["kan"]=true;
Iso639LangCodes_LangCodes.prototype["kar"]=true;
Iso639LangCodes_LangCodes.prototype["kas"]=true;
Iso639LangCodes_LangCodes.prototype["kat"]=true;
Iso639LangCodes_LangCodes.prototype["kat"]=true;
Iso639LangCodes_LangCodes.prototype["kau"]=true;
Iso639LangCodes_LangCodes.prototype["kaw"]=true;
Iso639LangCodes_LangCodes.prototype["kaz"]=true;
Iso639LangCodes_LangCodes.prototype["kbd"]=true;
Iso639LangCodes_LangCodes.prototype["kg"]=true;
Iso639LangCodes_LangCodes.prototype["kha"]=true;
Iso639LangCodes_LangCodes.prototype["khi"]=true;
Iso639LangCodes_LangCodes.prototype["khm"]=true;
Iso639LangCodes_LangCodes.prototype["kho"]=true;
Iso639LangCodes_LangCodes.prototype["ki"]=true;
Iso639LangCodes_LangCodes.prototype["kik"]=true;
Iso639LangCodes_LangCodes.prototype["kin"]=true;
Iso639LangCodes_LangCodes.prototype["kir"]=true;
Iso639LangCodes_LangCodes.prototype["kj"]=true;
Iso639LangCodes_LangCodes.prototype["kk"]=true;
Iso639LangCodes_LangCodes.prototype["kl"]=true;
Iso639LangCodes_LangCodes.prototype["km"]=true;
Iso639LangCodes_LangCodes.prototype["kmb"]=true;
Iso639LangCodes_LangCodes.prototype["kn"]=true;
Iso639LangCodes_LangCodes.prototype["ko"]=true;
Iso639LangCodes_LangCodes.prototype["kok"]=true;
Iso639LangCodes_LangCodes.prototype["kom"]=true;
Iso639LangCodes_LangCodes.prototype["kon"]=true;
Iso639LangCodes_LangCodes.prototype["kor"]=true;
Iso639LangCodes_LangCodes.prototype["kos"]=true;
Iso639LangCodes_LangCodes.prototype["kpe"]=true;
Iso639LangCodes_LangCodes.prototype["kr"]=true;
Iso639LangCodes_LangCodes.prototype["krc"]=true;
Iso639LangCodes_LangCodes.prototype["kro"]=true;
Iso639LangCodes_LangCodes.prototype["kru"]=true;
Iso639LangCodes_LangCodes.prototype["ks"]=true;
Iso639LangCodes_LangCodes.prototype["ku"]=true;
Iso639LangCodes_LangCodes.prototype["kua"]=true;
Iso639LangCodes_LangCodes.prototype["kum"]=true;
Iso639LangCodes_LangCodes.prototype["kur"]=true;
Iso639LangCodes_LangCodes.prototype["kut"]=true;
Iso639LangCodes_LangCodes.prototype["kv"]=true;
Iso639LangCodes_LangCodes.prototype["kw"]=true;
Iso639LangCodes_LangCodes.prototype["ky"]=true;
Iso639LangCodes_LangCodes.prototype["la"]=true;
Iso639LangCodes_LangCodes.prototype["lad"]=true;
Iso639LangCodes_LangCodes.prototype["lah"]=true;
Iso639LangCodes_LangCodes.prototype["lam"]=true;
Iso639LangCodes_LangCodes.prototype["lao"]=true;
Iso639LangCodes_LangCodes.prototype["lat"]=true;
Iso639LangCodes_LangCodes.prototype["lav"]=true;
Iso639LangCodes_LangCodes.prototype["lb"]=true;
Iso639LangCodes_LangCodes.prototype["lez"]=true;
Iso639LangCodes_LangCodes.prototype["lg"]=true;
Iso639LangCodes_LangCodes.prototype["li"]=true;
Iso639LangCodes_LangCodes.prototype["lim"]=true;
Iso639LangCodes_LangCodes.prototype["lin"]=true;
Iso639LangCodes_LangCodes.prototype["lit"]=true;
Iso639LangCodes_LangCodes.prototype["ln"]=true;
Iso639LangCodes_LangCodes.prototype["lo"]=true;
Iso639LangCodes_LangCodes.prototype["lol"]=true;
Iso639LangCodes_LangCodes.prototype["loz"]=true;
Iso639LangCodes_LangCodes.prototype["lt"]=true;
Iso639LangCodes_LangCodes.prototype["ltz"]=true;
Iso639LangCodes_LangCodes.prototype["lu"]=true;
Iso639LangCodes_LangCodes.prototype["lua"]=true;
Iso639LangCodes_LangCodes.prototype["lub"]=true;
Iso639LangCodes_LangCodes.prototype["lug"]=true;
Iso639LangCodes_LangCodes.prototype["lui"]=true;
Iso639LangCodes_LangCodes.prototype["lun"]=true;
Iso639LangCodes_LangCodes.prototype["luo"]=true;
Iso639LangCodes_LangCodes.prototype["lus"]=true;
Iso639LangCodes_LangCodes.prototype["lv"]=true;
Iso639LangCodes_LangCodes.prototype["mac"]=true;
Iso639LangCodes_LangCodes.prototype["mad"]=true;
Iso639LangCodes_LangCodes.prototype["mag"]=true;
Iso639LangCodes_LangCodes.prototype["mah"]=true;
Iso639LangCodes_LangCodes.prototype["mai"]=true;
Iso639LangCodes_LangCodes.prototype["mak"]=true;
Iso639LangCodes_LangCodes.prototype["mal"]=true;
Iso639LangCodes_LangCodes.prototype["man"]=true;
Iso639LangCodes_LangCodes.prototype["mao"]=true;
Iso639LangCodes_LangCodes.prototype["mao"]=true;
Iso639LangCodes_LangCodes.prototype["map"]=true;
Iso639LangCodes_LangCodes.prototype["mar"]=true;
Iso639LangCodes_LangCodes.prototype["mas"]=true;
Iso639LangCodes_LangCodes.prototype["may"]=true;
Iso639LangCodes_LangCodes.prototype["may"]=true;
Iso639LangCodes_LangCodes.prototype["mdf"]=true;
Iso639LangCodes_LangCodes.prototype["mdr"]=true;
Iso639LangCodes_LangCodes.prototype["men"]=true;
Iso639LangCodes_LangCodes.prototype["mg"]=true;
Iso639LangCodes_LangCodes.prototype["mga"]=true;
Iso639LangCodes_LangCodes.prototype["mh"]=true;
Iso639LangCodes_LangCodes.prototype["mi"]=true;
Iso639LangCodes_LangCodes.prototype["mi"]=true;
Iso639LangCodes_LangCodes.prototype["mic"]=true;
Iso639LangCodes_LangCodes.prototype["min"]=true;
Iso639LangCodes_LangCodes.prototype["mis"]=true;
Iso639LangCodes_LangCodes.prototype["mk"]=true;
Iso639LangCodes_LangCodes.prototype["mk"]=true;
Iso639LangCodes_LangCodes.prototype["mkd"]=true;
Iso639LangCodes_LangCodes.prototype["mkd"]=true;
Iso639LangCodes_LangCodes.prototype["mkh"]=true;
Iso639LangCodes_LangCodes.prototype["ml"]=true;
Iso639LangCodes_LangCodes.prototype["mlg"]=true;
Iso639LangCodes_LangCodes.prototype["mlt"]=true;
Iso639LangCodes_LangCodes.prototype["mn"]=true;
Iso639LangCodes_LangCodes.prototype["mnc"]=true;
Iso639LangCodes_LangCodes.prototype["mni"]=true;
Iso639LangCodes_LangCodes.prototype["mno"]=true;
Iso639LangCodes_LangCodes.prototype["mo"]=true;
Iso639LangCodes_LangCodes.prototype["moh"]=true;
Iso639LangCodes_LangCodes.prototype["mol"]=true;
Iso639LangCodes_LangCodes.prototype["mon"]=true;
Iso639LangCodes_LangCodes.prototype["mos"]=true;
Iso639LangCodes_LangCodes.prototype["mr"]=true;
Iso639LangCodes_LangCodes.prototype["mri"]=true;
Iso639LangCodes_LangCodes.prototype["mri"]=true;
Iso639LangCodes_LangCodes.prototype["ms"]=true;
Iso639LangCodes_LangCodes.prototype["ms"]=true;
Iso639LangCodes_LangCodes.prototype["msa"]=true;
Iso639LangCodes_LangCodes.prototype["msa"]=true;
Iso639LangCodes_LangCodes.prototype["mt"]=true;
Iso639LangCodes_LangCodes.prototype["mul"]=true;
Iso639LangCodes_LangCodes.prototype["mun"]=true;
Iso639LangCodes_LangCodes.prototype["mus"]=true;
Iso639LangCodes_LangCodes.prototype["mwl"]=true;
Iso639LangCodes_LangCodes.prototype["mwr"]=true;
Iso639LangCodes_LangCodes.prototype["my"]=true;
Iso639LangCodes_LangCodes.prototype["my"]=true;
Iso639LangCodes_LangCodes.prototype["mya"]=true;
Iso639LangCodes_LangCodes.prototype["mya"]=true;
Iso639LangCodes_LangCodes.prototype["myn"]=true;
Iso639LangCodes_LangCodes.prototype["myv"]=true;
Iso639LangCodes_LangCodes.prototype["na"]=true;
Iso639LangCodes_LangCodes.prototype["nah"]=true;
Iso639LangCodes_LangCodes.prototype["nai"]=true;
Iso639LangCodes_LangCodes.prototype["nap"]=true;
Iso639LangCodes_LangCodes.prototype["nau"]=true;
Iso639LangCodes_LangCodes.prototype["nav"]=true;
Iso639LangCodes_LangCodes.prototype["nb"]=true;
Iso639LangCodes_LangCodes.prototype["nbl"]=true;
Iso639LangCodes_LangCodes.prototype["nd"]=true;
Iso639LangCodes_LangCodes.prototype["nde"]=true;
Iso639LangCodes_LangCodes.prototype["ndo"]=true;
Iso639LangCodes_LangCodes.prototype["nds"]=true;
Iso639LangCodes_LangCodes.prototype["ne"]=true;
Iso639LangCodes_LangCodes.prototype["nep"]=true;
Iso639LangCodes_LangCodes.prototype["new"]=true;
Iso639LangCodes_LangCodes.prototype["ng"]=true;
Iso639LangCodes_LangCodes.prototype["nia"]=true;
Iso639LangCodes_LangCodes.prototype["nic"]=true;
Iso639LangCodes_LangCodes.prototype["niu"]=true;
Iso639LangCodes_LangCodes.prototype["nl"]=true;
Iso639LangCodes_LangCodes.prototype["nl"]=true;
Iso639LangCodes_LangCodes.prototype["nld"]=true;
Iso639LangCodes_LangCodes.prototype["nld"]=true;
Iso639LangCodes_LangCodes.prototype["nn"]=true;
Iso639LangCodes_LangCodes.prototype["nno"]=true;
Iso639LangCodes_LangCodes.prototype["no"]=true;
Iso639LangCodes_LangCodes.prototype["nob"]=true;
Iso639LangCodes_LangCodes.prototype["nog"]=true;
Iso639LangCodes_LangCodes.prototype["non"]=true;
Iso639LangCodes_LangCodes.prototype["nor"]=true;
Iso639LangCodes_LangCodes.prototype["nr"]=true;
Iso639LangCodes_LangCodes.prototype["nso"]=true;
Iso639LangCodes_LangCodes.prototype["nub"]=true;
Iso639LangCodes_LangCodes.prototype["nv"]=true;
Iso639LangCodes_LangCodes.prototype["nwc"]=true;
Iso639LangCodes_LangCodes.prototype["ny"]=true;
Iso639LangCodes_LangCodes.prototype["nya"]=true;
Iso639LangCodes_LangCodes.prototype["nym"]=true;
Iso639LangCodes_LangCodes.prototype["nyn"]=true;
Iso639LangCodes_LangCodes.prototype["nyo"]=true;
Iso639LangCodes_LangCodes.prototype["nzi"]=true;
Iso639LangCodes_LangCodes.prototype["oc"]=true;
Iso639LangCodes_LangCodes.prototype["oci"]=true;
Iso639LangCodes_LangCodes.prototype["oj"]=true;
Iso639LangCodes_LangCodes.prototype["oji"]=true;
Iso639LangCodes_LangCodes.prototype["om"]=true;
Iso639LangCodes_LangCodes.prototype["or"]=true;
Iso639LangCodes_LangCodes.prototype["ori"]=true;
Iso639LangCodes_LangCodes.prototype["orm"]=true;
Iso639LangCodes_LangCodes.prototype["os"]=true;
Iso639LangCodes_LangCodes.prototype["osa"]=true;
Iso639LangCodes_LangCodes.prototype["oss"]=true;
Iso639LangCodes_LangCodes.prototype["ota"]=true;
Iso639LangCodes_LangCodes.prototype["oto"]=true;
Iso639LangCodes_LangCodes.prototype["pa"]=true;
Iso639LangCodes_LangCodes.prototype["paa"]=true;
Iso639LangCodes_LangCodes.prototype["pag"]=true;
Iso639LangCodes_LangCodes.prototype["pal"]=true;
Iso639LangCodes_LangCodes.prototype["pam"]=true;
Iso639LangCodes_LangCodes.prototype["pan"]=true;
Iso639LangCodes_LangCodes.prototype["pap"]=true;
Iso639LangCodes_LangCodes.prototype["pau"]=true;
Iso639LangCodes_LangCodes.prototype["peo"]=true;
Iso639LangCodes_LangCodes.prototype["per"]=true;
Iso639LangCodes_LangCodes.prototype["per"]=true;
Iso639LangCodes_LangCodes.prototype["phi"]=true;
Iso639LangCodes_LangCodes.prototype["phn"]=true;
Iso639LangCodes_LangCodes.prototype["pi"]=true;
Iso639LangCodes_LangCodes.prototype["pl"]=true;
Iso639LangCodes_LangCodes.prototype["pli"]=true;
Iso639LangCodes_LangCodes.prototype["pol"]=true;
Iso639LangCodes_LangCodes.prototype["pon"]=true;
Iso639LangCodes_LangCodes.prototype["por"]=true;
Iso639LangCodes_LangCodes.prototype["pra"]=true;
Iso639LangCodes_LangCodes.prototype["pro"]=true;
Iso639LangCodes_LangCodes.prototype["ps"]=true;
Iso639LangCodes_LangCodes.prototype["pt"]=true;
Iso639LangCodes_LangCodes.prototype["pus"]=true;
Iso639LangCodes_LangCodes.prototype["qaa"]=true;
Iso639LangCodes_LangCodes.prototype["qtz"]=true;
Iso639LangCodes_LangCodes.prototype["qu"]=true;
Iso639LangCodes_LangCodes.prototype["que"]=true;
Iso639LangCodes_LangCodes.prototype["raj"]=true;
Iso639LangCodes_LangCodes.prototype["rap"]=true;
Iso639LangCodes_LangCodes.prototype["rar"]=true;
Iso639LangCodes_LangCodes.prototype["rm"]=true;
Iso639LangCodes_LangCodes.prototype["rn"]=true;
Iso639LangCodes_LangCodes.prototype["ro"]=true;
Iso639LangCodes_LangCodes.prototype["roa"]=true;
Iso639LangCodes_LangCodes.prototype["roh"]=true;
Iso639LangCodes_LangCodes.prototype["rom"]=true;
Iso639LangCodes_LangCodes.prototype["ron"]=true;
Iso639LangCodes_LangCodes.prototype["ru"]=true;
Iso639LangCodes_LangCodes.prototype["rum"]=true;
Iso639LangCodes_LangCodes.prototype["run"]=true;
Iso639LangCodes_LangCodes.prototype["rus"]=true;
Iso639LangCodes_LangCodes.prototype["rw"]=true;
Iso639LangCodes_LangCodes.prototype["sa"]=true;
Iso639LangCodes_LangCodes.prototype["sad"]=true;
Iso639LangCodes_LangCodes.prototype["sag"]=true;
Iso639LangCodes_LangCodes.prototype["sah"]=true;
Iso639LangCodes_LangCodes.prototype["sai"]=true;
Iso639LangCodes_LangCodes.prototype["sal"]=true;
Iso639LangCodes_LangCodes.prototype["sam"]=true;
Iso639LangCodes_LangCodes.prototype["san"]=true;
Iso639LangCodes_LangCodes.prototype["sas"]=true;
Iso639LangCodes_LangCodes.prototype["sat"]=true;
Iso639LangCodes_LangCodes.prototype["sc"]=true;
Iso639LangCodes_LangCodes.prototype["scc"]=true;
Iso639LangCodes_LangCodes.prototype["scc"]=true;
Iso639LangCodes_LangCodes.prototype["scn"]=true;
Iso639LangCodes_LangCodes.prototype["sco"]=true;
Iso639LangCodes_LangCodes.prototype["scr"]=true;
Iso639LangCodes_LangCodes.prototype["scr"]=true;
Iso639LangCodes_LangCodes.prototype["sd"]=true;
Iso639LangCodes_LangCodes.prototype["se"]=true;
Iso639LangCodes_LangCodes.prototype["sel"]=true;
Iso639LangCodes_LangCodes.prototype["sem"]=true;
Iso639LangCodes_LangCodes.prototype["sg"]=true;
Iso639LangCodes_LangCodes.prototype["sga"]=true;
Iso639LangCodes_LangCodes.prototype["sgn"]=true;
Iso639LangCodes_LangCodes.prototype["shn"]=true;
Iso639LangCodes_LangCodes.prototype["si"]=true;
Iso639LangCodes_LangCodes.prototype["sid"]=true;
Iso639LangCodes_LangCodes.prototype["sin"]=true;
Iso639LangCodes_LangCodes.prototype["sio"]=true;
Iso639LangCodes_LangCodes.prototype["sit"]=true;
Iso639LangCodes_LangCodes.prototype["sk"]=true;
Iso639LangCodes_LangCodes.prototype["sl"]=true;
Iso639LangCodes_LangCodes.prototype["sla"]=true;
Iso639LangCodes_LangCodes.prototype["slk"]=true;
Iso639LangCodes_LangCodes.prototype["slo"]=true;
Iso639LangCodes_LangCodes.prototype["slv"]=true;
Iso639LangCodes_LangCodes.prototype["sm"]=true;
Iso639LangCodes_LangCodes.prototype["sma"]=true;
Iso639LangCodes_LangCodes.prototype["sme"]=true;
Iso639LangCodes_LangCodes.prototype["smi"]=true;
Iso639LangCodes_LangCodes.prototype["smj"]=true;
Iso639LangCodes_LangCodes.prototype["smn"]=true;
Iso639LangCodes_LangCodes.prototype["smo"]=true;
Iso639LangCodes_LangCodes.prototype["sms"]=true;
Iso639LangCodes_LangCodes.prototype["sn"]=true;
Iso639LangCodes_LangCodes.prototype["sna"]=true;
Iso639LangCodes_LangCodes.prototype["snd"]=true;
Iso639LangCodes_LangCodes.prototype["snk"]=true;
Iso639LangCodes_LangCodes.prototype["so"]=true;
Iso639LangCodes_LangCodes.prototype["sog"]=true;
Iso639LangCodes_LangCodes.prototype["som"]=true;
Iso639LangCodes_LangCodes.prototype["son"]=true;
Iso639LangCodes_LangCodes.prototype["sot"]=true;
Iso639LangCodes_LangCodes.prototype["spa"]=true;
Iso639LangCodes_LangCodes.prototype["sq"]=true;
Iso639LangCodes_LangCodes.prototype["sqi"]=true;
Iso639LangCodes_LangCodes.prototype["sr"]=true;
Iso639LangCodes_LangCodes.prototype["srd"]=true;
Iso639LangCodes_LangCodes.prototype["srp"]=true;
Iso639LangCodes_LangCodes.prototype["srr"]=true;
Iso639LangCodes_LangCodes.prototype["ss"]=true;
Iso639LangCodes_LangCodes.prototype["ssa"]=true;
Iso639LangCodes_LangCodes.prototype["ssw"]=true;
Iso639LangCodes_LangCodes.prototype["st"]=true;
Iso639LangCodes_LangCodes.prototype["su"]=true;
Iso639LangCodes_LangCodes.prototype["suk"]=true;
Iso639LangCodes_LangCodes.prototype["sun"]=true;
Iso639LangCodes_LangCodes.prototype["sus"]=true;
Iso639LangCodes_LangCodes.prototype["sux"]=true;
Iso639LangCodes_LangCodes.prototype["sv"]=true;
Iso639LangCodes_LangCodes.prototype["sw"]=true;
Iso639LangCodes_LangCodes.prototype["swa"]=true;
Iso639LangCodes_LangCodes.prototype["swe"]=true;
Iso639LangCodes_LangCodes.prototype["syr"]=true;
Iso639LangCodes_LangCodes.prototype["ta"]=true;
Iso639LangCodes_LangCodes.prototype["tah"]=true;
Iso639LangCodes_LangCodes.prototype["tai"]=true;
Iso639LangCodes_LangCodes.prototype["tam"]=true;
Iso639LangCodes_LangCodes.prototype["tat"]=true;
Iso639LangCodes_LangCodes.prototype["te"]=true;
Iso639LangCodes_LangCodes.prototype["tel"]=true;
Iso639LangCodes_LangCodes.prototype["tem"]=true;
Iso639LangCodes_LangCodes.prototype["ter"]=true;
Iso639LangCodes_LangCodes.prototype["tet"]=true;
Iso639LangCodes_LangCodes.prototype["tg"]=true;
Iso639LangCodes_LangCodes.prototype["tgk"]=true;
Iso639LangCodes_LangCodes.prototype["tgl"]=true;
Iso639LangCodes_LangCodes.prototype["th"]=true;
Iso639LangCodes_LangCodes.prototype["tha"]=true;
Iso639LangCodes_LangCodes.prototype["ti"]=true;
Iso639LangCodes_LangCodes.prototype["tib"]=true;
Iso639LangCodes_LangCodes.prototype["tib"]=true;
Iso639LangCodes_LangCodes.prototype["tig"]=true;
Iso639LangCodes_LangCodes.prototype["tir"]=true;
Iso639LangCodes_LangCodes.prototype["tiv"]=true;
Iso639LangCodes_LangCodes.prototype["tk"]=true;
Iso639LangCodes_LangCodes.prototype["tkl"]=true;
Iso639LangCodes_LangCodes.prototype["tl"]=true;
Iso639LangCodes_LangCodes.prototype["tlh"]=true;
Iso639LangCodes_LangCodes.prototype["tli"]=true;
Iso639LangCodes_LangCodes.prototype["tmh"]=true;
Iso639LangCodes_LangCodes.prototype["tn"]=true;
Iso639LangCodes_LangCodes.prototype["to"]=true;
Iso639LangCodes_LangCodes.prototype["tog"]=true;
Iso639LangCodes_LangCodes.prototype["ton"]=true;
Iso639LangCodes_LangCodes.prototype["tpi"]=true;
Iso639LangCodes_LangCodes.prototype["tr"]=true;
Iso639LangCodes_LangCodes.prototype["ts"]=true;
Iso639LangCodes_LangCodes.prototype["tsi"]=true;
Iso639LangCodes_LangCodes.prototype["tsn"]=true;
Iso639LangCodes_LangCodes.prototype["tso"]=true;
Iso639LangCodes_LangCodes.prototype["tt"]=true;
Iso639LangCodes_LangCodes.prototype["tuk"]=true;
Iso639LangCodes_LangCodes.prototype["tum"]=true;
Iso639LangCodes_LangCodes.prototype["tup"]=true;
Iso639LangCodes_LangCodes.prototype["tur"]=true;
Iso639LangCodes_LangCodes.prototype["tut"]=true;
Iso639LangCodes_LangCodes.prototype["tvl"]=true;
Iso639LangCodes_LangCodes.prototype["tw"]=true;
Iso639LangCodes_LangCodes.prototype["twi"]=true;
Iso639LangCodes_LangCodes.prototype["ty"]=true;
Iso639LangCodes_LangCodes.prototype["tyv"]=true;
Iso639LangCodes_LangCodes.prototype["udm"]=true;
Iso639LangCodes_LangCodes.prototype["ug"]=true;
Iso639LangCodes_LangCodes.prototype["uga"]=true;
Iso639LangCodes_LangCodes.prototype["uig"]=true;
Iso639LangCodes_LangCodes.prototype["uk"]=true;
Iso639LangCodes_LangCodes.prototype["ukr"]=true;
Iso639LangCodes_LangCodes.prototype["umb"]=true;
Iso639LangCodes_LangCodes.prototype["und"]=true;
Iso639LangCodes_LangCodes.prototype["ur"]=true;
Iso639LangCodes_LangCodes.prototype["urd"]=true;
Iso639LangCodes_LangCodes.prototype["uz"]=true;
Iso639LangCodes_LangCodes.prototype["uzb"]=true;
Iso639LangCodes_LangCodes.prototype["vai"]=true;
Iso639LangCodes_LangCodes.prototype["ve"]=true;
Iso639LangCodes_LangCodes.prototype["ven"]=true;
Iso639LangCodes_LangCodes.prototype["vi"]=true;
Iso639LangCodes_LangCodes.prototype["vie"]=true;
Iso639LangCodes_LangCodes.prototype["vo"]=true;
Iso639LangCodes_LangCodes.prototype["vol"]=true;
Iso639LangCodes_LangCodes.prototype["vot"]=true;
Iso639LangCodes_LangCodes.prototype["wa"]=true;
Iso639LangCodes_LangCodes.prototype["wak"]=true;
Iso639LangCodes_LangCodes.prototype["wal"]=true;
Iso639LangCodes_LangCodes.prototype["war"]=true;
Iso639LangCodes_LangCodes.prototype["was"]=true;
Iso639LangCodes_LangCodes.prototype["wel"]=true;
Iso639LangCodes_LangCodes.prototype["wel"]=true;
Iso639LangCodes_LangCodes.prototype["wen"]=true;
Iso639LangCodes_LangCodes.prototype["wln"]=true;
Iso639LangCodes_LangCodes.prototype["wo"]=true;
Iso639LangCodes_LangCodes.prototype["wol"]=true;
Iso639LangCodes_LangCodes.prototype["xal"]=true;
Iso639LangCodes_LangCodes.prototype["xh"]=true;
Iso639LangCodes_LangCodes.prototype["xho"]=true;
Iso639LangCodes_LangCodes.prototype["yao"]=true;
Iso639LangCodes_LangCodes.prototype["yap"]=true;
Iso639LangCodes_LangCodes.prototype["yi"]=true;
Iso639LangCodes_LangCodes.prototype["yid"]=true;
Iso639LangCodes_LangCodes.prototype["yo"]=true;
Iso639LangCodes_LangCodes.prototype["yor"]=true;
Iso639LangCodes_LangCodes.prototype["ypk"]=true;
Iso639LangCodes_LangCodes.prototype["za"]=true;
Iso639LangCodes_LangCodes.prototype["zap"]=true;
Iso639LangCodes_LangCodes.prototype["zen"]=true;
Iso639LangCodes_LangCodes.prototype["zh"]=true;
Iso639LangCodes_LangCodes.prototype["zh"]=true;
Iso639LangCodes_LangCodes.prototype["zha"]=true;
Iso639LangCodes_LangCodes.prototype["zho"]=true;
Iso639LangCodes_LangCodes.prototype["zho"]=true;
Iso639LangCodes_LangCodes.prototype["znd"]=true;
Iso639LangCodes_LangCodes.prototype["zu"]=true;
Iso639LangCodes_LangCodes.prototype["zul"]=true;
Iso639LangCodes_LangCodes.prototype["zun"]=true;
Iso639LangCodes_LangCodes.prototype.IsValid=Iso639LangCodes_IsValid;
function Iso639LangCodes_IsValid(str){
if(str=="i"||str=="x"){
return true;
}
if(this[str]===true){
return true;
}
return false;
}
function Iso639LangCodes_LangCodes(){
}
function LogCompression(_157){
this.dictionary=_157;
this.dictKeyDelimiter=this.dictionary["delimiter"];
}
LogCompression.prototype.decompressXmltoString=function(_158){
var str=_158.toString();
var _15a=this.dictionary;
var _15b=new RegExp(this.dictKeyDelimiter+"([0-9]{1,4})"+this.dictKeyDelimiter,"g");
function getDictionaryValueforStrReplace(){
return _15a[arguments[1]];
}
return str.replace(_15b,getDictionaryValueforStrReplace);
};
LogCompression.prototype.decompressString=function(_15c){
var _15d=this.dictionary;
var _15e=new RegExp(this.dictKeyDelimiter+"([0-9]{1,4})"+this.dictKeyDelimiter,"g");
function getDictionaryValueforStrReplace(){
return _15d[arguments[1]];
}
return _15c.replace(_15e,getDictionaryValueforStrReplace);
};
function MenuItem(_15f,_160,_161,_162){
this.ParentMenuItem=_15f;
this.Document=_161;
this.ActivityId=_160.GetItemIdentifier()+_160.GetDatabaseIdentifier();
this.MenuElementId="MenuItem"+this.ActivityId;
this.DivTag=null;
if(_15f===null){
this.Level=0;
}else{
this.Level=_15f.Level+1;
}
this.Children=new Array();
this.Visible=true;
this.Enabled=true;
var node=this.Document.createElement("div");
node.id=this.MenuElementId;
this.DivTag=node;
this.CurrentDisplayState=null;
this.CurrentDisplayState=IntegrationImplementation.PopulateMenuItemDivTag(node,this.Document,this.ActivityId,_160.GetTitle(),this.Level,_160.IsDeliverable(),Control.Package.LearningStandard,Control.Package.Properties.StatusDisplay,_160.GetItemIdentifier(),_160,this);
}
MenuItem.prototype.Render=MenuItem_Render;
MenuItem.prototype.UpdateStateDisplay=MenuItem_UpdateStateDisplay;
MenuItem.prototype.Hide=MenuItem_Hide;
MenuItem.prototype.Show=MenuItem_Show;
MenuItem.prototype.Enable=MenuItem_Enable;
MenuItem.prototype.Disable=MenuItem_Disable;
MenuItem.prototype.BumpUpLevel=MenuItem_BumpUpLevel;
MenuItem.prototype.BumpDownLevel=MenuItem_BumpDownLevel;
MenuItem.prototype.ResynchChildren=MenuItem_ResynchChildren;
function MenuItem_Render(_164){
var _165;
if(this.ParentMenuItem===null){
_165=IntegrationImplementation.GetHtmlElementToInsertMenuWithin();
_165.insertBefore(this.DivTag,null);
return;
}else{
var i;
for(i=0;i<this.ParentMenuItem.Children.length;i++){
if(this.ParentMenuItem.Children[i].ActivityId==this.ActivityId){
break;
}
}
if(i===0){
_165=this.Document.getElementById(this.ParentMenuItem.MenuElementId);
}else{
var _167=this.ParentMenuItem.Children[i-1];
var _168=MenuItem_getLastSubmenuItem(_167);
_165=this.Document.getElementById(_168.MenuElementId);
}
}
_165.parentNode.insertBefore(this.DivTag,_165.nextSibling);
if(_164.DisplayInChoice()===true){
this.Show();
}else{
this.Hide();
}
}
function MenuItem_UpdateStateDisplay(_169,_16a,_16b,_16c){
var _16d=true;
var _16e=true;
if(_169.DisplayInChoice()===true){
_16d=true;
}else{
_16d=false;
}
if(!_16b.WillSucceed){
if(Control.Package.Properties.InvalidMenuItemAction==INVALID_MENU_ITEM_ACTION_DISABLE){
_16e=false;
}else{
if(Control.Package.Properties.InvalidMenuItemAction==INVALID_MENU_ITEM_ACTION_HIDE){
_16d=false;
}else{
if(Control.Package.Properties.InvalidMenuItemAction==INVALID_MENU_ITEM_ACTION_SHOW_ENABLE){
_16d=true;
}
}
}
}else{
if(Control.Package.Properties.InvalidMenuItemAction==INVALID_MENU_ITEM_ACTION_DISABLE){
_16e=true;
}else{
if(Control.Package.Properties.InvalidMenuItemAction==INVALID_MENU_ITEM_ACTION_HIDE){
_16d=true;
}else{
if(Control.Package.Properties.InvalidMenuItemAction==INVALID_MENU_ITEM_ACTION_SHOW_ENABLE){
_16d=true;
}
}
}
}
if(_16d!=this.Visible){
if(_16d==true){
this.Show();
}else{
this.Hide();
}
}
if(_169.IsTheRoot()===true&&Control.Package.Properties.ForceDisableRootChoice===true){
_16e=false;
}
if(_16e!=this.Enabled){
if(_16e==true){
this.Enable(_169.GetItemIdentifier(),_169.GetTitle());
}else{
this.Disable();
}
}
this.CurrentDisplayState=IntegrationImplementation.UpdateMenuStateDisplay(this.DivTag,this.Document,_169,this.ActivityId,_169.IsDeliverable(),_16a,_16b,Control.Package.LearningStandard,Control.Package.Properties.StatusDisplay,this.CurrentDisplayState,_16c);
}
function MenuItem_Hide(){
if(this.Visible===true){
this.DivTag.style.display="none";
this.BumpDownLevel(this);
}
this.Visible=false;
}
function MenuItem_Show(){
if(this.Visible===false){
this.DivTag.style.display="inline";
this.BumpUpLevel(this);
}
this.Visible=true;
}
function MenuItem_Enable(_16f,_170){
if(this.Enabled===false){
var _171=navigator.appName;
var _172=parseInt(navigator.appVersion,10);
if(_171=="Microsoft Internet Explorer"&&_172<6){
this.DivTag.onmouseover=function(){
this.style.cursor="hand";
window.status=_170;
return true;
};
}else{
this.DivTag.onmouseover=function(){
this.style.cursor="pointer";
window.status=_170;
return true;
};
}
this.DivTag.onclick=function(){
var _173=GetController();
_173.ChoiceRequest(_16f);
return true;
};
}
this.Enabled=true;
}
function MenuItem_Disable(){
if(this.Enabled===true){
this.DivTag.onmouseover=function(){
this.style.cursor="default";
window.status="";
return true;
};
this.DivTag.onclick="";
}
this.Enabled=false;
}
function MenuItem_BumpUpLevel(_174){
_174.Level++;
IntegrationImplementation.UpdateIndentLevel(_174.DivTag,_174.ActivityId,_174.Level);
for(var _175 in _174.Children){
_174.BumpUpLevel(_174.Children[_175]);
}
}
function MenuItem_BumpDownLevel(_176){
_176.Level--;
IntegrationImplementation.UpdateIndentLevel(_176.DivTag,_176.ActivityId,_176.Level);
for(var _177 in _176.Children){
_176.BumpDownLevel(_176.Children[_177]);
}
}
function MenuItem_ResynchChildren(_178){
var _179;
for(var _17a in this.Children){
_179=this.Children[_17a].DivTag;
_179.parentNode.removeChild(_179);
}
this.Children=new Array();
var _17b=_178.GetAvailableChildren();
for(var _17c in _17b){
this.Children[_17c]=_17b[_17c].MenuItem;
}
}
function MenuItem_getLastSubmenuItem(_17d){
if(_17d.Children.length===0){
return _17d;
}else{
return MenuItem_getLastSubmenuItem(_17d.Children[_17d.Children.length-1]);
}
}
function ScoLoader(_17e,_17f,_180,_181,_182,_183){
this.IntermediatePage=_17e;
this.PopupLauncherPage=_17f;
this.PathToCourse=_180;
this.ScoLaunchType=_181;
this.WrapScoWindowWithApi=_182;
this.Standard=_183;
this.ScoLoaded=false;
this.ContentFrame=ScoLoader_FindContentFrame(window);
if(this.ContentFrame===null){
Debug.AssertError("Unable to locate the content frame-"+IntegrationImplementation.CONTENT_FRAME_NAME);
}
}
ScoLoader.prototype.LoadSco=ScoLoader_LoadSco;
ScoLoader.prototype.UnloadSco=ScoLoader_UnloadSco;
ScoLoader.prototype.WriteHistoryLog=ScoLoader_WriteHistoryLog;
ScoLoader.prototype.WriteHistoryReturnValue=ScoLoader_WriteHistoryReturnValue;
ScoLoader.prototype.ConstructPreviewAiccSid=ScoLoader_ConstructPreviewAiccSid;
function ScoLoader_WriteHistoryLog(str,atts){
HistoryLog.WriteEventDetailed(str,atts);
}
function ScoLoader_WriteHistoryReturnValue(str,atts){
HistoryLog.WriteEventDetailedReturnValue(str,atts);
}
function ScoLoader_LoadSco(_188){
var _189={ev:"LoadSco"};
if(_188){
_189.ai=_188.ItemIdentifier;
_189.at=_188.LearningObject.Title;
}
this.WriteHistoryLog("",_189);
_188.LaunchedThisSession=false;
if(_188.GetActivityStartTimestampUtc()===null){
_188.SetActivityStartTimestampUtc(ConvertDateToIso8601String(new Date()));
}
if(_188.GetAttemptStartTimestampUtc()===null){
_188.SetAttemptStartTimestampUtc(ConvertDateToIso8601String(new Date()));
}
var _18a="";
if(this.Standard.isAICC()){
var _18b=ExternalRegistrationId=="";
var _18c;
if(_18b){
_18c="AICC_SID="+escape(this.ConstructPreviewAiccSid(_188)+escape(ExternalConfig));
}else{
_18c="AICC_SID="+escape(_188.AiccSessionId);
var _18d=_188.AiccSessionId.length==36&&_188.AiccSessionId.indexOf("~")<0;
if(_18d){
_18c+=escape(escape(ExternalConfig));
}
}
_18a+=_18c+"&AICC_URL="+escape(AICC_RESULTS_PAGE);
}
var _18e="";
if(this.PathToCourse.length>0&&_188.GetLaunchPath().toLowerCase().indexOf("http://")!=0&&_188.GetLaunchPath().toLowerCase().indexOf("https://")!=0){
_18e=this.PathToCourse;
if(this.PathToCourse.lastIndexOf("/")!=(this.PathToCourse.length-1)){
_18e+="/";
}
_18e+=_188.GetLaunchPath();
}else{
_18e=_188.GetLaunchPath();
}
var _18f;
if(_18a!==""){
_18e=MergeQueryStringParameters(_18e,_18a);
}
if(this.ScoLaunchType==LAUNCH_TYPE_FRAMESET){
Control.WriteDetailedLog("`1442`"+_18e);
this.ContentFrame.location=_18e;
Control.Api.InitTrackedTimeStart(_188);
_188.SetLaunchedThisSession();
}else{
if(this.ScoLaunchType==LAUNCH_TYPE_POPUP||this.ScoLaunchType==LAUNCH_TYPE_POPUP_WITHOUT_BROWSER_TOOLBAR||this.ScoLaunchType==LAUNCH_TYPE_POPUP_WITH_MENU||this.ScoLaunchType==LAUNCH_TYPE_POPUP_AFTER_CLICK||this.ScoLaunchType==LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR){
var _190;
if(this.ScoLaunchType==LAUNCH_TYPE_POPUP_WITHOUT_BROWSER_TOOLBAR||this.ScoLaunchType==LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR){
_190="false";
}else{
_190="true";
}
var _191;
if(this.ScoLaunchType==LAUNCH_TYPE_POPUP_WITH_MENU){
_191="yes";
}else{
_191="no";
}
var _192;
if(this.ScoLaunchType==LAUNCH_TYPE_POPUP_AFTER_CLICK||this.ScoLaunchType==LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR){
_192="true";
}else{
_192="false";
}
if(this.WrapScoWindowWithApi===true){
_18f=MergeQueryStringParameters(this.PopupLauncherPage.PageHref,this.PopupLauncherPage.Parameters,"ScoUrl="+escape(_18e),"LaunchAfterClick="+_192,"WrapApi=true","ShowToolbar="+_190,"ShowMenubar="+_191);
}else{
_18f=MergeQueryStringParameters(this.PopupLauncherPage.PageHref,this.PopupLauncherPage.Parameters,"ScoUrl="+escape(_18e),"LaunchAfterClick="+_192,"ShowToolbar="+_190,"ShowMenubar="+_191);
}
this.ContentFrame.location=_18f;
}else{
Debug.AssertError("Invalid Sco Launch Type");
}
}
}
function ScoLoader_UnloadSco(_193){
var path="";
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
Control.UpdateGlobalLearnerPrefs();
}
if(Control.DeliverFramesetUnloadEventCalled){
var _195=SCORM_RESULTS_PAGE.toLowerCase().indexOf("recordresults");
var _196=SCORM_RESULTS_PAGE.substring(0,_195);
path=_196+"blank.html";
}else{
if(_193===true){
path=MergeQueryStringParameters(this.IntermediatePage.PageHref,this.IntermediatePage.Parameters,"MessageWaiting=true");
}else{
path=MergeQueryStringParameters(this.IntermediatePage.PageHref,this.IntermediatePage.Parameters);
}
}
if((this.ScoLaunchType==LAUNCH_TYPE_POPUP||this.ScoLaunchType==LAUNCH_TYPE_POPUP_AFTER_CLICK)&&this.ContentFrame.CloseSco){
if(Control.DeliverFramesetUnloadEventCalled){
if(this.ContentFrame.scoWindow&&this.ContentFrame.scoWindow!==null&&!this.ContentFrame.scoWindow.closed){
this.ContentFrame.scoWindow.close();
}
this.ContentFrame.location=path;
}else{
Control.WriteDetailedLog("`1726`");
this.ContentFrame.CloseSco();
Control.WriteDetailedLog("`1349`"+path);
window.setTimeout("Control.ScoLoader.ContentFrame.location = '"+path+"'",250);
}
}else{
Control.WriteDetailedLog("`995`"+path);
this.ContentFrame.location=path;
}
}
function ScoLoader_FindContentFrame(wnd){
var _198=null;
for(var i=0;i<wnd.frames.length;i++){
if(wnd.frames[i].name==IntegrationImplementation.CONTENT_FRAME_NAME){
_198=wnd.frames[i];
return _198;
}
_198=ScoLoader_FindContentFrame(wnd.frames[i]);
if(_198!==null){
return _198;
}
}
return null;
}
function ScoLoader_ConstructPreviewAiccSid(_19a){
var _19b=RegistrationToDeliver.Package.Id;
var _19c;
if(_19b.length<10){
_19c="0"+_19b.length.toString();
}else{
_19c=_19b.length.toString();
}
var _19d=_19a.ScormObjectDatabaseId;
var _19e;
if(_19d.length<10){
_19e="0"+_19d.length.toString();
}else{
_19e=_19d.length.toString();
}
var _19f="PREVIEW"+_19c+_19b+_19e+_19d;
return _19f;
}
var HUNDREDTHS_PER_SECOND=100;
var HUNDREDTHS_PER_MINUTE=HUNDREDTHS_PER_SECOND*60;
var HUNDREDTHS_PER_HOUR=HUNDREDTHS_PER_MINUTE*60;
var HUNDREDTHS_PER_DAY=HUNDREDTHS_PER_HOUR*24;
var HUNDREDTHS_PER_MONTH=HUNDREDTHS_PER_DAY*(((365*4)+1)/48);
var HUNDREDTHS_PER_YEAR=HUNDREDTHS_PER_MONTH*12;
var REG_EX_DIGITS=/\d+/g;
var REG_EX_CHILDREN=/._children$/;
var REG_EX_COUNT=/._count$/;
function ConvertIso8601TimeToUtcAnsiSql(_1a0){
var _1a1=GetParsedIso8601Time(_1a0);
var date=new Date();
if(_1a1["timezoneoffsetchar"]===""||_1a1["timezoneoffsetchar"]===null||_1a1["timezoneoffsetchar"]===undefined){
date.setFullYear(_1a1["year"]);
date.setMonth(_1a1["month"]-1);
date.setDate(_1a1["day"]);
date.setHours(_1a1["hours"]);
date.setMinutes(_1a1["minutes"]);
date.setSeconds(_1a1["seconds"]);
date.setMilliseconds(_1a1["milliseconds"]);
}else{
date.setUTCFullYear(_1a1["year"]);
date.setUTCMonth(_1a1["month"]-1);
date.setUTCDate(_1a1["day"]);
date.setUTCHours(_1a1["hours"]);
date.setUTCMinutes(_1a1["minutes"]);
date.setUTCSeconds(_1a1["seconds"]);
date.setUTCMilliseconds(_1a1["milliseconds"]);
if(_1a1["timezoneoffsetchar"]=="-"){
date.setUTCHours(date.getUTCHours()+new Number(_1a1["offsethours"]));
date.setUTCMinutes(date.getUTCMinutes()+new Number(_1a1["offsetminutes"]));
}else{
if(_1a1["timezoneoffsetchar"]=="+"){
date.setUTCHours(date.getUTCHours()-new Number(_1a1["offsethours"]));
date.setUTCMinutes(date.getUTCMinutes()-new Number(_1a1["offsetminutes"]));
}
}
}
var _1a3=date.getUTCFullYear()+"-"+ZeroPad(date.getUTCMonth()+1,2)+"-"+ZeroPad(date.getUTCDate(),2)+"T"+ZeroPad(date.getUTCHours(),2)+":"+ZeroPad(date.getUTCMinutes(),2)+":"+ZeroPad(date.getUTCSeconds(),2);
return _1a3;
}
function ConvertDateToIso8601String(date){
var _1a5=function(num){
return ((num<10)?"0":"")+num;
};
var str="";
str+=date.getUTCFullYear();
str+="-"+_1a5(date.getUTCMonth()+1);
str+="-"+_1a5(date.getUTCDate());
str+="T"+_1a5(date.getUTCHours())+":"+_1a5(date.getUTCMinutes());
str+=":"+_1a5(date.getUTCSeconds())+".";
var _1a8=("00"+date.getUTCMilliseconds().toString());
str+=_1a8.substr(_1a8.length-3,2);
str+="Z";
return str;
}
function GetParsedIso8601Time(_1a9){
var _1aa=/^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?(?:T(\d{2})(?::(\d{2})(?::(\d{2})(?:\.(\d*))?)?)?((?:([+-])(\d{2})(?::(\d{2}))?)|Z)?)?$/;
var _1ab=_1aa.exec(_1a9);
var _1ac={};
_1ac.year="";
_1ac.month="";
_1ac.day="";
_1ac.hours="";
_1ac.minutes="";
_1ac.seconds="";
_1ac.milliseconds="";
_1ac.timezoneoffsetchar="";
_1ac.offsethours="";
_1ac.offsetminutes="";
if(!_1ab){
Debug.AssertError("ERROR - unable to recognize the date format '"+_1a9+"'.");
return _1ac;
}
_1ac.year=_1ab[1]||"";
_1ac.month=_1ab[2]||"";
_1ac.day=_1ab[3]||"";
_1ac.hours=_1ab[4]||"";
_1ac.minutes=_1ab[5]||"";
_1ac.seconds=_1ab[6]||"";
_1ac.milliseconds=((_1ab[7]||"")+"000").substring(0,3);
var _1ad=_1ab[8];
if(_1ad&&_1ad=="Z"){
_1ac.timezoneoffsetchar="Z";
}
if(_1ad&&_1ad!="Z"){
_1ac.timezoneoffsetchar=_1ab[9]||"";
_1ac.offsethours=_1ab[10]||"";
_1ac.offsetminutes=_1ab[11]||"";
}
return _1ac;
}
function GetDateFromUtcIso8601Time(_1ae){
var _1af=GetParsedIso8601Time(_1ae);
Debug.AssertError("Expected "+_1ae+" to be a UTC string",_1af.timezoneoffsetchar!=="Z");
var _1b0=new Date();
_1b0.setUTCFullYear(_1af.year);
_1b0.setUTCMonth(_1af.month-1);
_1b0.setUTCDate(_1af.day);
_1b0.setUTCHours(_1af.hours);
_1b0.setUTCMinutes(_1af.minutes);
_1b0.setUTCSeconds(_1af.seconds);
_1b0.setUTCMilliseconds(_1af.milliseconds);
return _1b0;
}
function ConvertIso8601TimeSpanToCmiTimeSpan(_1b1){
var _1b2=ConvertIso8601TimeSpanToHundredths(_1b1);
var _1b3=ConvertHundredthsIntoSCORMTime(_1b2);
return _1b3;
}
function ConvertCmiTimeSpanToIso8601TimeSpan(_1b4){
var _1b5=ConvertCmiTimeSpanToHundredths(_1b4);
var _1b6=ConvertHundredthsToIso8601TimeSpan(_1b5);
return _1b6;
}
function ConvertCmiTimeToIso8601Time(_1b7){
dtmNow=new Date();
var year=dtmNow.getFullYear();
var _1b9=dtmNow.getMonth();
var day=dtmNow.getDate();
year=ZeroPad(year,4);
_1b9=ZeroPad((_1b9+1),2);
day=ZeroPad(day,2);
var _1bb=year+"-"+_1b9+"-"+day+"T"+_1b7;
return _1bb;
}
function ConvertCmiTimeSpanToHundredths(_1bc){
if(_1bc===""){
return 0;
}
var _1bd;
var _1be;
var _1bf;
var _1c0;
var _1c1;
_1bd=_1bc.split(":");
_1be=_1bd[0];
_1bf=_1bd[1];
_1c0=_1bd[2];
intTotalHundredths=(_1be*360000)+(_1bf*6000)+(_1c0*100);
intTotalHundredths=Math.round(intTotalHundredths);
return intTotalHundredths;
}
function ConvertIso8601TimeSpanToHundredths(_1c2){
if(_1c2===""){
return 0;
}
var _1c3=0;
var _1c4;
var _1c5;
var _1c6;
var _1c7=0;
var _1c8=0;
var _1c9=0;
var Days=0;
var _1cb=0;
var _1cc=0;
_1c2=new String(_1c2);
_1c4="";
_1c5="";
_1c6=false;
for(var i=1;i<_1c2.length;i++){
_1c5=_1c2.charAt(i);
if(IsIso8601SectionDelimiter(_1c5)){
switch(_1c5.toUpperCase()){
case "Y":
_1cc=parseInt(_1c4,10);
break;
case "M":
if(_1c6){
_1c8=parseInt(_1c4,10);
}else{
_1cb=parseInt(_1c4,10);
}
break;
case "D":
Days=parseInt(_1c4,10);
break;
case "H":
_1c9=parseInt(_1c4,10);
break;
case "S":
_1c7=parseFloat(_1c4);
break;
case "T":
_1c6=true;
break;
}
_1c4="";
}else{
_1c4+=""+_1c5;
}
}
_1c3=(_1cc*HUNDREDTHS_PER_YEAR)+(_1cb*HUNDREDTHS_PER_MONTH)+(Days*HUNDREDTHS_PER_DAY)+(_1c9*HUNDREDTHS_PER_HOUR)+(_1c8*HUNDREDTHS_PER_MINUTE)+(_1c7*HUNDREDTHS_PER_SECOND);
_1c3=Math.round(_1c3);
return _1c3;
}
function IsIso8601SectionDelimiter(str){
if(str.search(/[PYMDTHS]/)>=0){
return true;
}else{
return false;
}
}
function ConvertHundredthsToIso8601TimeSpan(_1cf){
var _1d0="";
var _1d1;
var _1d2;
var _1d3;
var _1d4;
var Days;
var _1d6;
var _1d7;
_1d1=_1cf;
_1d7=Math.floor(_1d1/HUNDREDTHS_PER_YEAR);
_1d1-=(_1d7*HUNDREDTHS_PER_YEAR);
_1d6=Math.floor(_1d1/HUNDREDTHS_PER_MONTH);
_1d1-=(_1d6*HUNDREDTHS_PER_MONTH);
Days=Math.floor(_1d1/HUNDREDTHS_PER_DAY);
_1d1-=(Days*HUNDREDTHS_PER_DAY);
_1d4=Math.floor(_1d1/HUNDREDTHS_PER_HOUR);
_1d1-=(_1d4*HUNDREDTHS_PER_HOUR);
_1d3=Math.floor(_1d1/HUNDREDTHS_PER_MINUTE);
_1d1-=(_1d3*HUNDREDTHS_PER_MINUTE);
_1d2=Math.floor(_1d1/HUNDREDTHS_PER_SECOND);
_1d1-=(_1d2*HUNDREDTHS_PER_SECOND);
if(_1d7>0){
_1d0+=_1d7+"Y";
}
if(_1d0>0){
ScormTime+=_1d6+"M";
}
if(Days>0){
_1d0+=Days+"D";
}
if((_1d1+_1d2+_1d3+_1d4)>0){
_1d0+="T";
if(_1d4>0){
_1d0+=_1d4+"H";
}
if(_1d3>0){
_1d0+=_1d3+"M";
}
if((_1d1+_1d2)>0){
_1d0+=_1d2;
if(_1d1>0){
_1d0+="."+_1d1;
}
_1d0+="S";
}
}
if(_1d0===""){
_1d0="T0H0M0S";
}
_1d0="P"+_1d0;
return _1d0;
}
function ConvertHundredthsIntoSCORMTime(_1d8){
var _1d9;
var _1da;
var _1db;
var _1dc;
intTotalMilliseconds=(_1d8*10);
var _1dd;
_1dc=intTotalMilliseconds%1000;
_1db=((intTotalMilliseconds-_1dc)/1000)%60;
intMinutes=((intTotalMilliseconds-_1dc-(_1db*1000))/60000)%60;
_1d9=(intTotalMilliseconds-_1dc-(_1db*1000)-(intMinutes*60000))/3600000;
if(_1d9==10000){
_1d9=9999;
intMinutes=(intTotalMilliseconds-(_1d9*3600000))/60000;
if(intMinutes==100){
intMinutes=99;
}
intMinutes=Math.floor(intMinutes);
_1db=(intTotalMilliseconds-(_1d9*3600000)-(intMinutes*60000))/1000;
if(_1db==100){
_1db=99;
}
_1db=Math.floor(_1db);
_1dc=(intTotalMilliseconds-(_1d9*3600000)-(intMinutes*60000)-(_1db*1000));
}
intHundredths=Math.floor(_1dc/10);
_1dd=ZeroPad(_1d9,4)+":"+ZeroPad(intMinutes,2)+":"+ZeroPad(_1db,2)+"."+intHundredths;
if(_1d9>9999){
_1dd="9999:99:99.99";
}
return _1dd;
}
function RemoveIndiciesFromCmiElement(_1de){
return _1de.replace(REG_EX_DIGITS,"n");
}
function ExtractIndex(_1df){
var _1e0="";
var _1e1;
_1e1=_1df.match(/\.\d+\./);
if(_1e1!==null&&_1e1.length>0){
_1e0=_1e1[0].replace(/\./g,"");
_1e0=parseInt(_1e0,10);
}
return _1e0;
}
function ExtractSecondaryIndex(_1e2){
var _1e3="";
var _1e4;
_1e4=_1e2.match(/\.\d+\./g);
if(_1e4!==null&&_1e4.length>1){
_1e3=_1e4[1].replace(/\./g,"");
_1e3=parseInt(_1e3,10);
}
return _1e3;
}
function TranslateDualStausToSingleStatus(_1e5,_1e6){
var _1e7=null;
switch(_1e6){
case (SCORM_STATUS_PASSED):
_1e7=SCORM_STATUS_PASSED;
break;
case (SCORM_STATUS_FAILED):
_1e7=SCORM_STATUS_FAILED;
break;
case (SCORM_STATUS_UNKNOWN):
if(_1e5==SCORM_STATUS_COMPLETED){
_1e7=SCORM_STATUS_COMPLETED;
}else{
if(_1e5==SCORM_STATUS_INCOMPLETE){
_1e7=SCORM_STATUS_INCOMPLETE;
}else{
if(_1e5==SCORM_STATUS_UNKNOWN||_1e5==SCORM_STATUS_NOT_ATTEMPTED){
_1e7=SCORM_STATUS_NOT_ATTEMPTED;
}else{
if(_1e5==SCORM_STATUS_BROWSED){
_1e7=SCORM_STATUS_BROWSED;
}
}
}
}
break;
}
if(_1e7===null){
Debug.AssertError("Invalid status combination encountered in GetValue - Success = "+_1e6+", Completion = "+_1e5);
return "";
}else{
return _1e7;
}
}
function TranslateSingleStatusIntoSuccess(_1e8){
var _1e9;
switch(_1e8){
case (SCORM_STATUS_PASSED):
_1e9=SCORM_STATUS_PASSED;
break;
case (SCORM_STATUS_COMPLETED):
_1e9=SCORM_STATUS_UNKNOWN;
break;
case (SCORM_STATUS_FAILED):
_1e9=SCORM_STATUS_FAILED;
break;
case (SCORM_STATUS_INCOMPLETE):
_1e9=SCORM_STATUS_UNKNOWN;
break;
case (SCORM_STATUS_BROWSED):
_1e9=SCORM_STATUS_UNKNOWN;
break;
case (SCORM_STATUS_NOT_ATTEMPTED):
_1e9=SCORM_STATUS_UNKNOWN;
break;
default:
Debug.AssertError("Unrecognized single status");
}
return _1e9;
}
function TranslateSingleStatusIntoCompletion(_1ea){
var _1eb;
switch(_1ea){
case (SCORM_STATUS_PASSED):
_1eb=SCORM_STATUS_COMPLETED;
break;
case (SCORM_STATUS_COMPLETED):
_1eb=SCORM_STATUS_COMPLETED;
break;
case (SCORM_STATUS_FAILED):
if(Control.Package.Properties.CompletionStatOfFailedSuccessStat===SCORM_STATUS_COMPLETED||Control.Package.Properties.CompletionStatOfFailedSuccessStat===SCORM_STATUS_INCOMPLETE){
_1eb=Control.Package.Properties.CompletionStatOfFailedSuccessStat;
}else{
_1eb=SCORM_STATUS_COMPLETED;
}
break;
case (SCORM_STATUS_INCOMPLETE):
_1eb=SCORM_STATUS_INCOMPLETE;
break;
case (SCORM_STATUS_BROWSED):
_1eb=SCORM_STATUS_BROWSED;
break;
case (SCORM_STATUS_NOT_ATTEMPTED):
_1eb=SCORM_STATUS_NOT_ATTEMPTED;
break;
default:
Debug.AssertError("Unrecognized single status");
}
return _1eb;
}
function IsValidCMITimeSpan(_1ec){
var _1ed=/^\d?\d?\d\d:\d\d:\d\d(.\d\d?)?$/;
if(_1ec.search(_1ed)>-1){
return true;
}else{
return false;
}
}
function IsValidCMIDecimal(_1ee){
if(_1ee.search(/[^.\d-]/)>-1){
return false;
}
if(_1ee.search("-")>-1){
if(_1ee.indexOf("-",1)>-1){
return false;
}
}
if(_1ee.indexOf(".")!=_1ee.lastIndexOf(".")){
return false;
}
if(_1ee.search(/\d/)<0){
return false;
}
return true;
}
function IsValidCMIIdentifier(_1ef){
if(_1ef.length>255){
return false;
}
if(_1ef===""){
return false;
}
return true;
}
function IsValidCMISInteger(_1f0){
if(_1f0.search(/[^\d-]/)>-1){
return false;
}
if(_1f0.search("-")>-1){
if(_1f0.indexOf("-",1)>-1){
return false;
}
}
if(_1f0.search(/\d/)<0){
return false;
}
_1f0=parseInt(_1f0,10);
if(_1f0<-32768||_1f0>32768){
return false;
}
return true;
}
function IsValidCMITime(_1f1){
var _1f2=/^\d\d:\d\d:\d\d(.\d\d?)?$/;
var _1f3;
var _1f4;
var _1f5;
var _1f6;
var _1f7;
var _1f8=0;
if(_1f1.search(_1f2)<0){
return false;
}
_1f3=_1f1.split(":");
_1f4=_1f3[0];
_1f5=_1f3[1];
_1f6=_1f3[2].split(".");
_1f7=_1f6[0];
if(_1f6.length>1){
_1f8=_1f6[1];
}
if(_1f4<0||_1f4>23){
return false;
}
if(_1f5<0||_1f5>59){
return false;
}
if(_1f7<0||_1f7>59){
return false;
}
if(_1f8<0||_1f8>99){
return false;
}
return true;
}
function IsValidCMIFeedback(_1f9,_1fa){
if(_1fa.length>4096){
return false;
}
if(RegistrationToDeliver.Package.Properties.ValidateInteractionResponses){
_1fa=_1fa.toLowerCase();
switch(_1f9){
case "true-false":
if(_1fa.search(/^[01tf]/)!==0){
return false;
}
break;
case "choice":
if(_1fa.search(/(^(([a-z0-9])|(([a-z0-9]\,)+[a-z0-9]))$)|(^\{(([a-z0-9])|(([a-z0-9]\,)+[a-z0-9]))\}$)/)!==0){
return false;
}
break;
case "fill-in":
if(_1fa.length>255){
return false;
}
break;
case "numeric":
if(!IsValidCMIDecimal(_1fa)){
return false;
}
break;
case "likert":
break;
case "matching":
if(_1fa.search(/(^[0-9a-z]\.[0-9a-z]$)|(^([0-9a-z]\.[0-9a-z]\,)+([0-9a-z]\.[0-9a-z])$)|(^\{[0-9a-z]\.[0-9a-z]\}$)|(^\{([0-9a-z]\.[0-9a-z]\,)+([0-9a-z]\.[0-9a-z])\}$)/)!==0){
return false;
}
break;
case "performance":
if(_1fa.length>255){
return false;
}
break;
case "sequencing":
if(_1fa.search(/(^[a-z0-9]$)|(^([a-z0-9]\,)+[a-z0-9]$)/)!==0){
return false;
}
break;
default:
break;
}
}
return true;
}
function NormalizeRawScore(_1fb,_1fc,_1fd){
var _1fe=null;
if(_1fc!==null&&_1fc!==undefined){
_1fc=parseFloat(_1fc);
}
if(_1fd!==null&&_1fd!==undefined){
_1fd=parseFloat(_1fd);
}
if(_1fb!==null&&_1fb!==undefined){
_1fb=parseFloat(_1fb);
if(_1fc!==null&&_1fc!==undefined&&_1fd!==null&&_1fd!==undefined&&_1fb>=_1fc&&_1fb<=_1fd){
if(_1fc==_1fd){
if(_1fb==0){
_1fe=0;
}else{
_1fe=1;
}
}else{
_1fe=((_1fb-_1fc)/(_1fd-_1fc));
}
}else{
if(_1fb>=0&&_1fb<=100){
_1fe=(_1fb/100);
}
}
}
if(_1fe!==null){
return RoundToPrecision(_1fe,7);
}else{
return null;
}
}
function ServerFormater(){
}
ServerFormater.prototype.ConvertBoolean=ServerFormater_ConvertBoolean;
ServerFormater.prototype.ConvertCompletionStatus=ServerFormater_ConvertCompletionStatus;
ServerFormater.prototype.ConvertCredit=ServerFormater_ConvertCredit;
ServerFormater.prototype.ConvertEntry=ServerFormater_ConvertEntry;
ServerFormater.prototype.ConvertExit=ServerFormater_ConvertExit;
ServerFormater.prototype.ConvertMode=ServerFormater_ConvertMode;
ServerFormater.prototype.ConvertSuccessStatus=ServerFormater_ConvertSuccessStatus;
ServerFormater.prototype.ConvertInteractionType=ServerFormater_ConvertInteractionType;
ServerFormater.prototype.ConvertInteractionResult=ServerFormater_ConvertInteractionResult;
ServerFormater.prototype.GetNumericInteractionResultId=ServerFormater_GetNumericInteractionResultId;
ServerFormater.prototype.ConvertTimeSpan=ServerFormater_ConvertTimeSpan;
ServerFormater.prototype.ConvertTime=ServerFormater_ConvertTime;
ServerFormater.prototype.ConvertSSPAllocationSuccess=ServerFormater_ConvertSSPAllocationSuccess;
ServerFormater.prototype.ConvertSSPPersistence=ServerFormater_ConvertSSPPersistence;
ServerFormater.prototype.TrimToLength=ServerFormater_TrimToLength;
function ServerFormater_ConvertBoolean(_1ff){
var _200;
if(_1ff===true){
_200="1";
}else{
if(_1ff===false){
_200="0";
}else{
Debug.AssertError("Value is not a boolean");
}
}
return _200;
}
function ServerFormater_ConvertCompletionStatus(_201){
var _202=null;
switch(_201){
case (SCORM_STATUS_UNKNOWN):
_202=1;
break;
case (SCORM_STATUS_COMPLETED):
_202=2;
break;
case (SCORM_STATUS_INCOMPLETE):
_202=3;
break;
case (SCORM_STATUS_BROWSED):
_202=4;
break;
case (SCORM_STATUS_NOT_ATTEMPTED):
_202=5;
break;
default:
Debug.AssertError("Unrecognized Completion Status Value");
_202=-1;
break;
}
return _202;
}
function ServerFormater_ConvertCredit(_203){
var _204=null;
switch(_203){
case (SCORM_CREDIT):
_204=1;
break;
case (SCORM_CREDIT_NO):
_204=2;
break;
default:
Debug.AssertError("Unrecognized Credit Value");
_204=-1;
break;
}
return _204;
}
function ServerFormater_ConvertEntry(_205){
var _206=null;
switch(_205){
case (SCORM_ENTRY_AB_INITO):
_206=1;
break;
case (SCORM_ENTRY_RESUME):
_206=2;
break;
case (SCORM_ENTRY_NORMAL):
_206=3;
break;
default:
Debug.AssertError("Unrecognized Entry Value");
_206=-1;
break;
}
return _206;
}
function ServerFormater_ConvertExit(_207){
var _208=null;
switch(_207){
case (SCORM_EXIT_TIME_OUT):
_208=1;
break;
case (SCORM_EXIT_SUSPEND):
_208=2;
break;
case (SCORM_EXIT_LOGOUT):
_208=3;
break;
case (SCORM_EXIT_NORMAL):
_208=4;
break;
case (SCORM_EXIT_UNKNOWN):
_208=5;
break;
default:
Debug.AssertError("Unrecognized Exit Value");
_208=-1;
break;
}
return _208;
}
function ServerFormater_ConvertMode(_209){
var _20a=null;
switch(_209){
case (SCORM_MODE_NORMAL):
_20a=1;
break;
case (SCORM_MODE_BROWSE):
_20a=2;
break;
case (SCORM_MODE_REVIEW):
_20a=3;
break;
default:
Debug.AssertError("Unrecognized Mode Value");
_20a=-1;
break;
}
return _20a;
}
function ServerFormater_ConvertSuccessStatus(_20b){
var _20c=null;
switch(_20b){
case (SCORM_STATUS_UNKNOWN):
_20c=1;
break;
case (SCORM_STATUS_PASSED):
_20c=2;
break;
case (SCORM_STATUS_FAILED):
_20c=3;
break;
default:
Debug.AssertError("Unrecognized Success Status Value");
_20c=-1;
break;
}
return _20c;
}
function ServerFormater_ConvertInteractionType(_20d){
var _20e=null;
switch(_20d){
case (SCORM_TRUE_FALSE):
_20e=1;
break;
case (SCORM_CHOICE):
_20e=2;
break;
case (SCORM_FILL_IN):
_20e=3;
break;
case (SCORM_MATCHING):
_20e=6;
break;
case (SCORM_PERFORMANCE):
_20e=7;
break;
case (SCORM_SEQUENCING):
_20e=8;
break;
case (SCORM_LIKERT):
_20e=5;
break;
case (SCORM_NUMERIC):
_20e=9;
break;
case (SCORM_LONG_FILL_IN):
_20e=4;
break;
case (SCORM_OTHER):
_20e=10;
break;
default:
Debug.AssertError("Unrecognized Interaction Type Value");
_20e=-1;
break;
}
return _20e;
}
function ServerFormater_ConvertInteractionResult(_20f){
var _210=null;
switch(_20f){
case (SCORM_CORRECT):
_210=1;
break;
case (SCORM_UNANTICIPATED):
_210=3;
break;
case (SCORM_INCORRECT):
_210=2;
break;
case (SCORM_NEUTRAL):
_210=4;
break;
default:
Debug.AssertError("Unrecognized Interaction Result Value");
_210=-1;
break;
}
return _210;
}
function ServerFormater_GetNumericInteractionResultId(){
return 5;
}
function ServerFormater_ConvertTimeSpan(_211){
return ConvertIso8601TimeSpanToHundredths(_211);
}
function ServerFormater_ConvertTime(_212){
return ConvertIso8601TimeToUtcAnsiSql(_212);
}
function ServerFormater_ConvertSSPAllocationSuccess(_213){
var _214=null;
switch(_213){
case (SSP_ALLOCATION_SUCCESS_FAILURE):
_214=3;
break;
case (SSP_ALLOCATION_SUCCESS_MINIMUM):
_214=1;
break;
case (SSP_ALLOCATION_SUCCESS_REQUESTED):
_214=2;
break;
case (SSP_ALLOCATION_SUCCESS_NOT_ATTEMPTED):
_214=4;
break;
default:
Debug.AssertError("Unrecognized SSPAllocationSuccess Value");
_214=-1;
break;
}
return _214;
}
function ServerFormater_ConvertSSPPersistence(_215){
var _216=null;
switch(_215){
case (SSP_PERSISTENCE_LEARNER):
_216=1;
break;
case (SSP_PERSISTENCE_COURSE):
_216=2;
break;
case (SSP_PERSISTENCE_SESSION):
_216=3;
break;
default:
Debug.AssertError("Unrecognized SSPPersistence Value");
_216=-1;
break;
}
return _216;
}
function ServerFormater_TrimToLength(str,len){
if(str!==null&&str.length>len){
str=str.substr(0,len);
}
return str;
}
function StringBuilder(_219){
if(_219!==null&&parseInt(_219,10)>0){
this.Contents=new Array(parseInt(_219,10));
}else{
this.Contents=new Array();
}
this.CurrentEntry=0;
}
StringBuilder.prototype.Append=StringBuilder_Append;
StringBuilder.prototype.AppendLine=StringBuilder_AppendLine;
StringBuilder.prototype.toString=StringBuilder_toString;
function StringBuilder_Append(str){
this.Contents[this.CurrentEntry]=str;
this.CurrentEntry++;
}
function StringBuilder_AppendLine(str){
this.Append(str+"\r\n");
}
function StringBuilder_toString(){
return this.Contents.join("").trim();
}
String.prototype.trim=String_Trim;
String.prototype.toBoolean=String_ToBoolean;
function String_Trim(){
return Trim(this);
}
function Trim(str){
str=str.replace(/^\s*/,"");
str=str.replace(/\s*$/,"");
return str;
}
function String_ToBoolean(){
var str=this;
var _21e;
str=new String(str).toLowerCase();
if(str=="1"||str.charAt(0)=="t"){
_21e=true;
}else{
if(str=="0"||str.charAt(0)=="f"){
_21e=false;
}else{
Debug.AssertError("Value '"+str+"' can not be converted to a boolean.");
}
}
return _21e;
}
function MergeQueryStringParameters(){
var _21f=new Array();
var _220=new Array();
var url=null;
var _222=null;
var i;
var _224=0;
var _225=null;
for(i=0;i<arguments.length;i++){
if(arguments[i]!=null&&arguments[i].length>0){
_224++;
if(_225==null){
_225=arguments[i];
}
}
}
if(_224==1){
return _225;
}
for(i=0;i<arguments.length;i++){
var qs=arguments[i];
qs=new String(qs);
if(qs.indexOf("#")>-1){
if(qs.charAt(0)=="#"){
if(_222===null){
_222=qs.substring(1);
}
qs="";
}else{
var _227=qs.split("#");
if(_222===null){
_222=_227[1];
}
qs=_227[0];
}
}
if(qs.indexOf("?")>0){
var _228=qs.substring(0,qs.indexOf("?"));
var _229=qs.substring(qs.indexOf("?")+1,qs.length);
if(url===null){
url=_228;
}
qs=_229;
}
if(qs.indexOf("#")<0&&qs.indexOf("=")<0&&qs.indexOf("?")<0&&(qs.indexOf("&")<0||(qs.indexOf("&")>0&&qs.indexOf(".")>0))){
if(url===null){
url=qs;
}
qs="";
}
if(qs.charAt(0)=="?"){
qs=qs.substring(1);
}
if(qs.charAt(0)=="&"){
qs=qs.substring(1);
}
if(qs.indexOf("&")>-1){
var _22a=qs.split("&");
for(var j=0;j<_22a.length;j++){
AddQueryStringParm(_21f,_220,_22a[j]);
}
}else{
if(qs.length>0){
AddQueryStringParm(_21f,_220,qs);
}
}
}
var _22c="";
if(url!==null){
_22c+=url;
}
var _22d=true;
for(i=0;i<_21f.length;i++){
if(_22d){
_22c+="?";
_22d=false;
}else{
_22c+="&";
}
_22c+=_21f[i];
var _22e=_220[i];
if(_22e!=null){
_22c+="="+_22e;
}
}
if(_222!==null){
_22c+="#"+_222;
}
return _22c;
}
function AddQueryStringParm(_22f,_230,_231){
if(_231.indexOf("=")>-1){
var parm=_231.split("=");
var name=parm[0];
var _234=parm[1];
_22f[_22f.length]=name;
_230[_230.length]=_234;
}else{
_22f[_22f.length]=_231;
_230[_230.length]=null;
}
}
function CleanExternalString(str){
str=str+"";
str=new String(str);
str=str.toString();
str=unescape(escape(str));
return str;
}
function ZeroPad(num,_237){
var _238;
var _239;
var i;
_238=new String(num);
_239=_238.length;
if(_239>_237){
_238=_238.substr(0,_237);
}else{
for(i=_239;i<_237;i++){
_238="0"+_238;
}
}
return _238;
}
function RoundToPrecision(_23b,_23c){
return Math.round(_23b*Math.pow(10,_23c))/Math.pow(10,_23c);
}
function GetErrorDetailString(_23d){
var _23e=[];
if(typeof navigator!="undefined"){
if(typeof navigator.userAgent!="undefined"){
_23e.push("User Agent: "+navigator.userAgent);
}
if(typeof navigator.platform!="undefined"){
_23e.push("Platform: "+navigator.platform);
}
}else{
_23e.push("No browser information was available (via the global navigator object)");
}
if(typeof _23d.name!="undefined"){
_23e.push("Name: "+_23d.name);
}
if(typeof _23d.message!="undefined"){
_23e.push("Message: "+_23d.message);
}
if(typeof _23d.description!="undefined"){
_23e.push("Description: "+_23d.description);
}
if(typeof _23d.number!="undefined"){
_23e.push("Number: "+_23d.number);
}
if(typeof _23d.fileName!="undefined"){
_23e.push("Filename: "+_23d.fileName);
}
if(typeof _23d.lineNumber!="undefined"){
_23e.push("Linenumber: "+_23d.lineNumber);
}
if(typeof _23d.toString!="undefined"){
_23e.push("toString(): "+_23d.toString());
}
try{
var _23f=printStackTrace({e:_23d});
_23e.push("StackTrace: "+_23f.join("  -->  "));
}
catch(error2){
_23e.push("StackTrace: [Error fetching stack trace]");
}
return _23e.join(", ");
}
function XmlElement(_240){
this.ElementName=_240;
this.Attributes=new Array();
this.Elements=new Array();
}
XmlElement.prototype.AddAttribute=XmlElement_AddAttribute;
XmlElement.prototype.AddElement=XmlElement_AddElement;
XmlElement.prototype.Encode=XmlElement_Encode;
XmlElement.prototype.toString=XmlElement_toString;
function XmlElement_AddAttribute(_241,_242){
this.Attributes[_241]=this.Encode(_242);
}
function XmlElement_AddElement(_243){
this.Elements[this.Elements.length]=_243;
}
function XmlElement_toString(){
var xml=new StringBuilder(this.Attributes.length+this.Elements.length+2);
xml.Append("<"+this.ElementName+" ");
for(var _245 in this.Attributes){
xml.Append(_245+"=\""+this.Attributes[_245]+"\" ");
}
if(this.Elements.length>0){
xml.AppendLine(">");
for(var i=0;i<this.Elements.length;i++){
xml.AppendLine(this.Elements[i]);
}
xml.AppendLine("</"+this.ElementName+">");
}else{
xml.AppendLine("/>");
}
return xml.toString().trim();
}
function XmlElement_Encode(str){
str=new String(str);
if(str!==null){
str=str.replace(/\&/g,"&amp;");
str=str.replace(/\</g,"&lt;");
str=str.replace(/\>/g,"&gt;");
str=str.replace(/\'/g,"&apos;");
str=str.replace(/\"/g,"&quot;");
if("a".replace(/a/,function(){
return "";
}).length==0){
str=str.replace(/(\w|\W)/g,XmlElement_CharacterEscape);
}else{
str=EscapeCharacters(str);
}
}
return str;
}
function XmlElement_CharacterEscape(s,_249){
var _24a=_249.charCodeAt(0);
_24a=new Number(_24a);
if(_24a>127){
return "&#x"+_24a.toString(16)+";";
}else{
if(_24a<32){
return "&amp;#x"+_24a.toString(16)+";";
}else{
return _249;
}
}
}
function EscapeCharacters(str){
var _24c=new StringBuilder();
for(var c=0;c<str.length;c++){
var _24e=str.charCodeAt(c);
if(_24e>127){
_24c.Append("&#x"+_24e.toString(16)+";");
}else{
if(_24e<32){
_24c.Append("&amp;#x"+_24e.toString(16)+";");
}else{
_24c.Append(str.charAt(c));
}
}
}
return _24c.toString();
}
function ActivityObjective(_24f,_250,_251,_252,_253,_254,_255,_256,_257,_258,_259,_25a,_25b,_25c,_25d,_25e,_25f,_260,_261){
this.Identifier=_24f;
this.ProgressStatus=_250;
this.SatisfiedStatus=_251;
this.MeasureStatus=_252;
this.NormalizedMeasure=_253;
this.Primary=_254;
this.PrevProgressStatus=_255;
this.PrevSatisfiedStatus=_256;
this.PrevMeasureStatus=_257;
this.PrevNormalizedMeasure=_258;
this.FirstSuccessTimestampUtc=_259;
this.FirstNormalizedMeasure=_25a;
this.ScoreRaw=_25b;
this.ScoreMin=_25c;
this.ScoreMax=_25d;
this.CompletionStatus=_25e;
this.CompletionStatusValue=_25f;
this.ProgressMeasureStatus=_260;
this.ProgressMeasure=_261;
this.SatisfiedByMeasure=false;
this.MinNormalizedMeasure=1;
this.Maps=new Array();
this.DataState=DATA_STATE_CLEAN;
this.Sequencer=null;
}
ActivityObjective.prototype.GetXml=ActivityObjective_GetXml;
ActivityObjective.prototype.toString=ActivityObjective_toString;
ActivityObjective.prototype.ResetAttemptState=ActivityObjective_ResetAttemptState;
ActivityObjective.prototype.GetContributesToRollup=ActivityObjective_GetContributesToRollup;
ActivityObjective.prototype.GetMeasureStatus=ActivityObjective_GetMeasureStatus;
ActivityObjective.prototype.GetNormalizedMeasure=ActivityObjective_GetNormalizedMeasure;
ActivityObjective.prototype.SetMeasureStatus=ActivityObjective_SetMeasureStatus;
ActivityObjective.prototype.SetNormalizedMeasure=ActivityObjective_SetNormalizedMeasure;
ActivityObjective.prototype.SetProgressStatus=ActivityObjective_SetProgressStatus;
ActivityObjective.prototype.SetSatisfiedStatus=ActivityObjective_SetSatisfiedStatus;
ActivityObjective.prototype.GetSatisfiedByMeasure=ActivityObjective_GetSatisfiedByMeasure;
ActivityObjective.prototype.GetMinimumSatisfiedNormalizedMeasure=ActivityObjective_GetMinimumSatisfiedNormalizedMeasure;
ActivityObjective.prototype.GetProgressStatus=ActivityObjective_GetProgressStatus;
ActivityObjective.prototype.GetSatisfiedStatus=ActivityObjective_GetSatisfiedStatus;
ActivityObjective.prototype.GetScoreRaw=ActivityObjective_GetScoreRaw;
ActivityObjective.prototype.GetScoreMin=ActivityObjective_GetScoreMin;
ActivityObjective.prototype.GetScoreMax=ActivityObjective_GetScoreMax;
ActivityObjective.prototype.GetCompletionStatus=ActivityObjective_GetCompletionStatus;
ActivityObjective.prototype.GetCompletionStatusValue=ActivityObjective_GetCompletionStatusValue;
ActivityObjective.prototype.GetProgressMeasureStatus=ActivityObjective_GetProgressMeasureStatus;
ActivityObjective.prototype.GetProgressMeasure=ActivityObjective_GetProgressMeasure;
ActivityObjective.prototype.SetScoreRaw=ActivityObjective_SetScoreRaw;
ActivityObjective.prototype.SetScoreMin=ActivityObjective_SetScoreMin;
ActivityObjective.prototype.SetScoreMax=ActivityObjective_SetScoreMax;
ActivityObjective.prototype.SetCompletionStatus=ActivityObjective_SetCompletionStatus;
ActivityObjective.prototype.SetCompletionStatusValue=ActivityObjective_SetCompletionStatusValue;
ActivityObjective.prototype.SetProgressMeasureStatus=ActivityObjective_SetProgressMeasureStatus;
ActivityObjective.prototype.SetProgressMeasure=ActivityObjective_SetProgressMeasure;
ActivityObjective.prototype.GetIdentifier=ActivityObjective_GetIdentifier;
ActivityObjective.prototype.GetMaps=ActivityObjective_GetMaps;
ActivityObjective.prototype.SetDirtyData=ActivityObjective_SetDirtyData;
ActivityObjective.prototype.SetSequencer=ActivityObjective_SetSequencer;
ActivityObjective.prototype.Clone=ActivityObjective_Clone;
ActivityObjective.prototype.TearDown=ActivityObjective_TearDown;
ActivityObjective.prototype.GetSuccessStatusChangedDuringRuntime=ActivityObjective_GetSuccessStatusChangedDuringRuntime;
function ActivityObjective_GetXml(_262,_263){
var _264=new ServerFormater();
var xml=new XmlElement("AO");
xml.AddAttribute("AI",_262);
xml.AddAttribute("AOI",_263);
xml.AddAttribute("I",this.Identifier);
xml.AddAttribute("PS",_264.ConvertBoolean(this.ProgressStatus));
xml.AddAttribute("SS",_264.ConvertBoolean(this.SatisfiedStatus));
xml.AddAttribute("MS",_264.ConvertBoolean(this.MeasureStatus));
xml.AddAttribute("NM",this.NormalizedMeasure);
xml.AddAttribute("PPS",_264.ConvertBoolean(this.PrevProgressStatus));
xml.AddAttribute("PSS",_264.ConvertBoolean(this.PrevSatisfiedStatus));
xml.AddAttribute("PMS",_264.ConvertBoolean(this.PrevMeasureStatus));
xml.AddAttribute("PNM",this.PrevNormalizedMeasure);
if(this.FirstSuccessTimestampUtc!==null){
xml.AddAttribute("FSTU",this.FirstSuccessTimestampUtc);
}
if(this.FirstNormalizedMeasure!==null){
xml.AddAttribute("FNM",this.FirstNormalizedMeasure);
}
xml.AddAttribute("P",_264.ConvertBoolean(this.Primary));
xml.AddAttribute("CS",_264.ConvertBoolean(this.CompletionStatus));
xml.AddAttribute("CSV",_264.ConvertBoolean(this.CompletionStatusValue));
if(this.ScoreRaw!==null){
xml.AddAttribute("SR",this.ScoreRaw);
}
if(this.ScoreMax!==null){
xml.AddAttribute("SM",this.ScoreMax);
}
if(this.ScoreMin!==null){
xml.AddAttribute("SMi",this.ScoreMin);
}
xml.AddAttribute("PrMS",_264.ConvertBoolean(this.ProgressMeasureStatus));
if(this.ProgressMeasure!==null){
xml.AddAttribute("PM",this.ProgressMeasure);
}
return xml.toString();
}
function ActivityObjective_toString(){
return this.Identifier;
}
function ActivityObjective_ResetAttemptState(){
this.PrevProgressStatus=this.ProgressStatus;
this.PrevSatisfiedStatus=this.SatisfiedStatus;
this.PrevMeasureStatus=this.MeasureStatus;
this.PrevNormalizedMeasure=this.NormalizedMeasure;
this.ProgressStatus=false;
this.SatisfiedStatus=false;
this.MeasureStatus=false;
this.NormalizedMeasure=0;
this.ScoreRaw=null;
this.ScoreMin=null;
this.ScoreMax=null;
this.CompletionStatus=false;
this.CompletionStatusValue=false;
this.ProgressMeasureStatus=false;
this.ProgressMeasure=null;
this.SetDirtyData();
}
function ActivityObjective_GetContributesToRollup(){
var _266=this.Primary;
return _266;
}
function ActivityObjective_GetMeasureStatus(_267,_268){
if(_268===null||_268===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into GetMeasureStatus");
}
var _269;
if(_268===true&&(_267!=null&&_267!=undefined)&&_267.WasAttemptedDuringThisAttempt()===false){
_269=this.PrevMeasureStatus;
}else{
_269=this.MeasureStatus;
}
var _26a=(_269===false)||Control.Package.LearningStandard.is20043rdOrGreater();
if(_26a===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadNormalizedMeasure===true){
var _26d=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_26d!==null){
_269=_26d.MeasureStatus;
}
}
}
}
return _269;
}
function ActivityObjective_GetNormalizedMeasure(_26e,_26f){
if(_26f===null||_26f===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into GetNormalizedMeasure");
}
var _270;
var _271;
if(_26f===true&&(_26e!=null&&_26e!=undefined)&&_26e.WasAttemptedDuringThisAttempt()===false){
_270=this.PrevMeasureStatus;
_271=this.PrevNormalizedMeasure;
}else{
_270=this.MeasureStatus;
_271=this.NormalizedMeasure;
}
var _272=(_270===false)||Control.Package.LearningStandard.is20043rdOrGreater();
if(_272===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadNormalizedMeasure===true){
var _275=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_275!==null&&_275.MeasureStatus===true){
_271=_275.NormalizedMeasure;
}
}
}
}
return _271;
}
function ActivityObjective_SetMeasureStatus(_276,_277){
if(_277===null||_277===undefined){
Debug.AssertError("ERROR - activity must be passed into SetMeasureStatus");
}
this.MeasureStatus=_276;
if(_276===true){
_277.SetAttemptedDuringThisAttempt();
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteNormalizedMeasure===true){
var _27a=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_27a===null){
this.Sequencer.AddGlobalObjective(maps[i].TargetObjectiveId,false,false,true,0);
}else{
_27a.MeasureStatus=true;
_27a.SetDirtyData();
}
}
}
}
this.SetDirtyData();
}
function ActivityObjective_SetNormalizedMeasure(_27b,_27c){
this.NormalizedMeasure=_27b;
if(this.MeasureStatus===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteNormalizedMeasure===true){
var _27f=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_27f===null){
this.Sequencer.AddGlobalObjective(maps[i].TargetObjectiveId,false,false,true,_27b);
}else{
_27f.NormalizedMeasure=_27b;
_27f.SetDirtyData();
}
}
}
}
if(_27c===null||_27c===undefined){
Debug.AssertError("ERROR - activity must be passed into SetNormalizedMeasure");
}
if(this.GetSatisfiedByMeasure()===true&&(_27c.IsActive()===false||_27c.GetMeasureSatisfactionIfActive()===true)){
var _280=true;
var _281;
if(this.GetNormalizedMeasure(_27c,false)>=this.GetMinimumSatisfiedNormalizedMeasure()){
_281=true;
}else{
_281=false;
}
this.SetProgressStatus(_280,true,_27c);
this.SetSatisfiedStatus(_281,true,_27c);
}
if(this.ProgressStatus===true&&this.FirstNormalizedMeasure==0){
this.FirstNormalizedMeasure=_27b;
}
this.SetDirtyData();
}
function ActivityObjective_SetProgressStatus(_282,_283,_284,_285,_286){
if(_284===null||_284===undefined){
Debug.AssertError("ERROR - activity must be passed into SetMeasureStatus");
}
if(this.GetSatisfiedByMeasure()===false||_283===true){
this.ProgressStatus=_282;
if(_282===true){
_284.SetAttemptedDuringThisAttempt();
}
var _287=_282;
if(Control.Package.LearningStandard.is20044thOrGreater()){
_287=_287||(_285===true);
}
if(_287){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteSatisfiedStatus===true){
var _28a=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_28a===null){
this.Sequencer.AddGlobalObjective(maps[i].TargetObjectiveId,_282,false,false,0);
}else{
_28a.ProgressStatus=_282;
_28a.SetDirtyData();
}
}
}
}
this.SetDirtyData();
}
}
function ActivityObjective_SetSatisfiedStatus(_28b,_28c,_28d){
if(this.GetSatisfiedByMeasure()===false||_28c===true){
this.SatisfiedStatus=_28b;
if(_28b===true&&Control.Package.Properties.SatisfiedCausesCompletion===true){
_28d.SetAttemptProgressStatus(true);
_28d.SetAttemptCompletionStatus(true);
}
if(this.ProgressStatus===true){
if(this.FirstSuccessTimestampUtc===null&&_28b===true){
this.FirstSuccessTimestampUtc=ConvertDateToIso8601String(new Date());
}
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteSatisfiedStatus===true){
var _290=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_290===null){
this.Sequencer.AddGlobalObjective(maps[i].TargetObjectiveId,true,_28b,false,0);
}else{
_290.SatisfiedStatus=_28b;
_290.SetDirtyData();
}
}
}
}
this.SetDirtyData();
}
}
function ActivityObjective_GetSatisfiedByMeasure(){
var _291=this.SatisfiedByMeasure;
return _291;
}
function ActivityObjective_GetMinimumSatisfiedNormalizedMeasure(){
var _292=this.MinNormalizedMeasure;
_292=parseFloat(_292);
return _292;
}
function ActivityObjective_GetProgressStatus(_293,_294){
if(_294===null||_294===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into GetProgressStatus");
}
if(_293===null||_293===undefined){
Debug.AssertError("ERROR - activity must be passed into ActivityObjective_GetProgressStatus");
}
var _295;
if(_294===true&&_293.WasAttemptedDuringThisAttempt()===false){
_295=this.PrevProgressStatus;
}else{
_295=this.ProgressStatus;
}
var _296=(_295===false)||Control.Package.LearningStandard.is20043rdOrGreater();
if(_296===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadSatisfiedStatus===true){
var _299=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_299!==null){
_295=_299.ProgressStatus;
}
}
}
}
if(this.GetSatisfiedByMeasure()===true&&(_293.IsActive()===false||_293.GetMeasureSatisfactionIfActive()===true)){
if(this.GetMeasureStatus(_293,_294)===true){
_295=true;
}else{
_295=false;
}
}
return _295;
}
function ActivityObjective_GetSatisfiedStatus(_29a,_29b){
if(_29b===null||_29b===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into GetSatisfiedStatus");
}
var _29c;
var _29d;
if(_29b===true&&_29a.WasAttemptedDuringThisAttempt()===false){
_29d=this.PrevProgressStatus;
_29c=this.PrevSatisfiedStatus;
}else{
_29d=this.ProgressStatus;
_29c=this.SatisfiedStatus;
}
var _29e=(_29d===false)||Control.Package.LearningStandard.is20043rdOrGreater();
if(_29e===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadSatisfiedStatus===true){
var _2a1=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2a1!==null&&_2a1.ProgressStatus===true){
_29c=_2a1.SatisfiedStatus;
}
}
}
}
if(_29a===null||_29a===undefined){
Debug.AssertError("ERROR - activity must be passed into ActivityObjective_GetSatisfiedStatus");
}else{
if(this.GetSatisfiedByMeasure()===true&&(_29a.IsActive()===false||_29a.GetMeasureSatisfactionIfActive()===true)){
if(this.GetMeasureStatus(_29a,_29b)===true){
if(this.GetNormalizedMeasure(_29a,_29b)>=this.GetMinimumSatisfiedNormalizedMeasure()){
_29c=true;
}else{
_29c=false;
}
}
}
}
return _29c;
}
function ActivityObjective_GetScoreRaw(){
var _2a2=this.ScoreRaw;
var _2a3=Control.Package.LearningStandard.is20044thOrGreater();
if(_2a3===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadRawScore===true){
var _2a6=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2a6!==null&&_2a6.ScoreRaw!==null){
_2a2=_2a6.ScoreRaw;
}
}
}
}
return _2a2;
}
function ActivityObjective_SetScoreRaw(_2a7){
this.ScoreRaw=_2a7;
if(_2a7!==null){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteRawScore===true){
var _2aa=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2aa!==null){
_2aa.ScoreRaw=_2a7;
_2aa.SetDirtyData();
}
}
}
}
this.SetDirtyData();
}
function ActivityObjective_GetScoreMin(){
var _2ab=this.ScoreMin;
var _2ac=Control.Package.LearningStandard.is20044thOrGreater();
if(_2ac===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadMinScore===true){
var _2af=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2af!==null&&_2af.ScoreMin!==null){
_2ab=_2af.ScoreMin;
}
}
}
}
return _2ab;
}
function ActivityObjective_SetScoreMin(_2b0){
this.ScoreMin=_2b0;
if(_2b0!==null){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteMinScore===true){
var _2b3=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2b3!==null){
_2b3.ScoreMin=_2b0;
_2b3.SetDirtyData();
}
}
}
}
this.SetDirtyData();
}
function ActivityObjective_GetScoreMax(){
var _2b4=this.ScoreMax;
var _2b5=Control.Package.LearningStandard.is20044thOrGreater();
if(_2b5===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadMaxScore===true){
var _2b8=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2b8!==null&&_2b8.ScoreMax!==null){
_2b4=_2b8.ScoreMax;
}
}
}
}
return _2b4;
}
function ActivityObjective_SetScoreMax(_2b9){
this.ScoreMax=_2b9;
if(_2b9!==null){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteMaxScore===true){
var _2bc=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2bc!==null){
_2bc.ScoreMax=_2b9;
_2bc.SetDirtyData();
}
}
}
}
this.SetDirtyData();
}
function ActivityObjective_GetCompletionStatus(_2bd,_2be){
if(_2be===null||_2be===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into GetCompletionStatus");
}
if(_2bd===null||_2bd===undefined){
Debug.AssertError("ERROR - activity must be passed into ActivityObjective_GetCompletionStatusValue");
}
var _2bf=this.CompletionStatus;
var _2c0=Control.Package.LearningStandard.is20044thOrGreater();
if(_2c0===true){
var maps=this.Maps;
var _2c2;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadCompletionStatus===true){
_2c2=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2c2!==null){
_2bf=_2c2.CompletionStatus;
}
}
}
}
return _2bf;
}
function ActivityObjective_GetCompletionStatusValue(_2c4,_2c5){
if(_2c5===null||_2c5===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into GetCompletionStatusValue");
}
if(_2c4===null||_2c4===undefined){
Debug.AssertError("ERROR - activity must be passed into ActivityObjective_GetCompletionStatusValue");
}
var _2c6=this.CompletionStatusValue;
var _2c7=Control.Package.LearningStandard.is20044thOrGreater();
if(_2c7===true){
var maps=this.GetMaps("ReadCompletionStatus",true);
for(var i=0;i<maps.length;i++){
var _2ca=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2ca!==null){
_2c6=_2ca.CompletionStatusValue;
}
}
}
return _2c6;
}
function ActivityObjective_SetCompletionStatus(_2cb){
this.CompletionStatus=_2cb;
var maps=this.GetMaps("WriteCompletionStatus",true);
for(var i=0;i<maps.length;i++){
var _2ce=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2ce!==null){
_2ce.CompletionStatus=_2cb;
_2ce.SetDirtyData();
}
}
this.SetDirtyData();
}
function ActivityObjective_SetCompletionStatusValue(_2cf){
this.CompletionStatusValue=_2cf;
var maps=this.GetMaps("WriteCompletionStatus",true);
for(var i=0;i<maps.length;i++){
var _2d2=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2d2!==null){
_2d2.CompletionStatusValue=_2cf;
_2d2.SetDirtyData();
}
}
this.SetDirtyData();
}
function ActivityObjective_GetProgressMeasureStatus(){
var _2d3=this.ProgressMeasureStatus;
var _2d4=Control.Package.LearningStandard.is20044thOrGreater();
if(_2d4===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadProgressMeasure===true){
var _2d7=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2d7!==null){
_2d3=_2d7.ProgressMeasureStatus;
}
}
}
}
return _2d3;
}
function ActivityObjective_GetProgressMeasure(){
var _2d8=this.ProgressMeasure;
var _2d9=Control.Package.LearningStandard.is20044thOrGreater();
if(_2d9===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].ReadProgressMeasure===true){
var _2dc=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2dc!==null&&_2dc.ProgressMeasureStatus!==false){
_2d8=_2dc.ProgressMeasure;
}
}
}
}
return _2d8;
}
function ActivityObjective_SetProgressMeasureStatus(_2dd){
this.ProgressMeasureStatus=_2dd;
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteProgressMeasure===true){
var _2e0=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2e0!==null){
_2e0.ProgressMeasureStatus=_2dd;
_2e0.SetDirtyData();
}
}
}
this.SetDirtyData();
}
function ActivityObjective_SetProgressMeasure(_2e1){
this.ProgressMeasure=_2e1;
if(this.ProgressMeasureStatus===true){
var maps=this.Maps;
for(var i=0;i<maps.length;i++){
if(maps[i].WriteProgressMeasure===true){
var _2e4=this.Sequencer.GetGlobalObjectiveByIdentifier(maps[i].TargetObjectiveId);
if(_2e4!==null){
_2e4.ProgressMeasure=_2e1;
_2e4.SetDirtyData();
}
}
}
}
this.SetDirtyData();
}
function ActivityObjective_GetIdentifier(){
var _2e5=this.Identifier;
return _2e5;
}
function ActivityObjective_GetMaps(_2e6,_2e7){
var maps=this.Maps;
if(maps.length>0&&_2e6!==null&&_2e6!==undefined){
if(_2e7===null&&_2e7===undefined){
_2e7=true;
}
var _2e9=new Array();
for(var i=0;i<maps.length;i++){
if(maps[i][_2e6]===_2e7){
_2e9[_2e9.length]=maps[i];
}
}
return _2e9;
}
return maps;
}
function ActivityObjective_SetDirtyData(){
this.DataState=DATA_STATE_DIRTY;
}
function ActivityObjective_SetSequencer(_2eb){
this.Sequencer=_2eb;
}
function ActivityObjective_Clone(){
var _2ec=new ActivityObjective(this.Identifier,this.ProgressStatus,this.SatisfiedStatus,this.MeasureStatus,this.NormalizedMeasure,this.Primary,null,null,null,null,null,null,this.ScoreRaw,this.ScoreMin,this.ScoreMax,this.CompletionStatus,this.CompletionStatusValue,this.ProgressMeasureStatus,this.ProgressMeasure);
_2ec.SatisfiedByMeasure=this.SatisfiedByMeasure;
_2ec.MinNormalizedMeasure=this.MinNormalizedMeasure;
_2ec.CompletionStatusSetAtRuntime=this.CompletionStatusSetAtRuntime;
_2ec.Maps=this.Maps;
return _2ec;
}
function ActivityObjective_TearDown(){
this.Identifier=null;
this.ProgressStatus=null;
this.SatisfiedStatus=null;
this.MeasureStatus=null;
this.NormalizedMeasure=null;
this.ScoreRaw=null;
this.ScoreMin=null;
this.ScoreMax=null;
this.CompletionStatus=null;
this.CompletionStatusValue=null;
this.ProgressMeasure=null;
this.Primary=null;
this.SatisfiedByMeasure=null;
this.MinNormalizedMeasure=null;
this.Maps=null;
this.DataState=null;
this.Sequencer=null;
this.ProgressMeasureStatus=null;
this.ProgressMeasure=null;
}
function ActivityObjective_GetSuccessStatusChangedDuringRuntime(_2ed){
var _2ee=_2ed.RunTime.FindObjectiveWithId(this.Identifier);
if(_2ee!==null){
if(_2ee.SuccessStatusChangedDuringRuntime===true){
return true;
}
}
return false;
}
function ActivityRunTimeComment(_2ef,_2f0,_2f1,_2f2,_2f3){
this.Comment=_2ef;
this.Language=_2f0;
this.Location=_2f1;
this.TimestampUtc=_2f2;
this.Timestamp=_2f3;
}
ActivityRunTimeComment.prototype.GetXml=ActivityRunTimeComment_GetXml;
ActivityRunTimeComment.prototype.toString=ActivityRunTimeComment_toString;
ActivityRunTimeComment.prototype.GetCommentValue=ActivityRunTimeComment_GetCommentValue;
ActivityRunTimeComment.prototype.SetCommentValue=ActivityRunTimeComment_SetCommentValue;
function ActivityRunTimeComment_GetXml(_2f4,_2f5,_2f6){
var _2f7=new ServerFormater();
var xml=new XmlElement("ARTC");
xml.AddAttribute("AI",_2f4);
xml.AddAttribute("I",_2f5);
xml.AddAttribute("FL",_2f7.ConvertBoolean(_2f6));
if(this.Comment!==null){
xml.AddAttribute("C",_2f7.TrimToLength(this.Comment,4000));
}
if(this.Language!==null){
xml.AddAttribute("L",this.Language);
}
if(this.Location!==null){
xml.AddAttribute("Lo",_2f7.TrimToLength(this.Location,250));
}
if(this.Timestamp!==null&&this.Timestamp!=""){
xml.AddAttribute("TU",_2f7.ConvertTime(this.Timestamp));
xml.AddAttribute("T",this.Timestamp);
}
return xml.toString();
}
function ActivityRunTimeComment_toString(){
return "ActivityRunTimeComment";
}
function ActivityRunTimeComment_GetCommentValue(){
var _2f9="";
if(this.Language!==null&&this.Language!==undefined){
_2f9=this.Language;
}
_2f9+=this.Comment;
return _2f9;
}
function ActivityRunTimeComment_SetCommentValue(_2fa){
var _2fb="";
var _2fc="";
var _2fd=_2fa.indexOf("}");
if(_2fa.indexOf("{lang=")===0&&_2fd>0){
_2fb=_2fa.substr(0,_2fd+1);
if(_2fa.length>=(_2fd+2)){
_2fc=_2fa.substring(_2fd+1);
}
}else{
_2fc=_2fa;
}
this.Language=_2fb;
this.Comment=_2fc;
}
function ActivityRunTimeInteraction(Id,Type,_300,_301,_302,_303,_304,_305,_306,_307,_308){
this.Id=Id;
if(Type===""){
Type="";
}
this.Type=Type;
this.TimestampUtc=_300;
this.Timestamp=_301;
this.Weighting=_302;
if(_303===""){
_303=null;
}
this.Result=_303;
if(_304===""){
_304=null;
}
this.Latency=_304;
this.Description=_305;
this.LearnerResponse=_306;
this.CorrectResponses=_307;
this.Objectives=_308;
}
ActivityRunTimeInteraction.prototype.GetXml=ActivityRunTimeInteraction_GetXml;
ActivityRunTimeInteraction.prototype.toString=ActivityRunTimeInteraction_toString;
function ActivityRunTimeInteraction_GetXml(_309,_30a){
var _30b=new ServerFormater();
var xml=new XmlElement("ARTI");
xml.AddAttribute("AI",_309);
xml.AddAttribute("I",_30a);
xml.AddAttribute("Id",_30b.TrimToLength(this.Id,4000));
if(this.Type!==null){
xml.AddAttribute("T",_30b.ConvertInteractionType(this.Type));
}
if(this.Timestamp!==null){
xml.AddAttribute("TU",_30b.ConvertTime(this.Timestamp));
xml.AddAttribute("Ti",this.Timestamp);
}
if(this.Weighting!==null){
xml.AddAttribute("W",this.Weighting);
}
if(this.Result!==null&&this.Result!==""){
if(IsValidCMIDecimal(this.Result)){
xml.AddAttribute("R",_30b.GetNumericInteractionResultId());
xml.AddAttribute("RN",this.Result);
}else{
xml.AddAttribute("R",_30b.ConvertInteractionResult(this.Result));
}
}
if(this.Latency!==null){
xml.AddAttribute("L",_30b.ConvertTimeSpan(this.Latency));
}
if(this.Description!==null){
xml.AddAttribute("D",_30b.TrimToLength(this.Description,500));
}
if(this.LearnerResponse!==null){
xml.AddAttribute("LR",_30b.TrimToLength(this.LearnerResponse,7800));
}
var _30d;
var i;
for(i=0;i<this.CorrectResponses.length;i++){
_30d=new XmlElement("CR");
_30d.AddAttribute("AI",_309);
_30d.AddAttribute("II",_30a);
_30d.AddAttribute("I",i);
_30d.AddAttribute("V",_30b.TrimToLength(this.CorrectResponses[i],7800));
xml.AddElement(_30d.toString());
}
var _30f;
for(i=0;i<this.Objectives.length;i++){
_30f=new XmlElement("O");
_30f.AddAttribute("AI",_309);
_30f.AddAttribute("II",_30a);
_30f.AddAttribute("I",i);
_30f.AddAttribute("Id",_30b.TrimToLength(this.Objectives[i],4000));
xml.AddElement(_30f.toString());
}
return xml.toString();
}
function ActivityRunTimeInteraction_toString(){
return "ActivityRunTimeInteraction";
}
function ActivityRunTimeObjective(_310,_311,_312,_313,_314,_315,_316,_317,_318){
this.Identifier=_310;
this.SuccessStatus=_311;
this.CompletionStatus=_312;
this.ScoreScaled=_313;
this.ScoreRaw=_314;
this.ScoreMax=_315;
this.ScoreMin=_316;
this.ProgressMeasure=_317;
this.Description=_318;
this.SuccessStatusChangedDuringRuntime=false;
this.MeasureChangedDuringRuntime=false;
this.ProgressMeasureChangedDuringRuntime=false;
this.CompletionStatusChangedDuringRuntime=false;
}
ActivityRunTimeObjective.prototype.GetXml=ActivityRunTimeObjective_GetXml;
ActivityRunTimeObjective.prototype.toString=ActivityRunTimeObjective_toString;
function ActivityRunTimeObjective_GetXml(_319,_31a){
var _31b=new ServerFormater();
var xml=new XmlElement("ARTO");
xml.AddAttribute("AI",_319);
xml.AddAttribute("I",_31a);
if(this.Identifier!==null){
xml.AddAttribute("Id",_31b.TrimToLength(this.Identifier,4000));
}
xml.AddAttribute("SS",_31b.ConvertSuccessStatus(this.SuccessStatus));
xml.AddAttribute("CS",_31b.ConvertCompletionStatus(this.CompletionStatus));
if(this.ScoreScaled!==null){
xml.AddAttribute("SSc",this.ScoreScaled);
}
if(this.ScoreRaw!==null){
xml.AddAttribute("SR",this.ScoreRaw);
}
if(this.ScoreMax!==null){
xml.AddAttribute("SM",this.ScoreMax);
}
if(this.ScoreMin!==null){
xml.AddAttribute("SMi",this.ScoreMin);
}
if(this.ProgressMeasure!==null){
xml.AddAttribute("PM",this.ProgressMeasure);
}
if(this.Description!==null){
xml.AddAttribute("D",_31b.TrimToLength(this.Description,500));
}
return xml.toString();
}
function ActivityRunTimeObjective_toString(){
return "ActivityRunTimeObjective - "+this.Identifier;
}
function ActivityRunTimeSSPBucket(Id,_31e,_31f,_320,_321,_322,_323,Data){
this.Id=Id;
this.BucketType=_31e;
this.Persistence=_31f;
this.SizeMin=_320;
this.SizeRequested=_321;
this.Reducible=_322;
this.TotalSpace=_323;
this.Data=Data;
}
ActivityRunTimeSSPBucket.prototype.toString=function(){
return "Id="+this.Id+", BucketType="+this.BucketType+", Persistence="+this.Persistence+", SizeMin="+this.SizeMin+", SizeRequested="+this.SizeRequested+", Reducible="+this.Reducible+", TotalSpace="+this.TotalSpace+", Data="+this.Data;
};
var SCORM_MODE_NORMAL="normal";
var SCORM_MODE_REVIEW="review";
var SCORM_MODE_BROWSE="browse";
var SCORM_STATUS_PASSED="passed";
var SCORM_STATUS_COMPLETED="completed";
var SCORM_STATUS_FAILED="failed";
var SCORM_STATUS_INCOMPLETE="incomplete";
var SCORM_STATUS_BROWSED="browsed";
var SCORM_STATUS_NOT_ATTEMPTED="not attempted";
var SCORM_STATUS_UNKNOWN="unknown";
var SCORM_EXIT_TIME_OUT="time-out";
var SCORM_EXIT_SUSPEND="suspend";
var SCORM_EXIT_LOGOUT="logout";
var SCORM_EXIT_NORMAL="normal";
var SCORM_EXIT_UNKNOWN="";
var SCORM_CREDIT="credit";
var SCORM_CREDIT_NO="no-credit";
var SCORM_ENTRY_AB_INITO="ab-initio";
var SCORM_ENTRY_RESUME="resume";
var SCORM_ENTRY_NORMAL="";
var SCORM_TRUE_FALSE="true-false";
var SCORM_CHOICE="choice";
var SCORM_FILL_IN="fill-in";
var SCORM_MATCHING="matching";
var SCORM_PERFORMANCE="performance";
var SCORM_SEQUENCING="sequencing";
var SCORM_LIKERT="likert";
var SCORM_NUMERIC="numeric";
var SCORM_LONG_FILL_IN="long-fill-in";
var SCORM_OTHER="other";
var SCORM_CORRECT="correct";
var SCORM_WRONG="wrong";
var SCORM_INCORRECT="incorrect";
var SCORM_UNANTICIPATED="unanticipated";
var SCORM_NEUTRAL="neutral";
var SCORM_RUNTIME_NAV_REQUEST_CONTINUE="continue";
var SCORM_RUNTIME_NAV_REQUEST_PREVIOUS="previous";
var SCORM_RUNTIME_NAV_REQUEST_CHOICE="choice";
var SCORM_RUNTIME_NAV_REQUEST_JUMP="jump";
var SCORM_RUNTIME_NAV_REQUEST_EXIT="exit";
var SCORM_RUNTIME_NAV_REQUEST_EXITALL="exitAll";
var SCORM_RUNTIME_NAV_REQUEST_ABANDON="abandon";
var SCORM_RUNTIME_NAV_REQUEST_ABANDONALL="abandonAll";
var SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL="suspendAll";
var SCORM_RUNTIME_NAV_REQUEST_NONE="_none_";
function ActivityRunTime(_325,_326,_327,Exit,_329,Mode,_32b,_32c,_32d,_32e,_32f,_330,_331,_332,_333,_334,_335,_336,_337,_338,_339,_33a,_33b){
this.CompletionStatus=_325;
this.Credit=_326;
this.Entry=_327;
this.Exit=Exit;
this.Location=_329;
this.Mode=Mode;
this.ProgressMeasure=_32b;
this.ScoreRaw=_32c;
this.ScoreMax=_32d;
this.ScoreMin=_32e;
this.ScoreScaled=_32f;
this.SuccessStatus=_330;
this.SuspendData=_331;
this.TotalTime=_332;
this.TotalTimeTracked=_333;
this.AudioLevel=_334;
this.LanguagePreference=_335;
this.DeliverySpeed=_336;
this.AudioCaptioning=_337;
this.Comments=_338;
this.CommentsFromLMS=_339;
this.Interactions=_33a;
this.Objectives=_33b;
this.LookAheadCompletionStatus=_325;
this.LookAheadSuccessStatus=_330;
this.CompletionStatusChangedDuringRuntime=false;
this.SuccessStatusChangedDuringRuntime=false;
this.SessionTime="";
this.SessionTimeTracked="";
this.NavRequest=SCORM_RUNTIME_NAV_REQUEST_NONE;
this.DataState=DATA_STATE_CLEAN;
}
ActivityRunTime.prototype.ResetState=ActivityRunTime_ResetState;
ActivityRunTime.prototype.GetXml=ActivityRunTime_GetXml;
ActivityRunTime.prototype.toString=ActivityRunTime_toString;
ActivityRunTime.prototype.SetDirtyData=ActivityRunTime_SetDirtyData;
ActivityRunTime.prototype.IsValidObjectiveIndex=ActivityRunTime_IsValidObjectiveIndex;
ActivityRunTime.prototype.IsValidInteractionIndex=ActivityRunTime_IsValidInteractionIndex;
ActivityRunTime.prototype.IsValidInteractionObjectiveIndex=ActivityRunTime_IsValidInteractionObjectiveIndex;
ActivityRunTime.prototype.IsValidInteractionCorrectResponseIndex=ActivityRunTime_IsValidInteractionCorrectResponseIndex;
ActivityRunTime.prototype.AddObjective=ActivityRunTime_AddObjective;
ActivityRunTime.prototype.AddInteraction=ActivityRunTime_AddInteraction;
ActivityRunTime.prototype.AddComment=ActivityRunTime_AddComment;
ActivityRunTime.prototype.FindObjectiveWithId=ActivityRunTime_FindObjectiveWithId;
function ActivityRunTime_ResetState(){
this.CompletionStatus=SCORM_STATUS_UNKNOWN;
this.Entry=SCORM_ENTRY_AB_INITO;
this.Exit=SCORM_EXIT_UNKNOWN;
this.Location=null;
if(RegistrationToDeliver.LessonMode!==SCORM_MODE_REVIEW&&RegistrationToDeliver.LessonMode!==SCORM_MODE_BROWSE){
this.Mode=SCORM_MODE_NORMAL;
}
this.ProgressMeasure=null;
this.ScoreRaw=null;
this.ScoreMax=null;
this.ScoreMin=null;
this.ScoreScaled=null;
this.SuccessStatus=SCORM_STATUS_UNKNOWN;
this.SuspendData=null;
this.TotalTime="PT0H0M0S";
this.TotalTimeTracked="PT0H0M0S";
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse!==true){
this.AudioLevel=1;
this.LanguagePreference="";
this.DeliverySpeed=1;
this.AudioCaptioning=0;
}
this.Comments=new Array();
this.CommentsFromLMS=new Array();
this.Interactions=new Array();
this.Objectives=new Array();
this.LookAheadCompletionStatus=this.CompletionStatus;
this.LookAheadSuccessStatus=this.SuccessStatus;
this.SessionTime="";
this.NavRequest=SCORM_RUNTIME_NAV_REQUEST_NONE;
this.CompletionStatusChangedDuringRuntime=false;
this.SuccessStatusChangedDuringRuntime=false;
this.SetDirtyData();
}
function ActivityRunTime_GetXml(_33c){
var _33d=new ServerFormater();
var xml=new XmlElement("ART");
xml.AddAttribute("AI",_33c);
xml.AddAttribute("CS",_33d.ConvertCompletionStatus(this.CompletionStatus));
xml.AddAttribute("C",_33d.ConvertCredit(this.Credit));
xml.AddAttribute("E",_33d.ConvertEntry(this.Entry));
xml.AddAttribute("Ex",_33d.ConvertExit(this.Exit));
if(this.Location!==null){
xml.AddAttribute("L",_33d.TrimToLength(this.Location,1000));
}
xml.AddAttribute("M",_33d.ConvertMode(this.Mode));
if(this.ProgressMeasure!==null){
xml.AddAttribute("PM",this.ProgressMeasure);
}
if(this.ScoreRaw!==null){
xml.AddAttribute("SR",this.ScoreRaw);
}
if(this.ScoreMax!==null){
xml.AddAttribute("SM",this.ScoreMax);
}
if(this.ScoreMin!==null){
xml.AddAttribute("SMi",this.ScoreMin);
}
if(this.ScoreScaled!==null){
xml.AddAttribute("SS",this.ScoreScaled);
}
xml.AddAttribute("SuS",_33d.ConvertSuccessStatus(this.SuccessStatus));
if(this.SuspendData!==null){
xml.AddAttribute("SD",_33d.TrimToLength(this.SuspendData,Control.Package.Properties.SuspendDataMaxLength));
}
xml.AddAttribute("TT",_33d.ConvertTimeSpan(this.TotalTime));
xml.AddAttribute("TTT",_33d.ConvertTimeSpan(this.TotalTimeTracked));
xml.AddAttribute("AL",this.AudioLevel);
xml.AddAttribute("LP",_33d.TrimToLength(this.LanguagePreference,250));
xml.AddAttribute("DS",this.DeliverySpeed);
xml.AddAttribute("AC",this.AudioCaptioning);
var i;
for(i=0;i<this.Comments.length;i++){
xml.AddElement(this.Comments[i].GetXml(_33c,i,false));
}
for(i=0;i<this.CommentsFromLMS.length;i++){
xml.AddElement(this.CommentsFromLMS[i].GetXml(_33c,i,true));
}
for(i=0;i<this.Interactions.length;i++){
xml.AddElement(this.Interactions[i].GetXml(_33c,i));
}
for(i=0;i<this.Objectives.length;i++){
xml.AddElement(this.Objectives[i].GetXml(_33c,i));
}
return xml.toString();
}
function ActivityRunTime_toString(){
return "RunTimeData - CompletionStatus="+this.CompletionStatus+", SuccessStatus="+this.SuccessStatus;
}
function ActivityRunTime_SetDirtyData(){
this.DataState=DATA_STATE_DIRTY;
}
function ActivityRunTime_IsValidObjectiveIndex(_340){
_340=parseInt(_340,10);
if(_340<=this.Objectives.length){
return true;
}else{
return false;
}
}
function ActivityRunTime_IsValidInteractionIndex(_341){
_341=parseInt(_341,10);
if(_341<=this.Interactions.length){
return true;
}else{
return false;
}
}
function ActivityRunTime_IsValidInteractionObjectiveIndex(_342,_343){
_342=parseInt(_342,10);
_343=parseInt(_343,10);
if(this.Interactions[_342]){
if(_343<=this.Interactions[_342].Objectives.length){
return true;
}else{
return false;
}
}else{
if(_343===0){
return true;
}else{
return false;
}
}
}
function ActivityRunTime_IsValidInteractionCorrectResponseIndex(_344,_345){
_344=parseInt(_344,10);
_345=parseInt(_345,10);
if(this.Interactions[_344]){
if(_345<=this.Interactions[_344].CorrectResponses.length){
return true;
}else{
return false;
}
}else{
if(_345===0){
return true;
}else{
return false;
}
}
}
function ActivityRunTime_AddObjective(){
this.Objectives[this.Objectives.length]=new ActivityRunTimeObjective(null,SCORM_STATUS_UNKNOWN,SCORM_STATUS_UNKNOWN,null,null,null,null,null,null);
}
function ActivityRunTime_AddInteraction(){
this.Interactions[this.Interactions.length]=new ActivityRunTimeInteraction(null,null,null,null,null,null,null,null,null,new Array(),new Array());
}
function ActivityRunTime_AddComment(){
this.Comments[this.Comments.length]=new ActivityRunTimeComment(null,null,null,null,null);
}
function ActivityRunTime_FindObjectiveWithId(id){
for(var i=0;i<this.Objectives.length;i++){
if(this.Objectives[i].Identifier==id){
return this.Objectives[i];
}
}
return null;
}
function Activity(_348,_349,_34a,_34b,_34c,_34d,_34e,_34f,_350,_351,_352,_353,_354,_355,_356,_357,_358,_359,_35a,_35b,_35c,_35d,_35e,_35f,_360,_361,_362,_363,_364,_365){
this.StringIdentifier=null;
this.DatabaseId=_348;
this.ItemIdentifier=_349;
this.ScormObjectDatabaseId=_34a;
this.ActivityProgressStatus=_34b;
this.ActivityAttemptCount=_34c;
this.AttemptProgressStatus=_34d;
this.AttemptCompletionAmountStatus=_34e;
this.AttemptCompletionAmount=_34f;
this.AttemptCompletionStatus=_350;
this.Active=_351;
this.Suspended=_352;
this.Included=_353;
this.Ordinal=_354;
this.SelectedChildren=_355;
this.RandomizedChildren=_356;
this.ActivityObjectives=_357;
this.RunTime=_358;
this.PrevAttemptProgressStatus=_359;
this.PrevAttemptCompletionStatus=_35a;
this.AttemptedDuringThisAttempt=_35b;
this.FirstCompletionTimestampUtc=_35c;
this.ActivityStartTimestampUtc=_35d;
this.AttemptStartTimestampUtc=_35e;
this.ActivityAbsoluteDuration=_35f;
this.AttemptAbsoluteDuration=_360;
this.ActivityExperiencedDurationTracked=_361;
this.AttemptExperiencedDurationTracked=_362;
this.ActivityExperiencedDurationReported=_363;
this.AttemptExperiencedDurationReported=_364;
this.AiccSessionId=_365;
this.IsDurations=ConvertIso8601TimeSpanToHundredths(_35f)>=0;
this.ActivityEndedDate=null;
this.Sequencer=null;
this.LookAheadActivity=false;
this.LearningObject=null;
this.ParentActivity=null;
this.ChildActivities=new Array();
this.AvailableChildren=null;
this.DataState=DATA_STATE_CLEAN;
this.MenuItem=null;
this.CachedPrimaryObjective=null;
this.HiddenFromChoice=false;
this.HasSeqRulesRelevantToChoice=null;
this.HasChildActivitiesDeliverableViaFlow=false;
this.LaunchedThisSession=false;
}
Activity.prototype.GetXml=Activity_GetXml;
Activity.prototype.toString=Activity_toString;
Activity.prototype.GetTitle=Activity_GetTitle;
Activity.prototype.GetItemIdentifier=Activity_GetItemIdentifier;
Activity.prototype.GetDatabaseIdentifier=Activity_GetDatabaseIdentifier;
Activity.prototype.GetLaunchPath=Activity_GetLaunchPath;
Activity.prototype.IsDeliverable=Activity_IsDeliverable;
Activity.prototype.TransferRteDataToActivity=Activity_TransferRteDataToActivity;
Activity.prototype.IsTheRoot=Activity_IsTheRoot;
Activity.prototype.IsALeaf=Activity_IsALeaf;
Activity.prototype.IsActive=Activity_IsActive;
Activity.prototype.IsSuspended=Activity_IsSuspended;
Activity.prototype.HasSuspendedChildren=Activity_HasSuspendedChildren;
Activity.prototype.SetActive=Activity_SetActive;
Activity.prototype.SetSuspended=Activity_SetSuspended;
Activity.prototype.IsTracked=Activity_IsTracked;
Activity.prototype.IsCompletionSetByContent=Activity_IsCompletionSetByContent;
Activity.prototype.IsObjectiveSetByContent=Activity_IsObjectiveSetByContent;
Activity.prototype.GetAttemptProgressStatus=Activity_GetAttemptProgressStatus;
Activity.prototype.SetAttemptProgressStatus=Activity_SetAttemptProgressStatus;
Activity.prototype.SetAttemptCompletionStatus=Activity_SetAttemptCompletionStatus;
Activity.prototype.GetAttemptCompletionStatus=Activity_GetAttemptCompletionStatus;
Activity.prototype.GetChildren=Activity_GetChildren;
Activity.prototype.GetSequencingControlFlow=Activity_GetSequencingControlFlow;
Activity.prototype.GetSequencingControlChoice=Activity_GetSequencingControlChoice;
Activity.prototype.GetSequencingControlChoiceExit=Activity_GetSequencingControlChoiceExit;
Activity.prototype.GetSequencingControlForwardOnly=Activity_GetSequencingControlForwardOnly;
Activity.prototype.GetPreventActivation=Activity_GetPreventActivation;
Activity.prototype.GetConstrainedChoice=Activity_GetConstrainedChoice;
Activity.prototype.GetSelectionTiming=Activity_GetSelectionTiming;
Activity.prototype.GetSelectionCountStatus=Activity_GetSelectionCountStatus;
Activity.prototype.GetSelectionCount=Activity_GetSelectionCount;
Activity.prototype.GetRandomizationTiming=Activity_GetRandomizationTiming;
Activity.prototype.GetRandomizeChildren=Activity_GetRandomizeChildren;
Activity.prototype.GetLimitConditionAttemptControl=Activity_GetLimitConditionAttemptControl;
Activity.prototype.GetActivityProgressStatus=Activity_GetActivityProgressStatus;
Activity.prototype.SetActivityProgressStatus=Activity_SetActivityProgressStatus;
Activity.prototype.GetAttemptCount=Activity_GetAttemptCount;
Activity.prototype.GetLimitConditionAttemptLimit=Activity_GetLimitConditionAttemptLimit;
Activity.prototype.GetPreConditionRules=Activity_GetPreConditionRules;
Activity.prototype.GetPostConditionRules=Activity_GetPostConditionRules;
Activity.prototype.GetExitRules=Activity_GetExitRules;
Activity.prototype.IsSatisfied=Activity_IsSatisfied;
Activity.prototype.IsObjectiveStatusKnown=Activity_IsObjectiveStatusKnown;
Activity.prototype.IsObjectiveMeasureKnown=Activity_IsObjectiveMeasureKnown;
Activity.prototype.IsObjectiveMeasureGreaterThan=Activity_IsObjectiveMeasureGreaterThan;
Activity.prototype.IsObjectiveMeasureLessThan=Activity_IsObjectiveMeasureLessThan;
Activity.prototype.GetObjectiveMeasure=Activity_GetObjectiveMeasure;
Activity.prototype.IsCompleted=Activity_IsCompleted;
Activity.prototype.IsActivityProgressKnown=Activity_IsActivityProgressKnown;
Activity.prototype.IsAttempted=Activity_IsAttempted;
Activity.prototype.IsAttemptLimitExceeded=Activity_IsAttemptLimitExceeded;
Activity.prototype.GetObjectives=Activity_GetObjectives;
Activity.prototype.FindObjective=Activity_FindObjective;
Activity.prototype.GetPrimaryObjective=Activity_GetPrimaryObjective;
Activity.prototype.GetRollupObjectiveMeasureWeight=Activity_GetRollupObjectiveMeasureWeight;
Activity.prototype.GetMeasureSatisfactionIfActive=Activity_GetMeasureSatisfactionIfActive;
Activity.prototype.GetRollupRules=Activity_GetRollupRules;
Activity.prototype.ApplyRollupRule=Activity_ApplyRollupRule;
Activity.prototype.GetRollupObjectiveSatisfied=Activity_GetRollupObjectiveSatisfied;
Activity.prototype.GetRequiredForSatisfied=Activity_GetRequiredForSatisfied;
Activity.prototype.GetRequiredForNotSatisfied=Activity_GetRequiredForNotSatisfied;
Activity.prototype.RollupProgressCompletion=Activity_RollupProgressCompletion;
Activity.prototype.GetRequiredForCompleted=Activity_GetRequiredForCompleted;
Activity.prototype.GetRequiredForIncomplete=Activity_GetRequiredForIncomplete;
Activity.prototype.IncrementAttemptCount=Activity_IncrementAttemptCount;
Activity.prototype.SetRandomizedChildren=Activity_SetRandomizedChildren;
Activity.prototype.SetSelectedChildren=Activity_SetSelectedChildren;
Activity.prototype.GetRandomizedChildren=Activity_GetRandomizedChildren;
Activity.prototype.GetSelectedChildren=Activity_GetSelectedChildren;
Activity.prototype.GetActivityListBetweenChildren=Activity_GetActivityListBetweenChildren;
Activity.prototype.IsActivityAnAvailableChild=Activity_IsActivityAnAvailableChild;
Activity.prototype.IsActivityAnAvailableDescendent=Activity_IsActivityAnAvailableDescendent;
Activity.prototype.IsActivityTheLastAvailableChild=Activity_IsActivityTheLastAvailableChild;
Activity.prototype.IsActivityTheFirstAvailableChild=Activity_IsActivityTheFirstAvailableChild;
Activity.prototype.GetFirstAvailableChild=Activity_GetFirstAvailableChild;
Activity.prototype.GetNextActivityPreorder=Activity_GetNextActivityPreorder;
Activity.prototype.GetPreviousActivityPreorder=Activity_GetPreviousActivityPreorder;
Activity.prototype.GetNextSibling=Activity_GetNextSibling;
Activity.prototype.GetPreviousSibling=Activity_GetPreviousSibling;
Activity.prototype.InitializeAvailableChildren=Activity_InitializeAvailableChildren;
Activity.prototype.GetAvailableChildren=Activity_GetAvailableChildren;
Activity.prototype.SetAvailableChildren=Activity_SetAvailableChildren;
Activity.prototype.IsAvailable=Activity_IsAvailable;
Activity.prototype.InitializeForNewAttempt=Activity_InitializeForNewAttempt;
Activity.prototype.ResetAttemptState=Activity_ResetAttemptState;
Activity.prototype.RollupDurations=Activity_RollupDurations;
Activity.prototype.SetDirtyData=Activity_SetDirtyData;
Activity.prototype.IsAnythingDirty=Activity_IsAnythingDirty;
Activity.prototype.MarkPostedObjectiveDataDirty=Activity_MarkPostedObjectiveDataDirty;
Activity.prototype.MarkPostedObjectiveDataClean=Activity_MarkPostedObjectiveDataClean;
Activity.prototype.MarkDirtyObjectiveDataPosted=Activity_MarkDirtyObjectiveDataPosted;
Activity.prototype.SetSequencer=Activity_SetSequencer;
Activity.prototype.Clone=Activity_Clone;
Activity.prototype.TearDown=Activity_TearDown;
Activity.prototype.DisplayInChoice=Activity_DisplayInChoice;
Activity.prototype.SetHiddenFromChoice=Activity_SetHiddenFromChoice;
Activity.prototype.SetLaunchedThisSession=Activity_SetLaunchedThisSession;
Activity.prototype.WasLaunchedThisSession=Activity_WasLaunchedThisSession;
Activity.prototype.SetAttemptedDuringThisAttempt=Activity_SetAttemptedDuringThisAttempt;
Activity.prototype.WasAttemptedDuringThisAttempt=Activity_WasAttemptedDuringThisAttempt;
Activity.prototype.GetMinProgressMeasure=Activity_GetMinProgressMeasure;
Activity.prototype.GetCompletionProgressWeight=Activity_GetCompletionProgressWeight;
Activity.prototype.GetCompletedByMeasure=Activity_GetCompletedByMeasure;
Activity.prototype.GetAttemptCompletionAmount=Activity_GetAttemptCompletionAmount;
Activity.prototype.SetAttemptCompletionAmount=Activity_SetAttemptCompletionAmount;
Activity.prototype.GetAttemptCompletionAmountStatus=Activity_GetAttemptCompletionAmountStatus;
Activity.prototype.SetAttemptCompletionAmountStatus=Activity_SetAttemptCompletionAmountStatus;
Activity.prototype.GetCompletionStatusChangedDuringRuntime=Activity_GetCompletionStatusChangedDuringRuntime;
Activity.prototype.GetSuccessStatusChangedDuringRuntime=Activity_GetSuccessStatusChangedDuringRuntime;
Activity.prototype.GetActivityStartTimestampUtc=Activity_GetActivityStartTimestampUtc;
Activity.prototype.SetActivityStartTimestampUtc=Activity_SetActivityStartTimestampUtc;
Activity.prototype.GetAttemptStartTimestampUtc=Activity_GetAttemptStartTimestampUtc;
Activity.prototype.SetAttemptStartTimestampUtc=Activity_SetAttemptStartTimestampUtc;
Activity.prototype.GetActivityAbsoluteDuration=Activity_GetActivityAbsoluteDuration;
Activity.prototype.SetActivityAbsoluteDuration=Activity_SetActivityAbsoluteDuration;
Activity.prototype.GetAttemptAbsoluteDuration=Activity_GetAttemptAbsoluteDuration;
Activity.prototype.SetAttemptAbsoluteDuration=Activity_SetAttemptAbsoluteDuration;
Activity.prototype.GetActivityExperiencedDurationTracked=Activity_GetActivityExperiencedDurationTracked;
Activity.prototype.SetActivityExperiencedDurationTracked=Activity_SetActivityExperiencedDurationTracked;
Activity.prototype.GetAttemptExperiencedDurationTracked=Activity_GetAttemptExperiencedDurationTracked;
Activity.prototype.SetAttemptExperiencedDurationTracked=Activity_SetAttemptExperiencedDurationTracked;
Activity.prototype.GetActivityExperiencedDurationReported=Activity_GetActivityExperiencedDurationReported;
Activity.prototype.SetActivityExperiencedDurationReported=Activity_SetActivityExperiencedDurationReported;
Activity.prototype.GetAttemptExperiencedDurationReported=Activity_GetAttemptExperiencedDurationReported;
Activity.prototype.SetAttemptExperiencedDurationReported=Activity_SetAttemptExperiencedDurationReported;
Activity.prototype.UsesDefaultSatisfactionRollupRules=Activity_UsesDefaultSatisfactionRollupRules;
Activity.prototype.UsesDefaultCompletionRollupRules=Activity_UsesDefaultCompletionRollupRules;
function Activity_GetXml(){
var _366=new ServerFormater();
var xml=new XmlElement("A");
xml.AddAttribute("DI",this.DatabaseId);
xml.AddAttribute("II",this.ItemIdentifier);
xml.AddAttribute("APS",_366.ConvertBoolean(this.ActivityProgressStatus));
xml.AddAttribute("AAC",this.ActivityAttemptCount);
xml.AddAttribute("AtPS",_366.ConvertBoolean(this.AttemptProgressStatus));
xml.AddAttribute("ACS",_366.ConvertBoolean(this.AttemptCompletionStatus));
xml.AddAttribute("ACAS",_366.ConvertBoolean(this.AttemptCompletionAmountStatus));
xml.AddAttribute("ACA",this.AttemptCompletionAmount);
xml.AddAttribute("A",_366.ConvertBoolean(this.Active));
xml.AddAttribute("S",_366.ConvertBoolean(this.Suspended));
xml.AddAttribute("I",_366.ConvertBoolean(this.Included));
xml.AddAttribute("O",this.Ordinal);
xml.AddAttribute("SC",_366.ConvertBoolean(this.SelectedChildren));
xml.AddAttribute("RC",_366.ConvertBoolean(this.RandomizedChildren));
xml.AddAttribute("PAPS",_366.ConvertBoolean(this.PrevAttemptProgressStatus));
xml.AddAttribute("PACS",_366.ConvertBoolean(this.PrevAttemptCompletionStatus));
xml.AddAttribute("ADTA",_366.ConvertBoolean(this.AttemptedDuringThisAttempt));
if(this.FirstCompletionTimestampUtc!==null){
xml.AddAttribute("FCTU",this.FirstCompletionTimestampUtc);
}
if(this.IsDurations){
if(this.ActivityStartTimestampUtc!==null){
xml.AddAttribute("ASTU",this.ActivityStartTimestampUtc);
}
if(this.AttemptStartTimestampUtc!==null){
xml.AddAttribute("AtSTU",this.AttemptStartTimestampUtc);
}
xml.AddAttribute("AAD",_366.ConvertTimeSpan(this.ActivityAbsoluteDuration));
xml.AddAttribute("AtAD",_366.ConvertTimeSpan(this.AttemptAbsoluteDuration));
xml.AddAttribute("AEDT",_366.ConvertTimeSpan(this.ActivityExperiencedDurationTracked));
xml.AddAttribute("AtEDT",_366.ConvertTimeSpan(this.AttemptExperiencedDurationTracked));
xml.AddAttribute("AEDR",_366.ConvertTimeSpan(this.ActivityExperiencedDurationReported));
xml.AddAttribute("AtEDR",_366.ConvertTimeSpan(this.AttemptExperiencedDurationReported));
}
for(var i=0;i<this.ActivityObjectives.length;i++){
xml.AddElement(this.ActivityObjectives[i].GetXml(this.DatabaseId,i));
}
if(this.RunTime!==null){
xml.AddElement(this.RunTime.GetXml(this.DatabaseId));
}
return xml.toString();
}
function Activity_toString(){
var str=this.GetTitle()+" ("+this.GetItemIdentifier()+")";
return str;
}
function Activity_GetTitle(){
return this.LearningObject.Title;
}
function Activity_GetItemIdentifier(){
if(this.LearningObject.ItemIdentifier!==null&&this.LearningObject.ItemIdentifier!==""){
return this.LearningObject.ItemIdentifier;
}else{
return this.DatabaseId;
}
}
function Activity_GetDatabaseIdentifier(){
return this.DatabaseId;
}
function Activity_GetLaunchPath(){
return MergeQueryStringParameters(this.LearningObject.Href,this.LearningObject.Parameters);
}
function Activity_IsDeliverable(){
return (this.RunTime!==null);
}
function Activity_TransferRteDataToActivity(){
var _36a=this.GetObjectives();
var _36b;
var _36c=this.GetPrimaryObjective();
var _36d=false;
var id;
if(this.IsTracked()){
for(var i=0;i<_36a.length;i++){
id=_36a[i].GetIdentifier();
_36b=this.RunTime.FindObjectiveWithId(id);
if(_36b!==null){
if(_36b.SuccessStatusChangedDuringRuntime===true){
if(_36b.SuccessStatus==SCORM_STATUS_UNKNOWN){
_36a[i].SetProgressStatus(false,false,this,true);
}else{
if(_36b.SuccessStatus==SCORM_STATUS_PASSED){
_36a[i].SetProgressStatus(true,false,this,true);
_36a[i].SetSatisfiedStatus(true,false,this);
}else{
if(_36b.SuccessStatus==SCORM_STATUS_FAILED){
_36a[i].SetProgressStatus(true,false,this,true);
_36a[i].SetSatisfiedStatus(false,false,this);
}else{
Debug.AssertError("Invalid success status ("+_36b.SuccessStatus+") encountered in a RTE objective at position "+i);
}
}
}
}
if(_36b.MeasureChangedDuringRuntime===true){
if(_36b.ScoreScaled===null){
_36a[i].SetMeasureStatus(false,this);
}else{
_36a[i].SetMeasureStatus(true,this);
_36a[i].SetNormalizedMeasure(_36b.ScoreScaled,this);
}
}
_36a[i].SetScoreRaw(_36b.ScoreRaw);
_36a[i].SetScoreMin(_36b.ScoreMin);
_36a[i].SetScoreMax(_36b.ScoreMax);
if(_36b.ProgressMeasureChangedDuringRuntime===true){
if(_36c.GetIdentifier()===id){
_36d=true;
if(_36b.ProgressMeasure===null){
this.SetAttemptCompletionAmountStatus(false);
}else{
this.SetAttemptCompletionAmountStatus(true);
this.SetAttemptCompletionAmount(_36b.ProgressMeasure);
}
}
if(_36b.ProgressMeasure===null){
_36a[i].SetProgressMeasureStatus(false);
}else{
_36a[i].SetProgressMeasureStatus(true);
_36a[i].SetProgressMeasure(_36b.ProgressMeasure);
}
}
if(_36b.CompletionStatusChangedDuringRuntime===true){
var _370=false;
var _371=false;
if(_36b.CompletionStatus==SCORM_STATUS_UNKNOWN){
_370=false;
}else{
if(_36b.CompletionStatus==SCORM_STATUS_NOT_ATTEMPTED){
_370=true;
_371=false;
}else{
if(_36b.CompletionStatus==SCORM_STATUS_COMPLETED){
_370=true;
_371=true;
}else{
if(_36b.CompletionStatus==SCORM_STATUS_INCOMPLETE){
_370=true;
_371=false;
}else{
if(_36b.CompletionStatus==SCORM_STATUS_BROWSED){
_370=true;
_371=false;
}else{
Debug.AssertError("Invalid completion status-"+_36b.CompletionStatus);
}
}
}
}
}
_36a[i].SetCompletionStatus(_370);
if(_370===true){
_36a[i].SetCompletionStatusValue(_371);
}
if(_36c.GetIdentifier()===id){
this.SetAttemptProgressStatus(_370);
if(_370===true){
this.SetAttemptCompletionStatus(_371);
}
}
}
}else{
if(id.length>0){
Debug.AssertError("Sequencing objective not found in runtime, id="+_36a[i].GetIdentifier());
}
}
}
var _372;
var _373;
if(this.Sequencer.LookAhead===true){
_372=this.RunTime.LookAheadSuccessStatus;
_373=this.RunTime.LookAheadCompletionStatus;
}else{
_372=this.RunTime.SuccessStatus;
_373=this.RunTime.CompletionStatus;
}
if(_372==SCORM_STATUS_UNKNOWN){
_36c.SetProgressStatus(false,false,this);
}else{
if(_372==SCORM_STATUS_PASSED){
_36c.SetProgressStatus(true,false,this);
_36c.SetSatisfiedStatus(true,false,this);
}else{
if(_372==SCORM_STATUS_FAILED){
_36c.SetProgressStatus(true,false,this);
_36c.SetSatisfiedStatus(false,false,this);
}else{
this.Sequencer.LogSeq("`1379`"+_372);
}
}
}
if(this.RunTime.ScoreRaw==0&&Control.Package.Properties.ScoreRollupMode==SCORE_ROLLUP_METHOD_AVERAGE_SCORE_OF_ALL_UNITS_WITH_NONZERO_SCORES){
}else{
if(this.RunTime.ScoreScaled===null){
_36c.SetMeasureStatus(false,this);
if(Control.Package.Properties.ScaleRawScore==true){
var _374=NormalizeRawScore(this.RunTime.ScoreRaw,this.RunTime.ScoreMin,this.RunTime.ScoreMax);
if(_374!==null&&_374!==undefined){
_36c.SetMeasureStatus(true,this);
_36c.SetNormalizedMeasure(_374,this);
}else{
this.Sequencer.LogSeq("`1035`"+this.RunTime.ScoreRaw+"`1730`"+this.RunTime.ScoreMin+"`1729`"+this.RunTime.ScoreMax);
}
}
}else{
_36c.SetMeasureStatus(true,this);
_36c.SetNormalizedMeasure(this.RunTime.ScoreScaled,this);
}
}
_36c.SetScoreRaw(this.RunTime.ScoreRaw);
_36c.SetScoreMin(this.RunTime.ScoreMin);
_36c.SetScoreMax(this.RunTime.ScoreMax);
if(this.RunTime.ProgressMeasure===null){
if(_36d!==true){
this.SetAttemptCompletionAmountStatus(false);
_36c.SetProgressMeasureStatus(false);
}
}else{
this.SetAttemptCompletionAmountStatus(true);
this.SetAttemptCompletionAmount(this.RunTime.ProgressMeasure);
_36c.SetProgressMeasureStatus(true);
_36c.SetProgressMeasure(this.RunTime.ProgressMeasure);
}
var _375=false;
var _376=false;
if(Control.Package.LearningStandard.is20044thOrGreater()===false||this.RunTime.CompletionStatusChangedDuringRuntime===true){
if(_373==SCORM_STATUS_UNKNOWN){
_375=false;
_376=false;
}else{
if(_373==SCORM_STATUS_NOT_ATTEMPTED){
_375=true;
_376=false;
}else{
if(_373==SCORM_STATUS_COMPLETED){
_375=true;
_376=true;
}else{
if(_373==SCORM_STATUS_INCOMPLETE){
_375=true;
_376=false;
}else{
if(_373==SCORM_STATUS_BROWSED){
_375=true;
_376=false;
}else{
Debug.AssertError("Invalid completion status-"+_373);
}
}
}
}
}
this.SetAttemptProgressStatus(_375);
if(_375===true){
this.SetAttemptCompletionStatus(_376);
}
}
if(this.LookAheadActivity===false){
this.SetDirtyData();
}
}else{
}
}
function Activity_IsTheRoot(){
var _377=this.ParentActivity;
var _378=(_377===null);
return _378;
}
function Activity_IsALeaf(){
if(this.ChildActivities.length===0){
return true;
}else{
return false;
}
}
function Activity_IsActive(){
var _379;
_379=this.Active;
return _379;
}
function Activity_IsSuspended(){
var _37a;
_37a=this.Suspended;
return _37a;
}
function Activity_HasSuspendedChildren(){
var _37b=this.GetChildren();
for(var i=0;i<_37b.length;i++){
if(_37b[i].IsSuspended()){
return true;
}
}
return false;
}
function Activity_SetActive(_37d){
this.Active=_37d;
this.SetDirtyData();
}
function Activity_SetSuspended(_37e){
this.Suspended=_37e;
this.SetDirtyData();
}
function Activity_IsTracked(){
var _37f=this.LearningObject.SequencingData.Tracked;
return _37f;
}
function Activity_IsCompletionSetByContent(){
var _380=false;
if(Control.Package.Properties.ForceObjectiveCompletionSetByContent==true){
_380=true;
}else{
_380=this.LearningObject.SequencingData.CompletionSetByContent;
}
return _380;
}
function Activity_IsObjectiveSetByContent(){
var _381=false;
if(Control.Package.Properties.ForceObjectiveCompletionSetByContent==true){
_381=true;
}else{
_381=this.LearningObject.SequencingData.ObjectiveSetByContent;
}
return _381;
}
function Activity_GetAttemptProgressStatus(){
if(this.IsTracked()===false){
return false;
}
var _382=this.AttemptProgressStatus;
return _382;
}
function Activity_SetAttemptProgressStatus(_383){
this.AttemptProgressStatus=_383;
if(_383===true){
this.SetAttemptedDuringThisAttempt();
}
var _384=this.GetPrimaryObjective();
_384.SetCompletionStatus(_383);
this.SetDirtyData();
}
function Activity_SetAttemptCompletionStatus(_385){
if(this.FirstCompletionTimestampUtc===null&&_385===true){
this.FirstCompletionTimestampUtc=ConvertDateToIso8601String(new Date());
}
this.AttemptCompletionStatus=_385;
var _386=this.GetPrimaryObjective();
_386.SetCompletionStatusValue(_385);
this.SetDirtyData();
}
function Activity_GetAttemptCompletionStatus(){
if(this.IsTracked()===false){
return false;
}
var _387=this.AttemptCompletionStatus;
return _387;
}
function Activity_GetChildren(){
return this.ChildActivities;
}
function Activity_GetSequencingControlFlow(){
var _388=this.LearningObject.SequencingData.ControlFlow;
return _388;
}
function Activity_GetSequencingControlChoice(){
var _389=this.LearningObject.SequencingData.ControlChoice;
return _389;
}
function Activity_GetSequencingControlChoiceExit(){
var _38a=this.LearningObject.SequencingData.ControlChoiceExit;
return _38a;
}
function Activity_GetSequencingControlForwardOnly(){
var _38b=this.LearningObject.SequencingData.ControlForwardOnly;
return _38b;
}
function Activity_GetPreventActivation(){
var _38c=this.LearningObject.SequencingData.PreventActivation;
return _38c;
}
function Activity_GetConstrainedChoice(){
var _38d=this.LearningObject.SequencingData.ConstrainChoice;
return _38d;
}
function Activity_GetSelectionTiming(){
var _38e=this.LearningObject.SequencingData.SelectionTiming;
return _38e;
}
function Activity_GetSelectionCountStatus(){
var _38f=this.LearningObject.SequencingData.SelectionCountStatus;
return _38f;
}
function Activity_GetSelectionCount(){
var _390=this.LearningObject.SequencingData.SelectionCount;
return _390;
}
function Activity_GetRandomizationTiming(){
var _391=this.LearningObject.SequencingData.RandomizationTiming;
return _391;
}
function Activity_GetRandomizeChildren(){
var _392=this.LearningObject.SequencingData.RandomizeChildren;
return _392;
}
function Activity_GetLimitConditionAttemptControl(){
var _393=this.LearningObject.SequencingData.LimitConditionAttemptControl;
return _393;
}
function Activity_GetActivityProgressStatus(){
if(this.IsTracked()===false){
return false;
}
var _394=this.ActivityProgressStatus;
return _394;
}
function Activity_SetActivityProgressStatus(_395){
this.ActivityProgressStatus=_395;
this.SetDirtyData();
}
function Activity_GetAttemptCount(){
var _396=this.ActivityAttemptCount;
return _396;
}
function Activity_GetLimitConditionAttemptLimit(){
var _397=this.LearningObject.SequencingData.LimitConditionAttemptLimit;
return _397;
}
function Activity_GetPreConditionRules(){
var _398=this.LearningObject.SequencingData.PreConditionSequencingRules;
return _398;
}
function Activity_GetPostConditionRules(){
var _399=this.LearningObject.SequencingData.PostConditionSequencingRules;
return _399;
}
function Activity_GetExitRules(){
var _39a=this.LearningObject.SequencingData.ExitSequencingRules;
return _39a;
}
function Activity_IsSatisfied(_39b,_39c){
if(_39c===null||_39c===undefined){
_39c=false;
}
if(this.IsTracked()===false){
return RESULT_UNKNOWN;
}
var _39d;
if(_39b===""||_39b===undefined||_39b===null){
_39d=this.GetPrimaryObjective();
}else{
_39d=this.FindObjective(_39b);
}
if(_39d===null||_39d===undefined){
Debug.AssertError("Sequencing rule references a bad objective.");
}
if(_39d.GetProgressStatus(this,_39c)===true){
if(_39d.GetSatisfiedStatus(this,_39c)===true){
return true;
}else{
return false;
}
}else{
return RESULT_UNKNOWN;
}
}
function Activity_IsObjectiveStatusKnown(_39e,_39f){
if(_39f===null||_39f===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into IsObjectiveStatusKnown");
}
if(this.IsTracked()===false){
return false;
}
var _3a0=this.FindObjective(_39e);
if(_3a0.GetProgressStatus(this,_39f)===true){
return true;
}else{
return false;
}
}
function Activity_IsObjectiveMeasureKnown(_3a1,_3a2){
if(_3a2===null||_3a2===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into IsObjectiveMeasureKnown");
}
if(this.IsTracked()===false){
return false;
}
var _3a3=this.FindObjective(_3a1);
if(_3a3.GetMeasureStatus(this,_3a2)===true){
return true;
}else{
return false;
}
}
function Activity_IsObjectiveMeasureGreaterThan(_3a4,_3a5,_3a6){
if(_3a6===null||_3a6===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into IsObjectiveMeasureGreaterThan");
}
if(this.IsTracked()===false){
return RESULT_UNKNOWN;
}
var _3a7=this.FindObjective(_3a4);
if(_3a7.GetMeasureStatus(this,_3a6)===true){
if(_3a7.GetNormalizedMeasure(this,_3a6)>_3a5){
return true;
}else{
return false;
}
}else{
return RESULT_UNKNOWN;
}
}
function Activity_IsObjectiveMeasureLessThan(_3a8,_3a9,_3aa){
if(_3aa===null||_3aa===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into IsObjectiveMeasureLessThan");
}
if(this.IsTracked()===false){
return RESULT_UNKNOWN;
}
var _3ab=this.FindObjective(_3a8);
Debug.AssertError("The objective referenced by a sequencing rule was not found. Does the definition of the sequencing rule in the manifest erroneously reference the name of the global objective instead of the local name of the objective? Problematic reference="+_3a8,(_3ab===null));
if(_3ab.GetMeasureStatus(this,_3aa)===true){
if(_3ab.GetNormalizedMeasure(this,_3aa)<_3a9){
return true;
}else{
return false;
}
}else{
return RESULT_UNKNOWN;
}
}
function Activity_GetObjectiveMeasure(_3ac){
if(_3ac===null||_3ac===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into GetObjectiveMeasure");
}
if(this.IsTracked()===false){
return RESULT_UNKNOWN;
}
var _3ad=this.GetPrimaryObjective();
if(_3ad.GetMeasureStatus(this,_3ac)===true){
return _3ad.GetNormalizedMeasure(this,_3ac);
}else{
return RESULT_UNKNOWN;
}
}
function Activity_IsCompleted(_3ae,_3af){
if(_3af===null||_3af===undefined){
_3af=false;
}
if(this.IsTracked()===false){
return RESULT_UNKNOWN;
}
var _3b0=false;
var _3b1=false;
if(Control.Package.LearningStandard.is20044thOrGreater()){
_3b0=true;
}
if(Control.Package.LearningStandard.is20044thOrGreater()===true&&this.GetCompletedByMeasure()===true){
_3b1=true;
}
var _3b2;
var _3b3;
var _3b4;
var _3b5;
var _3b6=null;
if(_3b0===true&&_3ae!==""&&_3ae!==undefined&&_3ae!==null){
_3b6=this.FindObjective(_3ae);
if(_3b6===null||_3b6===undefined){
Debug.AssertError("Sequencing rule references a bad objective.");
}
}
if(_3b0===true&&_3b6!==null&&_3b6!==undefined){
_3b2=_3b6.GetCompletionStatus(this,_3af);
_3b3=_3b6.GetCompletionStatusValue(this,_3af);
if(_3b1===true){
_3b4=_3b6.GetProgressMeasureStatus();
_3b5=_3b6.GetProgressMeasure();
}
}else{
var _3b7=this.GetPrimaryObjective();
var _3b8=_3b7.GetMaps("ReadCompletionStatus",true);
if(_3b0===true&&_3b8.length>0){
_3b2=_3b7.GetCompletionStatus(this,_3af);
_3b3=_3b7.GetCompletionStatusValue(this,_3af);
if(_3b1===true){
_3b4=_3b7.GetProgressMeasureStatus();
_3b5=_3b7.GetProgressMeasure();
}
}else{
if(_3af===true&&this.WasAttemptedDuringThisAttempt()===false){
_3b2=this.PrevAttemptProgressStatus;
_3b3=this.PrevAttemptCompletionStatus;
}else{
_3b2=this.AttemptProgressStatus;
_3b3=this.AttemptCompletionStatus;
}
if(_3b1===true){
_3b4=this.GetAttemptCompletionAmountStatus();
_3b5=this.GetAttemptCompletionAmount();
}
}
}
if(_3b1===true&&(this.IsActive()===false||this.GetMeasureSatisfactionIfActive()===true)){
if(_3b4===true){
if(_3b5>=this.GetMinProgressMeasure()){
return true;
}else{
return false;
}
}else{
return RESULT_UNKNOWN;
}
}
if(_3b2===true){
if(_3b3===true){
return true;
}else{
return false;
}
}else{
return RESULT_UNKNOWN;
}
}
function Activity_IsActivityProgressKnown(_3b9,_3ba){
if(_3ba===null||_3ba===undefined){
Debug.AssertError("ERROR - canLookAtPreviousAttempt must be passed into IsActivityProgressKnown");
}
if(this.IsTracked()===false){
return false;
}
var _3bb=false;
if(Control.Package.LearningStandard.is20044thOrGreater()){
_3bb=true;
}
var _3bc=this.ActivityProgressStatus;
var _3bd;
var _3be;
var _3bf=null;
if(Control.Package.LearningStandard.is20044thOrGreater()===true&&this.GetCompletedByMeasure()===true){
_3bd=this.GetAttemptCompletionAmountStatus();
}else{
if(_3bb===true&&_3b9!==""&&_3b9!==undefined&&_3b9!==null){
_3bf=this.FindObjective(_3b9);
if(_3bf===null||_3bf===undefined){
Debug.AssertError("Sequencing rule references a bad objective.");
}
}
if(_3bb===true&&_3bf!==null&&_3bf!==undefined){
_3bd=_3bf.GetCompletionStatus(this,_3ba);
}else{
var _3c0=this.GetPrimaryObjective();
var _3c1=_3c0.GetMaps("ReadCompletionStatus",true);
if(_3bb===true&&_3c1.length>0){
_3bd=_3c0.GetCompletionStatus(this,_3ba);
}else{
if(_3ba===true&&this.WasAttemptedDuringThisAttempt()===false){
_3bd=this.PrevAttemptProgressStatus;
}else{
_3bd=this.AttemptProgressStatus;
}
}
}
}
if(_3bb===true){
return _3bd;
}else{
return (_3bd===true&&_3bc===true)?true:false;
}
}
function Activity_IsAttempted(){
if(this.IsTracked()===false){
return RESULT_UNKNOWN;
}
if(this.ActivityProgressStatus===true||Control.Package.LearningStandard.is20044thOrGreater()===true){
if(this.GetAttemptCount()>0){
return true;
}
}else{
return RESULT_UNKNOWN;
}
return false;
}
function Activity_IsAttemptLimitExceeded(){
if(this.IsTracked()===false){
return RESULT_UNKNOWN;
}
if(this.IsActive()||this.IsSuspended()){
return false;
}
if(this.ActivityProgressStatus===true){
if(this.GetLimitConditionAttemptControl()===true){
if(this.GetAttemptCount()>=this.GetLimitConditionAttemptLimit()){
return true;
}
}
}else{
return RESULT_UNKNOWN;
}
return false;
}
function Activity_GetObjectives(){
return this.ActivityObjectives;
}
function Activity_FindObjective(_3c2){
var _3c3=this.GetObjectives();
for(var i=0;i<_3c3.length;i++){
if(_3c2===""||_3c2===null){
if(_3c3[i].GetContributesToRollup()===true){
return _3c3[i];
}
}else{
if(_3c3[i].GetIdentifier()==_3c2){
return _3c3[i];
}
}
}
return null;
}
function Activity_GetPrimaryObjective(){
if(this.CachedPrimaryObjective===null){
var _3c5=null;
var _3c6=this.GetObjectives();
for(var i=0;i<_3c6.length;i++){
if(_3c6[i].GetContributesToRollup()===true){
_3c5=_3c6[i];
break;
}
}
this.CachedPrimaryObjective=_3c5;
}
if(this.CachedPrimaryObjective===null){
Debug.AssertError("Could not find a primary objective.");
}
return this.CachedPrimaryObjective;
}
function Activity_GetRollupObjectiveMeasureWeight(){
var _3c8=this.LearningObject.SequencingData.RollupObjectiveMeasureWeight;
_3c8=parseFloat(_3c8);
return _3c8;
}
function Activity_GetMeasureSatisfactionIfActive(){
var _3c9=this.LearningObject.SequencingData.MeasureSatisfactionIfActive;
return _3c9;
}
function Activity_GetRollupRules(){
var _3ca=this.LearningObject.SequencingData.RollupRules;
return _3ca;
}
function Activity_ApplyRollupRule(_3cb){
if(_3cb.Action==RULE_SET_SATISFIED||_3cb.Action==RULE_SET_NOT_SATISFIED){
this.LearningObject.UsesDefaultSatisfactionRollupRules=true;
}else{
this.LearningObject.UsesDefaultCompletionRollupRules=true;
}
var _3cc=this.LearningObject.SequencingData.RollupRules.length;
this.LearningObject.SequencingData.RollupRules[_3cc]=_3cb;
}
function Activity_GetRollupObjectiveSatisfied(){
var _3cd=this.LearningObject.SequencingData.RollupObjectiveSatisfied;
return _3cd;
}
function Activity_GetRequiredForSatisfied(){
var _3ce=this.LearningObject.SequencingData.RequiredForSatisfied;
return _3ce;
}
function Activity_GetRequiredForNotSatisfied(){
var _3cf=this.LearningObject.SequencingData.RequiredForNotSatisfied;
return _3cf;
}
function Activity_RollupProgressCompletion(){
var _3d0=this.LearningObject.SequencingData.RollupProgressCompletion;
return _3d0;
}
function Activity_GetRequiredForCompleted(){
var _3d1=this.LearningObject.SequencingData.RequiredForCompleted;
return _3d1;
}
function Activity_GetRequiredForIncomplete(){
var _3d2=this.LearningObject.SequencingData.RequiredForIncomplete;
return _3d2;
}
function Activity_IncrementAttemptCount(){
this.ActivityAttemptCount++;
}
function Activity_SetRandomizedChildren(_3d3){
this.RandomizedChildren=_3d3;
this.SetDirtyData();
}
function Activity_SetSelectedChildren(_3d4){
this.SelectedChildren=_3d4;
this.SetDirtyData();
}
function Activity_GetRandomizedChildren(){
var _3d5=this.RandomizedChildren;
return _3d5;
}
function Activity_GetSelectedChildren(){
var _3d6=this.SelectedChildren;
return _3d6;
}
function Activity_GetActivityListBetweenChildren(_3d7,_3d8,_3d9){
var _3da=this.GetAvailableChildren();
var _3db=new Array();
var _3dc=null;
var _3dd=null;
for(var i=0;i<_3da.length;i++){
if(_3d7==_3da[i]){
_3dc=i;
}
if(_3d8==_3da[i]){
_3dd=i;
}
}
if(_3dc==_3dd){
if(_3d9){
_3db[0]=_3da[_3dc];
}
}else{
if(_3dc<_3dd){
if(_3d9){
_3dd++;
}
_3db=_3da.slice(_3dc,_3dd);
}else{
if(_3dc>_3dd){
if(!_3d9){
_3dd++;
}
_3db=_3da.slice(_3dd,_3dc+1);
}
}
}
return _3db;
}
function Activity_IsActivityAnAvailableChild(_3df){
var _3e0=this.GetAvailableChildren();
for(var i=0;i<_3e0.length;i++){
if(_3e0[i]==_3df){
return true;
}
}
return false;
}
function Activity_IsActivityAnAvailableDescendent(_3e2){
return Activity_SearchAllAvailableDescendents(this,_3e2);
}
function Activity_SearchAllAvailableDescendents(_3e3,_3e4){
var _3e5=_3e3.GetAvailableChildren();
for(var i=0;i<_3e5.length;i++){
if(_3e5[i]==_3e4){
return true;
}
if(Activity_SearchAllAvailableDescendents(_3e5[i],_3e4)){
return true;
}
}
return false;
}
function Activity_IsActivityTheLastAvailableChild(_3e7){
var _3e8=this.GetAvailableChildren();
if(_3e8[_3e8.length-1]==_3e7){
return true;
}
return false;
}
function Activity_IsActivityTheFirstAvailableChild(_3e9){
var _3ea=this.GetAvailableChildren();
if(_3ea[0]==_3e9){
return true;
}
return false;
}
function Activity_GetFirstAvailableChild(){
var _3eb=this.GetAvailableChildren();
return _3eb[0];
}
function Activity_GetNextActivityPreorder(){
var _3ec=this.GetAvailableChildren();
if(_3ec.length!==0){
return _3ec[0];
}
for(var _3ed=this;_3ed.ParentActivity!==null;_3ed=_3ed.ParentActivity){
var _3ee=_3ed.GetNextSibling();
if(_3ee!==null){
return _3ee;
}
}
return null;
}
function Activity_GetPreviousActivityPreorder(){
var _3ef=this.GetPreviousSibling();
if(_3ef===null){
return this.ParentActivity;
}
var _3f0=_3ef.GetAvailableChildren();
while(_3f0.length>0){
_3ef=_3f0[_3f0.length-1];
_3f0=_3ef.GetAvailableChildren();
}
return _3ef;
}
function Activity_GetNextSibling(){
var _3f1=null;
var _3f2=this.ParentActivity;
if(_3f2===null){
return null;
}
var _3f3=_3f2.GetAvailableChildren();
for(var i=0;i<_3f3.length;i++){
if(_3f3[i]==this){
_3f1=i;
break;
}
}
if(_3f1!==null&&_3f1<(_3f3.length-1)){
return _3f3[_3f1+1];
}
return null;
}
function Activity_GetPreviousSibling(){
var _3f5=null;
var _3f6=this.ParentActivity;
if(_3f6===null){
return null;
}
var _3f7=_3f6.GetAvailableChildren();
for(var i=0;i<_3f7.length;i++){
if(_3f7[i]==this){
_3f5=i;
break;
}
}
if(_3f5!==null&&_3f5>0){
return _3f7[_3f5-1];
}
return null;
}
function Activity_InitializeAvailableChildren(){
var _3f9=this.GetChildren();
var _3fa=new Array();
for(var i=0;i<_3f9.length;i++){
if(_3f9[i].Included===true){
_3fa[_3fa.length]=_3f9[i];
}
}
if(_3fa.length===0){
this.SetAvailableChildren(_3f9);
}else{
_3fa.sort(function(_3fc,_3fd){
var _3fe=_3fc.Ordinal;
var _3ff=_3fd.Ordinal;
if(_3fe<_3ff){
return -1;
}
if(_3fe>_3ff){
return 1;
}
return 0;
});
this.SetAvailableChildren(_3fa);
}
}
function Activity_GetAvailableChildren(){
if(this.AvailableChildren===null){
this.InitializeAvailableChildren();
}
return this.AvailableChildren;
}
function Activity_SetAvailableChildren(_400){
this.AvailableChildren=_400;
var _401=this.GetChildren();
var i;
for(i=0;i<_401.length;i++){
_401[i].Ordinal=0;
_401[i].Included=false;
}
for(i=0;i<this.AvailableChildren.length;i++){
this.AvailableChildren[i].Ordinal=(i+1);
this.AvailableChildren[i].Included=true;
}
this.SetDirtyData();
}
function Activity_IsAvailable(){
return this.Included;
}
function Activity_InitializeForNewAttempt(_403,_404){
var i;
this.AttemptedDuringThisAttempt=false;
var _406=this.GetObjectives();
if(_403&&this.LearningObject.SequencingData.UseCurrentAttemptObjectiveInformation===true){
_403=true;
for(i=0;i<_406.length;i++){
_406[i].ResetAttemptState();
}
}else{
_403=false;
}
if(_404&&this.LearningObject.SequencingData.UseCurrentAttemptProgressInformation===true){
_404=true;
this.ResetAttemptState();
}else{
_404=false;
}
var _407=this.GetChildren();
for(i=0;i<_407.length;i++){
_407[i].InitializeForNewAttempt(_403,_404);
}
if(SSP_ENABLED&&Control.Api.SSPApi){
Control.Api.SSPApi.ResetBucketsForActivity(this.DatabaseId);
}
this.SetDirtyData();
}
function Activity_ResetAttemptState(){
this.PrevAttemptProgressStatus=this.AttemptProgressStatus;
this.PrevAttemptCompletionStatus=this.AttemptCompletionStatus;
this.AttemptProgressStatus=false;
this.AttemptCompletionAmountStatus=false;
this.AttemptCompletionAmount=0;
this.AttemptCompletionStatus=false;
this.SetDirtyData();
}
function Activity_RollupDurations(){
var _408=null;
var _409=null;
var _40a=null;
var _40b=null;
var _40c=0;
var _40d=0;
var _40e=0;
var _40f=0;
var _410=this.GetChildren();
for(var i=0;i<_410.length;i++){
if(_410[i].GetActivityStartTimestampUtc()){
if(!_408||_410[i].GetActivityStartTimestampUtc()<_408){
_408=_410[i].GetActivityStartTimestampUtc();
}
}
if(_410[i].ActivityEndedDate){
if(!_40a||_410[i].ActivityEndedDate>_40a){
_40a=_410[i].ActivityEndedDate;
}
}
if(_410[i].GetActivityExperiencedDurationTracked()){
_40c+=ConvertIso8601TimeSpanToHundredths(_410[i].GetActivityExperiencedDurationTracked());
}
if(_410[i].GetActivityExperiencedDurationReported()){
_40d+=ConvertIso8601TimeSpanToHundredths(_410[i].GetActivityExperiencedDurationReported());
}
if(!this.GetAttemptStartTimestampUtc()||(_410[i].GetAttemptStartTimestampUtc()&&_410[i].GetAttemptStartTimestampUtc()>=this.GetAttemptStartTimestampUtc())){
if(!this.GetAttemptStartTimestampUtc()&&_410[i].GetAttemptStartTimestampUtc()){
if(!_409||_410[i].GetAttemptStartTimestampUtc()<_409){
_409=_410[i].GetAttemptStartTimestampUtc();
}
}
if(_410[i].ActivityEndedDate){
if(!_40b||_410[i].ActivityEndedDate>_40b){
_40b=_410[i].ActivityEndedDate;
}
}
if(_410[i].GetAttemptExperiencedDurationTracked()){
_40e+=ConvertIso8601TimeSpanToHundredths(_410[i].GetAttemptExperiencedDurationTracked());
}
if(_410[i].GetAttemptExperiencedDurationReported()){
_40f+=ConvertIso8601TimeSpanToHundredths(_410[i].GetAttemptExperiencedDurationReported());
}
}
}
if(!this.IsALeaf()&&_408!==null){
this.SetActivityStartTimestampUtc(_408);
if(!this.GetAttemptStartTimestampUtc()){
this.SetAttemptStartTimestampUtc(_409);
}
this.ActivityEndedDate=_40a;
var _412=GetDateFromUtcIso8601Time(this.GetActivityStartTimestampUtc());
var _413=GetDateFromUtcIso8601Time(this.GetAttemptStartTimestampUtc());
this.SetActivityAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((_40a-_412)/10));
this.SetAttemptAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((_40b-_413)/10));
this.SetActivityExperiencedDurationTracked(ConvertHundredthsToIso8601TimeSpan(_40c));
this.SetActivityExperiencedDurationReported(ConvertHundredthsToIso8601TimeSpan(_40d));
this.SetAttemptExperiencedDurationTracked(ConvertHundredthsToIso8601TimeSpan(_40e));
this.SetAttemptExperiencedDurationReported(ConvertHundredthsToIso8601TimeSpan(_40f));
}
}
function Activity_SetDirtyData(){
this.DataState=DATA_STATE_DIRTY;
}
function Activity_IsAnythingDirty(){
if(this.DataState==DATA_STATE_DIRTY){
return true;
}
for(var i=0;i<this.ActivityObjectives.length;i++){
if(this.ActivityObjectives[i].DataState==DATA_STATE_DIRTY){
return true;
}
}
return false;
}
function Activity_MarkPostedObjectiveDataDirty(){
for(var i=0;i<this.ActivityObjectives.length;i++){
if(this.ActivityObjectives[i].DataState==DATA_STATE_POSTED){
this.ActivityObjectives[i].SetDirtyData();
}
}
}
function Activity_MarkPostedObjectiveDataClean(){
for(var i=0;i<this.ActivityObjectives.length;i++){
if(this.ActivityObjectives[i].DataState==DATA_STATE_POSTED){
this.ActivityObjectives[i].DataState=DATA_STATE_CLEAN;
}
}
}
function Activity_MarkDirtyObjectiveDataPosted(){
for(var i=0;i<this.ActivityObjectives.length;i++){
if(this.ActivityObjectives[i].DataState==DATA_STATE_DIRTY){
this.ActivityObjectives[i].DataState=DATA_STATE_POSTED;
}
}
}
function Activity_SetSequencer(_418,_419){
this.Sequencer=_418;
this.LookAheadActivity=_419;
for(var i=0;i<this.ActivityObjectives.length;i++){
this.ActivityObjectives[i].SetSequencer(_418);
}
}
function Activity_Clone(){
var _41b=new Activity(this.DatabaseId,this.ItemIdentifier,this.ScormObjectDatabaseId,this.ActivityProgressStatus,this.ActivityAttemptCount,this.AttemptProgressStatus,this.AttemptCompletionAmountStatus,this.AttemptCompletionAmount,this.AttemptCompletionStatus,this.Active,this.Suspended,this.Included,this.Ordinal,this.SelectedChildren,this.RandomizedChildren,null,null,this.PrevAttemptProgressStatus,this.PrevAttemptCompletionStatus,this.AttemptedDuringThisAttempt,this.FirstCompletionTimestampUtc,this.ActivityStartTimestampUtc,this.AttemptStartTimestampUtc,this.ActivityAbsoluteDuration,this.AttemptAbsoluteDuration,this.ActivityExperiencedDurationTracked,this.AttemptExperiencedDurationTracked,this.ActivityExperiencedDurationReported,this.AttemptExperiencedDurationReported);
_41b.StringIdentifier=this.toString();
_41b.ActivityObjectives=new Array();
for(var _41c in this.ActivityObjectives){
_41b.ActivityObjectives[_41c]=this.ActivityObjectives[_41c].Clone();
}
_41b.RunTime=this.RunTime;
_41b.LearningObject=this.LearningObject;
_41b.DataState=DATA_STATE_CLEAN;
_41b.LaunchedThisSession=this.LaunchedThisSession;
_41b.AttemptedDuringThisAttempt=this.AttemptedDuringThisAttempt;
_41b.UsesDefaultRollupRules=this.UsesDefaultRollupRules;
return _41b;
}
function Activity_TearDown(){
this.StringIdentifier=null;
this.DatabaseId=null;
this.ScormObjectDatabaseId=null;
this.ActivityProgressStatus=null;
this.ActivityAttemptCount=null;
this.AttemptProgressStatus=null;
this.AttemptCompletionAmountStatus=null;
this.AttemptCompletionAmount=null;
this.AttemptCompletionStatus=null;
this.FirstCompletionTimestampUtc=null;
this.ActivityStartTimestampUtc=null;
this.AttemptStartTimestampUtc=null;
this.ActivityAbsoluteDuration=null;
this.AttemptAbsoluteDuration=null;
this.ActivityExperiencedDurationTracked=null;
this.AttemptExperiencedDurationTracked=null;
this.ActivityExperiencedDurationReported=null;
this.AttemptExperiencedDurationReported=null;
this.Active=null;
this.Suspended=null;
this.Included=null;
this.Ordinal=null;
this.SelectedChildren=null;
this.RandomizedChildren=null;
this.RunTime=null;
this.Sequencer=null;
this.LookAheadActivity=null;
this.LearningObject=null;
this.ParentActivity=null;
this.AvailableChildren=null;
this.DataState=null;
this.MenuItem=null;
this.ChildActivities=null;
this.CachedPrimaryObjective=null;
this.HiddenFromChoice=null;
for(var _41d in this.ActivityObjectives){
this.ActivityObjectives[_41d].TearDown();
this.ActivityObjectives[_41d]=null;
}
this.ActivityObjectives=null;
}
function Activity_DisplayInChoice(){
if(this.LearningObject.Visible===false){
return false;
}else{
if(this.IsAvailable()===false){
return false;
}else{
if(this.HiddenFromChoice===true){
return false;
}
}
}
return true;
}
function Activity_SetHiddenFromChoice(_41e){
this.HiddenFromChoice=_41e;
}
function Activity_WasLaunchedThisSession(){
return this.LaunchedThisSession;
}
function Activity_SetLaunchedThisSession(){
this.LaunchedThisSession=true;
if(this.LearningObject.ScormType===SCORM_TYPE_ASSET){
Control.ScoLoader.ScoLoaded=true;
}
}
function Activity_WasAttemptedDuringThisAttempt(){
return this.AttemptedDuringThisAttempt;
}
function Activity_SetAttemptedDuringThisAttempt(){
this.AttemptedDuringThisAttempt=true;
}
function Activity_GetMinProgressMeasure(){
return this.LearningObject.CompletionThreshold;
}
function Activity_GetCompletionProgressWeight(){
var _41f=this.LearningObject.CompletionProgressWeight;
_41f=parseFloat(_41f);
return _41f;
}
function Activity_GetCompletedByMeasure(){
return this.LearningObject.CompletedByMeasure;
}
function Activity_GetAttemptCompletionAmount(){
return this.AttemptCompletionAmount;
}
function Activity_SetAttemptCompletionAmount(_420){
this.AttemptCompletionAmount=_420;
}
function Activity_GetAttemptCompletionAmountStatus(){
return this.AttemptCompletionAmountStatus;
}
function Activity_SetAttemptCompletionAmountStatus(_421){
this.AttemptCompletionAmountStatus=_421;
}
function Activity_GetCompletionStatusChangedDuringRuntime(){
if(this.RunTime!==null){
return this.RunTime.CompletionStatusChangedDuringRuntime;
}
return false;
}
function Activity_GetSuccessStatusChangedDuringRuntime(){
if(this.RunTime!==null){
return this.RunTime.SuccessStatusChangedDuringRuntime;
}
return false;
}
function Activity_GetActivityStartTimestampUtc(){
return this.ActivityStartTimestampUtc;
}
function Activity_SetActivityStartTimestampUtc(_422){
this.ActivityStartTimestampUtc=_422;
this.SetDirtyData();
}
function Activity_GetAttemptStartTimestampUtc(){
return this.AttemptStartTimestampUtc;
}
function Activity_SetAttemptStartTimestampUtc(_423){
this.AttemptStartTimestampUtc=_423;
this.SetDirtyData();
}
function Activity_GetActivityAbsoluteDuration(){
return this.ActivityAbsoluteDuration;
}
function Activity_SetActivityAbsoluteDuration(_424){
this.ActivityAbsoluteDuration=_424;
this.SetDirtyData();
}
function Activity_GetAttemptAbsoluteDuration(){
return this.AttemptAbsoluteDuration;
}
function Activity_SetAttemptAbsoluteDuration(_425){
this.AttemptAbsoluteDuration=_425;
this.SetDirtyData();
}
function Activity_GetActivityExperiencedDurationTracked(){
return this.ActivityExperiencedDurationTracked;
}
function Activity_SetActivityExperiencedDurationTracked(_426){
this.ActivityExperiencedDurationTracked=_426;
this.SetDirtyData();
}
function Activity_GetAttemptExperiencedDurationTracked(){
return this.AttemptExperiencedDurationTracked;
}
function Activity_SetAttemptExperiencedDurationTracked(_427){
this.AttemptExperiencedDurationTracked=_427;
this.SetDirtyData();
}
function Activity_GetActivityExperiencedDurationReported(){
return this.ActivityExperiencedDurationReported;
}
function Activity_SetActivityExperiencedDurationReported(_428){
this.ActivityExperiencedDurationReported=_428;
this.SetDirtyData();
}
function Activity_GetAttemptExperiencedDurationReported(){
return this.AttemptExperiencedDurationReported;
}
function Activity_SetAttemptExperiencedDurationReported(_429){
this.AttemptExperiencedDurationReported=_429;
this.SetDirtyData();
}
function Activity_UsesDefaultSatisfactionRollupRules(){
return this.LearningObject.UsesDefaultSatisfactionRollupRules;
}
function Activity_UsesDefaultCompletionRollupRules(){
return this.LearningObject.UsesDefaultCompletionRollupRules;
}
function CosmeticPage(_42a,_42b,_42c){
this.FrameName=_42a;
this.PageHref=_42b;
this.Parameters=_42c;
}
function GlobalObjective(_42d,ID,_42f,_430,_431,_432,_433,_434,_435,_436,_437,_438,_439){
Debug.AssertError("Global Objective not created with all parameters (is the call missing the index?).",(_432===null||_432===undefined));
this.Index=_42d;
this.ID=ID;
this.ProgressStatus=_42f;
this.SatisfiedStatus=_430;
this.MeasureStatus=_431;
this.NormalizedMeasure=_432;
this.ScoreRaw=_433;
this.ScoreMin=_434;
this.ScoreMax=_435;
this.CompletionStatus=_436;
this.CompletionStatusValue=_437;
this.ProgressMeasureStatus=_438;
this.ProgressMeasure=_439;
this.DataState=DATA_STATE_CLEAN;
}
GlobalObjective.prototype.GetXml=GlobalObjective_GetXml;
GlobalObjective.prototype.Clone=GlobalObjective_Clone;
GlobalObjective.prototype.SetDirtyData=GlobalObjective_SetDirtyData;
GlobalObjective.prototype.ResetState=GlobalObjective_ResetState;
function GlobalObjective_GetXml(_43a){
var _43b=new ServerFormater();
var xml=new XmlElement("GO");
xml.AddAttribute("RI",_43a);
xml.AddAttribute("ROI",this.Index);
xml.AddAttribute("I",this.ID);
xml.AddAttribute("PS",_43b.ConvertBoolean(this.ProgressStatus));
xml.AddAttribute("SS",_43b.ConvertBoolean(this.SatisfiedStatus));
xml.AddAttribute("MS",_43b.ConvertBoolean(this.MeasureStatus));
xml.AddAttribute("NM",this.NormalizedMeasure);
xml.AddAttribute("CS",_43b.ConvertBoolean(this.CompletionStatus));
xml.AddAttribute("CSV",_43b.ConvertBoolean(this.CompletionStatusValue));
if(this.ScoreRaw!==null){
xml.AddAttribute("SR",this.ScoreRaw);
}
if(this.ScoreMax!==null){
xml.AddAttribute("SM",this.ScoreMax);
}
if(this.ScoreMin!==null){
xml.AddAttribute("SMi",this.ScoreMin);
}
xml.AddAttribute("PrMS",_43b.ConvertBoolean(this.ProgressMeasureStatus));
if(this.ProgressMeasure!==null){
xml.AddAttribute("PM",this.ProgressMeasure);
}
return xml.toString();
}
function GlobalObjective_Clone(){
var _43d=new GlobalObjective(this.Index,this.ID,this.ProgressStatus,this.SatisfiedStatus,this.MeasureStatus,this.NormalizedMeasure,this.ScoreRaw,this.ScoreMin,this.ScoreMax,this.CompletionStatus,this.CompletionStatusValue,this.ProgressMeasureStatus,this.ProgressMeasure);
return _43d;
}
function GlobalObjective_SetDirtyData(){
this.DataState=DATA_STATE_DIRTY;
}
function GlobalObjective_ResetState(){
this.ProgressStatus=false;
this.SatisfiedStatus=false;
this.MeasureStatus=false;
this.NormalizedMeasure=0;
this.ScoreRaw=null;
this.ScoreMin=null;
this.ScoreMax=null;
this.CompletionStatus=false;
this.CompletionStatusValue=false;
this.ProgressMeasureStatus=false;
this.ProgressMeasure=null;
this.SetDirtyData();
}
function LearningObject(_43e,Href,_440,_441,_442,_443,_444,_445,_446,_447,_448,_449,_44a,_44b,_44c,_44d,_44e,_44f,_450,_451,_452,_453){
this.Title=_43e;
this.Href=Href;
this.Parameters=_440;
this.DataFromLms=_441;
this.MasteryScore=_442;
this.MaxTimeAllowed=_443;
this.TimeLimitAction=_444;
this.Prerequisites=_445;
this.Visible=_446;
this.CompletedByMeasure=_447;
this.CompletionThreshold=_448;
this.CompletionProgressWeight=_449;
this.PersistState=_44a;
this.ItemIdentifier=_44b;
this.ResourceIdentifier=_44c;
this.ExternalIdentifier=_44d;
this.DatabaseIdentifier=_44e;
this.ScormType=_44f;
this.SSPBuckets=_450;
this.SequencingData=_451;
this.SharedDataMaps=_452;
this.Children=_453;
this.UsesDefaultSatisfactionRollupRules=false;
this.UsesDefaultCompletionRollupRules=false;
}
LearningObject.prototype.GetScaledPassingScore=LearningObject_GetScaledPassingScore;
function LearningObject_GetScaledPassingScore(){
if(this.SequencingData!==null&&this.SequencingData.PrimaryObjective!==null){
if(this.SequencingData.PrimaryObjective.SatisfiedByMeasure===true){
if(this.SequencingData.PrimaryObjective.MinNormalizedMeasure!==null){
return this.SequencingData.PrimaryObjective.MinNormalizedMeasure;
}else{
return 1;
}
}
}
return null;
}
function LearningStandard(_454){
this.value=_454;
}
LearningStandard.prototype.isAICC=LearningStandard_isAICC;
LearningStandard.prototype.is12=LearningStandard_is12;
LearningStandard.prototype.is2004=LearningStandard_is2004;
LearningStandard.prototype.is20043rdOrGreater=LearningStandard_is20043rdOrGreater;
LearningStandard.prototype.is20044thOrGreater=LearningStandard_is20044thOrGreater;
function LearningStandard_isAICC(){
if(this.value==STANDARD_AICC){
return true;
}
return false;
}
function LearningStandard_is12(){
if(this.value==STANDARD_SCORM_12){
return true;
}
return false;
}
function LearningStandard_is2004(){
if(this.value==STANDARD_SCORM_2004_2ND_EDITION||this.value==STANDARD_SCORM_2004_3RD_EDITION||this.value==STANDARD_SCORM_2004_4TH_EDITION){
return true;
}
return false;
}
function LearningStandard_is20043rdOrGreater(){
if(this.value==STANDARD_SCORM_2004_3RD_EDITION||this.value==STANDARD_SCORM_2004_4TH_EDITION){
return true;
}
return false;
}
function LearningStandard_is20044thOrGreater(){
if(this.value==STANDARD_SCORM_2004_4TH_EDITION){
return true;
}
return false;
}
LearningStandard.prototype.toString=function(){
return this.value;
};
var NAVIGATION_REQUEST_START="START";
var NAVIGATION_REQUEST_RESUME_ALL="RESUME ALL";
var NAVIGATION_REQUEST_CONTINUE="CONTINUE";
var NAVIGATION_REQUEST_PREVIOUS="PREVIOUS";
var NAVIGATION_REQUEST_FORWARD="FORWARD";
var NAVIGATION_REQUEST_BACKWARD="BACKWARD";
var NAVIGATION_REQUEST_CHOICE="CHOICE";
var NAVIGATION_REQUEST_EXIT="EXIT";
var NAVIGATION_REQUEST_EXIT_ALL="EXIT ALL";
var NAVIGATION_REQUEST_SUSPEND_ALL="SUSPEND ALL";
var NAVIGATION_REQUEST_ABANDON="ABANDON";
var NAVIGATION_REQUEST_ABANDON_ALL="ABANDON ALL";
var NAVIGATION_REQUEST_NOT_VALID="INVALID";
var NAVIGATION_REQUEST_JUMP="JUMP";
var NAVIGATION_REQUEST_DISPLAY_MESSAGE="DISPLAY MESSAGE";
var NAVIGATION_REQUEST_EXIT_PLAYER="EXIT PLAYER";
function NavigationRequest(type,_456,_457){
this.Type=type;
this.TargetActivity=_456;
this.MessageToUser=_457;
}
NavigationRequest.prototype.toString=function(){
return "Type="+this.Type+", TargetActivity="+this.TargetActivity+", MessageToUser="+this.MessageToUser;
};
NavigationRequest.prototype.toDescriptiveString=function(){
var ret="";
ret+=this.Type;
if(this.TargetActivity!==null){
ret+=" targeting \""+this.TargetActivity+"\".";
}
return ret;
};
function PackageProperties(_459,_45a,_45b,_45c,_45d,_45e,_45f,_460,_461,_462,_463,_464,_465,_466,_467,_468,_469,_46a,_46b,_46c,_46d,_46e,_46f,_470,_471,_472,_473,_474,_475,_476,_477,_478,_479,_47a,_47b,_47c,_47d,_47e,_47f,_480,_481,_482,_483,_484,_485,_486,_487,_488,_489,_48a,_48b,_48c,_48d,_48e,_48f,_490,_491,_492,_493,_494,_495,_496,_497,_498,_499,_49a,_49b,_49c,_49d,_49e,_49f,_4a0,_4a1,_4a2,_4a3,_4a4,_4a5,_4a6,_4a7,_4a8,_4a9,_4aa,_4ab,_4ac,_4ad,_4ae,_4af,_4b0,_4b1,_4b2){
this.ShowFinishButton=_459;
this.ShowCloseItem=_45a;
this.ShowHelp=_45b;
this.ShowProgressBar=_45c;
this.UseMeasureProgressBar=_45d;
this.ShowCourseStructure=_45e;
this.CourseStructureStartsOpen=_45f;
this.ShowNavBar=_460;
this.ShowTitleBar=_461;
this.EnableFlowNav=_462;
this.EnableChoiceNav=_463;
this.DesiredWidth=_464;
this.DesiredHeight=_465;
this.DesiredFullScreen=_466;
this.RequiredWidth=_467;
this.RequiredHeight=_468;
this.RequiredFullScreen=_469;
this.CourseStructureWidth=_46a;
this.ScoLaunchType=_46b;
this.PlayerLaunchType=_46c;
this.IntermediateScoSatisfiedNormalExitAction=_46d;
this.IntermediateScoSatisfiedSuspendExitAction=_46e;
this.IntermediateScoSatisfiedTimeoutExitAction=_46f;
this.IntermediateScoSatisfiedLogoutExitAction=_470;
this.IntermediateScoNotSatisfiedNormalExitAction=_471;
this.IntermediateScoNotSatisfiedSuspendExitAction=_472;
this.IntermediateScoNotSatisfiedTimeoutExitAction=_473;
this.IntermediateScoNotSatisfiedLogoutExitAction=_474;
this.FinalScoCourseSatisfiedNormalExitAction=_475;
this.FinalScoCourseSatisfiedSuspendExitAction=_476;
this.FinalScoCourseSatisfiedTimeoutExitAction=_477;
this.FinalScoCourseSatisfiedLogoutExitAction=_478;
this.FinalScoCourseNotSatisfiedNormalExitAction=_479;
this.FinalScoCourseNotSatisfiedSuspendExitAction=_47a;
this.FinalScoCourseNotSatisfiedTimeoutExitAction=_47b;
this.FinalScoCourseNotSatisfiedLogoutExitAction=_47c;
this.PreventRightClick=_47d;
this.PreventWindowResize=_47e;
this.IsAvailableOffline=_47f;
this.StatusDisplay=_480;
this.ScoreRollupMode=_481;
this.NumberOfScoringObjects=_482;
this.StatusRollupMode=_483;
this.ThresholdScore=_484;
this.ApplyRollupStatusToSuccess=_485;
this.FirstScoIsPretest=_486;
this.WrapScoWindowWithApi=_487;
this.FinishCausesImmediateCommit=_488;
this.DebugControlAudit=_489;
this.DebugControlDetailed=_48a;
this.DebugRteAudit=_48b;
this.DebugRteDetailed=_48c;
this.DebugSequencingAudit=_48d;
this.DebugSequencingDetailed=_48e;
this.DebugSequencingSimple=_48f;
this.DebugLookAheadAudit=_490;
this.DebugLookAheadDetailed=_491;
this.DebugIncludeTimestamps=_492;
this.CaptureHistory=_493;
this.CaptureHistoryDetailed=_494;
this.CommMaxFailedSubmissions=_495;
this.CommCommitFrequency=_496;
this.InvalidMenuItemAction=_497;
this.AlwaysFlowToFirstSco=_498;
this.LogoutCausesPlayerExit=_499;
this.ResetRunTimeDataTiming=_49a;
this.ValidateInteractionResponses=_49b;
this.LookaheadSequencerMode=_49c;
this.ScoreOverridesStatus=_49d;
this.AllowCompleteStatusChange=_49e;
this.ScaleRawScore=_49f;
this.RollupEmptySetToUnknown=_4a0;
this.ReturnToLmsAction=_4a1;
this.UseQuickLookaheadSequencer=_4a2;
this.ForceDisableRootChoice=_4a3;
this.RollupRuntimeAtScoUnload=_4a4;
this.ForceObjectiveCompletionSetByContent=_4a5;
this.InvokeRollupAtSuspendAll=_4a6;
this.CompletionStatOfFailedSuccessStat=_4a7;
this.SatisfiedCausesCompletion=_4a8;
this.MakeStudentPrefsGlobalToCourse=_4a9;
this.LaunchCompletedRegsAsNoCredit=_4aa;
this.IsCompletionTracked=_4ab;
this.IsSatisfactionTracked=_4ac;
this.IsScoreTracked=_4ad;
this.IsIncompleteScoreMeaningful=_4ae;
this.IsIncompleteSatisfactionMeaningful=_4af;
this.SuspendDataMaxLength=_4b0;
this.TimeLimit=_4b1;
this.InternetExplorerCompatibilityMode=_4b2;
}
function Package(Id,_4b4,_4b5,_4b6,_4b7,_4b8){
this.Id=Id;
this.ObjectivesGlobalToSystem=_4b4;
this.LearningStandard=new LearningStandard(_4b5);
this.Properties=_4b6;
this.SharedDataGlobalToSystem=_4b7;
this.LearningObjects=_4b8;
}
function PossibleRequest(_4b9,_4ba,_4bb,_4bc,_4bd){
this.NavigationRequest=_4b9;
this.TargetActivityItemIdentifier=_4ba;
this.WillSucceed=_4bb;
this.Exception=_4bc;
this.ExceptionText=_4bd;
this.TargetActivity=null;
this.SequencingRequest=null;
this.TerminationSequencingRequest=null;
this.Hidden=false;
this.Disabled=false;
this.PreConditionSkipped=false;
this.PreConditionStopForwardTraversal=false;
this.PreConditionStopForwardTraversalViolation=false;
this.PreConditionDisabled=false;
this.PreConditionHiddenFromChoice=false;
this.LimitConditionViolation=false;
this.IsVisibleViolation=false;
this.PreventActivationViolation=false;
this.ControlChoiceViolation=false;
this.ForwardOnlyViolation=false;
this.ChoiceExitViolation=false;
this.ConstrainedChoiceViolation=false;
this.NoDeliverablieActivityViolation=false;
this.WillAlwaysSucceed=false;
this.WillNeverSucceed=false;
}
PossibleRequest.prototype.toString=function(){
return "Navigation Request = "+this.NavigationRequest+", TargetActivityItemIdentifier="+this.TargetActivityItemIdentifier;
};
PossibleRequest.prototype.GetErrorString=function(){
var ret=this.ExceptionText;
return ret.trim();
};
PossibleRequest.prototype.GetExceptionReason=function(){
var ret=this.ExceptionText;
ret.trim();
ret+="["+this.Exception+"], ";
ret+=", WillAlwaysSucceed = ";
ret+=this.WillAlwaysSucceed.toString();
ret+=", WillNeverSucceed = ";
ret+=this.WillNeverSucceed.toString();
ret+=", PreConditionSkipped = ";
ret+=this.PreConditionSkipped.toString();
ret+=", PreConditionStopForwardTraversal = ";
ret+=this.PreConditionStopForwardTraversal.toString();
ret+=", PreConditionDisabled = ";
ret+=this.PreConditionDisabled.toString();
ret+=", PreConditionHiddenFromChoice = ";
ret+=this.PreConditionHiddenFromChoice.toString();
ret+=", LimitConditionViolation = ";
ret+=this.LimitConditionViolation.toString();
ret+=", IsVisibleViolation = ";
ret+=this.IsVisibleViolation.toString();
ret+=", PreventActivationViolation = ";
ret+=this.PreventActivationViolation.toString();
ret+=", ControlChoiceViolation = ";
ret+=this.ControlChoiceViolation.toString();
ret+=", ForwardOnlyViolation = ";
ret+=this.ForwardOnlyViolation.toString();
ret+=", ChoiceExitViolation = ";
ret+=this.ChoiceExitViolation.toString();
ret+=", ConstrainedChoiceViolation = ";
ret+=this.ConstrainedChoiceViolation.toString();
return ret;
};
PossibleRequest.prototype.ResetForNewEvaluation=function(){
this.WillSucceed=true;
this.Hidden=false;
this.Disabled=false;
this.PreConditionSkipped=false;
this.PreConditionStopForwardTraversal=false;
this.PreConditionDisabled=false;
this.PreConditionHiddenFromChoice=false;
this.LimitConditionViolation=false;
this.IsVisibleViolation=false;
this.PreventActivationViolation=false;
this.ControlChoiceViolation=false;
this.ForwardOnlyViolation=false;
this.ChoiceExitViolation=false;
this.ConstrainedChoiceViolation=false;
};
function Registration(Id,_4c1,_4c2,_4c3,_4c4,_4c5,_4c6,_4c7,_4c8){
this.Id=Id;
this.SuspendedActivity=_4c1;
this.TrackingEnabled=_4c2;
this.LessonMode=_4c3;
this.Package=_4c4;
this.Activities=_4c5;
this.GlobalObjectives=_4c6;
this.SSPBuckets=_4c7;
this.SharedData=_4c8;
}
Registration.prototype.FindActivityForThisScormObject=Registration_FindActivityForThisScormObject;
function Registration_FindActivityForThisScormObject(_4c9){
for(var i=0;i<this.Activities.length;i++){
if(this.Activities[i].ScormObjectDatabaseId==_4c9){
return this.Activities[i];
}
}
Debug.AssertError("Registration_FindActivityForThisScormObject could not find the activity for learning object "+_4c9);
return null;
}
function SequencingData(_4cb,_4cc,_4cd,_4ce,_4cf,_4d0,_4d1,_4d2,_4d3,_4d4,_4d5,_4d6,_4d7,_4d8,_4d9,_4da,_4db,_4dc,_4dd,_4de,_4df,_4e0,_4e1,_4e2,_4e3,_4e4,_4e5,_4e6,_4e7,_4e8,_4e9,_4ea,_4eb,_4ec,_4ed,_4ee,_4ef,_4f0,_4f1,_4f2,_4f3,_4f4,_4f5){
this.Identifier=_4cb;
this.Identifierref=_4cc;
this.ControlChoice=_4cd;
this.ControlChoiceExit=_4ce;
this.ControlFlow=_4cf;
this.ControlForwardOnly=_4d0;
this.UseCurrentAttemptObjectiveInformation=_4d1;
this.UseCurrentAttemptProgressInformation=_4d2;
this.ConstrainChoice=_4d3;
this.PreventActivation=_4d4;
this.PreConditionSequencingRules=_4d5;
this.PostConditionSequencingRules=_4d6;
this.ExitSequencingRules=_4d7;
this.LimitConditionAttemptControl=_4d8;
this.LimitConditionAttemptLimit=_4d9;
this.LimitConditionAttemptAbsoluteDurationControl=_4da;
this.LimitConditionAttemptAbsoluteDurationLimit=_4db;
this.RollupRules=_4dc;
this.RollupObjectiveSatisfied=_4dd;
this.RollupObjectiveMeasureWeight=_4de;
this.RollupProgressCompletion=_4df;
this.MeasureSatisfactionIfActive=_4e0;
this.RequiredForSatisfied=_4e1;
this.RequiredForNotSatisfied=_4e2;
this.RequiredForCompleted=_4e3;
this.RequiredForIncomplete=_4e4;
this.PrimaryObjective=_4e5;
this.Objectives=_4e6;
this.SelectionTiming=_4e7;
this.SelectionCountStatus=_4e8;
this.SelectionCount=_4e9;
this.RandomizationTiming=_4ea;
this.RandomizeChildren=_4eb;
this.Tracked=_4ec;
this.CompletionSetByContent=_4ed;
this.ObjectiveSetByContent=_4ee;
this.HidePrevious=_4ef;
this.HideContinue=_4f0;
this.HideExit=_4f1;
this.HideAbandon=_4f2;
this.HideSuspendAll=_4f3;
this.HideAbandonAll=_4f4;
this.HideExitAll=_4f5;
}
function SequencingObjectiveMap(_4f6,_4f7,_4f8,_4f9,_4fa,_4fb,_4fc,_4fd,_4fe,_4ff,_500,_501,_502,_503,_504){
this.TargetObjectiveId=_4f6;
this.ReadSatisfiedStatus=_4f7;
this.ReadNormalizedMeasure=_4f8;
this.ReadRawScore=_4f9;
this.ReadMinScore=_4fa;
this.ReadMaxScore=_4fb;
this.ReadCompletionStatus=_4fc;
this.ReadProgressMeasure=_4fd;
this.WriteSatisfiedStatus=_4fe;
this.WriteNormalizedMeasure=_4ff;
this.WriteRawScore=_500;
this.WriteMinScore=_501;
this.WriteMaxScore=_502;
this.WriteCompletionStatus=_503;
this.WriteProgressMeasure=_504;
}
SequencingObjectiveMap.prototype.toString=function(){
return "TargetObjectiveId="+this.TargetObjectiveId+", ReadSatisfiedStatus="+this.ReadSatisfiedStatus+", ReadNormalizedMeasure="+this.ReadNormalizedMeasure+", ReadRawScore="+this.ReadRawScore+", ReadMinScore="+this.ReadMinScore+", ReadMaxScore="+this.ReadMaxScore+", ReadCompletionStatus="+this.ReadCompletionStatus+", ReadProgressMeasure="+this.ReadProgressMeasure+", WriteSatisfiedStatus="+this.WriteSatisfiedStatus+", WriteNormalizedMeasure="+this.WriteNormalizedMeasure+", WriteRawScore="+this.WriteRawScore+", WriteMinScore="+this.WriteMinScore+", WriteMaxScore="+this.WriteMaxScore+", WriteCompletionStatus="+this.WriteCompletionStatus+", WriteProgressMeasure="+this.ReadProgressMeasure;
};
function SequencingObjective(Id,_506,_507,Maps){
this.Id=Id;
this.SatisfiedByMeasure=_506;
this.MinNormalizedMeasure=_507;
this.Maps=Maps;
}
SequencingObjective.prototype.toString=function(){
var ret="Id="+this.Id+", SatisfiedByMeasure="+this.SatisfiedByMeasure+", MinNormalizedMeasure="+this.MinNormalizedMeasure;
ret+="Maps:";
for(var map in this.Maps){
ret+="{"+map+"}"+this.Maps[map]+"  ";
}
return ret;
};
function SequencingRollupRuleCondition(_50b,_50c){
this.Operator=_50b;
this.Condition=_50c;
}
SequencingRollupRuleCondition.prototype.toString=function(){
var ret="";
if(this.Operator==RULE_CONDITION_OPERATOR_NOT){
ret+="NOT ";
}
ret+=this.Condition;
return ret;
};
function SequencingRollupRule(_50e,_50f,_510,_511,_512,_513){
this.ConditionCombination=_50e;
this.ChildActivitySet=_50f;
this.MinimumCount=_510;
this.MinimumPercent=_511;
this.Action=_512;
this.Conditions=_513;
}
SequencingRollupRule.prototype.toString=function(){
var ret="If ";
if(this.ChildActivitySet==CHILD_ACTIVITY_SET_AT_LEAST_COUNT){
ret+="At Least "+this.MinimumCount+" Child Activities Meet ";
}else{
if(this.ChildActivitySet==CHILD_ACTIVITY_SET_AT_LEAST_PERCENT){
ret+="At Least "+this.MinimumPercent+" Percent of Child Activities Meet ";
}else{
if(this.ChildActivitySet==CHILD_ACTIVITY_SET_ALL){
ret+="All Child Activities Meet ";
}else{
if(this.ChildActivitySet==CHILD_ACTIVITY_SET_ANY){
ret+="Any Child Activity Meets ";
}else{
if(this.ChildActivitySet==CHILD_ACTIVITY_SET_NONE){
ret+="No Child Activity Meets ";
}
}
}
}
}
if(this.ConditionCombination==RULE_CONDITION_COMBINATION_ANY){
ret+=" Any Condition ";
}else{
ret+=" All Conditions ";
}
ret+=" THEN "+this.Action;
if(this.Conditions.length>1){
ret+=". Conditions: ";
for(var _515 in this.Conditions){
ret+="{"+_515+"} "+this.Conditions[_515]+"; ";
}
}else{
ret+=". Condition: "+this.Conditions[0];
}
return ret;
};
function SequencingRuleCondition(_516,_517,_518,_519){
this.Condition=_516;
this.ReferencedObjective=_517;
this.MeasureThreshold=_518;
this.Operator=_519;
}
SequencingRuleCondition.prototype.toString=function(){
var ret="";
if(this.ReferencedObjective!=null&&this.ReferencedObjective.length>0){
ret+="Objective "+this.ReferencedObjective+" ";
}else{
ret+="Activity ";
}
if(this.Operator==RULE_CONDITION_OPERATOR_NOT){
ret+="NOT ";
}
ret+=this.Condition;
if(this.Condition==SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN||this.Condition==SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN){
ret+=" "+this.MeasureThreshold;
}
return ret;
};
function SequencingRule(_51b,_51c,_51d){
this.ConditionCombination=_51b;
this.Action=_51c;
this.RuleConditions=_51d;
}
SequencingRule.prototype.toString=function(){
var ret="If "+this.ConditionCombination+" condition(s) evaluate to true, then "+this.Action+".  ";
if(this.RuleConditions.length>1){
ret+="Conditions: ";
for(var _51f in this.RuleConditions){
ret+="{"+_51f+"} "+this.RuleConditions[_51f]+"; ";
}
}else{
ret+="Condition: "+this.RuleConditions[0];
}
return ret;
};
function SharedDataMap(_520,_521,_522){
this.Id=_520;
this.ReadSharedData=_521;
this.WriteSharedData=_522;
}
SharedDataMap.prototype.toString=function(){
return "Id="+this.Id+", ReadSharedData="+this.ReadSharedData+", WriteSharedData="+this.WriteSharedData;
};
function SharedData(_523,_524,Data){
this.SharedDataId=_523;
this.SharedDataValId=_524;
this.Data=Data;
this.DataState=DATA_STATE_CLEAN;
}
SharedData.prototype.toString=function(){
return "SharedDataId="+this.SharedDataId+", SharedDataValId="+this.SharedDataValId+", Data="+this.Data;
};
SharedData.prototype.GetXml=SharedData_GetXml;
SharedData.prototype.GetData=SharedData_GetData;
SharedData.prototype.WriteData=SharedData_WriteData;
SharedData.prototype.SetDirtyData=SharedData_SetDirtyData;
function SharedData_GetXml(){
var _526=new ServerFormater();
var xml=new XmlElement("SD");
xml.AddAttribute("SDVI",this.SharedDataValId);
xml.AddAttribute("D",_526.TrimToLength(this.Data,64000));
return xml.toString();
}
function SharedData_GetData(){
return this.Data;
}
function SharedData_WriteData(_528){
this.Data=_528;
this.SetDirtyData();
}
function SharedData_SetDirtyData(){
this.DataState=DATA_STATE_DIRTY;
}
function SSPBucketDefinition(Id,_52a,_52b,_52c,_52d,_52e){
this.Id=Id;
this.BucketType=_52a;
this.Persistence=_52b;
this.SizeMin=_52c;
this.SizeRequested=_52d;
this.Reducible=_52e;
}
SSPBucketDefinition.prototype.toString=function(){
return "Id="+this.Id+", BucketType="+this.BucketType+", Persistence="+this.Persistence+", SizeMin="+this.SizeMin+", SizeRequested="+this.SizeRequested+", Reducible="+this.Reducible;
};
var SSP_ALLOCATION_SUCCESS_FAILURE="failure";
var SSP_ALLOCATION_SUCCESS_MINIMUM="minimum";
var SSP_ALLOCATION_SUCCESS_REQUESTED="requested";
var SSP_ALLOCATION_SUCCESS_NOT_ATTEMPTED="not attempted";
var SSP_PERSISTENCE_LEARNER="learner";
var SSP_PERSISTENCE_COURSE="course";
var SSP_PERSISTENCE_SESSION="session";
function SSPBucket(_52f,Id,_531,_532,_533,_534,_535,_536,_537,Data){
this.BucketIndex=CleanExternalString(_52f);
this.Id=CleanExternalString(Id);
this.BucketType=CleanExternalString(_531);
this.Persistence=CleanExternalString(_532);
this.SizeMin=parseInt(CleanExternalString(_533),10);
this.SizeRequested=parseInt(CleanExternalString(_534),10);
this.Reducible=CleanExternalString(_535).toBoolean();
this.LocalActivityId=CleanExternalString(_536);
this.AllocationSuccess=CleanExternalString(_537);
this.Data=CleanExternalString(Data);
this.DataState=DATA_STATE_CLEAN;
}
SSPBucket.prototype.toString=function(){
return "BucketIndex="+this.Index+"Id="+this.Id+", BucketType="+this.BucketType+", Persistence="+this.Persistence+", SizeMin="+this.SizeMin+", SizeRequested="+this.SizeRequested+", Reducible="+this.Reducible+", LocalActivityId="+this.LocalActivityId+", AllocationSuccess="+this.AllocationSuccess+", Data="+this.Data;
};
SSPBucket.prototype.GetXml=SSPBucket_GetXml;
SSPBucket.prototype.IsVisible=SSPBucket_IsVisible;
SSPBucket.prototype.CurrentlyUsedStorage=SSPBucket_CurrentlyUsedStorage;
SSPBucket.prototype.GetBucketState=SSPBucket_GetBucketState;
SSPBucket.prototype.GetData=SSPBucket_GetData;
SSPBucket.prototype.WriteData=SSPBucket_WriteData;
SSPBucket.prototype.SetDirtyData=SSPBucket_SetDirtyData;
SSPBucket.prototype.AppendData=SSPBucket_AppendData;
SSPBucket.prototype.SizeAllocated=SSPBucket_SizeAllocated;
SSPBucket.prototype.ResetData=SSPBucket_ResetData;
function SSPBucket_GetXml(){
var _539=new ServerFormater();
var xml=new XmlElement("SSP");
xml.AddAttribute("IN",this.BucketIndex);
xml.AddAttribute("ID",_539.TrimToLength(this.Id,4000));
xml.AddAttribute("BT",_539.TrimToLength(this.BucketType,4000));
xml.AddAttribute("P",_539.ConvertSSPPersistence(this.Persistence));
xml.AddAttribute("SM",this.SizeMin);
xml.AddAttribute("SR",this.SizeRequested);
xml.AddAttribute("R",_539.ConvertBoolean(this.Reducible));
xml.AddAttribute("LAI",this.LocalActivityId);
xml.AddAttribute("AS",_539.ConvertSSPAllocationSuccess(this.AllocationSuccess));
xml.AddAttribute("D",this.Data);
return xml.toString();
}
function SSPBucket_IsVisible(_53b){
if(this.LocalActivityId==""||this.LocalActivityId==null||this.LocalActivityId==_53b){
return true;
}
return false;
}
function SSPBucket_CurrentlyUsedStorage(){
return this.Data.length*2;
}
function SSPBucket_GetBucketState(){
var _53c="";
var _53d=this.SizeAllocated();
_53c="{totalSpace="+((_53d!=null)?_53d:0)+"}";
_53c+="{used="+this.CurrentlyUsedStorage()+"}";
if(this.BucketType!=null&&this.BucketType.length>0){
_53c+="{type="+this.BucketType+"}";
}
return _53c;
}
function SSPBucket_GetData(_53e,size){
if(_53e==null||_53e.length==0){
_53e=0;
}else{
_53e=parseInt(_53e,10);
}
if(size==null||size.length==0){
size=0;
}else{
size=parseInt(size,10);
}
_53e=_53e/2;
size=size/2;
var str=new String();
if(size>0){
return this.Data.substr(_53e,size);
}else{
return this.Data.substr(_53e);
}
}
function SSPBucket_WriteData(_541,_542){
if(_541==null||_541.length==0){
_541=0;
}else{
_541=parseInt(_541,10);
}
_541=_541/2;
if(_541==0){
this.Data=_542;
}else{
var _543=this.Data.slice(0,_541);
var _544="";
if(_541+_542.length<this.Data.length){
_544=this.Data.slice(_541+_542.length);
}
this.Data=_543+_542+_544;
}
this.SetDirtyData();
}
function SSPBucket_AppendData(_545){
this.Data+=_545;
this.SetDirtyData();
}
function SSPBucket_SetDirtyData(){
this.DataState=DATA_STATE_DIRTY;
}
function SSPBucket_SizeAllocated(){
var _546;
switch(this.AllocationSuccess){
case SSP_ALLOCATION_SUCCESS_FAILURE:
_546=null;
break;
case SSP_ALLOCATION_SUCCESS_MINIMUM:
_546=this.SizeMin;
break;
case SSP_ALLOCATION_SUCCESS_REQUESTED:
_546=this.SizeRequested;
break;
case SSP_ALLOCATION_SUCCESS_NOT_ATTEMPTED:
_546=0;
break;
default:
Debug.AssertError("Invalid allocation success");
break;
}
return _546;
}
function SSPBucket_ResetData(){
this.Data="";
this.SetDirtyData();
}

dictionary_ll={"delimiter":"`","1152":" (and all its descendents) will be skipped.","1014":" (and all of its descendents) should be disabled. ","1052":" (and all of its descendents) should be hidden. ","597":" (and all of its descendents) will be disabled because its attempt limit has been reached. ","520":" (and all of its descendents) will be hidden because its Prevent Activation attribute is set to true. ","1632":" ; Exception: n/a)","1744":" and ","1094":" and all its descendents to skipped. IsActive=","1430":" and all of its descendents.","1633":" are not siblings.","1710":" are siblings.","716":" because it has a stop forward traversal precondition rule and is a cluster.","753":" because it has a stop forward traversal precondition rule and is a leaf.","898":" because it has a stop forward traversal precondition rule.","1388":" do not have a common ancestor","606":" does not allow choice exit requests. Hiding all activities that are not its descendents.","876":" does not allow flow navigation. Flow navigation is disabled.","842":" does not allow previous navigation. Previous button is disabled.","1319":" does not have suspended children.","1221":" has Sequencing Control Choice = false).","1511":" has suspended children.","1719":" hundredths)","1746":" is ","1239":" is a descendent and will be disabled. ","1276":" is a descendent and will be hidden. ","843":" is a forward sibling so it and its descendents will be disabled.","1534":" is after the activity ","1512":" is before the activity ","1277":" is currently active, stop disabling.","1222":" is not a descendent and will be hidden.","784":" is not a descendent of the previous/next activity and will be hidden.","1345":" is not the last overall activity","1409":" is the last overall activity","55":" only allows it immediate siblings to be selected (constrained choice). Only activities that are logically next or previous and their descendents (plus the root) are all valid targets for choice, hiding all other activities.","785":" since it does not allow flow navigation. Previous button is disabled.","129":" since it does not allow flow navigation. Stopping here, continue button stays enabled even though request won't succeed. Continue results in user being prompted to select a child item.","786":" since it only allows forward navigation. Previous button is disabled.","1410":" will Stop Forward Traversal.","361":" will be disabled because it is a cluster that does not allow flow navigation and thus its children must be selected explicitly.","796":" will be disabled because its parent does not allow choice requests (","844":" will be hidden because its isVisible attribute is set to false. ","38":" will not succeed. Not initiating SCO unload yet. The EvaluatePossibleNavigationRequests will check to see if the nav request will succeed after re-evaluating all dirty data and if it will succeed, the SCO will be unloaded and it will be invoked.","1474":" would flow to a cluster (","1431":" would flow to an activity (","1694":"' + operand + '","1733":"' From GUI","1475":"' corresponds to activity ","1223":"' does not correspond to valid activity.","1255":"' does not represent a valid activity.","1389":"' represents a valid activity.","1747":"', '","1554":") (Nothing to deliver)","964":") (The current activity must have already been exited)","1495":") (Violates control mode)","1513":") Violates control mode.","1376":") and the identified activity (","928":") and we're starting a new attempt on the root activity (","941":") and we're starting a new attempt on the root activity.","1377":") divided by counted measures (","744":") from the runtime will succeed now after re-evaluating with current data.","1169":") is Active for the activity is False Then","1682":") is a leaf Then","953":") is not a leaf Then - Can only deliver leaf activities","1720":") is tracked","1555":") is tracked, tracked=","1015":") that does not permit flow navigation, disabling.","1016":") that has a limit condition violation, disabling.","1390":") that is disabled, disabling.","532":") to the rollup condition bag (Add the evaluation of this condition the set of evaluated conditions)","285":") to the rollup condition bag to produce a single combined rule evaluation ('And' or 'Or' set of evaluated conditions, on the rollup definition)","669":"), but Progress Measure is unknown, therefore CompletionStatus is unknown as well","1734":"). Equals ","1256":"**************************************","1602":", CompletionStatus=","1452":", Objective Measure Weight=","1711":", attempted = ","704":", had reached its attempt limit and cannot be delivered. Disable next button.","670":", had reached its attempt limit and cannot be delivered. Disable previous button.","899":", is disabled and cannot be delivered. Disable next button.","865":", is disabled and cannot be delivered. Disable previous button.","1737":", isExit=","1695":", notSatisfied=","1715":", returning 0","1712":", strPostData=","1303":", this.Api.NeedToCloseOutSession()=","1411":", this.ExitScormPlayerCalled=","1721":". Exception=","223":"7.1.1.3.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception ","1535":"; Traversal Direction: ","1304":"API Runtime Nav Request Detected = ","871":"About to save final data upon player exit, final exit calls = ","1725":"Activities ","1170":"Activity Progress Rollup Process [RB.1.3](","907":"Activity Progress Rollup Using Default Process [RB.1.3 a](","908":"Activity Progress Rollup Using Measure Process [RB.1.3 a](","942":"Activity Progress Rollup Using Rules Process [RB.1.3 b](","1124":"Adding new Comment From Learner at position ","984":"Adding new Interaction Correct Response at position ","1107":"Adding new Interaction Objective at position ","1305":"Adding new Interaction at position ","1346":"Adding new Objective at position ","1306":"Adding new interaction at position ","1391":"Adding new objective at index ","1556":"Allowing status change","533":"Bypassing Lookahead Sequencer processing because PackageProperties.LookaheadSequencerMode = disabled","1603":"Call is error free.","965":"Calling Integration Implementation UpdateControl State","1392":"Check Activity Process [UP.5](","1108":"Check Child for Rollup Subprocess [RB.1.4.2](","1536":"CheckForGetValueError (","1537":"CheckForSetValueError (","1496":"Checking for Commit Error","1497":"Checking for Finish Error","1453":"Checking for GetValue Error","1412":"Checking for Initialize Error","1432":"Checking for Terminate Error","1393":"Checking for first SCO pretest","1278":"Checking for valid choice nav request","1171":"Checking for valid choice/jump nav request","1291":"Checking to see if the nav request (","1095":"Choice Activity Traversal Subprocess [SB.2.4](","1320":"Choice Flow Subprocess [SB.2.9.1](","1031":"Choice Flow Tree Traversal Subprocess [SB.2.9.2](","1153":"Choice Sequencing Request Process [SB.2.9](","1109":"Clear Suspended Activity Subprocess [DB.2.1](","1454":"Clearing Suspended Activity","1655":"Cloning sequencer","1656":"Close Out Session","1726":"Closing Sco","1739":"Commit('","1072":"Communications Call Failed, Failed Submissions=","1257":"Communications Save Data, synchronous=","1321":"Communications_KillPostDataProcess","1476":"Communications_SaveDataNow","1413":"Communications_SaveDataOnExit","1307":"Communications_StartPostDataProcess","1571":"CompletedByMeasure = ","648":"CompletedByMeasure is not enabled, using the completion status recorded by the SCO-","1110":"Completion Measure Rollup Process [RB.1.1 b](","1538":"Completion Threshold = ","992":"Completion Threshold is known (Completion Treshold=","623":"Completion Threshold is not specified, using the completion status recorded by the SCO-","1604":"CompletionStatus = ","1125":"Content Delivery Environment Process [DB.2](","1126":"Continue Sequencing Request Process [SB.2.7]","1279":"Control ClearPendingNavigationRequest","1455":"Control CreateMenuItem for ","1477":"Control DeliverActivity - ","1539":"Control DisplayError - ","1111":"Control Evaluate Possible Navigation Requests","1514":"Control GetExceptionText","1478":"Control GetXmlForDirtyData","1634":"Control Initialize","1515":"Control IsThereDirtyData","1456":"Control MarkDirtyDataPosted","1457":"Control MarkPostedDataClean","1458":"Control MarkPostedDataDirty","1112":"Control Recieved Abandon All Request From GUI","1204":"Control Recieved Abandon Request From GUI","1280":"Control Recieved Choice Request For '","1308":"Control Recieved Close Sco From GUI","1172":"Control Recieved Exit All Request From GUI","1258":"Control Recieved Exit Request From GUI","1259":"Control Recieved Next Request From GUI","1173":"Control Recieved Previous Request From GUI","1240":"Control Recieved Return To Lms From GUI","1205":"Control Recieved Suspend Request From GUI","1459":"Control RenderMenuItem for ","1394":"Control ScoUnloaded called by ","1433":"Control ToggleMenuVisibility","1479":"Control TriggerReturnToLMS","1281":"Control Unload: this.ProcessedUnload=","1557":"Control Update Display","1738":"Credit = ","1460":"Current Activity is defined","1378":"Current Activity is not defined","909":"Current status is not attempted so changing based on score","264":"DB.2]1.1. Exit Content Delivery Environment Process (Exception: DB.2-1) (Delivery request is invalid - The Current Activity has not been terminated)","1635":"Deliver activity: ","1322":"Delivery Request Process [DB.1.1](","1540":"Deliverying Activity - ","1127":"Done Evaluating Possible Navigation Requests","966":"ERROR - Invalid server response received from the LMS.","370":"ERROR - LMS was unable to successfully save state date, see the LMS response for specific error information. Server Response=","562":"ERROR - Server side error occurred when saving state data, HTTP response not 200 (OK). Status: ","1359":"ERROR - invalid rollup condition","1379":"ERROR - invalid success status-","246":"Either activity.HasSeqRulesRelevantToChoice = false or possibleNavRequest.WillNeverSucceed = true.  Setting possibleNavRequest.WillAlwaysSucceed = false.","1605":"Element Not Matched","1587":"Element is: _version","1461":"Element is: adl nav request","1323":"Element is: adl nav request choice","1360":"Element is: adl nav request jump","1174":"Element is: adl nav request valid continue","1175":"Element is: adl nav request valid previous","1395":"Element is: adl.data._children","1462":"Element is: adl.data._count","1541":"Element is: adl.data.id","1498":"Element is: adl.data.n.id","1434":"Element is: adl.data.n.store","1480":"Element is: adl.data.store","1499":"Element is: adl.data.type","1463":"Element is: adl.nav.request","1224":"Element is: adl.nav.request_valid.choice","1176":"Element is: adl.nav.request_valid.continue","1260":"Element is: adl.nav.request_valid.jump","1177":"Element is: adl.nav.request_valid.previous","1657":"Element is: audio","1435":"Element is: audio captioning","1542":"Element is: audio level","1516":"Element is: audion level","1588":"Element is: comments","1225":"Element is: comments from leaner.comment","1178":"Element is: comments from learner.location","1154":"Element is: comments from learner.timestamp","1414":"Element is: comments from lms","1179":"Element is: comments, storing at position ","1155":"Element is: comments_from_learner._children","1226":"Element is: comments_from_learner._count","1206":"Element is: comments_from_learner.comment","1180":"Element is: comments_from_learner.location","1156":"Element is: comments_from_learner.n.comment","1128":"Element is: comments_from_learner.n.location","1113":"Element is: comments_from_learner.n.timestamp","1157":"Element is: comments_from_learner.timestamp","1181":"Element is: comments_from_learner_children","1241":"Element is: comments_from_lms._children","1292":"Element is: comments_from_lms._count","1282":"Element is: comments_from_lms.comment","1261":"Element is: comments_from_lms.location","1242":"Element is: comments_from_lms.n.comment","1227":"Element is: comments_from_lms.n.location","1207":"Element is: comments_from_lms.n.timestamp","1243":"Element is: comments_from_lms.timestamp","1361":"Element is: completion threshold","1415":"Element is: completion_status","1362":"Element is: completion_threshold","1481":"Element is: core._children","1500":"Element is: core._version","1636":"Element is: credit","1501":"Element is: deliver speed","1482":"Element is: delivery speed","1658":"Element is: entry","1683":"Element is: exit","1416":"Element is: interacitons.type","1324":"Element is: interactions._children","1380":"Element is: interactions._count","1017":"Element is: interactions.correct responses.pattern","1032":"Element is: interactions.correct_responses._count","1018":"Element is: interactions.correct_responses.pattern","1053":"Element is: interactions.corret_responses._count","1293":"Element is: interactions.description","1464":"Element is: interactions.id","1363":"Element is: interactions.latency","1208":"Element is: interactions.learner_response","993":"Element is: interactions.n.correct_responses._count","967":"Element is: interactions.n.correct_responses.n.pattern","1262":"Element is: interactions.n.description","1417":"Element is: interactions.n.id","1325":"Element is: interactions.n.latency","1158":"Element is: interactions.n.learner_response","1129":"Element is: interactions.n.objectives._count","1182":"Element is: interactions.n.objectives.n.id","1347":"Element is: interactions.n.result","1294":"Element is: interactions.n.timestamp","1381":"Element is: interactions.n.type","1295":"Element is: interactions.n.weighting","1183":"Element is: interactions.objectives._count","1263":"Element is: interactions.objectives.id","1382":"Element is: interactions.result","1209":"Element is: interactions.student_response","1418":"Element is: interactions.text","1419":"Element is: interactions.time","1326":"Element is: interactions.timestamp","1420":"Element is: interactions.type","1327":"Element is: interactions.weighting","1589":"Element is: language","1543":"Element is: launch data","1544":"Element is: launch_data","1558":"Element is: learner id","1517":"Element is: learner name","1559":"Element is: learner_id","1518":"Element is: learner_name","1228":"Element is: learner_preference._children","1073":"Element is: learner_preference.audio_captioning","1184":"Element is: learner_preference.audio_level","1114":"Element is: learner_preference.delivery_speed","1244":"Element is: learner_preference.language","1465":"Element is: lesson location","1545":"Element is: lesson mode","1502":"Element is: lesson status","1466":"Element is: lesson_location","1503":"Element is: lesson_status","1590":"Element is: location","1504":"Element is: mastery score","1436":"Element is: max time allowed","1437":"Element is: max_time_allowed","1684":"Element is: mode","1185":"Element is: nteractions.n.learner_response","1364":"Element is: objectives._children","1421":"Element is: objectives._count","1229":"Element is: objectives.completion_status","1328":"Element is: objectives.description","1505":"Element is: objectives.id","1186":"Element is: objectives.n.completion_status","1296":"Element is: objectives.n.description","1467":"Element is: objectives.n.id","1210":"Element is: objectives.n.progress_measure","1230":"Element is: objectives.n.score._children","1329":"Element is: objectives.n.score.max","1330":"Element is: objectives.n.score.min","1331":"Element is: objectives.n.score.raw","1283":"Element is: objectives.n.score.scaled","1245":"Element is: objectives.n.success_status","1246":"Element is: objectives.progress_measure","1264":"Element is: objectives.score._children","1365":"Element is: objectives.score.max","1366":"Element is: objectives.score.min","1367":"Element is: objectives.score.raw","1309":"Element is: objectives.score.scaled","1310":"Element is: objectives.score_scaled","1422":"Element is: objectives.status","1284":"Element is: objectives.success_status","1438":"Element is: progress measure","1439":"Element is: progress_measure","1368":"Element is: scaled passing score","1369":"Element is: scaled_passing_score","1468":"Element is: score._children","1572":"Element is: score.max","1573":"Element is: score.min","1574":"Element is: score.raw","1519":"Element is: score.scaled","1520":"Element is: session time","1521":"Element is: session_time","1659":"Element is: speed","1560":"Element is: ssp._count","1522":"Element is: ssp.allocate","1483":"Element is: ssp.appendData","1440":"Element is: ssp.bucket_state","1591":"Element is: ssp.data","1297":"Element is: ssp.n.allocation_success","1441":"Element is: ssp.n.appendData","1469":"Element is: ssp.n.bucket_id","1396":"Element is: ssp.n.bucket_state","1561":"Element is: ssp.n.data","1592":"Element is: ssp.n.id","1562":"Element is: student id","1523":"Element is: student name","1332":"Element is: student_data._children","1231":"Element is: student_preference._children","1484":"Element is: success status","1485":"Element is: success_status","1524":"Element is: suspend data","1525":"Element is: suspend_data","1685":"Element is: text","1423":"Element is: time limit action","1424":"Element is: time_limit_action","1563":"Element is: total time","1564":"Element is: total_time","1606":"Element is: version","1470":"End Attempt Process [UP.4](","985":"Evaluate Possible Navigation Requests Process [EPNR]","1033":"Evaluate Rollup Conditions Subprocess [RB.1.4.1](","1311":"Evaluate Sequencing Rule Condition(","1211":"Exit Sequencing Request Process [SB.2.11]","1370":"Exiting Control Deliver Activity","1397":"Exiting Control Update Display","1130":"Flow Activity Traversal Subprocess [SB.2.2](","1506":"Flow Subprocess [SB.2.3](","1232":"Flow Tree Traversal Subprocess [SB.2.1](","1526":"Found Dirty Data to Save","1471":"Generating Exit Nav Request","1333":"Generating Suspend All Nav Request","1696":"GetDiagnostic('","1686":"GetErrorString('","1713":"GetLastError()","1312":"GetSequencingControlChoice = false.","1735":"GetValue('","1472":"In ScoHasTerminatedSoUnload","1348":"In SendDataToServer, synchronous=","1313":"Initial Selection and Randomization","1722":"Initialize('","1723":"Initialized ","1019":"Initializing Possible Navigation Request Absolutes","1212":"Initializing Possible Navigation Requests","442":"Invoking ScoHasTerminatedSoUnload from Terminate, scheduled for 150 ms. Control.IsThereAPendingNavigationRequest() = ","1213":"Jump Sequencing Request Process [SB.2.13]","1727":"LMSCommit('","1728":"LMSFinish('","1637":"LMSGetDiagnostic('","1607":"LMSGetErrorString('","1660":"LMSGetLastError()","1716":"LMSGetValue('","1697":"LMSInitialize('","1717":"LMSSetValue('","1349":"Launching intermediate page from ","1265":"Limit Conditions Check Process [UP.1](","1442":"Loading Sco In Frameset at: ","1350":"Lookahead Sequencer Mode Disabled","1371":"Lookahead Sequencer Mode Enabled","1698":"MasteryScore = ","1729":"Max Score: ","1372":"Measure Rollup Process [RB.1.1](","1730":"Min Score: ","276":"Missing mastery score or raw score, but skipping auto-completion because compatibility setting ForceObjectiveCompletionSetByContent is set to true","943":"Missing mastery score or raw score, setting to completed","1741":"Mode = ","1398":"Mode is review so don't change","12":"NB.2.1]4.2.1. If the Sequencing Control Flow for the parent of the Current Activity is True And the Sequencing Control Forward Only for the parent of the Current Activity is False Then (Validate that a 'flow' sequencing request can be processed from the current activity)","1034":"Nav request will NOT succeed. Leaving SCO loaded.","1233":"Nav request will succeed. Unloading SCO.","1298":"Navigation Request Process [NB.2.1](","1687":"New Total Time: ","1334":"New Tracked Total Time for Asset: ","1527":"New Tracked Total Time: ","1593":"Next entry is normal","1594":"Next entry is resume","1234":"No API Runtime Nav Request, exit action=","1638":"No interaction at ","1399":"No navigation request, exiting","1266":"Not tracked...not transfering RTE data","1020":"Objective Rollup Using Default Process [RB.1.2 c](","1021":"Objective Rollup Using Measure Process [RB.1.2 a](","1054":"Objective Rollup Using Rules Process [RB.1.2 b](","1351":"Objective RollupProcess [RB.1.2](","954":"Objective element is undefined, returning empty string.","1373":"Overall Rollup Process [RB.1.5](","1352":"Overall Sequencing Process [OP.1]","1022":"OverallSequencingProcess for SCORM 1.1 / SCORM 1.2","722":"Package had non-legacy setting for ReturnToLMS, but does not use SCORM 2004","1159":"Performing sequencing look ahead evaluation","1425":"Pre-evaluation of exit action","1023":"Pretest satisfied, marking all activities complete","1131":"Previous Sequencing Request Process [SB.2.8]","1699":"Previous Time: ","1608":"Progress Measure = ","615":"Progress Measure exceeds Completion Threshold so setting completion status to completed.","569":"Progress Measure is less than Completion Threshold so setting completion status to incomplete.","1546":"RB.1.1]5.1.2. Break For","1335":"Randomize Children Process [SR.2](","1443":"Recorded CompletionStatus = ","1507":"Recorded SuccessStatus = ","1096":"Resume All Sequencing Request Process [SB.2.6]","1565":"RetrieveGetValueData (","1187":"Retry Sequencing Request Process [SB.2.10]","1528":"Rolling up activity data","1267":"Rollup Rule Check Subprocess [RB.1.4](","1299":"Rollup will skip blocked activities.","1661":"Root Activity is ","1353":"RunTimeApi_ImmediateRollup called","1214":"RunTimeApi_IsValidArrayOfLocalizedStrings","1215":"RunTimeApi_IsValidArrayOfShortIdentifiers","1575":"RunTimeApi_IsValidUrn","1486":"RunTimeApi_ValidCharString","1400":"RunTimeApi_ValidFillInResponse","1487":"RunTimeApi_ValidIdentifier","1529":"RunTimeApi_ValidLanguage","1401":"RunTimeApi_ValidLikeRTResponse","1383":"RunTimeApi_ValidLocalizedString","1336":"RunTimeApi_ValidLongFillInResponse","1402":"RunTimeApi_ValidLongIdentifier","1374":"RunTimeApi_ValidMatchingResponse","1268":"RunTimeApi_ValidMultipleChoiceResponse","1384":"RunTimeApi_ValidNumericResponse","1444":"RunTimeApi_ValidOtheresponse","1314":"RunTimeApi_ValidPerformanceResponse","1595":"RunTimeApi_ValidReal","1337":"RunTimeApi_ValidSequencingResponse","1385":"RunTimeApi_ValidShortIdentifier","1596":"RunTimeApi_ValidTime","1445":"RunTimeApi_ValidTimeInterval","1354":"RunTimeApi_ValidTrueFalseResponse","13":"SB.2.9]11.9.1.1. If Activity is Active for the activity is False And (the activity is Not the common ancestor And adlseq:preventActivation for the activity is True) Then (If the activity being considered is not already active, make sure we are allowed to activate it)","14":"SB.2.9]12.9.1.1. If Activity is Active for the activity is False And (the activity is Not the common ancestor And adlseq:preventActivation for the activity is True) Then (If the activity being considered is not already active, make sure we are allowed to activate it)","929":"SCO requested a Suspend All, setting exit type to suspend","1285":"SCORM ERROR FOUND - Set Error State: ","1547":"SSP Call is error free.","570":"Scaled Passing Score is known, but score is unknown, therefore SuccessStaus is unknown as well","640":"Scaled Passing Score is not specified, using the success status recorded by the SCO-","696":"Scaled Score exceeds Scaled Passing Score so setting success status to passed.","649":"Scaled Score is less than Scaled Passing Score so setting success status to failed.","1576":"ScaledPassingScore = ","810":"Sco is completed so resetting credit to no-credit and mode to review","1530":"Sco was taken for credit","1740":"Score = ","1235":"Score exceeds mastery, setting to passed","1188":"Score less than mastery, setting to failed","1386":"Select Children Process [SR.1](","1055":"Sequencing Exit Action Rules Subprocess [TB.2.1]","994":"Sequencing Post Condition Rules Subprocess [TB.2.2]","1286":"Sequencing Request Process [SB.2.12](","1269":"Sequencing Rules Check Process [UP.2](","1160":"Sequencing Rules Check Subprocess [UP.2.1](","1566":"Server Responded With:","1714":"Session Time: ","1736":"SetValue('","1446":"Setting Current Activity to ","834":"Setting WillNeverSucceed = true on all child activities. (Count = ","1300":"Setting completion status to browsed","1074":"Setting sequencer pointer for cloned activities","224":"Skipping ContentDeliveryEnvironmentActivityDataSubProcess because content is LAUNCH AFTER CLICK.  This method will get called when activity is actually viewed","1447":"Skipping blocked activity : ","1216":"Start Sequencing Request Process [SB.2.5]","754":"Status has been set, checking to override to passed/failed based on score","1448":"StatusSetInCurrentSession = ","1724":"StoreValue (","1731":"Stored as: ","1688":"SuccessStatus = ","1567":"Suspended Activity is ","1426":"Suspended Activity is defined","1355":"Suspended Activity is not defined","397":"SuspendedActivityDefined[SB.2.6]2. If the Suspended Activity is Not Defined Then (Make sure there is something to resume)","1609":"Suspending Activity","341":"Suspending Activity (no nav request because the package property LogoutCausesPlayerExit precludes logout from causing a suspend all)","475":"TB.2.3]3.3.3. If the Sequencing Post Condition Rule Subprocess returned a termination request of Exit All Then","181":"TB.2.3]3.4. If the Current Activity is the Root of the Activity Tree AND the sequencing request returned by the Sequencing Post Condition Rule Subprocess is not Retry Then","452":"TB.2.3]3.4.1. Exit Termination Request Process (Termination Request: Valid; Sequencing Request: Exit; Exception n/a)","910":"TB.2.3]3.5. Until processed exit is False (processed exit=","1568":"Tearing down sequencer","1115":"Terminate Descendent Attempts Process [UP.3](","1732":"Terminate('","1287":"Termination Request Process [TB.2.3](","835":"The Return To LMS button should be not be available for selection.","1700":"The activities ","1718":"The activity ","1338":"The common ancestor of activities ","1689":"The identifier '","1339":"The runtime navigation request of ","775":"This activity utilized a launchable Asset, so automatically complete it","845":"Time limit exceeded, automatically returning user from the course","1116":"Time limit exceeded, blocking entry to course","1270":"Transferring RTE data to Activity data","417":"UP.1]10. Exit Limit Conditions Check Process (Limit Condition Violated: False) (No limit conditions have been violated)","995":"UnLoading Sco and launching intermediate page from ","1315":"Updating display for each menu item","911":"User requested a Suspend All, setting exit type to suspend","1035":"WARNING - Unable to normalize score - Raw Score: ","349":"WARNING: The value 'logout' has been deprecated by ADL and should no longer be used. This value may lead to unpredictable behavior.","1597":"WillAlwaysSucceed = ","1610":"WillNeverSucceed = ","872":"[DB.1.1]1. If the activity specified by the delivery request (","581":"[DB.1.1]1.1. Exit Delivery Request Process (Delivery Request: Not Valid; Exception: DB.1.1-1)","207":"[DB.1.1]2. Form the activity path as the ordered series of activities from the root of the activity tree to the activity specified in the delivery request, inclusive","836":"[DB.1.1]3. If the activity path is Empty Then - Nothing to deliver","582":"[DB.1.1]3.1. Exit Delivery Request Process (Delivery Request: Not Valid; Exception: DB.1.1-2)","528":"[DB.1.1]4. For each activity in the activity path - Make sure each activity along the path is allowed","857":"[DB.1.1]4.1. Apply the Check Activity Process to the activity - ","900":"[DB.1.1]4.2. If the Check Activity Process return True Then","563":"[DB.1.1]4.2.1. Exit Delivery Request Process (Delivery Request: Not Valid; Exception: DB.1.1-3)","658":"[DB.1.1]5. Exit Delivery Request Process (Delivery Request: Valid; Exception: n/a)","604":"[DB.2.1]1. If the Suspended Activity is Defined Then Make sure there is something to clear","598":"[DB.2.1]1.1. Find the common ancestor of the identified activity and the Suspended Activity","342":"[DB.2.1]1.2. Form an activity path as the ordered series of activities from the Suspended Activity to the common ancestor, inclusive","996":"[DB.2.1]1.3. If the activity path is Not Empty Then","334":"[DB.2.1]1.3.1. For each activity in the activity path (Walk down the tree setting each of the identified activities to not suspended)","1075":"[DB.2.1]1.3.1.1. If the activity is a leaf Then","787":"[DB.2.1]1.3.1.1.1. Set Activity is Suspended for the activity to False","1577":"[DB.2.1]1.3.1.2. Else","398":"[DB.2.1]1.3.1.2.1. If the activity does not include any child activity whose Activity is Suspended attribute is True Then","766":"[DB.2.1]1.3.1.2.1.1. Set Activity is Suspended for the activity to False","607":"[DB.2.1]1.4. Set Suspended Activity to Undefined (Clear the Suspended Activity attribute)","997":"[DB.2.1]2. Exit Clear Suspended Activity Subprocess","200":"[DB.2]1.If the Activity is Active for the Current Activity is True Then (If the attempt on the current activity has not been terminated, we cannot deliver new content)","208":"[DB.2]2. If the activity identified for delivery is not equal to the Suspended Activity Then (Content is about to be delivered, clear any existing suspend all state)","554":"[DB.2]2.1. Apply the Clear Suspended Activity Subprocess to the activity identified for delivery","230":"[DB.2]3. Apply the Terminate Descendent Attempts Process to the activity identified for delivery (Make sure that all attempts that should end are terminated)","66":"[DB.2]4.Form the activity path as the ordered series of activities from the root of the activity tree to the activity identified for delivery, inclusive (Begin all attempts required to deliver the identified activity)","1076":"[DB.2]5. For each activity in the activity path","1531":"[DB.2]5.1. If Activity (","978":"[DB.2]5.1.1. If Tracked for the activity is True Then","114":"[DB.2]5.1.1.1. If Activity is Suspended for the activity is True Then (If the previous attempt on the activity ended due to a suspension, clear the suspended state; do not start a new attempt)","811":"[DB.2]5.1.1.1.1. Set Activity is Suspended for the activity to False","1611":"[DB.2]5.1.1.2. Else","485":"[DB.2]5.1.1.2.1. Increment the Activity Attempt Count for the activity (Begin a new attempt on the activity)","357":"[DB.2]5.1.1.2.2. If Activity Attempt Count for the activity is equal to One (1) Then (Is this the first attempt on the activity?)","767":"[DB.2]5.1.1.2.2.1. Set Activity Progress Status for the activity to True","161":"[DB.2]5.1.1.2.3. Initialize Objective Progress Information and Attempt Progress Information required for the new attempt. Initialize tracking information for the new attempt.","797":"[DB.2]5.1.1.2.4. If objectives global to system is false (obj global=","544":"[DB.2]5.1.1.2.4.1. Reset any global objectives and initialize the activity tree for a new attempt.","697":"[DB.2]5.1.1.2.5. If shared data global to system is false (shared data global=","671":"[DB.2]5.1.1.2.5.1. Reset any shared data associated with this attempt on content.","888":"[DB.2]5.1.2. Set Activity is Active for the activity to True","231":"[DB.2]6. The activity identified for delivery becomes the current activity Set Current Activity to the activity identified for delivery. Identified Activity=","1132":"[DB.2]7. Set Suspended Activity to undefined","820":"[DB.2]8. Exit Content Delivery Environment Process (Exception: n/a)","821":"[DB.2]9. Exit Content Delivery Environment Process (Exception: n/a)","1743":"[EPNR]","1742":"[EPNR] ","788":"[EPNR] 1. Run the navigation request process for each possible request","755":"[EPNR] 1.1. If the navigation request fails, set its WillSucceed to false","723":"[EPNR] 1.2. If the navigation request succeeds, set its WillSucceed to true","215":"[EPNR] 2. If the current activity is active (we are going to need to terminate it for internally navigating sequencing requests (continue, previous, choice, exit)","955":"[EPNR] 2.1 Run the Termination Request Process for Exit","514":"[EPNR] 2.2 There's a rare situation where the suspend all termination request can fail, so check for it","912":"[EPNR] 2.2 if the termination request process return false","858":"[EPNR] 2.2.1 Run the Termination Request Process For Suspend All","717":"[EPNR] 2.2.1 Set the possible navigations that result in sequencing to false","293":"[EPNR] 2.3 If there's an exit all request, the termination request process performs sequencing actions that are relevant later on, so do those.","659":"[EPNR] 2.5. For each possible navigation request that hasn't already been excluded","866":"[EPNR] 2.5.1. Check for disabled and limit condition violations","745":"[EPNR] 2.5.1.1. Activity is disabled, mark it and its children as disabled","677":"[EPNR] 3. For each possible navigation request that hasn't already been excluded","624":"[EPNR] 3.1 If there is a sequencing request returned by the termination request process","418":"[EPNR] 3.1.1 Run the sequencing request process for that sequencing request returned by the termination request process","1036":"[EPNR] 3.1.2 Make sure the activity is not hidden","1639":"[EPNR] 3.1.2. Else","718":"[EPNR] 3.1.3. Run the sequencing request process for that navigation request","837":"[EPNR] 3.2. If the Sequencing Request Process returns an exception","1288":"[EPNR] 3.2.1 Set WillSucceed to false","1117":"[EPNR] 3.2.2 Run the Delivery Request Process","705":"[EPNR] 3.2.2 Set will succed to the results of the delivery request process (","362":"[EPNR] 4. Set any requests that are invalid due to Control Choice, Prevent Activation or Constrained Choice violations to hidden","1488":"[EPNR] 4.1 Hiding request ","430":"[EPNR] 5.1 Overriding continue status based on 3rd Edition GUI requirements, parent's flow = true, continue is enabled","405":"[EPNR] 5.2 Overriding continue status based on 3rd Edition GUI requirements, parent's flow = false, continue is disabled","1189":"[EPNR] A precondition rule indicates that ","1403":"[EPNR] A precondition rule on ","1289":"[EPNR] Cannot flow backwards through ","1473":"[EPNR] Cannot flow through ","390":"[EPNR] Check each activity for sequencing rules that are independent of context (i.e. independent of the current activity)","812":"[EPNR] Check rules that rely on the context of the current activity.","986":"[EPNR] Clearing out possible navigation request data","838":"[EPNR] Current activity is undefined, flow navigation is disabled.","724":"[EPNR] Current activity is undefined, not checking context dependent rules.","1701":"[EPNR] Disable ","1340":"[EPNR] Disable the descendents of ","1247":"[EPNR] Disable the forward siblings of ","26":"[EPNR] Encountered a cluster that must be entered forward only. This traversal is beyond the capabilities of the 'quick' look ahead sequencer. If this navigation request results in an error message, then this course requires the full look ahead sequencer.","789":"[EPNR] Evaluate all precondition rules that could affect the activity.","521":"[EPNR] Run the Termination Request Process To Move Current Runtime Data to Sequencer and Invoke Rollup","1662":"[EPNR] Selecting ","1702":"[EPNR] Setting ","1387":"[EPNR] The current activity is ","302":"[EPNR] The current activity's parent only allows Forward Traversal. Disable all of the parent's children that are before the active activity.","1271":"[EPNR] The logically next activity is ","1316":"[EPNR] The logically next activity,","1190":"[EPNR] The logically previous activity is ","1248":"[EPNR] The logically previous activity,","486":"[EPNR] There is either no previous activity or all previous activities are skipped, disable previous button.","1161":"[EPNR] There is no logically next activity.","1077":"[EPNR] There is no logically previous activity.","1024":"[EPNR] Using the 'Quick' Lookahead Sequencing Mode","463":"[NB.2.1]1.1. If the Current Activity is Not Defined Then (Make sure the sequencing session has not already begun)","209":"[NB.2.1]1.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: n/a; Sequencing Request: Start; Target Activity: n/a; Exception: n/a)","1663":"[NB.2.1]1.2. Else","176":"[NB.2.1]1.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-1)","1162":"[NB.2.1]1.Case: navigation request is Start","1078":"[NB.2.1]10. Case: navigation request is Abandon","506":"[NB.2.1]10.1. If the Current Activity is Defined Then (Make sure the sequencing session has already begun)","286":"[NB.2.1]10.1.1. If the Activity is Active for the Current Activity is True Then (Make sure the current activity has not already been terminated)","182":"[NB.2.1]10.1.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Abandon; Sequencing Request: Exit; Target Activity: n/a; Exception: n/a)","1598":"[NB.2.1]10.1.2. Else","153":"[NB.2.1]10.1.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-12)","1612":"[NB.2.1]10.2. Else ","166":"[NB.2.1]10.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-2)","998":"[NB.2.1]11. Case: navigation request is Abandon All","277":"[NB.2.1]11.1. If the Current Activity is Defined Then (If the sequencing session has already begun, unconditionally abandon all active activities)","167":"[NB.2.1]11.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Abandon All; Sequencing Request: Exit; Target Activity: n/a; Exception: n/a)","1640":"[NB.2.1]11.2. Else","162":"[NB.2.1]11.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-2) ","999":"[NB.2.1]12. Case: navigation request is Suspend All","538":"[NB.2.1]12.1. If the Current Activity is Defined Then (If the sequencing session has already begun)","168":"[NB.2.1]12.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Suspend All; Sequencing Request: Exit; Target Activity: n/a; Exception: n/a)","1641":"[NB.2.1]12.2. Else","169":"[NB.2.1]12.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-2)","1133":"[NB.2.1]13. Case: navigation request is Jump","94":"[NB.2.1]13. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-13) (Undefined navigation request)","21":"[NB.2.1]13.1. If the activity specified by the Jump navigation request exists within the activity tree And Available Children for the parent of the activity contains the activity Then (Make sure the target activity exists in the activity tree and is available)","68":"[NB.2.1]13.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Exit; Sequencing Request: Jump; Target Activity: the activity specified by the Jump navigation request; Exception: n/a)","79":"[NB.2.1]13.1.2. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-11) (Target activity does not exist.)","1642":"[NB.2.1]13.2. Else","80":"[NB.2.1]13.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-11) (Target activity does not exist.)","95":"[NB.2.1]14. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-13) (Undefined navigation request)","1037":"[NB.2.1]2. Case: navigation request is Resume All","464":"[NB.2.1]2.1. If the Current Activity is Not Defined Then (Make sure the sequencing session has not already begun)","335":"[NB.2.1]2.1.1. If the Suspended Activity is Defined Then (Make sure the previous sequencing session ended with a suspend all request)","170":"[NB.2.1]2.1.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: n/a; Sequencing Request: Resume All; Target Activity: n/a; Exception: n/a) ","1599":"[NB.2.1]2.1.2. Else ","163":"[NB.2.1]2.1.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-3)","1664":"[NB.2.1]2.2. Else","177":"[NB.2.1]2.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-1)","1079":"[NB.2.1]3. Case: navigation request is Continue","480":"[NB.2.1]3.1. If the Current Activity is Not Defined Then (Make sure the sequencing session has already begun)","178":"[NB.2.1]3.1.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-2)","40":"[NB.2.1]3.2. If the Current Activity is not the root of the activity tree And the Sequencing Control Flow for the parent of the Current Activity is True Then (Validate that a 'flow' sequencing request can be processed from the current activity)","212":"[NB.2.1]3.2.1. If the Activity is Active for the Current Activity is True Then (If the current activity has not been terminated, terminate the current the activity)","183":"[NB.2.1]3.2.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Exit; Sequencing Request: Continue; Target Activity: n/a; Exception: n/a)","1613":"[NB.2.1]3.2.2. Else","186":"[NB.2.1]3.2.2.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: n/a; Sequencing Request: Continue; Target Activity: n/a; Exception: n/a)","1665":"[NB.2.1]3.3. Else","34":"[NB.2.1]3.3.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-4) (Flow is not enabled or the current activity is the root of the activity tree)","1080":"[NB.2.1]4. Case: navigation request is Previous","481":"[NB.2.1]4.1. If the Current Activity is Not Defined Then (Make sure the sequencing session has already begun)","184":"[NB.2.1]4.1.1.Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-2)","239":"[NB.2.1]4.2. If the Current Activity is not the root of the activity tree Then (There is no activity logically 'previous' to the root of the activity tree)","202":"[NB.2.1]4.2.1.1. If the Activity is Active for the Current Activity is True Then (If the current activity has not been terminated, terminate the current the activity)","171":"[NB.2.1]4.2.1.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Exit; Sequencing Request: Previous; Target Activity: n/a; Exception: n/a)","1578":"[NB.2.1]4.2.1.2. Else","179":"[NB.2.1]4.2.1.2.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: n/a; Sequencing Request: Previous; Target Activity: n/a; Exception: n/a)","1614":"[NB.2.1]4.2.2. Else","100":"[NB.2.1]4.2.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-5) (Violates control mode)","1666":"[NB.2.1]4.3. Else","50":"[NB.2.1]4.3.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-6) (Cannot move backward from the root of the activity tree)","798":"[NB.2.1]5. Case: navigation request is Forward (Behavior not defined)","187":"[NB.2.1]5.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-7)","790":"[NB.2.1]6. Case: navigation request is Backward (Behavior not defined)","188":"[NB.2.1]6.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-7)","1097":"[NB.2.1]7. Case: navigation request is Choice ","195":"[NB.2.1]7.1. If the activity specified by the Choice navigation request exists within the activity tree Then (Make sure the target activity exists in the activity tree)","2":"[NB.2.1]7.1.1. If the activity specified by the Choice navigation request is the root of the activity tree Or the Sequencing Control Choice for the parent of the activity specified by the Choice navigation request is True Then (Validate that a 'choice' sequencing request can be processed on the target activity)","443":"[NB.2.1]7.1.1.1. If the Current Activity is Not Defined Then (Attempt to start the sequencing session through choice)","59":"[NB.2.1]7.1.1.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: n/a; Sequencing Request: Choice; Target Activity: the activity specified by the Choice navigation request; Exception: n/a)","399":"[NB.2.1]7.1.1.2. If the activity specified by the Choice navigation request is Not a sibling of the Current Activity Then","124":"[NB.2.1]7.1.1.2. If the activity specified by the Choice navigation request is Not a sibling of the Current Activity Then (We are always allowed to choose a sibling of the current activity)","365":"[NB.2.1]7.1.1.2.1. Find the common ancestor of the Current Activity and the activity specified by the Choice navigation request","1":"[NB.2.1]7.1.1.2.2. Form the activity path as the ordered series of activities from the Current Activity to the common ancestor (The common ancestor will not terminate as a result of processing the choice sequencing request, unless the common ancestor is the Current Activity - the current activity should always be included in the activity path)","930":"[NB.2.1]7.1.1.2.3. If the activity path is Not Empty Then","96":"[NB.2.1]7.1.1.2.3.1. For each activity in the activity path (Make sure that 'choosing' the target will not force an active activity to terminate, if that activity does not allow choice to terminate it)","216":"[NB.2.1]7.1.1.2.3.1.1. If Activity is Active for the activity is True And the Sequencing Control Choice Exit for the activity is False Then (Activity Identifier-","172":"[NB.2.1]7.1.1.2.3.1.1.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: ","86":"[NB.2.1]7.1.1.2.3.1.1.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-8) (Violates control mode)","1548":"[NB.2.1]7.1.1.2.4. Else","145":"[NB.2.1]7.1.1.2.4.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-9)","46":"[NB.2.1]7.1.1.3. If Activity is Active for the Current Activity is True And the Sequencing Control Choice Exit for the Current Activity is False Then (The Choice target is a sibling to the Current Activity, check if the Current Activity)","203":"[NB.2.1]7.1.1.3. If the Activity is Active for the Current Activity is True Then (If the current activity has not been terminated, terminate the current the activity)","56":"[NB.2.1]7.1.1.3.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Exit; Sequencing Request: Choice; Target Activity: the activity specified by the Choice navigation request; Exception: n/a) ","1579":"[NB.2.1]7.1.1.4. Else","204":"[NB.2.1]7.1.1.4. If the Activity is Active for the Current Activity is True Then (If the current activity has not been terminated, terminate the current the activity)","57":"[NB.2.1]7.1.1.4.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Exit; Sequencing Request: Choice; Target Activity: the activity specified by the Choice navigation request; Exception: n/a) ","60":"[NB.2.1]7.1.1.4.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: n/a; Sequencing Request: Choice; Target Activity: the activity specified by the Choice navigation request; Exception: n/a)","1580":"[NB.2.1]7.1.1.5. Else","61":"[NB.2.1]7.1.1.5.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: n/a; Sequencing Request: Choice; Target Activity: the activity specified by the Choice navigation request; Exception: n/a)","1615":"[NB.2.1]7.1.2. Else","99":"[NB.2.1]7.1.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Termination Request: n/a; Sequencing Request: n/a; Target Activity: n/a; Exception: NB.2.1-10) (Violates control mode)","1667":"[NB.2.1]7.2. Else","87":"[NB.2.1]7.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-11) (Target activity does not exist)","1163":"[NB.2.1]8. Case: navigation request is Exit","507":"[NB.2.1]8.1. If the Current Activity is Defined Then (Make sure the sequencing session has already begun)","193":"[NB.2.1]8.1.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Exit; Sequencing Request: Exit; Target Activity: n/a) ; Exception: n/a)","1616":"[NB.2.1]8.1.2. Else","75":"[NB.2.1]8.1.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-12) (Activity has already terminated )","1668":"[NB.2.1]8.2. Else","173":"[NB.2.1]8.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-2) ","1081":"[NB.2.1]9. Case: navigation request is Exit All","269":"[NB.2.1]9.1. If the Current Activity is Defined Then (If the sequencing session has already begun, unconditionally terminate all active activities)","194":"[NB.2.1]9.1.1. Exit Navigation Request Process (Navigation Request: Valid; Termination Request: Exit All; Sequencing Request: Exit; Target Activity: n/a; Exception: n/a)","1669":"[NB.2.1]9.2. Else","180":"[NB.2.1]9.2.1. Exit Navigation Request Process (Navigation Request: Not Valid; Sequencing Request: n/a; Termination Request: n/a; Target Activity: n/a; Exception: NB.2.1-2)","1404":"[OP.1]1. Navigation Request = ","756":"[OP.1]1.1. Apply the Navigation Request Process to the navigation request","625":"[OP.1]1.2. If the Navigation Request Process returned navigation request Not Valid Then","725":"[OP.1]1.2.1. Handle the navigation request exception Behavior not specified","846":"[OP.1]1.2.2. Continue Loop - wait for the next navigation request","368":"[OP.1]1.3. If there is a termination request Then (If the current activity is active, end the attempt on the current activity)","706":"[OP.1]1.3.1. Apply the Termination Request Process to the termination request","599":"[OP.1]1.3.2. If the Termination Request Process returned termination request Not Valid Then","698":"[OP.1]1.3.2.1. Handle the termination request exception Behavior not specified","822":"[OP.1]1.3.2.2. Continue Loop - wait for the next navigation request","699":"[OP.1]1.3.3. If Termination Request Process returned a sequencing request Then","39":"[OP.1]1.3.3.1. Replace any pending sequencing request by the sequencing request returned by the Termination Request Process (There can only be one pending sequencing request. Use the one returned by the termination request process, if it exists)","1056":"[OP.1]1.4. If there is a sequencing request Then","726":"[OP.1]1.4.1. Apply the Sequencing Request Process to the sequencing request","608":"[OP.1]1.4.2. If the Sequencing Request Process returned sequencing request Not Valid Then","707":"[OP.1]1.4.2.1. Handle the sequencing request exception Behavior not specified","823":"[OP.1]1.4.2.2. Continue Loop - wait for the next navigation request","534":"[OP.1]1.4.3. If the Sequencing Request Process returned a request to end the sequencing session Then","76":"[OP.1]1.4.3.1. Exit Overall Sequencing Process - the sequencing session has terminated; return control to LTS (Exiting from the root of the activity tree ends the sequencing session; return control to the LTS)","583":"[OP.1]1.4.4. If the Sequencing Request Process did not identify an activity for delivery Then","824":"[OP.1]1.4.4.1. Continue Loop - wait for the next navigation request","571":"[OP.1]1.4.5. Delivery request is for the activity identified by the Sequencing Request Process","1098":"[OP.1]1.5. If there is a delivery request Then","776":"[OP.1]1.5.1. Apply the Delivery Request Process to the delivery request","629":"[OP.1]1.5.2. If the Delivery Request Process returned delivery request Not Valid Then","727":"[OP.1]1.5.2.1. Handle the delivery request exception Behavior not specified","825":"[OP.1]1.5.2.2. Continue Loop - wait for the next navigation request","650":"[OP.1]1.5.3. Apply the Content Delivery Environment Process to the delivery request","944":"[OP.1]2. End Loop - wait for the next navigation request","768":"[OP.1]x. Navigation request is display message, exit sequencing process.","689":"[OP.1]x. Navigation request is display message, translating to an exit request.","813":"[OP.1]x. Navigation request is exit player, exit sequencing process.","1038":"[OP.1]x. No API Runtime Nav Request, exit action=","931":"[RB.1.1 b]1. Set the total weighted measure to Zero (0.0)","1301":"[RB.1.1 b]2. Set valid data to False","1000":"[RB.1.1 b]3. Set the counted measures to Zero (0.0)","1164":"[RB.1.1 b]4. For each child of the activity","630":"[RB.1.1 b]4.1. If Tracked for the child is True Then (Only include tracked children.)","259":"[RB.1.1 b]4.1.1. Increment counted measures by the adlcp:progressWeight for the child (The child is included, account for it in the weighted average)","799":"[RB.1.1 b]4.1.2. If the Attempt Completion Amount Status is True Then","90":"[RB.1.1 b]4.1.2.1. Add the product of Attempt Completion Amount multiplied by the adlcp:progressWeight to the total weighted measure (Only include progress that has been reported or previously rolled-up)","1217":"[RB.1.1 b]4.1.2.2. Set valid data to True","1236":"[RB.1.1 b]5. If valid data is False Then","320":"[RB.1.1 b]5.1. Set the Attempt Completion Amount Status to False (No progress state rolled-up, cannot determine the rolled-up progress.)","1617":"[RB.1.1 b]5.2. Else","522":"[RB.1.1 b]5.2.1. If counted measures is greater than (>) Zero (0.0) Then (Set the rolled-up progress.)","826":"[RB.1.1 b]5.2.1.1. Set the Attempt Completion Amount Status to True","476":"[RB.1.1 b]5.2.1.2. Set the Attempt Completion Amount to the total weighted measure divided by counted measures","1569":"[RB.1.1 b]5.2.2. Else ","366":"[RB.1.1 b]5.2.2.1. Set the Attempt Completion Amount Status for the target objective to False (No children contributed weight.)","1001":"[RB.1.1 b]6. Exit Completion Measure Rollup Process","956":"[RB.1.1]1. Set the total weighted measure to Zero (0.0)","1341":"[RB.1.1]2. Set valid date to False","1039":"[RB.1.1]3. Set the counted measures to Zero (0.0)","1057":"[RB.1.1]4. Set the target objective to Undefined","913":"[RB.1.1]5. For each objective associated with the activity","626":"[RB.1.1]5. Get the primary objective (For each objective associated with the activity)","343":"[RB.1.1]5.1. If Objective Contributes to Rollup for the objective is True Then (Find the target objective for the rolled-up measure)","945":"[RB.1.1]5.1.1. Set the target objective to the objective","1099":"[RB.1.1]6. If target objective is Defined Then","1165":"[RB.1.1]6.1. For each child of the activity","555":"[RB.1.1]6.1.1. If Tracked for the child is True Then (Only include tracked children). Tracked = ","979":"[RB.1.1]6.1.1.1. Set rolled-up objective to Undefined","877":"[RB.1.1]6.1.1.2. For each objective associated with the child","1166":"[RB.1.1]6.1.1.2. Get the primary objective.","641":"[RB.1.1]6.1.1.2.1. If Objective Contributes to Rollup for the objective is True Then","878":"[RB.1.1]6.1.1.2.1.1. Set rolled-up objective to the objective","1405":"[RB.1.1]6.1.1.2.1.2. Break For","957":"[RB.1.1]6.1.1.3. If rolled-up objective is Defined Then","545":"[RB.1.1]6.1.1.3.1. Increment counted measures by the Rollup Objective Measure Weight for the child","600":"[RB.1.1]6.1.1.3.2. If the Objective Measure Status for the rolled-up objective is True Then","121":"[RB.1.1]6.1.1.3.2.1. Add the product of Objective Normalized Measure for the rolled-up objective multiplied by the Rollup Objective Measure Weight for the child to the total weighted measure","827":"[RB.1.1]6.1.1.3.2.2. Set valid data to True - Normalized Measure = ","1581":"[RB.1.1]6.1.1.4. Else","495":"[RB.1.1]6.1.1.4.1. Exit Measure Rollup Process (One of the children does not include a rolled-up objective)","1237":"[RB.1.1]6.2. If valid data is False Then","103":"[RB.1.1]6.2.1. Set the Objective Measure Status for the target objective to False (No tracking state rolled-up, cannot determine the rolled-up measure. Total of all objectivemeasureweight values = ","1670":"[RB.1.1]6.3. Else","385":"[RB.1.1]6.3.1 If counted measures is greater than (>) Zero (0.0) Then (Set the rolled-up measure for the target objective.)","678":"[RB.1.1]6.3.1. Set the Objective Measure Status for the target objective to True","672":"[RB.1.1]6.3.1.1 Set the Objective Measure Status for the target objective to True","477":"[RB.1.1]6.3.1.2. Set the Objective Normalized Measure for the target objective to the total weighted measure (","1618":"[RB.1.1]6.3.2. Else","487":"[RB.1.1]6.3.2. Set the Objective Normalized Measure for the target objective to the total weighted measure (","453":"[RB.1.1]6.3.2.1 Set the Objective Measure Status for the target objective to False (No children contributed weight.)","1191":"[RB.1.1]6.3.3. Exit Measure Rollup Process","539":"[RB.1.1]7.Exit Measure Rollup Process No objective contributes to rollup, so we cannot set anything","1025":"[RB.1.2 a]1. Set the target objective to Undefined","889":"[RB.1.2 a]2. For each objective associated with the activity","616":"[RB.1.2 a]2. Get the primary objective (For each objective associated with the activity)","146":"[RB.1.2 a]2.1. If Objective Contributes to Rollup for the objective is True Then (Identify the objective that may be altered based on the activity's children's rolled up measure)","914":"[RB.1.2 a]2.1.1. Set the target objective to the objective","1489":"[RB.1.2 a]2.1.2. Break For","1058":"[RB.1.2 a]3. If target objective is Defined Then","127":"[RB.1.2 a]3.1. If Objective Satisfied by Measure for the target objective is True Then (If the objective is satisfied by measure, test the rolled-up measure against the defined threshold)","303":"[RB.1.2 a]3.1.1. If the Objective Measure Status for the target objective is False Then (No Measure known, so objective status is unreliable)","627":"[RB.1.2 a]3.1.1.1. Set the Objective Progress Status for the target objective to False","1582":"[RB.1.2 a]3.1.2. Else","130":"[RB.1.2 a]3.1.2.1. If Activity is Active for the activity is False Or (Activity is Active for the activity is True And adlseq:measureSatisfactionIfActive for the activity is True ) Then","105":"[RB.1.2 a]3.1.2.1.1. If the Objective Normalized Measure for the target objective is greater than or equal (>=) to the Objective Minimum Satisfied Normalized Measure for the target objective Then","609":"[RB.1.2 a]3.1.2.1.1.1. Set the Objective Progress Status for the target objective to True","605":"[RB.1.2 a]3.1.2.1.1.2. Set the Objective Satisfied Status for the target objective to True","1508":"[RB.1.2 a]3.1.2.1.2. Else","610":"[RB.1.2 a]3.1.2.1.2.1. Set the Objective Progress Status for the target objective to True","601":"[RB.1.2 a]3.1.2.1.2.2. Set the Objective Satisfied Status for the target objective to False","1549":"[RB.1.2 a]3.1.2.2. Else","270":"[RB.1.2 a]3.1.2.2.1. Set the Objective Progress Status for the target objective to False (Incomplete information, do not evaluate objective status)","915":"[RB.1.2 a]3.2. Exit Objective Rollup Using Measure Process","1671":"[RB.1.2 a]4. Else","482":"[RB.1.2 a]4.1. Exit Objective Roll up Process (No objective contributes to rollup, so we cannot set anything)","391":"[RB.1.2 a]4.1. Exit Objective Rollup Using Measure Process (No objective contributes to rollup, so we cannot set anything)","23":"[RB.1.2 b]1. If the activity does not include Rollup Rules with the Not Satisfied  rollup action And the activity does not include Rollup Rules with the Satisfied  rollup action Then (If no objective rollup rules are defined, use the default rollup rules.)  ","110":"[RB.1.2 b]1.1. Apply a Rollup Rule to the activity with a Rollup Child Activity Set of All; a Rollup Condition of Satisfied; and a Rollup Action of Satisfied (Define the default satisfied rule )","69":"[RB.1.2 b]1.2. Apply a Rollup Rule to the activity with a Rollup Child Activity Set of All; a Rollup Condition of Objective Status Known; and a Rollup Action of Not Satisfied (Define the default not satisfied rule )","1040":"[RB.1.2 b]1.Set the target objective to Undefined","890":"[RB.1.2 b]2. For each objective associated with the activity","617":"[RB.1.2 b]2. Get the primary objective (For each objective associated with the activity)","148":"[RB.1.2 b]2.1. If Objective Contributes to Rollup for the objective is True Then (Identify the objective that may be altered based on the activity's children's rolled up status)","916":"[RB.1.2 b]2.1.1. Set the target objective to the objective","1490":"[RB.1.2 b]2.1.2. Break For","1041":"[RB.1.2 b]2.Set the target objective to Undefined","891":"[RB.1.2 b]3. For each objective associated with the activity","618":"[RB.1.2 b]3. Get the primary objective (For each objective associated with the activity)","1059":"[RB.1.2 b]3. If target objective is Defined Then","294":"[RB.1.2 b]3.1. Apply the Rollup Rule Check Subprocess to the activity and the Not Satisfied rollup action Process all Not Satisfied rules first","149":"[RB.1.2 b]3.1. If Objective Contributes to Rollup for the objective is True Then (Identify the objective that may be altered based on the activity's children's rolled up status)","917":"[RB.1.2 b]3.1.1. Set the target objective to the objective","1491":"[RB.1.2 b]3.1.2. Break For","800":"[RB.1.2 b]3.2. If the Rollup Rule Check Subprocess returned True Then","651":"[RB.1.2 b]3.2.1. Set the Objective Progress Status for the target objective to True","631":"[RB.1.2 b]3.2.2. Set the Objective Satisfied Status for the target objective to False","327":"[RB.1.2 b]3.3. Apply the Rollup Rule Check Subprocess to the activity and the Satisfied rollup action Process all Satisfied rules last","801":"[RB.1.2 b]3.4. If the Rollup Rule Check Subprocess returned True Then","652":"[RB.1.2 b]3.4.1. Set the Objective Progress Status for the target objective to True","642":"[RB.1.2 b]3.4.2. Set the Objective Satisfied Status for the target objective to True","946":"[RB.1.2 b]3.5. Exit Objective Rollup Using Rules Process","1672":"[RB.1.2 b]4. Else","1060":"[RB.1.2 b]4. If target objective is Defined Then","295":"[RB.1.2 b]4.1. Apply the Rollup Rule Check Subprocess to the activity and the Not Satisfied rollup action Process all Not Satisfied rules first","431":"[RB.1.2 b]4.1. Exit Objective Rollup Using Rules Process No objective contributes to rollup, so we cannot set anything","802":"[RB.1.2 b]4.2. If the Rollup Rule Check Subprocess returned True Then","653":"[RB.1.2 b]4.2.1. Set the Objective Progress Status for the target objective to True","632":"[RB.1.2 b]4.2.2. Set the Objective Satisfied Status for the target objective to False","328":"[RB.1.2 b]4.3. Apply the Rollup Rule Check Subprocess to the activity and the Satisfied rollup action Process all Satisfied rules last","803":"[RB.1.2 b]4.4. If the Rollup Rule Check Subprocess returned True Then","654":"[RB.1.2 b]4.4.1. Set the Objective Progress Status for the target objective to True","643":"[RB.1.2 b]4.4.2. Set the Objective Satisfied Status for the target objective to True","947":"[RB.1.2 b]4.5. Exit Objective Rollup Using Rules Process","1673":"[RB.1.2 b]5. Else","432":"[RB.1.2 b]5.1. Exit Objective Rollup Using Rules Process No objective contributes to rollup, so we cannot set anything","1550":"[RB.1.2 c] satisfied = ","1238":"[RB.1.2 c]0.5. If the activity is a leaf","1249":"[RB.1.2 c]0.5.1 Exit, nothing to rollup","1026":"[RB.1.2 c]1. Set the target objective to Undefined","892":"[RB.1.2 c]2. For each objective associated with the activity","619":"[RB.1.2 c]2. Get the primary objective (For each objective associated with the activity)","147":"[RB.1.2 c]2.1. If Objective Contributes to Rollup for the objective is True Then (Identify the objective that may be altered based on the activity's children's rolled up measure)","918":"[RB.1.2 c]2.1.1. Set the target objective to the objective","1492":"[RB.1.2 c]2.1.2. Break For","1082":"[RB.1.2 c]3. Get the set of applicable children","1042":"[RB.1.2 c]4. initialize all not satisfied to true","1118":"[RB.1.2 c]5. initialize all satisfied to true","1272":"[RB.1.2 c]6. for each applicable child","1356":"[RB.1.2 c]6.1 if child activity (","1083":"[RB.1.2 c]6.1 satisfied = activity.getsatisfied","1043":"[RB.1.2 c]6.1.1 satisfied = activity.getsatisfied","1044":"[RB.1.2 c]6.1.2 attempted = activity.getattempted","728":"[RB.1.2 c]6.1.3 not satisfied = (satisfied === false || attempted === true)","893":"[RB.1.2 c]6.1.4 all statisfied = all satisfied AND satisfied","777":"[RB.1.2 c]6.1.5 all not satisfied = all not satisfied AND not satisfied","1084":"[RB.1.2 c]6.2 attempted = activity.getattempted","757":"[RB.1.2 c]6.3 not satisfied = (satisfied === false || attempted === true)","919":"[RB.1.2 c]6.4 all statisfied = all satisfied AND satisfied","804":"[RB.1.2 c]6.5 all not satisfied = all not satisfied AND not satisfied","1002":"[RB.1.2 c]7. If All Not Satified. (allNotSatisfied=","673":"[RB.1.2 c]7.1. Set the Objective Progress Status for the target objective to True","655":"[RB.1.2 c]7.2. Set the Objective Satisfied Status for the target objective to False","1085":"[RB.1.2 c]7.3. If All Satisfied. (allSatisfied=","656":"[RB.1.2 c]7.3.1. Set the Objective Progress Status for the target objective to True","644":"[RB.1.2 c]7.3.2. Set the Objective Satisfied Status for the target objective to True","1250":"[RB.1.2 c]Retrieving Status for child #","1061":"[RB.1.2]1. Set the target objective to Undefined","920":"[RB.1.2]2. For each objective associated with the activity","628":"[RB.1.2]2. Get the primary objective (For each objective associated with the activity)","154":"[RB.1.2]2.1. If Objective Contributes to Rollup for the objective is True Then (Identify the objective that may be altered based on the activity's children's rolled up measure)","948":"[RB.1.2]2.1.1. Set the target objective to the objective","1532":"[RB.1.2]2.1.2. Break For","690":"[RB.1.2]3.1. If Objective Satisfied By Measure for the target objective is True","867":"[RB.1.2]3.1.1 Invoke the Objective Rollup Process Using Measure","1134":"[RB.1.2]3.1.2 Exit Objective Roll up Process","1674":"[RB.1.2]3.2 Else ","590":"[RB.1.2]3.2 If the Activity has rollup rules that have the action Satisfied or Not Satisfied","496":"[RB.1.2]3.2.1 Apply Objective Rollup Using Rules Process (The default is included in the Rules process now)","879":"[RB.1.2]3.2.1 Invoke the Objective Rollup Process Using Rules","1135":"[RB.1.2]3.2.2 Exit Objective Roll up Process","1192":"[RB.1.2]3.3 Exit Objective Roll up Process","386":"[RB.1.2]3.3 Invoke the Objective Rollup Process Using Default - Neither Sub Process is Applicable, so use the Default Rules","1193":"[RB.1.2]3.4 Exit Objective Roll up Process","1086":"[RB.1.3 a]1. If activity is not tracked, return","1273":"[RB.1.3 a]1. If the activity is a leaf","1290":"[RB.1.3 a]1.1 Exit, nothing to rollup","1087":"[RB.1.3 a]2. Get the set of applicable children","1045":"[RB.1.3 a]2. Set Attempt Progress Status to False","987":"[RB.1.3 a]3.  Set Attempt Completion Status to False","1100":"[RB.1.3 a]3. initialize all incomplete to true","134":"[RB.1.3 a]4. If adlcp:completedbyMeasure for the target objective is True Then (If the completion is determined by measure, test the rolled-up progress against the defined threshold.)","1218":"[RB.1.3 a]4. initialize completed to true","371":"[RB.1.3 a]4.1. If the Attempt Completion Amount Status is False Then (No progress amount known, so the status is unreliable.)","901":"[RB.1.3 a]4.1.1. Set the Attempt Completion Status to False","1619":"[RB.1.3 a]4.2. Else","444":"[RB.1.3 a]4.2.1. If the Attempt Completion Amount is greater than or equal (>=) to the adlcp:minProgressMeasure  Then","932":"[RB.1.3 a]4.2.1.1. Set the Attempt Progress Status True  ","873":"[RB.1.3 a]4.2.1.2. Set the Attempt Completion Status to True  ","1570":"[RB.1.3 a]4.2.2. Else ","958":"[RB.1.3 a]4.2.2.1. Set the Attempt Progress Status True","880":"[RB.1.3 a]4.2.2.2. Set the Attempt Completion Status to False","1675":"[RB.1.3 a]5. Else","1274":"[RB.1.3 a]5. for each applicable child","1357":"[RB.1.3 a]5.1 if child activity (","461":"[RB.1.3 a]5.1. Set the Attempt Progress Status False (Incomplete information, do not evaluate completion status.) ","1046":"[RB.1.3 a]5.1.1 completed = activity.getcompleted","1047":"[RB.1.3 a]5.1.2 attempted = activity.getattempted","769":"[RB.1.3 a]5.1.3 incomplete = (completed === false || attempted === true)","881":"[RB.1.3 a]5.1.4. Child should be included in completed rollup","882":"[RB.1.3 a]5.1.4.1 all completed = all completed AND completed","874":"[RB.1.3 a]5.1.5. Child should be included in incomplete rollup","847":"[RB.1.3 a]5.1.5.1. all incomplete = all incomplete AND incomplete","859":"[RB.1.3 a]6. Exit Activity Progress Rollup Using Measure Process","1406":"[RB.1.3 a]6. If All Incomplete","778":"[RB.1.3 a]6.1. Set the Attempt Progress Status for the activity to True","746":"[RB.1.3 a]6.2. Set the Attempt Completion Status for the activity to False","1427":"[RB.1.3 a]7. If All Satisfied","779":"[RB.1.3 a]7.1. Set the Attempt Progress Status for the activity to True","758":"[RB.1.3 a]7.2. Set the Attempt Completion Status for the activity to True","31":"[RB.1.3 b]1. If the activity does not include Rollup Rules with the Incomplete rollup action And the activity does not include Rollup Rules with the Completed  rollup action Then (If no progress rollup rules are defined, use the default rollup rules.) ","111":"[RB.1.3 b]1.1. Apply a Rollup Rule to the activity with a Rollup Child Activity Set of All; a Rollup Condition of Completed; and a Rollup Action of Completed (Define the default completed rule)","70":"[RB.1.3 b]1.2. Apply a Rollup Rule to the activity with a Rollup Child Activity Set of All; a Rollup Condition of Activity Progress Known; and a Rollup Action of Incomplete (Define the default not incomplete rule)","314":"[RB.1.3 b]2. Apply the Rollup Rule Check Subprocess to the activity and the Incomplete rollup action (Process all Incomplete rules first.)","805":"[RB.1.3 b]3. If the Rollup Rule Check Subprocess returned True Then  ","759":"[RB.1.3 b]3.1. Set the Attempt Progress Status for the activity to True  ","719":"[RB.1.3 b]3.2. Set the Attempt Completion Status for the activity to False  ","321":"[RB.1.3 b]4. Apply the Rollup Rule Check Subprocess to the activity and the Completed rollup action (Process all Completed rules last.) ","828":"[RB.1.3 b]5. If the Rollup Rule Check Subprocess returned True Then","760":"[RB.1.3 b]5.1. Set the Attempt Progress Status for the activity to True  ","729":"[RB.1.3 b]5.2. Set the Attempt Completion Status for the activity to True  ","1027":"[RB.1.3 b]6. Exit Activity Progress Rollup Process","336":"[RB.1.3]1. Apply the Rollup Rule Check Subprocess to the activity and the Incomplete rollup action Process all Incomplete rules first","91":"[RB.1.3]1. Using Measure:  If the activity has Completed by Measure equal to True, then the rolled-up progress measure is compared against the Minimum Progress Measure and Measure Satisfaction if Active:","848":"[RB.1.3]1.1 Apply Activity Progress Rollup Using Measure Process ","1703":"[RB.1.3]2. Else","849":"[RB.1.3]2. If the Rollup Rule Check Subprocess returned True Then","850":"[RB.1.3]2.1. Apply Activity Progress Rollup Using Measure Process","806":"[RB.1.3]2.1. Set the Attempt Progress Status for the activity to True","770":"[RB.1.3]2.2. Set the Attempt Completion Status for the activity to False","350":"[RB.1.3]3. Apply the Rollup Rule Check Subprocess to the activity and the Completed rollup action Process all Completed rules last.","1062":"[RB.1.3]3. Exit Activity Progress Rollup Process","851":"[RB.1.3]4. If the Rollup Rule Check Subprocess returned True Then","807":"[RB.1.3]4.1. Set the Attempt Progress Status for the activity to True","780":"[RB.1.3]4.2. Set the Attempt Completion Status for the activity to True","1167":"[RB.1.3]4.5. Rolling up using Default Rules","1063":"[RB.1.3]5. Exit Activity Progress Rollup Process","387":"[RB.1.4.1]1.Initialize rollup condition bag as an Empty collection (This is used track of the evaluation rule's conditions)","791":"[RB.1.4.1]2. For each Rollup Condition in the set of Rollup Conditions","36":"[RB.1.4.1]2.1. Evaluate the rollup condition by applying the appropriate tracking information for the activity to the Rollup Condition. (Evaluate each condition against the activity's tracking information. This evaluation may result in 'unknown'.)","369":"[RB.1.4.1]2.2. If the Rollup Condition Operator for the Rollup Condition is Not Then (Negating 'unknown' results in 'unknown')","1136":"[RB.1.4.1]2.2.1. Negate the rollup condition","968":"[RB.1.4.1]2.3. Add the value of the rollup condition (","308":"[RB.1.4.1]3. If the rollup condition bag is Empty Then (If there are no defined conditions for the rule, cannot determine the rule applies)","691":"[RB.1.4.1]3.1. Exit Evaluate Rollup Conditions Subprocess (Evaluation: Unknown)","1101":"[RB.1.4.1]4. Apply the Condition Combination (","497":"[RB.1.4.1]5. Exit Evaluate Rollup Conditions Subprocess (Evaluation: the value of combined rule evaluation)","1375":"[RB.1.4.2] Set included to False","1342":"[RB.1.4.2]1. Set included to False","814":"[RB.1.4.2]2. If the Rollup Action is Satisfied Or Not Satisfied Then","406":"[RB.1.4.2]2.1. If the Rollup Objective Satisfied value for the activity is True Then (Test the objective rollup control)","591":"[RB.1.4.2]2.1.1. Set included to True (Default Behavior \ufffd adlseq:requiredFor[xxx] == always)","97":"[RB.1.4.2]2.1.2. If (the Rollup Action is Satisfied And adlseq:requiredForSatisfied is ifNotSuspended) Or (the Rollup Action is Not Satisfied And adlseq:requiredForNotSatisfied is ifNotSuspended) Then","92":"[RB.1.4.2]2.1.2.1. If  Activity Progress Status for the activity is False Or (Activity Attempt Count for the activity is greater than (>) Zero (0) And Activity is Suspended for the activity is True) Then","278":"[RB.1.4.2]2.1.2.1. If Activity Attempt Count for the activity is greater than (>) Zero (0) And Activity is Suspended for the activity is True Then","1194":"[RB.1.4.2]2.1.2.1.1. Set included to False","1583":"[RB.1.4.2]2.1.3. Else","104":"[RB.1.4.2]2.1.3.1. If (the Rollup Action is Satisfied And adlseq:requiredForSatisfied is ifAttempted) Or (the Rollup Action is Not Satisfied And adlseq:requiredForNotSatisfied is ifAttempted) Then","679":"[RB.1.4.2]2.1.3.1.1. If Activity Attempt Count for the activity is Zero (0) Then","329":"[RB.1.4.2]2.1.3.1.1. If Activity Progress Status for the activity is False Or Activity Attempt Count for the activity is Zero (0) Then","1137":"[RB.1.4.2]2.1.3.1.1.1. Set included to False","1551":"[RB.1.4.2]2.1.3.2. Else","98":"[RB.1.4.2]2.1.3.2.1. If (the Rollup Action is Satisfied And adlseq:requiredForSatisfied is ifNotSkipped) Or (the Rollup Action is Not Satisfied And adlseq:requiredForNotSatisfied is ifNotSkipped) Then","467":"[RB.1.4.2]2.1.3.2.1.1. Apply the Sequencing Rules Check Process to the activity and its Skipped sequencing rules","633":"[RB.1.4.2]2.1.3.2.1.2. If the Sequencing Rules Check Process does not return Nil Then","1102":"[RB.1.4.2]2.1.3.2.1.2.1. Set included to False","852":"[RB.1.4.2]3. If the Rollup Action is Completed Or Incomplete Then","419":"[RB.1.4.2]3.1. If the Rollup Progress Completion value for the activity is True Then (Test the progress rollup control)","592":"[RB.1.4.2]3.1.1. Set included to True (Default Behavior \ufffd adlseq:requiredFor[xxx] == always)","106":"[RB.1.4.2]3.1.2. If (the Rollup Action is Completed And adlseq:requiredForCompleted is ifNotSuspended) Or (the Rollup Action is Incomplete And adlseq:requiredForIncomplete is ifNotSuspended) Then","279":"[RB.1.4.2]3.1.2.1. If Activity Attempt Count for the activity is greater than (>) Zero (0) And Activity is Suspended for the activity is True Then","93":"[RB.1.4.2]3.1.2.1. If Activity Progress Status for the activity is False Or (Activity Attempt Count for the activity is greater than (>) Zero (0) And Activity is Suspended for the activity is True) Then","1584":"[RB.1.4.2]3.1.3. Else","117":"[RB.1.4.2]3.1.3.1. If (the Rollup Action is Completed And adlseq:requiredForCompleted is ifAttempted) Or (the Rollup Action is Incomplete And adlseq:requiredForIncomplete is ifAttempted) Then","680":"[RB.1.4.2]3.1.3.1.1. If Activity Attempt Count for the activity is Zero (0) Then","330":"[RB.1.4.2]3.1.3.1.1. If Activity Progress Status for the activity is False Or Activity Attempt Count for the activity is Zero (0) Then","1138":"[RB.1.4.2]3.1.3.1.1.1. Set included to False","1552":"[RB.1.4.2]3.1.3.2. Else","107":"[RB.1.4.2]3.1.3.2.1. If (the Rollup Action is Completed And adlseq:requiredForCompleted is ifNotSkipped) Or (the Rollup Action is Incomplete And adlseq:requiredForIncomplete is ifNotSkipped) Then","468":"[RB.1.4.2]3.1.3.2.1.1. Apply the Sequencing Rules Check Process to the activity and its Skipped sequencing rules","634":"[RB.1.4.2]3.1.3.2.1.2. If the Sequencing Rules Check Process does not return Nil Then","1103":"[RB.1.4.2]3.1.3.2.1.2.1. Set included to False","602":"[RB.1.4.2]4. Exit Check Child for Rollup Subprocess (Child is Included in Rollup: included)","260":"[RB.1.4] 1.2.10.1.Exit RollupRule Check Subprocess (Evaluation: True) (Stop at the first rule that evaluates to true - perform the associated action)","265":"[RB.1.4] 1.2.9.1.Exit RollupRule Check Subprocess (Evaluation: True) (Stop at the first rule that evaluates to true - perform the associated action)","331":"[RB.1.4]1. If the activity includes Rollup Rules with the specified Rollup Action Then  (Make sure the activity has rules to evaluate)","214":"[RB.1.4]1.1. Initialize rules list by selecting the set of Rollup Rules for the activity that have the specified Rollup Actions, maintaining original rule ordering","1139":"[RB.1.4]1.2. For each rule in the rules list","1358":"[RB.1.4]1.2.0. Rule Description: ","747":"[RB.1.4]1.2.1. Initialize contributing children bag as an empty collection","1119":"[RB.1.4]1.2.10. If status change is True Then","1120":"[RB.1.4]1.2.2. For each child of the activity","969":"[RB.1.4]1.2.2.1. If Tracked for the child is True Then","236":"[RB.1.4]1.2.2.2.1. Apply Check Child for Rollup Subprocess to the child and the Rollup Action (Make sure this child contributes to the status of its parent)","748":"[RB.1.4]1.2.2.2.2. If Check Child for Rollup Subprocess returned True Then","156":"[RB.1.4]1.2.2.2.2.1. Apply the Evaluate Rollup Conditions Subprocess to the child and the Rollup Conditions for the rule (Evaluate the rollup conditions on the child activity)","309":"[RB.1.4]1.2.2.2.2.2. If Evaluate Rollup Conditions Subprocess returned Unknown Then (Account for a possible 'unknown' condition evaluation)","720":"[RB.1.4]1.2.2.2.2.2.1. Add an Unknown value to the contributing children bag","1509":"[RB.1.4]1.2.2.2.2.3. Else","681":"[RB.1.4]1.2.2.2.2.4. If Evaluate Rollup Conditions Subprocess returned True Then","771":"[RB.1.4]1.2.2.2.2.4.1. Add a True value to the contributing children bag","1510":"[RB.1.4]1.2.2.2.2.5. Else","761":"[RB.1.4]1.2.2.2.2.5.1. Add a False value to the contributing children bag","189":"[RB.1.4]1.2.3. Initialize status change to False (Determine if the appropriate children contributed to rollup; if they did, the status of the activity should be changed.)","933":"[RB.1.4]1.2.4. Case: the Rollup Child Activity Set is All","902":"[RB.1.4]1.2.4. Case: the contributing children bag is empty","550":"[RB.1.4]1.2.4.1. Break  (No action; do not change status unless some child contributed to rollup)","540":"[RB.1.4]1.2.4.1. If the contributing children bag does not contain a value of False Or Unknown Then","1140":"[RB.1.4]1.2.4.1.1. Set status change to True","934":"[RB.1.4]1.2.5. Case: the Rollup Child Activity Set is All","935":"[RB.1.4]1.2.5. Case: the Rollup Child Activity Set is Any","692":"[RB.1.4]1.2.5.1. If the contributing children bag contains a value of True Then","541":"[RB.1.4]1.2.5.1. If the contributing children bag does not contain a value of False Or Unknown Then","1141":"[RB.1.4]1.2.5.1.1. Set status change to True","936":"[RB.1.4]1.2.6. Case: the Rollup Child Activity Set is Any","921":"[RB.1.4]1.2.6. Case: the Rollup Child Activity Set is None","693":"[RB.1.4]1.2.6.1. If the contributing children bag contains a value of True Then","546":"[RB.1.4]1.2.6.1. If the contributing children bag does not contain a value of True Or Unknown Then","1142":"[RB.1.4]1.2.6.1.1. Set status change to True","815":"[RB.1.4]1.2.7. Case: the Rollup Child Activity Set is At Least Count","922":"[RB.1.4]1.2.7. Case: the Rollup Child Activity Set is None","547":"[RB.1.4]1.2.7.1. If the contributing children bag does not contain a value of True Or Unknown Then","271":"[RB.1.4]1.2.7.1. If the count of True values contained in the contributing children bag equals or exceeds the Rollup Minimum Count of the rule Then","1143":"[RB.1.4]1.2.7.1.1. Set status change to True","816":"[RB.1.4]1.2.8. Case: the Rollup Child Activity Set is At Least Count","792":"[RB.1.4]1.2.8. Case: the Rollup Child Activity Set is At Least Percent","272":"[RB.1.4]1.2.8.1. If the count of True values contained in the contributing children bag equals or exceeds the Rollup Minimum Count of the rule Then","118":"[RB.1.4]1.2.8.1. If the percentage (normalized between 0..1, inclusive) of True values contained in the contributing children bag equals or exceeds the Rollup Minimum Percent of the rule Then","1144":"[RB.1.4]1.2.8.1.1. Set status change to True","793":"[RB.1.4]1.2.9. Case: the Rollup Child Activity Set is At Least Percent","1145":"[RB.1.4]1.2.9. If status change is True Then","119":"[RB.1.4]1.2.9.1. If the percentage (normalized between 0..1, inclusive) of True values contained in the contributing children bag equals or exceeds the Rollup Minimum Percent of the rule Then","1146":"[RB.1.4]1.2.9.1.1. Set status change to True","420":"[RB.1.4]2. Exit Rollup Rule Check Subprocess (Evaluation: False) No rules evaluated to true - do not perform any action","868":"[RB.1.5] Adding activity to collection of rolled up activities.","903":"[RB.1.5] No tracking data changed, stopping further rollup.","256":"[RB.1.5]1. Form the activity path as the ordered series of activities from the root of the activity tree to the activity, inclusive, in reverse order.","1121":"[RB.1.5]2. If the activity path is Empty Then","894":"[RB.1.5]2.1. Exit Overall Rollup Process - Nothing to rollup","1048":"[RB.1.5]3. For each activity in the activity path","551":"[RB.1.5]3.1. If the activity has children Then (Only apply Measure Rollup to non-leaf activities)","564":"[RB.1.5]3.1.1. Apply the Measure Rollup Process to the activity (Rollup the activity's measure)","454":"[RB.1.5]3.1.2. Apply the Completion Measure Rollup Process to the activity (Rollup the activity\ufffds progress measure.)","730":"[RB.1.5]3.2. Apply the appropriate Objective Rollup Process to the activity","115":"[RB.1.5]3.2. Apply the appropriate Objective Rollup Process to the activity (Apply the appropriate behavior described in section RB.1.2, based on the activity's defined sequencing information)","781":"[RB.1.5]3.3. Apply the Activity Progress Rollup Process to the activity","126":"[RB.1.5]3.3. Apply the Activity Progress Rollup Process to the activity (Apply the appropriate behavior described in section RB.1.3, based on the activity's defined sequencing information)","261":"[RB.1.5]3.3. Apply the appropriate Activity Progress Rollup Process to the activity (R.S.:Apply the Activity Progress Rollup Process to the activity)","1275":"[RB.1.5]4. Exit Overall Rollup Process","488":"[SB.2.10]1. If the Current Activity is Not Defined Then (Make sure the sequencing session has already begun)","433":"[SB.2.10]1.1. Exit Retry Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.10-1) (Nothing to deliver)","101":"[SB.2.10]2. If the Activity is Active for the Current Activity is True Or the Activity is Suspended for the Current Activity is True Then (Cannot retry an activity that is still active or suspended)","434":"[SB.2.10]2.1. Exit Retry Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.10-2) (Nothing to deliver)","970":"[SB.2.10]3. If the Current Activity is not a leaf Then","372":"[SB.2.10]3.1. Apply the Flow Subprocess to the Current Activity in the Forward direction with consider children equal to True","949":"[SB.2.10]3.2. If the Flow Subprocess returned False Then","407":"[SB.2.10]3.2.1. Exit Retry Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.10-3) (Nothing to deliver)","1643":"[SB.2.10]3.3. Else","322":"[SB.2.10]3.3.1. Exit Retry Sequencing Request Process (Delivery Request: the activity identified by the Flow Subprocess; Exception: n/a)","511":"[SB.2.10]3.a. (step not in pseudo code) Reset activity data for the re-tried activity and its children (","829":"[SB.2.10]3.a.1 If objectives global to system is false (obj global=","1195":"[SB.2.10]3.a.2 Reset any global objectives","1690":"[SB.2.10]4. Else","489":"[SB.2.10]4.1. Exit Retry Sequencing Request Process (Delivery Request: the Current Activity; Exception: n/a)","490":"[SB.2.11]1. If the Current Activity is Not Defined Then (Make sure the sequencing session has already begun)","512":"[SB.2.11]1.1. Exit Exit Sequencing Request Process (End Sequencing Session: False; Exception: SB.2.11-1)","323":"[SB.2.11]2. If the Activity is Active for the Current Activity is True Then (Make sure the current activity has already been terminated)","513":"[SB.2.11]2.1. Exit Exit Sequencing Request Process (End Sequencing Session: False; Exception: SB.2.11-2)","762":"[SB.2.11]3. If the Current Activity is the root of the activity tree Then","219":"[SB.2.11]3.1. Exit Exit Sequencing Request Process (End Sequencing Session: True; Exception: n/a) (The sequencing session has ended, return control to the LTS)","556":"[SB.2.11]4. Exit Exit Sequencing Request Process (End Sequencing Session: False; Exception: n/a)","1122":"[SB.2.12]1. Case: sequencing request is Start","950":"[SB.2.12]1.1. Apply the Start Sequencing Request Process","694":"[SB.2.12]1.2. If the Start Sequencing Request Process returns an exception Then","81":"[SB.2.12]1.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Start Sequencing Request Process)","1644":"[SB.2.12]1.3. Else","42":"[SB.2.12]1.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Start Sequencing Request Process; End Sequencing Session: as identified by the Start Sequencing Request Process; Exception: n/a)","122":"[SB.2.12]1.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Start Sequencing Request Process; End Sequencing Session: n/a; Exception: n/a)","1028":"[SB.2.12]2. Case: sequencing request is Resume All","883":"[SB.2.12]2.1. Apply the Resume All Sequencing Request Process","645":"[SB.2.12]2.2. If the Resume All Sequencing Request Process returns an exception Then","71":"[SB.2.12]2.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Resume All Sequencing Request Process)","1645":"[SB.2.12]2.3. Else","108":"[SB.2.12]2.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Resume All Sequencing Request Process; End Sequencing Session: n/a; Exception: n/a)","1147":"[SB.2.12]3. Case: sequencing request is Exit","959":"[SB.2.12]3.1. Apply the Exit Sequencing Request Process","700":"[SB.2.12]3.2. If the Exit Sequencing Request Process returns an exception Then","83":"[SB.2.12]3.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Exit Sequencing Request Process)","1646":"[SB.2.12]3.3. Else","125":"[SB.2.12]3.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: n/a; End Sequencing Session: the result of the Exit Sequencing Request Process; Exception: n/a)","1123":"[SB.2.12]4. Case: sequencing request is Retry","951":"[SB.2.12]4.1. Apply the Retry Sequencing Request Process","82":"[SB.2.12]4.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Retry Sequencing Request Process)","1647":"[SB.2.12]4.3. Else","116":"[SB.2.12]4.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Retry Sequencing Request Process; End Sequencing Session: n/a) ; Exception: n/a)","1064":"[SB.2.12]5. Case: sequencing request is Continue","904":"[SB.2.12]5.1. Apply the Continue Sequencing Request Process","660":"[SB.2.12]5.2. If the Continue Sequencing Request Process returns an exception Then","27":"[SB.2.12]5.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: Value from Continue Sequencing Request Process; Exception: the exception identified by the Continue Sequencing Request Process)","72":"[SB.2.12]5.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Continue Sequencing Request Process)","1648":"[SB.2.12]5.3. Else","37":"[SB.2.12]5.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Continue Sequencing Request Process; End Sequencing Session: as identified by the Continue Sequencing Request Process;; Exception: n/a)","112":"[SB.2.12]5.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Continue Sequencing Request Process; End Sequencing Session: n/a; Exception: n/a)","1065":"[SB.2.12]6. Case: sequencing request is Previous","905":"[SB.2.12]6.1. Apply the Previous Sequencing Request Process","661":"[SB.2.12]6.2. If the Previous Sequencing Request Process returns an exception Then","73":"[SB.2.12]6.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Previous Sequencing Request Process)","1649":"[SB.2.12]6.3. Else","113":"[SB.2.12]6.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Previous Sequencing Request Process; End Sequencing Session: n/a; Exception: n/a)","1104":"[SB.2.12]7. Case: sequencing request is Choice","937":"[SB.2.12]7.1. Apply the Choice Sequencing Request Process","682":"[SB.2.12]7.2. If the Choice Sequencing Request Process returns an exception Then","77":"[SB.2.12]7.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Choice Sequencing Request Process)","1650":"[SB.2.12]7.3. Else","120":"[SB.2.12]7.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request: the result of the Choice Sequencing Request Process; End Sequencing Session: n/a; Exception: n/a)","1148":"[SB.2.12]8. Case: sequencing request is Jump","960":"[SB.2.12]8.1. Apply the Jump Sequencing Request Process","701":"[SB.2.12]8.2. If the Jump Sequencing Request Process returns an exception Then","84":"[SB.2.12]8.2.1. Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: the exception identified by the Jump Sequencing Request Process)","1651":"[SB.2.12]8.3. Else","123":"[SB.2.12]8.3.1. Exit Sequencing Request Process (Sequencing Request: Valid; Delivery Request:  the result of the Jump Sequencing Request Process; End Sequencing Session: n/a; Exception: n/a)","150":"[SB.2.12]8.Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: SB.2.12-1) (Invalid sequencing request)","151":"[SB.2.12]9.Exit Sequencing Request Process (Sequencing Request: Not Valid; Delivery Request: n/a; End Sequencing Session: n/a; Exception: SB.2.12-1) (Invalid sequencing request)","483":"[SB.2.13]1. If the Current Activity is not Defined Then (Make sure the sequencing session has already begun.)","435":"[SB.2.13]1.1. Exit Jump Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.13-1) (Nothing to deliver.)","351":"[SB.2.13]2. Exit Jump Sequencing Request Process (Delivery Request: the activity identified by the target activity; Exception: n/a)","1196":"[SB.2.1]1. Set reversed direction to False","24":"[SB.2.1]2. If (previous traversal direction is Defined And is Backward) And the activity is the last activity in the activity's parent's list of Available Children Then (Test if we have skipped all of the children in a forward only cluster moving backward)","1149":"[SB.2.1]2.1. traversal direction is Backward","552":"[SB.2.1]2.2. activity is the first activity in the activity's parent's list of Available Children","1168":"[SB.2.1]2.3. Set reversed direction to True","980":"[SB.2.1]3. If the traversal direction is Forward Then","266":"[SB.2.1]3.1. If the activity is the last activity in a forward preorder tree traversal of the activity tree Then (Cannot walk off the activity tree)","20":"[SB.2.1]3.1. If the activity is the last available activity in a forward preorder tree traversal of the activity tree Or (the activity is the Root of the Activity Tree And consider children is False) Then (Walking off the tree causes the sequencing session to end)","572":"[SB.2.1]3.1.1. Apply the Terminate Descendent Attempt Process to the root of the activity tree","436":"[SB.2.1]3.1.1. Exit Flow Tree Traversal Subprocess (Next Activity: Nil; Traversal Direction: n/a; Exception: SB.2.1-1)","174":"[SB.2.1]3.1.2. Exit Flow Tree Traversal Subprocess (Next Activity: n/a; End Sequencing Session: True; Exception: n/a) - Continuing past the last activity, exiting the course","763":"[SB.2.1]3.2. If the activity is a leaf Or consider children is False Then","478":"[SB.2.1]3.2.1. If the activity is the last activity in the activity's parent's list of Available Children Then","28":"[SB.2.1]3.2.1.1. Apply the Flow Tree Traversal Subprocess to the activity's parent in the Forward direction and a previous traversal direction of n/a with consider children equal to False (Recursion - Move to the activity's parent's next forward sibling)","225":"[SB.2.1]3.2.1.2. Exit Flow Tree Traversal Subprocess (Return the results of the recursive Flow Tree Traversal Subprocess) (Return the result of the recursion)","1620":"[SB.2.1]3.2.2. Else","298":"[SB.2.1]3.2.2.1. Traverse the tree, forward preorder, one activity to the next activity, in the activity's parent's list of Available Children","201":"[SB.2.1]3.2.2.2.Exit Flow Tree Traversal Subprocess (Next Activity: the activity identified by the traversal; Traversal Direction: traversal direction; Exception: n/a)","1150":"[SB.2.1]3.3. Else Entering a cluster Forward","392":"[SB.2.1]3.3.1. If the activity's list of Available Children is Not Empty Then Make sure this activity has a child activity","332":"[SB.2.1]3.3.1.1. Exit Flow Tree Traversal Subprocess (Next Activity: the first activity in the activity's list of Available Children (","1621":"[SB.2.1]3.3.2. Else","421":"[SB.2.1]3.3.2.1. Exit Flow Tree Traversal Subprocess (Next Activity Nil; Traversal Direction: n/a; Exception: SB.2.1-2)","971":"[SB.2.1]4. If the traversal direction is Backward Then","437":"[SB.2.1]4.1.1. Exit Flow Tree Traversal Subprocess (Next Activity: Nil; Traversal Direction: n/a; Exception: SB.2.1-3)","465":"[SB.2.1]4.1.If the activity is the root activity of the tree Then (Cannot walk off the root of the activity tree)","764":"[SB.2.1]4.2. If the activity is a leaf Or consider children is False Then","337":"[SB.2.1]4.2.1. If reversed direction is False Then (Only test 'forward only' if we are not going to leave this forward only cluster.)","317":"[SB.2.1]4.2.1.1. If Sequencing Control Forward Only for the parent of the activity is True Then (Test the control mode before traversing)","393":"[SB.2.1]4.2.1.1.1. Exit Flow Tree Traversal Subprocess (Next Activity: Nil; Traversal Direction: n/a; Exception: SB.2.1-4)","471":"[SB.2.1]4.2.2. If the activity is the first activity in the activity's parent's list of Available Children Then","25":"[SB.2.1]4.2.2.1. Apply the Flow Tree Traversal Subprocess to the activity's parent in the Backward direction and a previous traversal direction of n/a with consider children equal to False (Recursion - Move to the activity's parent's next backward sibling)","226":"[SB.2.1]4.2.2.2. Exit Flow Tree Traversal Subprocess (Return the results of the recursive Flow Tree Traversal Subprocess) (Return the result of the recursion)","1622":"[SB.2.1]4.2.3. Else","267":"[SB.2.1]4.2.3.1. Traverse the tree, reverse preorder, one activity to the previous activity, from the activity's parent's list of Available Children","808":"[SB.2.1]4.2.3.2. Exit Flow Tree Traversal Subprocess (Next Activity: ","1088":"[SB.2.1]4.3. Else (Entering a cluster Backward)","376":"[SB.2.1]4.3.1. If the activity's list of Available Children is Not Empty Then (Make sure this activity has a child activity)","49":"[SB.2.1]4.3.1.1.1. Exit Flow Tree Traversal Subprocess (Next Activity: the first activity in the activity's list of Available Children; Traversal Direction: Forward; Exception: n/a) (Start at the beginning of a forward only cluster)","1585":"[SB.2.1]4.3.1.2. Else","43":"[SB.2.1]4.3.1.2.1. Exit Flow Tree Traversal Subprocess (Next Activity: the last activity in the activity's list of Available Children; Traversal Direction: Backward; Exception: n/a) Start at the end of the cluster if we are backing into it","1623":"[SB.2.1]4.3.2. Else","408":"[SB.2.1]4.3.2.1. Exit Flow Tree Traversal Subprocess (Next Activity: Nil; Traversal Direction: n/a; Exception: SB.2.1-2)","458":"[SB.2.2]1. If Sequencing Control Flow for the parent of the activity is False Then (Confirm that 'flow' is enabled)","388":"[SB.2.2]1.1. Exit Flow Activity Traversal Subprocess (Deliverable: False; Next Activity: the activity; Exception: SB.2.2-1)","535":"[SB.2.2]2. Apply the Sequencing Rules Check Process to the activity and its Skipped sequencing rules","358":"[SB.2.2]3. If the Sequencing Rules Check Process does not return Nil Then (Activity is skipped, try to go to the 'next' activity)","185":"[SB.2.2]3.1. Apply the Flow Tree Traversal Subprocess to the activity in the traversal direction and the previous traversal direction with consider children equal to False","635":"[SB.2.2]3.2. If the Flow Tree Traversal Subprocess does not identify an activity Then","157":"[SB.2.2]3.2.1. Exit Flow Activity Traversal Subprocess (Deliverable: False; Next Activity: the activity; Exception: exception identified by the Flow Tree Traversal Subprocess)","32":"[SB.2.2]3.2.1. Exit Flow Activity Traversal Subprocess (Deliverable: False; Next Activity: the activity;End Sequencing Session: as identified by the Flow Tree Traversal Subprocess;  Exception: exception identified by the Flow Tree Traversal Subprocess)","1676":"[SB.2.2]3.3. Else","67":"[SB.2.2]3.3.1. If the previous traversal direction is Backward And the Traversal Direction returned by the Flow Tree Traversal Subprocess is Backward Then (Make sure the recursive call considers the correct direction)","35":"[SB.2.2]3.3.1.1. Apply the Flow Activity Traversal Subprocess to the activity identified by the Flow Tree Traversal Subprocess in the traversal direction and a previous traversal direction of n/a (Recursive call \ufffd make sure the 'next' activity is OK)","1624":"[SB.2.2]3.3.2. Else","9":"[SB.2.2]3.3.2.1. Apply the Flow Activity Traversal Subprocess to the activity identified by the Flow Tree Traversal Subprocess in the traversal direction and a previous traversal direction of previous traversal direction (Recursive call \ufffd make sure the 'next' activity is OK)","232":"[SB.2.2]3.3.3. Exit Flow Activity Traversal Subprocess -(Return the results of the recursive Flow Activity Traversal Subprocess) Possible exit from recursion","565":"[SB.2.2]4. Apply the Check Activity Process to the activity (Make sure the activity is allowed)","923":"[SB.2.2]5. If the Check Activity Process returns True Then","389":"[SB.2.2]5.1. Exit Flow Activity Traversal Subprocess (Deliverable: False; Next Activity: the activity; Exception: SB.2.2-2)","280":"[SB.2.2]6. If the activity is not a leaf node in the activity tree Then (Cannot deliver a non-leaf activity; enter the cluster looking for a leaf)","158":"[SB.2.2]6.1. Apply the Flow Tree Traversal Subprocess to the activity in the traversal direction and a previous traversal direction of n/a with consider children equal to True","636":"[SB.2.2]6.2. If the Flow Tree Traversal Subprocess does not identify an activity Then","33":"[SB.2.2]6.2.1. Exit Flow Activity Traversal Subprocess (Deliverable: False; Next Activity: the activity; End Sequencing Session: as identified by the Flow Tree Traversal Subprocess; Exception: exception identified by the Flow Tree Traversal Subprocess)","159":"[SB.2.2]6.2.1. Exit Flow Activity Traversal Subprocess (Deliverable: False; Next Activity: the activity; Exception: exception identified by the Flow Tree Traversal Subprocess)","1677":"[SB.2.2]6.3. Else","44":"[SB.2.2]6.3.1. If the traversal direction is Backward And the traversal direction returned by the Flow Tree Traversal Subprocess is Forward Then (Check if we are flowing backward through a forward only cluster - must move forward instead)","22":"[SB.2.2]6.3.1.1. Apply the Flow Activity Traversal Subprocess to the activity identified by the Flow Tree Traversal Subprocess in the Forward direction with the previous traversal direction of Backward (Recursive call \ufffd Make sure the identified activity is OK)","1625":"[SB.2.2]6.3.2. Else","29":"[SB.2.2]6.3.2.1. Apply the Flow Activity Traversal Subprocess to the activity identified by the Flow Tree Traversal Subprocess in the traversal direction and a previous traversal direction of n/a (Recursive call \ufffd Make sure the identified activity is OK)","227":"[SB.2.2]6.3.3. Exit Flow Activity Traversal Subprocess - (Return the results of the recursive Flow Activity Traversal Subprocess) Possible exit from recursion","359":"[SB.2.2]7. Exit Flow Activity Traversal Subprocess (Deliverable: True; Next Activity: the activity; Exception: n/a ) Found a leaf","508":"[SB.2.3]1. The candidate activity is the activity The candidate activity is where we start 'flowing' from","4":"[SB.2.3]2. Apply the Flow Tree Traversal Subprocess to the candidate activity in the traversal direction and a previous traversal direction of n/a with consider children equal to the consider children flag (Attempt to move away from the starting activity, one activity in the specified direction)","491":"[SB.2.3]3. If the Flow Tree Traversal Subprocess does not identify an activity Then (No activity to move to)","41":"[SB.2.3]3.1. Exit Flow Subprocess (Identified Activity: candidate activity; Deliverable: False; End Sequencing Session: as identified by the Flow Tree Traversal Subprocess; Exception: exception identified by the Flow Tree Traversal Subprocess)","205":"[SB.2.3]3.1. Exit Flow Subprocess (Identified Activity: candidate activity; Deliverable: False; Exception: exception identified by the Flow Tree Traversal Subprocess)","1704":"[SB.2.3]4. Else","557":"[SB.2.3]4.1. Candidate activity is the activity identified by the Flow Tree Traversal Subprocess","48":"[SB.2.3]4.2. Apply the Flow Activity Traversal Subprocess to the candidate activity in the traversal direction and a previous traversal direction of n/a (Validate the candidate activity and traverse until a valid leaf is encountered)","17":"[SB.2.3]4.3.Exit Flow Subprocess (Identified Activity: the activity identified by the Flow Activity Traversal Subprocess; Deliverable: as identified by the Flow Activity Traversal Subprocess; Exception: exception identified by the Flow Activity Traversal Subprocess)","0":"[SB.2.3]4.3.Exit Flow Subprocess (Identified Activity: the activity identified by the Flow Activity Traversal Subprocess; Deliverable: as identified by the Flow Activity Traversal Subprocess;End Sequencing Session: value identified by the Flow Activity Traversal Subprocess; Exception: exception identified by the Flow Activity Traversal Subprocess)","981":"[SB.2.4]1. If the traversal direction is Forward Then","445":"[SB.2.4]1.1. Apply the Sequencing Rules Check Process to the activity and the Stop Forward Traversal sequencing rules","731":"[SB.2.4]1.2. If the Sequencing Rules Check Process does not return Nil Then","558":"[SB.2.4]1.2.1. Exit Choice Activity Traversal Subprocess (Reachable: False; Exception: SB.2.4-1)","611":"[SB.2.4]1.3. Exit Choice Activity Traversal Subprocess (Reachable: True; Exception: n/a )","972":"[SB.2.4]2. If the traversal direction is Backward Then","1105":"[SB.2.4]2.1. If the activity has a parent Then","584":"[SB.2.4]2.1.1. If Sequencing Control Forward Only for the parent of the activity is True Then","548":"[SB.2.4]2.1.1.1. Exit Choice Activity Traversal Subprocess (Reachable: False; Exception: SB.2.4-2)","1626":"[SB.2.4]2.1.2. Else","237":"[SB.2.4]2.1.2.1. Exit Choice Activity Traversal Subprocess (Reachable: False; Exception: SB.2.4-3) (Cannot walk backward from the root of the activity tree)","612":"[SB.2.4]2.2. Exit Choice Activity Traversal Subprocess (Reachable: True; Exception: n/a )","498":"[SB.2.5]1. If the Current Activity is Defined Then (Make sure the sequencing session has not already begun)","455":"[SB.2.5]1.1. Exit Start Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.5-1) (Nothing to deliver)","318":"[SB.2.5]2. If the root of the activity tree is a leaf Then (Before starting, make sure the activity tree contains more than one activity)","240":"[SB.2.5]2.1. Exit Start Sequencing Request Process (Delivery Request: the root of the activity tree; Exception: n/a) (Only one activity, it must be a leaf)","315":"[SB.2.5]2.5 Rustici Extension - This course has a property that indicates we should always flow to the first SCO, so find it and return it","1049":"[SB.2.5]2.5.1. Get the ordered list of activities","924":"[SB.2.5]2.5.2. Loop to find the first deliverable activity","1691":"[SB.2.5]3. Else ","164":"[SB.2.5]3.1. Apply the Flow Subprocess to the root of the activity tree in the Forward direction with consider children equal to True (Attempt to flow into the activity tree)","973":"[SB.2.5]3.2. If the Flow Subprocess returns False Then","65":"[SB.2.5]3.2.1. Exit Start Sequencing Request Process (Delivery Request: n/a; End Sequencing Session: as identified by the Flow Subprocess; Exception: the exception identified by the Flow Subprocess) (Nothing to deliver)","233":"[SB.2.5]3.2.1. Exit Start Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Flow Subprocess) (Nothing to deliver)","1652":"[SB.2.5]3.3. Else ","325":"[SB.2.5]3.3.1. Exit Start Sequencing Request Process (Delivery Request: the activity identified by the Flow Subprocess; Exception: n/a)","499":"[SB.2.6]1. If the Current Activity is Defined Then (Make sure the sequencing session has not already begun)","400":"[SB.2.6]1.1. Exit Resume All Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.6-1) (Nothing to deliver)","401":"[SB.2.6]2.1. Exit Resume All Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.6-2) (Nothing to deliver)","58":"[SB.2.6]3.Exit Resume All Sequencing Request Process (Delivery Request: the activity identified by the Suspended Activity; Exception: n/a) (The Delivery Request Process validates that the Suspended Activity can be delivered)","500":"[SB.2.7]1. If the Current Activity is Not Defined Then (Make sure the sequencing session has already begun)","422":"[SB.2.7]1.1. Exit Continue Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.7-1) (Nothing to deliver)","708":"[SB.2.7]2. If the activity is not the root activity of the activity tree Then","299":"[SB.2.7]2.1. If Sequencing Control Flow for the parent of the activity is False Then (Confirm a 'flow' traversal is allowed from the activity)","566":"[SB.2.7]2.1.1. Exit Flow Tree Traversal Subprocess (Delivery Request: n/a; Exception: SB.2.7-2)","585":"[SB.2.7]2.1.1. Exit Flow Tree Traversal Subprocess (Next Activity: Nil; Exception: SB.2.7-2 )","136":"[SB.2.7]3. Apply the Flow Subprocess to the Current Activity in the Forward direction with consider children equal to False (Flow in a forward direction to the next allowed activity)","988":"[SB.2.7]4. If the Flow Subprocess returns False Then","63":"[SB.2.7]4.1. Exit Continue Sequencing Request Process (Delivery Request: n/a; End Sequencing Session: as identified by the Flow Subprocess; Exception: the exception identified by the Flow Subprocess) (Nothing to deliver)","228":"[SB.2.7]4.1. Exit Continue Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Flow Subprocess) (Nothing to deliver)","1705":"[SB.2.7]5. Else","319":"[SB.2.7]5.1. Exit Continue Sequencing Request Process (Delivery Request: the activity identified by the Flow Subprocess; Exception: n/a )","501":"[SB.2.8]1. If the Current Activity is Not Defined Then (Make sure the sequencing session has already begun)","409":"[SB.2.8]1.1. Exit Previous Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.8-1 ) (Nothing to deliver)","709":"[SB.2.8]2. If the activity is not the root activity of the activity tree Then","300":"[SB.2.8]2.1. If Sequencing Control Flow for the parent of the activity is False Then (Confirm a 'flow' traversal is allowed from the activity)","567":"[SB.2.8]2.1.1. Exit Flow Tree Traversal Subprocess (Delivery Request: n/a; Exception: SB.2.8-2)","593":"[SB.2.8]2.1.1. Exit Flow Tree Traversal Subprocess (Next Activity: Nil; Exception: SB.2.8-2)","131":"[SB.2.8]3. Apply the Flow Subprocess to the Current Activity in the Backward direction with consider children equal to False (Flow in a backward direction to the next allowed activity)","989":"[SB.2.8]4. If the Flow Subprocess returns False Then","229":"[SB.2.8]4.1. Exit Previous Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Flow Subprocess) (Nothing to deliver)","1706":"[SB.2.8]5. Else","324":"[SB.2.8]5.1. Exit Previous Sequencing Request Process (Delivery Request: the activity identified by the Flow Subprocess; Exception: n/a)","128":"[SB.2.9.1]1. Apply the Choice Flow Tree Traversal Subprocess to the activity in the traversal direction (Attempt to move away from the activity, 'one' activity in the specified direction)","732":"[SB.2.9.1]2. If the Choice Flow Tree Traversal Subprocess returned Nil Then","710":"[SB.2.9.1]2.1. Exit Choice Flow Subprocess (Identified Activity the activity)","1678":"[SB.2.9.1]3. Else","338":"[SB.2.9.1]3.1. Exit Choice Flow Subprocess (Identified Activity the activity identified by the Choice Flow Tree Traversal Subprocess)","961":"[SB.2.9.2]1. If the traversal direction is Forward Then","257":"[SB.2.9.2]1.1. If the activity is the last activity in a forward preorder tree traversal of the activity tree Then (Cannot walk off the activity tree)","74":"[SB.2.9.2]1.1. If the activity is the last available activity in a forward preorder tree traversal of the activity tree Or (the activity is the Root of the Activity Tree) Then (Cannot walk off the activity tree)","683":"[SB.2.9.2]1.1.1. Exit Choice Flow Tree Traversal Subprocess (Next Activity: Nil)","479":"[SB.2.9.2]1.2. If the activity is the last activity in the activity's parent's list of Available Children Then","137":"[SB.2.9.2]1.2.1.  Apply the Choice Flow Tree Traversal Subprocess to the activity's parent in the Forward direction (Recursion - Move to the activity's parent's next forward sibling)","143":"[SB.2.9.2]1.2.2. Exit Choice Flow Tree Traversal Subprocess (Next Activity: the results of the recursive Choice Flow Tree Traversal Subprocess) (Return the result of the recursion)","1627":"[SB.2.9.2]1.3. Else","301":"[SB.2.9.2]1.3.1. Traverse the tree, forward preorder, one activity to the next activity, in the activity's parent's list of Available Children","446":"[SB.2.9.2]1.3.2. Exit Choice Flow Tree Traversal Subprocess (Next Activity: the activity identified by the traversal)","952":"[SB.2.9.2]2. If the traversal direction is Backward Then","456":"[SB.2.9.2]2.1. If the activity is the root activity of the tree Then (Cannot walk off the root of the activity tree)","684":"[SB.2.9.2]2.1.1. Exit Choice Flow Tree Traversal Subprocess (Next Activity: Nil)","472":"[SB.2.9.2]2.2. If the activity is the first activity in the activity's parent's list of Available Children Then","135":"[SB.2.9.2]2.2.1. Apply the Choice Flow Tree Traversal Subprocess to the activity's parent in the Backward direction (Recursion \ufffd Move to the activity's parent's next backward sibling)","138":"[SB.2.9.2]2.2.1.1. Exit Choice Flow Tree Traversal Subprocess (Next Activity: the results of the recursive Choice Flow Tree Traversal Subprocess) (Return the result of the recursion)","1628":"[SB.2.9.2]2.3. Else","268":"[SB.2.9.2]2.3.1. Traverse the tree, reverse preorder, one activity to the previous activity, from the activity's parent's list of Available Children","447":"[SB.2.9.2]2.3.2. Exit Choice Flow Tree Traversal Subprocess (Next Activity: the activity identified by the traversal)","502":"[SB.2.9]1. If there is no target activity Then (There must be a target activity for choice) targetActivity=","448":"[SB.2.9]1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-1) (Nothing to deliver)","210":"[SB.2.9]10. Case: Current Activity and common ancestor are the same Or Current Activity is Not Defined (Case #3 - path to the target is forward in the activity tree)","287":"[SB.2.9]10. Case: Target activity is the common ancestor of the Current Activity (Case #4 - path to the target is backward in the activity tree)","344":"[SB.2.9]10.1. Form the activity path as the ordered series of activities from the Current Activity to the target activity, inclusive","242":"[SB.2.9]10.1. Form the activity path as the ordered series of activities from the common ancestor to the target activity, exclusive of the target activity","1066":"[SB.2.9]10.2. If the activity path is Empty Then","410":"[SB.2.9]10.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-5) (Nothing to deliver)","990":"[SB.2.9]10.3. For each activity on the activity path","515":"[SB.2.9]10.3.1. Apply the Choice Activity Traversal Subprocess to the activity in the Forward direction","662":"[SB.2.9]10.3.1. If the activity is not the last activity in the activity path Then","196":"[SB.2.9]10.3.1.1. If the Sequencing Control Choice Exit for the activity is False Then (Make sure an activity that should not exit will exit if the target is delivered)","573":"[SB.2.9]10.3.1.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: ","702":"[SB.2.9]10.3.2. If the Choice Activity Traversal Subprocess returns False Then","139":"[SB.2.9]10.3.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Choice Activity Traversal Subprocess) (Nothing to deliver)","18":"[SB.2.9]10.3.3. If Activity is Active for the activity is False And (the activity is Not the common ancestor And adlseq:preventActivation for the activity is True) Then (If the activity being considered is not already active, make sure we are allowed to activate it)","394":"[SB.2.9]10.3.3.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-6) (Nothing to deliver)","1428":"[SB.2.9]10.4. Break All Cases","288":"[SB.2.9]11. Case: Target activity is the common ancestor of the Current Activity (Case #4 - path to the target is backward in the activity tree)","251":"[SB.2.9]11.1. Form the activity path as the ordered series of activities from the Current Activity to the common ancestor, excluding the common ancestor","345":"[SB.2.9]11.1. Form the activity path as the ordered series of activities from the Current Activity to the common ancestor, inclusive","346":"[SB.2.9]11.1. Form the activity path as the ordered series of activities from the Current Activity to the target activity, inclusive","1407":"[SB.2.9]11.10. Break All Cases","1067":"[SB.2.9]11.2. If the activity path is Empty Then","411":"[SB.2.9]11.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-5) (Nothing to deliver)","991":"[SB.2.9]11.3. For each activity on the activity path","1003":"[SB.2.9]11.3. Set constrained activity to Undefined","663":"[SB.2.9]11.3.1. If the activity is not the last activity in the activity path Then","197":"[SB.2.9]11.3.1.1. If the Sequencing Control Choice Exit for the activity is False Then (Make sure an activity that should not exit will exit if the target is delivered)","377":"[SB.2.9]11.3.1.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-7) (Nothing to deliver)","1429":"[SB.2.9]11.4. Break All Cases","574":"[SB.2.9]11.4. For each activity on the activity path (Walk up the tree to the common ancestor)","206":"[SB.2.9]11.4.1. If the Sequencing Control Choice Exit for the activity is False Then - Make sure an activity that should not exit will exit if the target is delivered","664":"[SB.2.9]11.4.1. If the activity is not the last activity in the activity path Then","594":"[SB.2.9]11.4.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: ","198":"[SB.2.9]11.4.1.1. If the Sequencing Control Choice Exit for the activity is False Then - Make sure an activity that should not exit will exit if the target is delivered","575":"[SB.2.9]11.4.1.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: ","402":"[SB.2.9]11.4.2. If constrained activity is Undefined Then (Find the closest constrained activity to the current activity)","733":"[SB.2.9]11.4.2.1. If adlseq:constrainedChoice for the activity is True Then","925":"[SB.2.9]11.4.2.1.1.Set constrained activity to activity: '","982":"[SB.2.9]11.5. If constrained activity is Defined Then","469":"[SB.2.9]11.5.1. If the target activity is Forward in the activity tree relative to the constrained activity Then","529":"[SB.2.9]11.5.1.1. traverse is Forward ('Flow' in a forward direction to see what activity comes next)","1600":"[SB.2.9]11.5.2. Else","516":"[SB.2.9]11.5.2.1. traverse is Backward ('Flow' in a backward direction to see what activity comes next)","523":"[SB.2.9]11.5.3. Apply the Choice Flow Subprocess to the constrained activity in the traverse direction","559":"[SB.2.9]11.5.4. Set activity to consider to the activity identified by the Choice FlowSubprocess","7":"[SB.2.9]11.5.5. If the target activity is Not an available descendent of the activity to consider And the target activity is Not the activity to consider And the target activity is Not the constrained activity Then (Make sure the target activity is within the set of 'flow' constrained choices)","5":"[SB.2.9]11.5.5. If the target activity is Not an available descendent of the activity to consider And the target activity is Not the activity to considered And the target activity is Not the constrained activity Then (Make sure the target activity is within the set of 'flow' constrained choices)","595":"[SB.2.9]11.5.5.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: ","243":"[SB.2.9]11.6. Form the activity path as the ordered series of activities from the common ancestor to the target activity, exclusive of the target activity","1068":"[SB.2.9]11.7. If the activity path is Empty Then","412":"[SB.2.9]11.7.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-5) (Nothing to deliver)","305":"[SB.2.9]11.8. If the target activity is forward in the activity tree relative to the Current Activity Then (Walk toward the target activity)","974":"[SB.2.9]11.8.1. For each activity on the activity path","234":"[SB.2.9]11.8.1.1. Apply the Choice Activity Traversal Subprocess to the activity in the Forward direction (to check for Stop Forward Traversal violations) i=","685":"[SB.2.9]11.8.1.2. If the Choice Activity Traversal Subprocess returns False Then","132":"[SB.2.9]11.8.1.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Choice Activity Traversal Subprocess) (Nothing to deliver)","15":"[SB.2.9]11.8.1.3. If Activity is Active for the activity is False And(the activity is Not the common ancestor And adlseq:preventActivation for the activity is True) Then (If the activity being considered is not already active, make sure we are allowed to activate it)","576":"[SB.2.9]11.8.1.3.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: ","1653":"[SB.2.9]11.9. Else","975":"[SB.2.9]11.9.1. For each activity on the activity path","577":"[SB.2.9]11.9.1.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: ","289":"[SB.2.9]11.Case: Target activity is forward from the common ancestor activity (Case #5 - target is a descendent activity of the common ancestor)","926":"[SB.2.9]12. If the target activity is a leaf activity Then","492":"[SB.2.9]12.1. Exit Choice Sequencing Request Process (Delivery Request: the target activity; Exception: n/a)","347":"[SB.2.9]12.1. Form the activity path as the ordered series of activities from the Current Activity to the common ancestor, inclusive","1408":"[SB.2.9]12.10. Break All Cases","1069":"[SB.2.9]12.2. If the activity path is Empty Then","413":"[SB.2.9]12.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-5) (Nothing to deliver)","1004":"[SB.2.9]12.3. Set constrained activity to Undefined","578":"[SB.2.9]12.4. For each activity on the activity path (Walk up the tree to the common ancestor)","665":"[SB.2.9]12.4.1. If the activity is not the last activity in the activity path Then","199":"[SB.2.9]12.4.1.1. If the Sequencing Control Choice Exit for the activity is False Then - Make sure an activity that should not exit will exit if the target is delivered","378":"[SB.2.9]12.4.1.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-7) (Nothing to deliver)","403":"[SB.2.9]12.4.2. If constrained activity is Undefined Then (Find the closest constrained activity to the current activity)","734":"[SB.2.9]12.4.2.1. If adlseq:constrainedChoice for the activity is True Then","962":"[SB.2.9]12.4.2.1.1.Set constrained activity to activity","983":"[SB.2.9]12.5. If constrained activity is Defined Then","470":"[SB.2.9]12.5.1. If the target activity is Forward in the activity tree relative to the constrained activity Then","530":"[SB.2.9]12.5.1.1. traverse is Forward ('Flow' in a forward direction to see what activity comes next)","1601":"[SB.2.9]12.5.2. Else","517":"[SB.2.9]12.5.2.1. traverse is Backward ('Flow' in a backward direction to see what activity comes next)","524":"[SB.2.9]12.5.3. Apply the Choice Flow Subprocess to the constrained activity in the traverse direction","560":"[SB.2.9]12.5.4. Set activity to consider to the activity identified by the Choice FlowSubprocess","6":"[SB.2.9]12.5.5. If the target activity is Not an available descendent of the activity to consider And the target activity is Not the activity to considered And the target activity is Not the constrained activity Then (Make sure the target activity is within the set of 'flow' constrained choices)","531":"[SB.2.9]12.5.5.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-8)","244":"[SB.2.9]12.6. Form the activity path as the ordered series of activities from the common ancestor to the target activity, exclusive of the target activity","1070":"[SB.2.9]12.7. If the activity path is Empty Then","414":"[SB.2.9]12.7.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-5) (Nothing to deliver)","306":"[SB.2.9]12.8. If the target activity is forward in the activity tree relative to the Current Activity Then (Walk toward the target activity)","976":"[SB.2.9]12.8.1. For each activity on the activity path","509":"[SB.2.9]12.8.1.1. Apply the Choice Activity Traversal Subprocess to the activity in the Forward direction","686":"[SB.2.9]12.8.1.2. If the Choice Activity Traversal Subprocess returns False Then","133":"[SB.2.9]12.8.1.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Choice Activity Traversal Subprocess) (Nothing to deliver)","16":"[SB.2.9]12.8.1.3. If Activity is Active for the activity is False And(the activity is Not the common ancestor And adlseq:preventActivation for the activity is True) Then (If the activity being considered is not already active, make sure we are allowed to activate it)","379":"[SB.2.9]12.8.1.3.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-6) (Nothing to deliver)","1654":"[SB.2.9]12.9. Else","977":"[SB.2.9]12.9.1. For each activity on the activity path","380":"[SB.2.9]12.9.1.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-6) (Nothing to deliver)","290":"[SB.2.9]12.Case: Target activity is forward from the common ancestor activity (Case #5 - target is a descendent activity of the common ancestor)","51":"[SB.2.9]13. Apply the Flow Subprocess to the target activity in the Forward direction with consider children equal to True (The identified activity is a cluster. Enter the cluster and attempt to find a descendent leaf to deliver)","927":"[SB.2.9]13. If the target activity is a leaf activity Then","493":"[SB.2.9]13.1. Exit Choice Sequencing Request Process (Delivery Request: the target activity; Exception: n/a)","52":"[SB.2.9]14. Apply the Flow Subprocess to the target activity in the Forward direction with consider children equal to True (The identified activity is a cluster. Enter the cluster and attempt to find a descendent leaf to deliver)","252":"[SB.2.9]14. If the Flow Subprocess returns False Then (Nothing to deliver, but we succeeded in reaching the target activity - move the current activity)","646":"[SB.2.9]14.1. Apply the Terminate Descendent Attempts Process to the common ancestor","839":"[SB.2.9]14.2. Apply the End Attempt Process to the common ancestor","884":"[SB.2.9]14.3. Set the Current Activity to the target activity","438":"[SB.2.9]14.4. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-9) (Nothing to deliver)","1692":"[SB.2.9]15. Else","253":"[SB.2.9]15. If the Flow Subprocess returns False Then (Nothing to deliver, but we succeeded in reaching the target activity - move the current activity)","647":"[SB.2.9]15.1. Apply the Terminate Descendent Attempts Process to the common ancestor","310":"[SB.2.9]15.1. Exit Choice Sequencing Request Process (Delivery Request: for the activity identified by the Flow Subprocess; Exception: n/a)","840":"[SB.2.9]15.2. Apply the End Attempt Process to the common ancestor","885":"[SB.2.9]15.3. Set the Current Activity to the target activity","439":"[SB.2.9]15.4. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-9) (Nothing to deliver)","1693":"[SB.2.9]16. Else","311":"[SB.2.9]16.1. Exit Choice Sequencing Request Process (Delivery Request: for the activity identified by the Flow Subprocess; Exception: n/a)","333":"[SB.2.9]2.\tForm the activity path as the ordered series of activities from root of the activity tree to the target activity, inclusive","735":"[SB.2.9]2. If the target activity is not the root of the activity tree Then","217":"[SB.2.9]2.1. If the Available Children for the parent of the target activity does not contain the target activity Then (The activity is currently not available)","423":"[SB.2.9]2.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-2) (Nothing to deliver)","1029":"[SB.2.9]3.\tFor each activity in the activity path\t","316":"[SB.2.9]3. Form the activity path as the ordered series of activities from the root of the activity tree to the target activity, inclusive","794":"[SB.2.9]3.1.\tIf the activity is Not the root of the activity tree Then","262":"[SB.2.9]3.1.1.\tIf the Available Children for the parent of the activity does not contain the activity Then\t(The activity is currently not available.)","395":"[SB.2.9]3.1.1.1.\tExit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-2)\t(Nothing to deliver.)","247":"[SB.2.9]3.2.\tApply the Sequencing Rules Check Process to the activity and the Hide from Choice sequencing rules\t(Cannot choose something that is hidden.)","736":"[SB.2.9]3.3.\tIf the Sequencing Rules Check Process does not return Nil Then","220":"[SB.2.9]3.3.1\tExit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-3)\tNothing to deliver. (Cannot choose something that is hidden.)","1050":"[SB.2.9]4. For each activity in the activity path","254":"[SB.2.9]4.1. Apply the Sequencing Rules Check Process to the activity and the Hide from Choice sequencing rules (Cannot choose something that is hidden)","221":"[SB.2.9]4.1. If the Sequencing Control Mode Choice for the parent of the target activity is False Then (Confirm that control mode allow 'choice' of the target)","424":"[SB.2.9]4.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-4) (Nothing to deliver)","737":"[SB.2.9]4.2. If the Sequencing Rules Check Process does not return Nil Then","425":"[SB.2.9]4.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-3) (Nothing to deliver)","749":"[SB.2.9]4.If the target activity is not the root of the activity tree Then","579":"[SB.2.9]5. If the Current Activity is Defined Then (Has the sequencing session already begun?)","637":"[SB.2.9]5.1. Find the common ancestor of the Current Activity and the target activity","222":"[SB.2.9]5.1. If the Sequencing Control Mode Choice for the parent of the target activity is False Then (Confirm that control mode allow 'choice' of the target)","426":"[SB.2.9]5.1.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-4) (Nothing to deliver)","750":"[SB.2.9]5.If the target activity is not the root of the activity tree Then","1707":"[SB.2.9]6. Else","580":"[SB.2.9]6. If the Current Activity is Defined Then (Has the sequencing session already begun?)","638":"[SB.2.9]6.1. Find the common ancestor of the Current Activity and the target activity","373":"[SB.2.9]6.1. Set common ancestor is the root of the activity tree (No, choosing the target will start the sequencing session)","503":"[SB.2.9]7. Case: Current Activity and target activity are identical (Case #1 - select the current activity)","1708":"[SB.2.9]7. Else","938":"[SB.2.9]7.1. Break All Cases (Nothing to do in this case)","374":"[SB.2.9]7.1. Set common ancestor is the root of the activity tree (No, choosing the target will start the sequencing session)","504":"[SB.2.9]8. Case: Current Activity and target activity are identical (Case #1 - select the current activity)","363":"[SB.2.9]8. Case: Current Activity and the target activity are siblings (Case #2 - same cluster; move toward the target activity)","939":"[SB.2.9]8.1. Break All Cases (Nothing to do in this case)","10":"[SB.2.9]8.1. Form the activity list as the ordered sequence of activities from the Current Activity to the target activity, exclusive of the target activity (We are attempted to walk toward the target activity. Once we reach the target activity, we don't need to test it.)","830":"[SB.2.9]8.2. If the activity list is Empty Then (Nothing to choose)","427":"[SB.2.9]8.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-5) (Nothing to deliver)","449":"[SB.2.9]8.3. If the target activity occurs after the Current Activity in preorder traversal of the activity tree Then","1343":"[SB.2.9]8.3.1. traverse is Forward","1679":"[SB.2.9]8.4. Else","1317":"[SB.2.9]8.4.1. traverse is Backward","1005":"[SB.2.9]8.5. For each activity on the activity list","518":"[SB.2.9]8.5.1. Apply the Choice Activity Traversal Subprocess to the activity in the traverse direction","711":"[SB.2.9]8.5.2. If the Choice Activity Traversal Subprocess returns False Then","140":"[SB.2.9]8.5.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Choice Activity Traversal Subprocess) (Nothing to deliver)","1449":"[SB.2.9]8.6. Break All Cases","213":"[SB.2.9]9. Case: Current Activity and common ancestor are the same Or Current Activity is Not Defined (Case #3 - path to the target is forward in the activity tree)","364":"[SB.2.9]9. Case: Current Activity and the target activity are siblings (Case #2 - same cluster; move toward the target activity)","11":"[SB.2.9]9.1. Form the activity list as the ordered sequence of activities from the Current Activity to the target activity, exclusive of the target activity (We are attempted to walk toward the target activity. Once we reach the target activity, we don't need to test it.)","248":"[SB.2.9]9.1. Form the activity path as the ordered series of activities from the common ancestor to the target activity, exclusive of the target activity","831":"[SB.2.9]9.2. If the activity list is Empty Then (Nothing to choose)","1089":"[SB.2.9]9.2. If the activity path is Empty Then","428":"[SB.2.9]9.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: SB.2.9-5) (Nothing to deliver)","1006":"[SB.2.9]9.3. For each activity on the activity path","450":"[SB.2.9]9.3. If the target activity occurs after the Current Activity in preorder traversal of the activity tree Then","525":"[SB.2.9]9.3.1. Apply the Choice Activity Traversal Subprocess to the activity in the Forward direction","1344":"[SB.2.9]9.3.1. traverse is Forward","712":"[SB.2.9]9.3.2. If the Choice Activity Traversal Subprocess returns False Then","141":"[SB.2.9]9.3.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Choice Activity Traversal Subprocess) (Nothing to deliver)","19":"[SB.2.9]9.3.3. If Activity is Active for the activity is False And (the activity is Not the common ancestor And adlseq:preventActivation for the activity is True) Then (If the activity being considered is not already active, make sure we are allowed to activate it)","603":"[SB.2.9]9.3.3.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: ","1450":"[SB.2.9]9.4. Break All Cases","1680":"[SB.2.9]9.4. Else","1318":"[SB.2.9]9.4.1. traverse is Backward","1007":"[SB.2.9]9.5. For each activity on the activity list","519":"[SB.2.9]9.5.1. Apply the Choice Activity Traversal Subprocess to the activity in the traverse direction","713":"[SB.2.9]9.5.2. If the Choice Activity Traversal Subprocess returns False Then","142":"[SB.2.9]9.5.2.1. Exit Choice Sequencing Request Process (Delivery Request: n/a; Exception: the exception identified by the Choice Activity Traversal Subprocess) (Nothing to deliver)","1451":"[SB.2.9]9.6. Break All Cases","542":"[SCORM Engine Extension] Child Set is Empty and Control.Package.Properties.RollupEmptySetToUnknown=","561":"[SR.1]1. If the activity does not have children Then (Cannot apply selection to a leaf activity)","1251":"[SR.1]1.1. Exit Select Children Process","175":"[SR.1]2. If Activity is Suspended for the activity is True Or the Activity is Active for the activity is True Then (Cannot apply selection to a suspended or active activity)","1252":"[SR.1]2.1. Exit Select Children Process","886":"[SR.1]3. Case: the Selection Timing for the activity is Never","1253":"[SR.1]3.1. Exit Select Children Process","895":"[SR.1]4. Case: the Selection Timing for the activity is Once","817":"[SR.1]4.05. If children have not been selected for this activity yet","440":"[SR.1]4.1. If the Activity Progress Status for the activity is False Then (If the activity has not been attempted yet)","772":"[SR.1]4.1.1. If the Selection Count Status for the activity is True Then","887":"[SR.1]4.1.1.1. Initialize child list as an Empty ordered list","869":"[SR.1]4.1.1.2. Iterate Selection Count, for the activity, times","536":"[SR.1]4.1.1.2.1. Randomly select (without replacement) an activity from the children of the activity","339":"[SR.1]4.1.1.2.2. Add the selected activity to the child list, retaining the original (from the activity) relative order of activities","773":"[SR.1]4.1.1.3. Set Available Children for the activity to the child list","1254":"[SR.1]4.2. Exit Select Children Process","738":"[SR.1]5. Case: the Selection Timing for the activity is On Each New Attempt","896":"[SR.1]5.1. Exit Select Children Process (Undefined behavior)","841":"[SR.1]6. Exit Select Children Process (Undefined timing attribute)","537":"[SR.2]1. If the activity does not have children Then (Cannot apply randomization to a leaf activity)","1197":"[SR.2]1.1. Exit Randomize Children Process","155":"[SR.2]2. If Activity is Suspended for the activity is True Or the Activity is Activefor the activity is True Then (Cannot apply randomization to a suspended or active activity)","1198":"[SR.2]2.1. Exit Randomize Children Process","853":"[SR.2]3. Case: the Randomization Timing for the activity is Never","1199":"[SR.2]3.1. Exit Randomize Children Process","860":"[SR.2]4. Case: the Randomization Timing for the activity is Once","782":"[SR.2]4.05. If the activity's children have not already been randomized","441":"[SR.2]4.1. If the Activity Progress Status for the activity is False Then (If the activity has not been attempted yet)","861":"[SR.2]4.1.1. If Randomize Children for the activity is True Then","568":"[SR.2]4.1.1.1. Randomly reorder the activities contained in Available Children for the activity","1200":"[SR.2]4.2. Exit Randomize Children Process","695":"[SR.2]5. Case: the Randomization Timing for the activity is On Each New Attempt","875":"[SR.2]5.1. If Randomize Children for the activity is True Then","586":"[SR.2]5.1.1. Randomly reorder the activities contained in Available Children for the activity","1201":"[SR.2]5.2. Exit Randomize Children Process","832":"[SR.2]6. Exit Randomize Children Process Undefined timing attribute","249":"[TB.2.1]1. Form the activity path as the ordered series of activities from the root of the activity tree to the parent of the Current Activity, inclusive","1219":"[TB.2.1]2. Initialize exit target to Null","307":"[TB.2.1]3. For each activity in the activity path (Evaluate all exit rules along the active path, starting at the root of the activity tree)","553":"[TB.2.1]3.1. Apply the Sequencing Rules Check Process to the activity and the set of Exit actions","739":"[TB.2.1]3.2. If the Sequencing Rules Check Process does not return Nil Then","415":"[TB.2.1]3.2.1. Set the exit target to the activity (Stop at the first activity that has an exit rule evaluating to true)","1533":"[TB.2.1]3.2.2. Break For","1202":"[TB.2.1]4. If exit target is Not Null Then","352":"[TB.2.1]4.1. Apply the Terminate Descendent Attempts Process to the exit target (End the current attempt on all active descendents)","466":"[TB.2.1]4.2. Apply the End Attempt Process to the exit target (End the current attempt on the 'exiting' activity)","348":"[TB.2.1]4.3. Set the Current Activity to the exit target (Move the current activity to the activity that identified for termination)","963":"[TB.2.1]5. Exit Sequencing Exit Action Rules Subprocess","340":"[TB.2.2]1. If Activity is Suspended for the Current Activity is True Then (Do not apply post condition rules to a suspended activity)","897":"[TB.2.2]1.1. Exit Sequencing Post Condition Rules Subprocess","190":"[TB.2.2]2. Apply the Sequencing Rules Check Process to the Current Activity and the set of Post Condition actions (Apply the post condition rules to the current activity)","765":"[TB.2.2]3. If the Sequencing Rules Check Process does not return Nil Then","587":"[TB.2.2]3.1. If the Sequencing Rules Check Process returned Retry, Continue, Or Previous Then","47":"[TB.2.2]3.1.1. Exit Sequencing Post Condition Rules Subprocess (Sequencing Request: the value returned by the Sequencing Rules Check Process; Termination Request: n/a) (Attempt to override any pending sequencing request with this one)","620":"[TB.2.2]3.2. If the Sequencing Rules Check Process returned Exit Parent Or Exit All Then","85":"[TB.2.2]3.2.1. Exit Sequencing Post Condition Rules Subprocess (Sequencing Request: n/a; Termination Request: the value returned by the Sequencing Rules Check Process) (Terminate the appropriate activity(s))","751":"[TB.2.2]3.3. If the Sequencing Rules Check Process returned Retry All Then","30":"[TB.2.2]3.3.1. Exit Sequencing Post Condition Rules Subprocess (Termination Request: Exit All; Sequencing Request: Retry) (Terminate all active activities and move the current activity to the root of the activity tree; then perform an 'in-process' start)","484":"[TB.2.2]4. Exit Sequencing Post Condition Rules Subprocess (Sequencing Request: n/a; Sequencing Request; n/a)","367":"[TB.2.3]1. If the Current Activity is Not Defined Then (If the sequencing session has not begun, there is nothing to terminate)","381":"[TB.2.3]1.1. Exit Termination Request Process (Termination Request: Not Valid; Sequencing Request: n/a; Exception: TB.2.3-1)","88":"[TB.2.3]2. If (the termination request is Exit Or Abandon) And Activity is Active for the Current Activity is False Then (If the current activity has already been terminated, there is nothing to terminate)","382":"[TB.2.3]2.1. Exit Termination Request Process (Termination Request: Not Valid; Sequencing Request: n/a; Exception: TB.2.3-2)","1151":"[TB.2.3]3. Case: termination request is Exit","383":"[TB.2.3]3.1. Apply the End Attempt Process to the Current Activity  (Ensure the state of the current activity is up to date)","241":"[TB.2.3]3.2. Apply the Sequencing Exit Action Rules Subprocess to the Current Activity (Check if any of the current activity's ancestors need to terminate)","1629":"[TB.2.3]3.3. Repeat","1106":"[TB.2.3]3.3.1. Set the processed exit to False","588":"[TB.2.3]3.3.2. Apply the Sequencing Post Condition Rules Subprocess to the Current Activity (","473":"[TB.2.3]3.3.3. If the Sequencing Post Condition Rule Subprocess returned a termination request of Exit All Then","906":"[TB.2.3]3.3.3.1. Change the termination request to Exit All","674":"[TB.2.3]3.3.3.2. Break to the next Case (Process an Exit All Termination Request)","53":"[TB.2.3]3.3.4. If the Sequencing Post Condition Rule Subprocess returned a termination request of Exit Parent Then (If we exit the parent of the current activity, move the current activity to the parent of the current activity.)","281":"[TB.2.3]3.3.4.1. If the Current Activity is Not the root of the activity tree Then (The root of the activity tree does not have a parent to exit)","675":"[TB.2.3]3.3.4.1.1. Set the Current Activity to the parent of the Current Activity","774":"[TB.2.3]3.3.4.1.2. Apply the End Attempt Process to the Current Activity","494":"[TB.2.3]3.3.4.1.3. Set processed exit to True (Need to evaluate post conditions on the new current activity)","1586":"[TB.2.3]3.3.4.2. Else","355":"[TB.2.3]3.3.4.2.1. Exit Termination Request Process (Termination Request: Not Valid; Sequencing Request: n/a; Exception: TB.2.3-4)","1630":"[TB.2.3]3.3.5. Else","8":"[TB.2.3]3.3.5.1. If the Current Activity is the Root of the Activity Tree And the sequencing request returned by the Sequencing Post Condition Rule Subprocess is Not Retry Then If the attempt on the root of the Activity Tree is ending without a Retry, the Sequencing Session also ends","404":"[TB.2.3]3.3.5.1.1. Exit Termination Request Process (Termination Request: Valid; Sequencing Request: Exit; Exception: n/a","54":"[TB.2.3]3.6. Exit Termination Request Process (Termination Request: Valid; Sequencing Request: is the sequencing request returned by the Sequencing Post Condition Rule Subprocess, if one exists, otherwise n/a; Exception: n/a)","1071":"[TB.2.3]4. Case: termination request is Exit All","818":"[TB.2.3]4.1.1. Apply the End Attempt Process to the Current Activity","238":"[TB.2.3]4.1.If Activity is Active for the Current Activity is True Then (Has the completion subprocess and rollup been applied to the current activity yet?)","589":"[TB.2.3]4.2. Apply the Terminate Descendent Attempts Process to the root of the activity tree","740":"[TB.2.3]4.3. Apply the End Attempt Process to the root of the activity tree","353":"[TB.2.3]4.4. Set the Current Activity to the root of the activity tree (Move the current activity to the root of the activity tree)","3":"[TB.2.3]4.5. Exit Termination Request Process (Termination Request: Valid; Sequencing Request: is the sequencing request returned by the Sequencing Post Condition Rule Subprocess, if one exists, otherwise an Exit sequencing request; Exception: n/a) Inform the sequencer that the sequencing session has ended","451":"[TB.2.3]4.5.1 Sequencing Request: is the sequencing request returned by the Sequencing Post Condition Rule Subprocess","1030":"[TB.2.3]4.5.2 Otherwise an Exit sequencing request","1008":"[TB.2.3]5. Case: termination request is Suspend All","45":"[TB.2.3]5.1. If (the Activity is Active for the Current Activity is True) Or (the Activity is Suspended for the Current Activity is True) Then (If the current activity is active or already suspended, suspend it and all of its descendents)","510":"[TB.2.3]5.1.0.1. Apply the End Attempt Process to the Current Activity upon Return To LMS (Not in p-code)","1090":"[TB.2.3]5.1.1. Apply the Overall Rollup Process","854":"[TB.2.3]5.1.1. Set the Suspended Activity to the Current Activity","855":"[TB.2.3]5.1.2. Set the Suspended Activity to the Current Activity","1681":"[TB.2.3]5.2. Else","258":"[TB.2.3]5.2.1. If the Current Activity is not the root of the activity tree Then (Make sure the current activity is not the root of the activity tree)","676":"[TB.2.3]5.2.1.1. Set the Suspended Activity to the parent of the Current Activity","1631":"[TB.2.3]5.2.2. Else","263":"[TB.2.3]5.2.2.1. Exit Termination Request Process (Termination Request: Not Valid; Sequencing Request: n/a; Exception: TB.2.3-3) (Nothing to suspend)","273":"[TB.2.3]5.3. Form the activity path as the ordered series of all activities from the Suspended Activity to the root of the activity tree, inclusive","1091":"[TB.2.3]5.4. If the activity path is Empty Then","274":"[TB.2.3]5.4.1. Exit Termination Request Process (Termination Request: Not Valid; Sequencing Request: n/a; Exception: TB.2.3-5) (Nothing to suspend)","1009":"[TB.2.3]5.5. For each activity in the activity path","639":"[TB.2.3]5.5.1. Set Activity is Active for the activity to False (Activity Identifier=","856":"[TB.2.3]5.5.2. Set Activity is Suspended for the activity to True","354":"[TB.2.3]5.6. Set the Current Activity to the root of the activity tree (Move the current activity to the root of the activity tree)","160":"[TB.2.3]5.7. Exit Termination Request Process (Termination Request: Valid; Sequencing Request: Exit; Exception: n/a) Inform the sequencer that the sequencing session has ended","1092":"[TB.2.3]6. Case: termination request is Abandon","809":"[TB.2.3]6.1. Set Activity is Active for the Current Activity to False","459":"[TB.2.3]6.2. Exit Termination Request Process (Termination Request: Valid; Sequencing Request: n/a; Exception: n/a)","1010":"[TB.2.3]7. Case: termination request is Abandon All","282":"[TB.2.3]7.1. Form the activity path as the ordered series of all activities from the Current Activity to the root of the activity tree, inclusive","1093":"[TB.2.3]7.2. If the activity path is Empty Then","283":"[TB.2.3]7.2.1. Exit Termination Request Process (Termination Request: Not Valid; Sequencing Request: n/a; Exception: TB.2.3-6) Nothing to abandon","1011":"[TB.2.3]7.3. For each activity in the activity path","870":"[TB.2.3]7.3.1. Set Activity is Active for the activity to False","360":"[TB.2.3]7.4. Set the Current Activity to the root of the activity tree Move the current activity to the root of the activity tree","165":"[TB.2.3]7.5.Exit Termination Request Process (Termination Request: Valid; Sequencing Request: Exit; Exception: n/a) Inform the sequencer that the sequencing session has ended","255":"[TB.2.3]8. Exit Termination Request Process (Termination Request: Not Valid; Sequencing Request: n/a; Exception: TB.2.3-7) Undefined termination request","543":"[UP.1] 4 - 9 Note - duration and time based limit controls are not evaluated in this implementation","384":"[UP.1]1. If Tracked for the activity is False Then (If the activity is not tracked, its limit conditions cannot be violated)","296":"[UP.1]1.1. Exit Limit Conditions Check Process (Limit Condition Violated: False) (Activity is not tracked, no limit conditions can be violated)","144":"[UP.1]2. If the Activity is Active for the activity is True Or the Activity is Suspended for the activity is True Then (Only need to check activities that will begin a new attempt)","687":"[UP.1]2.1. Exit Limit Conditions Check Process (Limit Condition Violated: False)","714":"[UP.1]3. If the Limit Condition Attempt Control for the activity is True Then","89":"[UP.1]3.1. If the Activity Progress Status for the activity is True And the Activity Attempt Count for the activity is greater than or equal (>=) to the Limit Condition Attempt Limit for the activity Then","429":"[UP.1]3.1.1. Exit Limit Conditions Check Process (Limit Condition Violated: True) (Limit conditions have been violated)","326":"[UP.2.1]1. Initialize rule condition bag as an Empty collection (This is used to keep track of the evaluation of the rule's conditions)","741":"[UP.2.1]2. For each Rule Condition for the Sequencing Rule for the activity","102":"[UP.2.1]2.1. Evaluate the rule condition by applying the appropriate tracking information for the activity to the Rule Condition (Evaluate each condition against the activity's tracking information)","703":"[UP.2.1]2.2. If the Rule Condition Operator for the Rule Condition is Not Then","666":"[UP.2.1]2.2.1. Negate the rule condition (Negating 'unknown' results in 'unknown')","291":"[UP.2.1]2.3. Add the value of rule condition to the rule condition bag (Add the evaluation of this condition to the set of evaluated conditions)","375":"[UP.2.1]3. If the rule condition bag is Empty Then (If there are no defined conditions for the rule, the rule does not apply)","613":"[UP.2.1]3.1. Exit Sequencing Rule Check Subprocess (Result: Unknown) (No rule conditions)","62":"[UP.2.1]4. Apply the Rule Combination for the Sequencing Rule to the rule condition bag to produce a single combined rule evaluation ('And' or 'Or' the set of evaluated conditions, based on the sequencing rule definition)","621":"[UP.2.1]5. Exit Sequencing Rule Check Subprocess (Result: the value of rule evaluation) ","304":"[UP.2]1. If the activity includes Sequencing Rules with any of the specified Rule Actions Then (Make sure the activity has rules to evaluate)","191":"[UP.2]1.1. Initialize rules list by selecting the set of Sequencing Rules for the activity that have any of the specified Rule Actions (maintaining original rule ordering","1203":"[UP.2]1.2. For each rule in the rules list","416":"[UP.2]1.2.1. Apply the Sequencing Rule Check Subprocess to the activity and the rule (Evaluate each rule, one at a time)","795":"[UP.2]1.2.2. If the Sequencing Rule Check Subprocess returns True Then","211":"[UP.2]1.2.2.1. Exit Sequencing Rules Check Process (Action: Rule Action for the rule) (Stop at the first rule that evaluates to true - perform the associated action)","460":"[UP.2]2. Exit Sequencing Rules Check Process (Action: Nil) (No rules evaluated to true - do not perform any action)","688":"[UP.3]1. Find the activity that is the common ancestor of the Current Activity (","152":"[UP.3]2. Form the activity path as the ordered series of activities from the Current Activity to the common ancestor, exclusive of the Current Activity and the common ancestor (","526":"[UP.3]3. If the activity path is Not Empty Then (There are some activities that need to be terminated)","1051":"[UP.3]3.1. For each activity in the activity path","474":"[UP.3]3.1.1. Apply the End Attempt Process to the activity (End the current attempt on each activity) Activity-","742":"[UP.3]3.a Rollup the rollup set accumulated during the EndAttempt processes","1012":"[UP.3]4. Exit Terminate Descendent Attempts Process","1493":"[UP.4]1. If the activity (","1013":"[UP.4]1.1. If Tracked for the activity is True Then","862":"[UP.4]1.1.05 Transfer data from the RTE to the sequencing engine","312":"[UP.4]1.1.1.  If the Activity is Suspended for the activity is False Then (The sequencer will not affect the state of suspended activities)","284":"[UP.4]1.1.1.1. If the Completion Set by Content for the activity is False Then (Should the sequencer set the completion status of the activity? )","78":"[UP.4]1.1.1.1.1. If the Attempt Progress Status for the activity is False  And Completion Status was not changed during runtime  Then (Did the content inform the sequencer of the activity's completion status?)","245":"[UP.4]1.1.1.1.1. If the Attempt Progress Status for the activity is False Then (Did the content inform the sequencer of the activity's completion status?)","743":"[UP.4]1.1.1.1.1.1. Set the Attempt Progress Status for the activity to True","715":"[UP.4]1.1.1.1.1.2. Set the Attempt Completion Status for the activity to True","297":"[UP.4]1.1.1.2.  If the Objective Set by Content for the activity is False Then (Should the sequencer set the objective status of the activity?)","863":"[UP.4]1.1.1.2.1. For all objectives associated with the activity","596":"[UP.4]1.1.1.2.1. Get the primary objective (For all objectives associated with the activity)","622":"[UP.4]1.1.1.2.1.1. If the Objective Contributes to Rollup for the objective is True Then","64":"[UP.4]1.1.1.2.1.1.1. If the Objective Progress Status for the objective is False And Success Status was not changed during runtime Then (Did the content inform the sequencer of the activity's rolled-up objective status?)","192":"[UP.4]1.1.1.2.1.1.1. If the Objective Progress Status for the objective is False Then (Did the content inform the sequencer of the activity's rolled-up objective status?)","667":"[UP.4]1.1.1.2.1.1.1.1. Set the Objective Progress Status for the objective to True","657":"[UP.4]1.1.1.2.1.1.1.2. Set the Objective Satisfied Status for the objective to True","1220":"[UP.4]2. Else (The activity has children)","109":"[UP.4]2.1. If the activity includes any child activity whose Activity is Suspended attribute is True Then (The suspended status of the parent is dependent on the suspended status of its children)","833":"[UP.4]2.1.1. Set the Activity is Suspended for the activity to True","1709":"[UP.4]2.2. Else","819":"[UP.4]2.2.1. Set the Activity is Suspended for the activity to False","462":"[UP.4]3. Set the Activity is Active for the activity to False (The current attempt on this the activity has ended)","250":"[UP.4]4. Apply the Overall Rollup Process to the activity (Ensure that any status change to this activity is propagated through the entire activity tree)","235":"[UP.4]4.5 Find all the activities that read the global objectives written by this activity and invoke the overall rollup process on them (not in pseudo code)","527":"[UP.4]4.a. Performance Optimization - Deferring rollup to parent process to ensure minimal rollup set.","457":"[UP.4]4.b. Apply the Overall Rollup Process to the parents of activities affected by write maps (not in pseudo code)","218":"[UP.4]4.c. Performance Optimization - Deferring rollup or activities affected by write maps to parent process to ensure minimal rollup set. (not in pseudo code)","1302":"[UP.4]5. Exit End Attempt Subprocess","313":"[UP.5]1.Apply the Sequencing Rules Check Process to the activity and the Disabled sequencing rules (Make sure the activity is not disabled)","783":"[UP.5]2. If the Sequencing Rules Check Process does not return Nil Then","721":"[UP.5]2.1. Exit Check Activity Process (Result: True) (Activity is Disabled)","396":"[UP.5]3. Apply the Limit Conditions Check Process to the activity (Make the activity does not violate any limit condition)","864":"[UP.5]4. If the Limit Conditions Check Process returns True Then","614":"[UP.5]4.1. Exit Check Activity Process (Result: True) (Limit Condition Has Been Violated)","752":"[UP.5]5. Exit Check Activity Process (Result: False) (Activity is allowed)","292":"[[NB.2.1]8.1.1. If the Activity is Active for the Current Activity is True Then (Make sure the current activity has not already been terminated)","668":"[[SB.2.1]4.3.1.1. If Sequencing Control Forward Only for the activity is True Then","505":"activity.HasChildActivitiesDeliverableViaFlow = false.  Setting possibleNavRequest.WillNeverSucceed = true.","275":"activity.HasSeqRulesRelevantToChoice = false and possibleNavRequest.WillNeverSucceed = false.  Setting possibleNavRequest.WillAlwaysSucceed = true.","356":"activity.IsDeliverable = false and activity.GetSequencingControlFlow = false.  Setting possibleNavRequest.WillNeverSucceed = true.","1494":"controlChoiceExitIsUsed = ","549":"controlChoiceExitIsUsed = true.  Setting WillAlwaysSucceed = false for all possible nav. requests.","1553":"failed to pass logEntry","1745":"false","940":"is the root, therefore the common ancestor of activities ","1748":"null","1749":"true"};

