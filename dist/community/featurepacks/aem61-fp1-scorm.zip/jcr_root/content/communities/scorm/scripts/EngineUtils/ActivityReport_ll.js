﻿/**********************************************************
ActivityReport.js

Rustici Software

To embed the properties editor, include the following in your web page:

<script type="text/javascript">
    var ActivityReportHelperUrl = '<%=EngineUtilsHelperUrl%>';
    var ScormEngineScriptsUrl = '<%=ScormEngineScriptsUrl%>';
    var extRegId = '<%=RegIdString%>';
	var ActivityReportStylesUrl = "<optional setting if you choose to override the default styles - otherwise leave this line out>";
</script>
<script src="<%=ScormEngineScriptsUrl%>/thirdparty/jquery-1.9.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<%=ScormEngineScriptsUrl%>/EngineUtils/ActivityReport.js"></script>
<div id="ar_ActivityReport"></div>

***********************************************************/

var ReportData;

(function($ar){
    if (typeof(ActivityReportStylesUrl) != 'undefined'){
        $ar('head').append('<link href="' + ActivityReportStylesUrl + '" type="text/css" rel="stylesheet" />');
    } else {
        $ar('head').append('<link href="' + ScormEngineScriptsUrl + '/EngineUtils/ActivityReport.css" type="text/css" rel="stylesheet" />');
    }
    
    
    //kick it all off...
    $ar(document).ready(function(){
        AR_BuildReport();
     
    });
    
    function AR_BuildReport()
    {
        
        $ar(function() {
              $ar.ajax({
                type: "POST",
                url: ActivityReportHelperUrl,
                dataType: "xml",
                data: "method=GetActivityReport&reporttype=full&format=json&externalRegId=" + extRegId + "&externalConfig=",
                success: function(xml){
                
                    if(xml.firstChild == undefined)
                    {
                        ReportData = xml.childNodes[1]; //ie
                    }
                    else
                    {
                        ReportData = xml.firstChild;//firefox
                    }
                    var activity = $ar(ReportData).children('activity:first');
                    render(activity,$ar('#ar_ActivityReport'));
                    renderGlobalObjectives($ar(ReportData).children('globals'),$ar('#ar_ActivityReport ul:first'));
                    makeCollapseableTreeFromUnorderedList("ar_ActivityReport")
                    
                }//close success
              });
              
              
              
          });
      }
    
      function render(activity, parent) {
        $ar('<span class="ar_activityTitle" >Activity: ' + activity.children('title').text() + '</span>').appendTo(parent);
        var ul = $ar('<ul class="ar_childList">');
        ul.append(fmtListItem('Success', activity.children('success').text()));
        ul.append(fmtListItem('Completion', activity.children('complete').text()));
        if(activity.children('completion_amount').length > 0){
            ul.append(fmtListItem("Completion Amount", activity.children('completion_amount').text()));
        }
        ul.append(fmtListItem('Attempts', activity.children('attempts').text()))
            .append(fmtListItem('Suspended', activity.children('suspended').text()))
            .append(fmtListObjectiveItems(activity.children('objectives')))
            .append(fmtRuntime(activity.children('runtime')))
            .appendTo(parent);
                        
        // If child activities are defined, render them as well
        if (activity.children('children').length > 0) {
            activity.children('children:first').children('activity').each(function() {
                render($ar(this), $ar('<li class="ar_actItem ar_closed">').appendTo(ul).get());
            });
        }
     
     }
    function fmtListItem(name, value) {

        if (value === undefined || value === null) {
            value = "";
        }

        return "<li class='ar_listItem'><span class='ar_label'>" + name + "</span>: <span class='ar_dataValue'>" + value + "</span></li>";
    }

    // Returns the html of one or more lists items representing objective data
    function fmtListObjectiveItems(objectives) {
        
        if (objectives === undefined) {
            return "";
        }   

        var result = "";

        objectives.children('objective').each(function(index) {
          
            temp_ul = $ar('<ul class="ar_childList">')
                    .append(fmtListItem('Measure Status', $ar(this).children('measurestatus').text()));
            if($ar(this).children('normalizedmeasure').length > 0){
                temp_ul.append(fmtListItem('Normalized Measure', $ar(this).children('normalizedmeasure').text()));
            }
            else{
                temp_ul.append(fmtListItem('Normalized Measure', "unknown"));
            }
            temp_ul.append(fmtListItem('Progress Measure', $ar(this).children('progressstatus').text()))
                    .append(fmtListItem('Satisfied Status', $ar(this).children('satisfiedstatus').text()));
            result = result + '<li class="ar_groupHeader ar_closed">' +
                $ar('<li>')
                .append('Activity Objective #' + (index+1) + ': ' + $ar(this).attr('id'))
                .append(temp_ul)
                .html() +  '</li>';
        });
      
        return result;
    }


    // Returns the html of the runtime data if it exists
    function fmtRuntime(runtime) {
        
        if (runtime === undefined) {
            return "";

        } else {

            return $ar('<li class="ar_groupHeader ar_closed">')
                .append('Runtime Data')
                .append($ar('<ul class="ar_childList">')
                    .append(fmtListItem('cmi.completion_status', runtime.children('completion_status').text()))
                    .append(fmtListItem('cmi.credit', runtime.children('credit').text()))
                    .append(fmtListItem('cmi.entry', runtime.children('entry').text()))
                    .append(fmtListItem('cmi.exit', runtime.children('exit').text()))
                    .append(fmtLearnerPreference(runtime.children('learnerpreference')))
                    .append(fmtListItem('cmi.location', runtime.children('location').text()))
                    .append(fmtListItem('cmi.mode', runtime.children('mode').text()))
                    .append(fmtListItem('cmi.progress_measure', runtime.children('progress_measure').text()))
                    .append(fmtListItem('cmi.score_scaled', runtime.children('score_scaled').text()))
                    .append(fmtListItem('cmi.score_raw', runtime.children('score_raw').text()))
                    .append(fmtListItem('cmi.score_min', runtime.children('score_min').text()))
                    .append(fmtListItem('cmi.score_max', runtime.children('score_max').text()))
                    .append(fmtListItem('cmi.total_time', runtime.children('total_time').text()))
                    .append(fmtListItem('Total Time Tracked by SCORM Engine', runtime.children('timetracked').text()))
                    .append(fmtListItem('cmi.success_status', runtime.children('success_status').text()))
                    .append(fmtListItem('cmi.suspend_data', runtime.children('suspend_data').text()))
                    .append(fmtInteractions(runtime.children('interactions')))
                    .append(fmtRtObjectives(runtime.children('objectives')))
                    .append(fmtComments(runtime.children('comments_from_learner'), false))
                    .append(fmtComments(runtime.children('comments_from_lms'), true))
                    .append(fmtStaticData(runtime.children('static')))
                 )
        }
    }

    function fmtLearnerPreference(learner_preference) {
        
        return $ar('<li class="ar_groupHeader ar_closed">')
            .append('cmi.learner_preference')
            .append($ar('<ul class="ar_childList">')
                .append(fmtListItem('cmi.learner_preference.audio_level', learner_preference.children('audio_level').text()))
                .append(fmtListItem('cmi.learner_preference.language', learner_preference.children('language').text()))
                .append(fmtListItem('cmi.learner_preference.delivery_speed', learner_preference.children('delivery_speed').text()))
                .append(fmtListItem('cmi.learner_preference.audio_captioning', learner_preference.children('audio_captioning').text()))
             )
    }

    function fmtStaticData(staticNode) {
        
        return $ar('<li class="ar_groupHeader ar_closed">')
            .append('Static Data')
            .append($ar('<ul class="ar_childList">')
                .append(fmtListItem('cmi.completion_threshold', staticNode.children('completion_threshold').text()))
                .append(fmtListItem('cmi.launch_data', staticNode.children('launch_data').text()))
                .append(fmtListItem('cmi.learner_id', staticNode.children('learner_id').text()))
                .append(fmtListItem('cmi.learner_name', staticNode.children('learner_name').text()))
                .append(fmtListItem('cmi.max_time_allowed', staticNode.children('max_time_allowed').text()))
                .append(fmtListItem('cmi.scaled_passing_score', staticNode.children('scaled_passing_score').text()))
                .append(fmtListItem('cmi.time_limit_action', staticNode.children('time_limit_action').text()))
             )
    }

    // Returns the html of one or more lists items representing objective data
    function fmtInteractions(interactions) {
        
        if (interactions === undefined || interactions == null || interactions == "") {
            return "";
        }   

        var result = "";
          
        interactions.children('interaction').each(function(index) {

            result = result + '<li class="ar_groupHeader ar_closed">' +
                $ar('<li>')
                .append('cmi.interactions.' + index)
                .append($ar('<ul class="ar_childList">')
                    .append(fmtListItem('cmi.interactions.' + index + '.id', $ar(this).attr('id')))
                    .append(fmtListItem('cmi.interactions.' + index + '.type', $ar(this).children('type').text()))
                    .append(fmtInteractionObjectives('cmi.interactions.' + index + '.objectives.', $ar(this).children('objectives')))
                    .append(fmtListItem('cmi.interactions.' + index + '.timestamp', $ar(this).children('timestamp').text()))
                    .append(fmtCorrectResponses('cmi.interactions.' + index + '.correct_responses.', $ar(this).children('correct_responses')))
                    .append(fmtListItem('cmi.interactions.' + index + '.weighting', $ar(this).children('weighting').text()))
                    .append(fmtListItem('cmi.interactions.' + index + '.learner_response', $ar(this).children('learner_response').text()))
                    .append(fmtListItem('cmi.interactions.' + index + '.result', $ar(this).children('result').text()))
                    .append(fmtListItem('cmi.interactions.' + index + '.latency', $ar(this).children('latency').text()))
                    .append(fmtListItem('cmi.interactions.' + index + '.description', $ar(this).children('description').text()))
                )
                .html() + '</li>';
                
        });

        return result;
    }

    // Returns the html of one or more lists items representing objective data
    function fmtComments(comments, fromLms) {
        
        if (comments === undefined || comments == null || comments == "") {
            return "";
        }   
        
        if (fromLms) {
            var commentType = "comments_from_lms";
        } else { 
            var commentType = "comments_from_learner";
        }

        var result = "";
          
        comments.children('comment').each(function(index) {
          
            result = result + '<li class="ar_groupHeader ar_closed">' +
                $ar('<li>')
                .append('cmi.' + commentType + '.' + index)
                .append($ar('<ul class="ar_childList">')
                    .append(fmtListItem('cmi.' + commentType + '.' + index + '.comment', $ar(this).children('value').text()))
                    .append(fmtListItem('cmi.' + commentType + '.' + index + '.location', $ar(this).children('location').text()))
                    .append(fmtListItem('cmi.' + commentType + '.' + index + '.timestamp', $ar(this).children('timestamp').text()))
                )
                .html() + '</li>';
                
        });

        return result;
    }

    function fmtCorrectResponses(title, correctResponses) {
        
        if (correctResponses === undefined || correctResponses == null || correctResponses == "") {
            return "";
        }   

        var result = "";
          
        correctResponses.children('response').each(function(index) {
          
            result = result + 
                $ar('<li>')
                .append(fmtListItem(title + index + '.pattern', $ar(this).attr('id')))
                .html();
                
        });

        return result;
    }

    function fmtInteractionObjectives(title, interactionObjectives) {
        
        if (interactionObjectives === undefined || interactionObjectives == null || interactionObjectives == "") {
            return "";
        }   

        var result = "";
          
        interactionObjectives.children('objective').each(function(index) {
          
            result = result + 
                $ar('<li>')
                .append(fmtListItem(title + index + '.id', $ar(this).attr('id')))
                .html();
                
        });

        return result;
    }

    // Returns the html of one or more lists items representing objective data
    function fmtRtObjectives(objectives) {
        
        if (objectives === undefined || objectives == null || objectives == '') {
            return "";
        }   

        var result = "";
          
        objectives.children('objective').each(function(index) {
          
            result = result + '<li class="ar_groupHeader ar_closed">' +
                $ar('<li>')
                .append('cmi.objectives.' + index)
                .append($ar('<ul class="ar_childList">')
                    .append(fmtListItem('cmi.objectives.' + index + '.id', $ar(this).attr('id')))
                    .append(fmtListItem('cmi.objectives.' + index + '.score.scaled', $ar(this).children('score_scaled').text()))
                    .append(fmtListItem('cmi.objectives.' + index + '.score.raw', $ar(this).children('score_raw').text()))
                    .append(fmtListItem('cmi.objectives.' + index + '.score.min', $ar(this).children('score_min').text()))
                    .append(fmtListItem('cmi.objectives.' + index + '.score.max', $ar(this).children('score_max').text()))
                    .append(fmtListItem('cmi.objectives.' + index + '.success_status', $ar(this).children('success_status').text()))
                    .append(fmtListItem('cmi.objectives.' + index + '.completion_status', $ar(this).children('completion_status').text()))
                    .append(fmtListItem('cmi.objectives.' + index + '.progress_measure', $ar(this).children('progress_measure').text()))
                    .append(fmtListItem('cmi.objectives.' + index + '.description', $ar(this).children('description').text()))
                )
                .html() + '</li>';
                
        });

        return result;
    }

    function renderGlobalObjectives(globals,parentObj){
        
        if (globals === undefined) {
            return;
        }   

        globals.children('objective').each(function(index) {
          
            temp_ul = $ar('<ul class="ar_childList">')
                    .append(fmtListItem('Measure Status', $ar(this).children('measurestatus').text()));
            if($ar(this).children('normalizedmeasure').length > 0){
                temp_ul.append(fmtListItem('Normalized Measure', $ar(this).children('normalizedmeasure').text()));
            }
            else{
                temp_ul.append(fmtListItem('Normalized Measure', "unknown"));
            }
            temp_ul.append(fmtListItem('Progress Measure', $ar(this).children('progressstatus').text()))
                    .append(fmtListItem('Satisfied Status', $ar(this).children('satisfiedstatus').text()));
            //result = result + '<li class="ar_groupHeader ar_closed">' +
            $ar('<li class="ar_globObj ar_closed">')
                .append('<span class="ar_globObjTitle">Global Objective #' + (index+1) + ': ' + $ar(this).attr('id') + '</span>')
                .append(temp_ul)
                .appendTo(parentObj);
        });
      
    }


   // Applies tree control type dhtml collapse/expand functionality to 
    // the unordered lists within the specified div.
    function makeCollapseableTreeFromUnorderedList(divName) {

      $ar('#' + divName + ' li:has(ul)')  
        .click(function(event){   
          if (this == event.target) { 
            if ($ar(this).children().is(':hidden')) {   
              $ar(this).removeClass('ar_closed').addClass('ar_open').children().show(); 
            } else { 
              $ar(this).removeClass('ar_open').addClass('ar_closed').children().not('span').hide(); 
            } 
          } 
          return false;   
        })
        .css('cursor','pointer');   
      
      $ar('li.ar_closed').children('ul').hide();
        
      $ar('li:not(:has(ul))').css({   
        cursor: 'default', 
        'list-style-image':'none' 
      });
    } 
        
    
    
})(jQuery);