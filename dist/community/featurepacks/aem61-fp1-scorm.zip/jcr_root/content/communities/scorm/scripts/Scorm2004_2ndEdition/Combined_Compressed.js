var SCORM_TRUE="true";
var SCORM_FALSE="false";
var SCORM_UNKNOWN="unknown";
var SCORM2004_NO_ERROR="0";
var SCORM2004_GENERAL_EXCEPTION_ERROR="101";
var SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR="102";
var SCORM2004_ALREADY_INTIAILIZED_ERROR="103";
var SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR="104";
var SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR="111";
var SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR="112";
var SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR="113";
var SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR="122";
var SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR="123";
var SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR="132";
var SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR="133";
var SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR="142";
var SCORM2004_COMMIT_AFTER_TERMINATION_ERROR="143";
var SCORM2004_GENERAL_ARGUMENT_ERROR="201";
var SCORM2004_GENERAL_GET_FAILURE_ERROR="301";
var SCORM2004_GENERAL_SET_FAILURE_ERROR="351";
var SCORM2004_GENERAL_COMMIT_FAILURE_ERROR="391";
var SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR="401";
var SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR="402";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR="403";
var SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR="404";
var SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR="405";
var SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR="406";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR="407";
var SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR="408";
var SCORM2004_ErrorStrings=new Array();
SCORM2004_ErrorStrings[SCORM2004_NO_ERROR]="No Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_EXCEPTION_ERROR]="General Exception";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR]="General Initialization Failure";
SCORM2004_ErrorStrings[SCORM2004_ALREADY_INTIAILIZED_ERROR]="Already Initialized";
SCORM2004_ErrorStrings[SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR]="Content Instance Terminated";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR]="General Termination Failure";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR]="Termination Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR]="Termination AFter Termination";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR]="Retrieve Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR]="Retrieve Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR]="Store Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR]="Store Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR]="Commit Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_AFTER_TERMINATION_ERROR]="Commit After Termination";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_ARGUMENT_ERROR]="General Argument Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_GET_FAILURE_ERROR]="General Get Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_SET_FAILURE_ERROR]="General Set Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_COMMIT_FAILURE_ERROR]="General Commit Failure";
SCORM2004_ErrorStrings[SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR]="Undefined Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR]="Unimplemented Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR]="Data Model Element Value Not Initialized";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR]="Data Model Element Is Read Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR]="Data Model Element Is Write Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR]="Data Model Element Type Mismatch";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR]="Data Model Element Value Out Of Range";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR]="Data Model Dependency Not Established";
var SCORM2004_VERSION="1.0";
var SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN="comment,location,timestamp";
var SCORM2004_COMMENTS_FROM_LMS_CHILDREN="comment,location,timestamp";
var SCORM2004_INTERACTIONS_CHILDREN="id,type,objectives,timestamp,correct_responses,weighting,learner_response,result,latency,description";
var SCORM2004_LEARNER_PREFERENCE_CHILDREN="audio_level,language,delivery_speed,audio_captioning";
var SCORM2004_OBJECTIVES_CHILDREN="progress_measure,description,score,id,success_status,completion_status";
var SCORM2004_OBJECTIVES_SCORE_CHILDREN="scaled,raw,min,max";
var SCORM2004_SCORE_CHILDREN="scaled,min,max,raw";
function RunTimeApi(_1,_2){
this.LearnerId=_1;
this.LearnerName=_2;
this.ErrorNumber=SCORM2004_NO_ERROR;
this.ErrorString="";
this.ErrorDiagnostic="";
this.TrackedStartDate=null;
this.TrackedEndDate=null;
this.Initialized=false;
this.Terminated=false;
this.ScoCalledFinish=false;
this.CloseOutSessionCalled=false;
this.RunTimeData=null;
this.LearningObject=null;
this.Activity=null;
this.IsLookAheadSequencerDataDirty=false;
this.IsLookAheadSequencerRunning=false;
this.LearnerPrefsArray=new Object();
if(SSP_ENABLED){
this.SSPApi=new SSPApi(MAX_SSP_STORAGE,this);
}
}
RunTimeApi.prototype.GetNavigationRequest=RunTimeApi_GetNavigationRequest;
RunTimeApi.prototype.ResetState=RunTimeApi_ResetState;
RunTimeApi.prototype.InitializeForDelivery=RunTimeApi_InitializeForDelivery;
RunTimeApi.prototype.SetDirtyData=RunTimeApi_SetDirtyData;
RunTimeApi.prototype.WriteHistoryLog=RunTimeApi_WriteHistoryLog;
RunTimeApi.prototype.WriteHistoryReturnValue=RunTimeApi_WriteHistoryReturnValue;
RunTimeApi.prototype.WriteAuditLog=RunTimeApi_WriteAuditLog;
RunTimeApi.prototype.WriteAuditReturnValue=RunTimeApi_WriteAuditReturnValue;
RunTimeApi.prototype.WriteDetailedLog=RunTimeApi_WriteDetailedLog;
RunTimeApi.prototype.CloseOutSession=RunTimeApi_CloseOutSession;
RunTimeApi.prototype.NeedToCloseOutSession=RunTimeApi_NeedToCloseOutSession;
RunTimeApi.prototype.AccumulateTotalTimeTracked=RunTimeApi_AccumulateTotalTimeTracked;
RunTimeApi.prototype.InitTrackedTimeStart=RunTimeApi_InitTrackedTimeStart;
function RunTimeApi_GetNavigationRequest(){
return null;
}
function RunTimeApi_ResetState(_3){
this.TrackedStartDate=null;
this.TrackedEndDate=null;
}
function RunTimeApi_InitializeForDelivery(_4){
this.RunTimeData=_4.RunTime;
this.LearningObject=_4.LearningObject;
this.Activity=_4;
this.CloseOutSessionCalled=false;
if(Control.Package.Properties.ResetRunTimeDataTiming==RESET_RT_DATA_TIMING_WHEN_EXIT_IS_NOT_SUSPEND){
if(this.RunTimeData.Exit!=SCORM_EXIT_SUSPEND&&this.RunTimeData.Exit!=SCORM_EXIT_LOGOUT){
var _5={ev:"ResetRuntime",ai:_4.ItemIdentifier,at:_4.LearningObject.Title};
this.WriteHistoryLog("",_5);
this.RunTimeData.ResetState();
}
}
this.RunTimeData.Exit=SCORM_EXIT_UNKNOWN;
this.RunTimeData.NavRequest=SCORM_RUNTIME_NAV_REQUEST_NONE;
this.Initialized=false;
this.Terminated=false;
this.ScoCalledFinish=false;
this.TrackedStartDate=null;
this.TrackedEndDate=null;
this.ErrorNumber=SCORM2004_NO_ERROR;
this.ErrorString="";
this.ErrorDiagnostic="";
var _6;
var _7;
var _8;
for(var _9 in this.Activity.ActivityObjectives){
_8=this.Activity.ActivityObjectives[_9];
_6=_8.GetIdentifier();
if(_6!==null&&_6!==undefined&&_6.length>0){
_7=this.RunTimeData.FindObjectiveWithId(_6);
if(_7===null){
this.RunTimeData.AddObjective();
_7=this.RunTimeData.Objectives[this.RunTimeData.Objectives.length-1];
_7.Identifier=_6;
}
if(_8.GetProgressStatus(this.Activity,false)===true){
if(_8.GetSatisfiedStatus(this.Activity,false)===true){
_7.SuccessStatus=SCORM_STATUS_PASSED;
}else{
_7.SuccessStatus=SCORM_STATUS_FAILED;
}
}
if(_8.GetMeasureStatus(this.Activity,false)===true){
_7.ScoreScaled=_8.GetNormalizedMeasure(this.Activity,false);
}
_7.SuccessStatusChangedDuringRuntime=false;
_7.MeasureChangedDuringRuntime=false;
}
}
}
function RunTimeApi_SetDirtyData(){
this.Activity.DataState=DATA_STATE_DIRTY;
}
function RunTimeApi_WriteHistoryLog(_a,_b){
HistoryLog.WriteEventDetailed(_a,_b);
}
function RunTimeApi_WriteHistoryReturnValue(_c,_d){
HistoryLog.WriteEventDetailedReturnValue(_c,_d);
}
function RunTimeApi_WriteAuditLog(_e){
Debug.WriteRteAudit(_e);
}
function RunTimeApi_WriteAuditReturnValue(_f){
Debug.WriteRteAuditReturnValue(_f);
}
function RunTimeApi_WriteDetailedLog(str){
Debug.WriteRteDetailed(str);
}
function RunTimeApi_NeedToCloseOutSession(){
return !this.CloseOutSessionCalled;
}
RunTimeApi.prototype.version=SCORM2004_VERSION;
RunTimeApi.prototype.Initialize=RunTimeApi_Initialize;
RunTimeApi.prototype.Terminate=RunTimeApi_Terminate;
RunTimeApi.prototype.GetValue=RunTimeApi_GetValue;
RunTimeApi.prototype.SetValue=RunTimeApi_SetValue;
RunTimeApi.prototype.Commit=RunTimeApi_Commit;
RunTimeApi.prototype.GetLastError=RunTimeApi_GetLastError;
RunTimeApi.prototype.GetErrorString=RunTimeApi_GetErrorString;
RunTimeApi.prototype.GetDiagnostic=RunTimeApi_GetDiagnostic;
RunTimeApi.prototype.RetrieveGetValueData=RunTimeApi_RetrieveGetValueData;
RunTimeApi.prototype.StoreValue=RunTimeApi_StoreValue;
RunTimeApi.prototype.SetErrorState=RunTimeApi_SetErrorState;
RunTimeApi.prototype.ClearErrorState=RunTimeApi_ClearErrorState;
RunTimeApi.prototype.CheckMaxLength=RunTimeApi_CheckMaxLength;
RunTimeApi.prototype.CheckLengthAndWarn=RunTimeApi_CheckLengthAndWarn;
RunTimeApi.prototype.CheckForInitializeError=RunTimeApi_CheckForInitializeError;
RunTimeApi.prototype.CheckForTerminateError=RunTimeApi_CheckForTerminateError;
RunTimeApi.prototype.CheckForGetValueError=RunTimeApi_CheckForGetValueError;
RunTimeApi.prototype.CheckForSetValueError=RunTimeApi_CheckForSetValueError;
RunTimeApi.prototype.CheckForCommitError=RunTimeApi_CheckForCommitError;
RunTimeApi.prototype.CheckCommentsCollectionLength=RunTimeApi_CheckCommentsCollectionLength;
RunTimeApi.prototype.CheckInteractionsCollectionLength=RunTimeApi_CheckInteractionsCollectionLength;
RunTimeApi.prototype.CheckInteractionObjectivesCollectionLength=RunTimeApi_CheckInteractionObjectivesCollectionLength;
RunTimeApi.prototype.CheckInteractionsCorrectResponsesCollectionLength=RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength;
RunTimeApi.prototype.CheckObjectivesCollectionLength=RunTimeApi_CheckObjectivesCollectionLength;
RunTimeApi.prototype.LookAheadSessionClose=RunTimeApi_LookAheadSessionClose;
RunTimeApi.prototype.ValidOtheresponse=RunTimeApi_ValidOtheresponse;
RunTimeApi.prototype.ValidNumericResponse=RunTimeApi_ValidNumericResponse;
RunTimeApi.prototype.ValidSequencingResponse=RunTimeApi_ValidSequencingResponse;
RunTimeApi.prototype.ValidPerformanceResponse=RunTimeApi_ValidPerformanceResponse;
RunTimeApi.prototype.ValidMatchingResponse=RunTimeApi_ValidMatchingResponse;
RunTimeApi.prototype.ValidLikeRTResponse=RunTimeApi_ValidLikeRTResponse;
RunTimeApi.prototype.ValidLongFillInResponse=RunTimeApi_ValidLongFillInResponse;
RunTimeApi.prototype.ValidFillInResponse=RunTimeApi_ValidFillInResponse;
RunTimeApi.prototype.IsValidArrayOfLocalizedStrings=RunTimeApi_IsValidArrayOfLocalizedStrings;
RunTimeApi.prototype.IsValidArrayOfShortIdentifiers=RunTimeApi_IsValidArrayOfShortIdentifiers;
RunTimeApi.prototype.IsValidCommaDelimitedArrayOfShortIdentifiers=RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers;
RunTimeApi.prototype.ValidMultipleChoiceResponse=RunTimeApi_ValidMultipleChoiceResponse;
RunTimeApi.prototype.ValidTrueFalseResponse=RunTimeApi_ValidTrueFalseResponse;
RunTimeApi.prototype.ValidTimeInterval=RunTimeApi_ValidTimeInterval;
RunTimeApi.prototype.ValidTime=RunTimeApi_ValidTime;
RunTimeApi.prototype.ValidReal=RunTimeApi_ValidReal;
RunTimeApi.prototype.IsValidUrn=RunTimeApi_IsValidUrn;
RunTimeApi.prototype.ValidIdentifier=RunTimeApi_ValidIdentifier;
RunTimeApi.prototype.ValidShortIdentifier=RunTimeApi_ValidShortIdentifier;
RunTimeApi.prototype.ValidLongIdentifier=RunTimeApi_ValidLongIdentifier;
RunTimeApi.prototype.ValidLanguage=RunTimeApi_ValidLanguage;
RunTimeApi.prototype.ExtractLanguageDelimiterFromLocalizedString=RunTimeApi_ExtractLanguageDelimiterFromLocalizedString;
RunTimeApi.prototype.ValidLocalizedString=RunTimeApi_ValidLocalizedString;
RunTimeApi.prototype.ValidCharString=RunTimeApi_ValidCharString;
RunTimeApi.prototype.TranslateBooleanIntoCMI=RunTimeApi_TranslateBooleanIntoCMI;
RunTimeApi.prototype.SetLookAheadDirtyDataFlagIfNeeded=RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded;
RunTimeApi.prototype.RunLookAheadSequencerIfNeeded=RunTimeApi_RunLookAheadSequencerIfNeeded;
function RunTimeApi_Initialize(arg){
this.WriteAuditLog("`1722`"+arg+"')");
var _12={ev:"ApiInitialize"};
if(this.Activity){
_12.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_12);
var _13;
var _14;
this.ClearErrorState();
_13=this.CheckForInitializeError(arg);
if(!_13){
_14=SCORM_FALSE;
}else{
if(this.TrackedStartDate==null){
this.TrackedStartDate=new Date();
}
if(this.StartSessionTotalTime==null&&this.Activity){
this.StartSessionTotalTime=this.Activity.RunTime.TotalTime;
}
this.Initialized=true;
_14=SCORM_TRUE;
}
Control.ScoLoader.ScoLoaded=true;
this.WriteAuditReturnValue(_14);
return _14;
}
function RunTimeApi_Terminate(arg){
this.WriteAuditLog("`1732`"+arg+"')");
var _16;
var _17;
var _18;
this.ClearErrorState();
_16=this.CheckForTerminateError(arg);
var _19=(_16&&(this.ScoCalledFinish===false));
if(!_16){
_18=SCORM_FALSE;
}else{
var _1a={ev:"ApiTerminate"};
if(this.Activity){
_1a.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_1a);
this.LookAheadSessionClose();
this.CloseOutSession("Terminiate");
this.RunLookAheadSequencerIfNeeded();
this.Terminated=true;
this.ScoCalledFinish=true;
this.SetDirtyData();
_18=SCORM_TRUE;
}
if(_19===true&&this.RunTimeData.NavRequest!=SCORM_RUNTIME_NAV_REQUEST_NONE&&Control.IsThereAPendingNavigationRequest()===false){
this.WriteDetailedLog("`442`"+Control.IsThereAPendingNavigationRequest());
window.setTimeout("Control.ScoHasTerminatedSoUnload();",150);
}
Control.SignalTerminated();
this.WriteAuditReturnValue(_18);
return _18;
}
function RunTimeApi_GetValue(_1b){
this.WriteAuditLog("`1735`"+_1b+"')");
var _1c;
var _1d;
this.ClearErrorState();
_1b=CleanExternalString(_1b);
var _1e=RemoveIndiciesFromCmiElement(_1b);
var _1f=ExtractIndex(_1b);
var _20=ExtractSecondaryIndex(_1b);
_1d=this.CheckForGetValueError(_1b,_1e,_1f,_20);
if(!_1d){
_1c="";
}else{
_1c=this.RetrieveGetValueData(_1b,_1e,_1f,_20);
if(_1c===null){
_1c="";
}
}
this.WriteAuditReturnValue(_1c);
return _1c;
}
function RunTimeApi_SetValue(_21,_22){
this.WriteAuditLog("`1736`"+_21+"`1747`"+_22+"')");
var _23;
var _24;
this.ClearErrorState();
_21=CleanExternalString(_21);
_22=CleanExternalString(_22);
var _25=RemoveIndiciesFromCmiElement(_21);
var _26=ExtractIndex(_21);
var _27=ExtractSecondaryIndex(_21);
this.CheckMaxLength(_25,_22);
_23=this.CheckForSetValueError(_21,_22,_25,_26,_27);
if(!_23){
_24=SCORM_FALSE;
}else{
this.StoreValue(_21,_22,_25,_26,_27);
this.SetDirtyData();
_24=SCORM_TRUE;
}
this.WriteAuditReturnValue(_24);
return _24;
}
function RunTimeApi_Commit(arg){
this.WriteAuditLog("`1739`"+arg+"')");
var _29;
var _2a;
this.ClearErrorState();
_29=this.CheckForCommitError(arg);
if(!_29){
_2a=SCORM_FALSE;
}else{
_2a=SCORM_TRUE;
}
this.RunLookAheadSequencerIfNeeded(true);
this.WriteAuditReturnValue(_2a);
return _2a;
}
function RunTimeApi_GetLastError(){
this.WriteAuditLog("`1713`");
var _2b=this.ErrorNumber;
this.WriteAuditReturnValue(_2b);
return _2b;
}
function RunTimeApi_GetErrorString(arg){
this.WriteAuditLog("`1686`"+arg+"')");
var _2d="";
if(arg===""){
_2d=this.ErrorString;
}else{
if(SCORM2004_ErrorStrings[arg]!==null&&SCORM2004_ErrorStrings[arg]!==undefined){
_2d=SCORM2004_ErrorStrings[arg];
}
}
this.WriteAuditReturnValue(_2d);
return _2d;
}
function RunTimeApi_GetDiagnostic(arg){
this.WriteAuditLog("`1696`"+arg+"')");
var _2f;
if(this.ErrorDiagnostic===""){
_2f="No diagnostic information available";
}else{
_2f=this.ErrorDiagnostic;
}
this.WriteAuditReturnValue(_2f);
return _2f;
}
function RunTimeApi_CloseOutSession(_30){
this.WriteDetailedLog("`1656`");
var _31=this.LearningObject.GetScaledPassingScore();
this.WriteDetailedLog("`1741`"+this.RunTimeData.Mode);
this.WriteDetailedLog("`1738`"+this.RunTimeData.Credit);
this.WriteDetailedLog("`1604`"+this.RunTimeData.CompletionStatus);
this.WriteDetailedLog("`1688`"+this.RunTimeData.SuccessStatus);
this.WriteDetailedLog("`1576`"+_31);
this.WriteDetailedLog("`1740`"+this.RunTimeData.ScoreScaled);
this.WriteDetailedLog("`1538`"+this.LearningObject.CompletionThreshold);
this.WriteDetailedLog("`1608`"+this.RunTimeData.ProgressMeasure);
var _32=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTime);
var _33=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime);
var _34=_32+_33;
var _35=ConvertHundredthsToIso8601TimeSpan(_34);
this.WriteDetailedLog("`1714`"+this.RunTimeData.SessionTime+" ("+_32+"`1719`");
this.WriteDetailedLog("`1699`"+this.RunTimeData.TotalTime+" ("+_33+"`1719`");
this.WriteDetailedLog("`1687`"+_35+" ("+_34+"`1719`");
this.RunTimeData.TotalTime=_35;
this.RunTimeData.SessionTime="";
this.AccumulateTotalTimeTracked();
this.WriteDetailedLog("`1527`"+this.RunTimeData.TotalTimeTracked);
if(this.RunTimeData.Exit==SCORM_EXIT_SUSPEND||this.RunTimeData.Exit==SCORM_EXIT_LOGOUT){
this.WriteDetailedLog("`1594`");
this.RunTimeData.Entry=SCORM_ENTRY_RESUME;
}
if(this.RunTimeData.ProgressMeasure!==null&&this.LearningObject.CompletionThreshold!==null){
if(parseFloat(this.RunTimeData.ProgressMeasure)>=parseFloat(this.LearningObject.CompletionThreshold)){
this.WriteDetailedLog("`615`");
this.RunTimeData.CompletionStatus=SCORM_STATUS_COMPLETED;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
}else{
this.WriteDetailedLog("`569`");
this.RunTimeData.CompletionStatus=SCORM_STATUS_INCOMPLETE;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
}
}
if(_31!==null){
if(this.RunTimeData.ScoreScaled!==null){
if(parseFloat(this.RunTimeData.ScoreScaled)>=parseFloat(_31)){
this.WriteDetailedLog("`696`");
this.RunTimeData.SuccessStatus=SCORM_STATUS_PASSED;
this.RunTimeData.SuccessStatusChangedDuringRuntime=true;
}else{
this.WriteDetailedLog("`649`");
this.RunTimeData.SuccessStatus=SCORM_STATUS_FAILED;
this.RunTimeData.SuccessStatusChangedDuringRuntime=true;
}
}else{
this.WriteDetailedLog("`570`");
this.RunTimeData.SuccessStatus=SCORM_STATUS_UNKNOWN;
this.RunTimeData.SuccessStatusChangedDuringRuntime=true;
}
}
if(this.RunTimeData.Exit==SCORM_EXIT_TIME_OUT){
this.WriteDetailedLog("`1471`");
this.RunTimeData.NavRequest=SCORM_RUNTIME_NAV_REQUEST_EXIT;
}else{
if(this.RunTimeData.Exit==SCORM_EXIT_LOGOUT){
if(Control.Package.Properties.LogoutCausesPlayerExit===true){
this.WriteDetailedLog("`1333`");
this.RunTimeData.NavRequest=SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL;
}else{
this.WriteDetailedLog("`341`");
this.Activity.SetSuspended(true);
}
}else{
if(this.RunTimeData.Exit==SCORM_EXIT_SUSPEND){
this.WriteDetailedLog("`1609`");
this.Activity.SetSuspended(true);
}
}
}
this.CloseOutSessionCalled=true;
return true;
}
function RunTimeApi_LookAheadSessionClose(){
if(this.RunTimeData==null){
return;
}
this.RunTimeData.LookAheadCompletionStatus=this.RunTimeData.CompletionStatus;
if(this.RunTimeData.ProgressMeasure!==null&&this.LearningObject.CompletionThreshold!==null){
if(parseFloat(this.RunTimeData.ProgressMeasure)>=parseFloat(this.LearningObject.CompletionThreshold)){
this.WriteDetailedLog("`615`");
this.RunTimeData.LookAheadCompletionStatus=SCORM_STATUS_COMPLETED;
}else{
this.WriteDetailedLog("`569`");
this.RunTimeData.LookAheadCompletionStatus=SCORM_STATUS_INCOMPLETE;
}
}
this.RunTimeData.LookAheadSuccessStatus=this.RunTimeData.SuccessStatus;
var _36=this.LearningObject.GetScaledPassingScore();
if(_36!==null){
if(this.RunTimeData.ScoreScaled!==null){
if(parseFloat(this.RunTimeData.ScoreScaled)>=parseFloat(_36)){
this.WriteDetailedLog("`696`");
this.RunTimeData.LookAheadSuccessStatus=SCORM_STATUS_PASSED;
}else{
this.WriteDetailedLog("`649`");
this.RunTimeData.LookAheadSuccessStatus=SCORM_STATUS_FAILED;
}
}else{
this.WriteDetailedLog("`570`");
this.RunTimeData.LookAheadSuccessStatus=SCORM_STATUS_UNKNOWN;
}
}
}
function RunTimeApi_RetrieveGetValueData(_37,_38,_39,_3a){
this.WriteDetailedLog("`1565`"+_37+", "+_38+", "+_39+", "+_3a+") ");
var _3b;
var _3c="";
if(_37.indexOf("adl.nav.request_valid.choice")===0){
this.WriteDetailedLog("`1278`");
_3b=((_37.indexOf("{")>=0)?_37.substring(_37.indexOf("{")):"");
if(!Control.IsTargetValid(_3b)){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The target of the choice request ("+_3b+") is invalid.");
return SCORM_FALSE;
}
_3c=this.TranslateBooleanIntoCMI(Control.IsChoiceRequestValid(_3b));
return _3c;
}
switch(_38){
case "cmi._version":
this.WriteDetailedLog("`1500`");
_3c=SCORM2004_VERSION;
break;
case "cmi.comments_from_learner._children":
this.WriteDetailedLog("`1155`");
_3c=SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN;
break;
case "cmi.comments_from_learner._count":
this.WriteDetailedLog("`1226`");
_3c=this.RunTimeData.Comments.length;
break;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1206`");
_3c=this.RunTimeData.Comments[_39].GetCommentValue();
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1180`");
_3c=this.RunTimeData.Comments[_39].Location;
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1157`");
_3c=this.RunTimeData.Comments[_39].Timestamp;
break;
case "cmi.comments_from_lms._children":
this.WriteDetailedLog("`1241`");
_3c=SCORM2004_COMMENTS_FROM_LMS_CHILDREN;
break;
case "cmi.comments_from_lms._count":
this.WriteDetailedLog("`1292`");
_3c=this.RunTimeData.CommentsFromLMS.length;
break;
case "cmi.comments_from_lms.n.comment":
this.WriteDetailedLog("`1282`");
_3c=this.RunTimeData.CommentsFromLMS[_39].GetCommentValue();
break;
case "cmi.comments_from_lms.n.location":
this.WriteDetailedLog("`1261`");
_3c=this.RunTimeData.CommentsFromLMS[_39].Location;
break;
case "cmi.comments_from_lms.n.timestamp":
this.WriteDetailedLog("`1243`");
_3c=this.RunTimeData.CommentsFromLMS[_39].Timestamp;
break;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
_3c=this.RunTimeData.CompletionStatus;
break;
case "cmi.completion_threshold":
this.WriteDetailedLog("`1361`");
_3c=this.LearningObject.CompletionThreshold;
break;
case "cmi.credit":
this.WriteDetailedLog("`1636`");
_3c=this.RunTimeData.Credit;
break;
case "cmi.entry":
this.WriteDetailedLog("`1658`");
_3c=this.RunTimeData.Entry;
break;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
Debug.AssertError("Exit element is write only");
_3c="";
break;
case "cmi.interactions._children":
this.WriteDetailedLog("`1324`");
_3c=SCORM2004_INTERACTIONS_CHILDREN;
break;
case "cmi.interactions._count":
this.WriteDetailedLog("`1380`");
_3c=this.RunTimeData.Interactions.length;
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1464`");
_3c=this.RunTimeData.Interactions[_39].Id;
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1420`");
_3c=this.RunTimeData.Interactions[_39].Type;
break;
case "cmi.interactions.n.objectives._count":
this.WriteDetailedLog("`1183`");
_3c=this.RunTimeData.Interactions[_39].Objectives.length;
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1263`");
_3c=this.RunTimeData.Interactions[_39].Objectives[_3a];
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1326`");
_3c=this.RunTimeData.Interactions[_39].Timestamp;
break;
case "cmi.interactions.n.correct_responses._count":
this.WriteDetailedLog("`1053`");
_3c=this.RunTimeData.Interactions[_39].CorrectResponses.length;
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`1018`");
_3c=this.RunTimeData.Interactions[_39].CorrectResponses[_3a];
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1327`");
_3c=this.RunTimeData.Interactions[_39].Weighting;
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1208`");
_3c=this.RunTimeData.Interactions[_39].LearnerResponse;
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1382`");
_3c=this.RunTimeData.Interactions[_39].Result;
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1363`");
_3c=this.RunTimeData.Interactions[_39].Latency;
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1293`");
_3c=this.RunTimeData.Interactions[_39].Description;
break;
case "cmi.launch_data":
this.WriteDetailedLog("`1544`");
_3c=this.LearningObject.DataFromLms;
break;
case "cmi.learner_id":
this.WriteDetailedLog("`1558`");
_3c=LearnerId;
break;
case "cmi.learner_name":
this.WriteDetailedLog("`1517`");
_3c=LearnerName;
break;
case "cmi.learner_preference._children":
this.WriteDetailedLog("`1228`");
_3c=SCORM2004_LEARNER_PREFERENCE_CHILDREN;
break;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1542`");
_3c=this.RunTimeData.AudioLevel;
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1589`");
_3c=this.RunTimeData.LanguagePreference;
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1482`");
_3c=this.RunTimeData.DeliverySpeed;
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1435`");
_3c=this.RunTimeData.AudioCaptioning;
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
_3c=this.RunTimeData.Location;
var _3d={ev:"Get",k:"location",v:(_3c==null?"<null>":_3c)};
if(this.Activity){
_3d.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_3d);
break;
case "cmi.max_time_allowed":
this.WriteDetailedLog("`1436`");
_3c="";
if(this.LearningObject.SequencingData!==null&&this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl===true){
_3c=this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationLimit;
}
break;
case "cmi.mode":
this.WriteDetailedLog("`1684`");
_3c=this.RunTimeData.Mode;
break;
case "cmi.objectives._children":
this.WriteDetailedLog("`1364`");
_3c=SCORM2004_OBJECTIVES_CHILDREN;
break;
case "cmi.objectives._count":
this.WriteDetailedLog("`1421`");
_3c=this.RunTimeData.Objectives.length;
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1505`");
_3c=this.RunTimeData.Objectives[_39].Identifier;
break;
case "cmi.objectives.n.score._children":
this.WriteDetailedLog("`1264`");
_3c=SCORM2004_OBJECTIVES_SCORE_CHILDREN;
break;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1309`");
_3c=this.RunTimeData.Objectives[_39].ScoreScaled;
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1367`");
_3c=this.RunTimeData.Objectives[_39].ScoreRaw;
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1366`");
_3c=this.RunTimeData.Objectives[_39].ScoreMin;
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1365`");
_3c=this.RunTimeData.Objectives[_39].ScoreMax;
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1284`");
_3c=this.RunTimeData.Objectives[_39].SuccessStatus;
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1229`");
_3c=this.RunTimeData.Objectives[_39].CompletionStatus;
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1246`");
_3c=this.RunTimeData.Objectives[_39].ProgressMeasure;
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1328`");
_3c=this.RunTimeData.Objectives[_39].Description;
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1438`");
_3c=this.RunTimeData.ProgressMeasure;
break;
case "cmi.scaled_passing_score":
this.WriteDetailedLog("`1368`");
_3c=this.LearningObject.GetScaledPassingScore();
if(_3c===null){
_3c="";
}
break;
case "cmi.score._children":
this.WriteDetailedLog("`1468`");
_3c=SCORM2004_SCORE_CHILDREN;
break;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
_3c=this.RunTimeData.ScoreScaled;
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
_3c=this.RunTimeData.ScoreRaw;
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
_3c=this.RunTimeData.ScoreMax;
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
_3c=this.RunTimeData.ScoreMin;
break;
case "cmi.session_time":
this.WriteDetailedLog("`1520`");
_3c=this.RunTimeData.SessionTime;
break;
case "cmi.success_status":
this.WriteDetailedLog("`1484`");
_3c=this.RunTimeData.SuccessStatus;
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1524`");
_3c=this.RunTimeData.SuspendData;
break;
case "cmi.time_limit_action":
this.WriteDetailedLog("`1423`");
_3c=this.LearningObject.TimeLimitAction;
break;
case "cmi.total_time":
this.WriteDetailedLog("`1563`");
_3c=this.RunTimeData.TotalTime;
break;
case "adl.nav.request":
this.WriteDetailedLog("`1461`");
_3c=this.RunTimeData.NavRequest;
break;
case "adl.nav.request_valid.continue":
this.WriteDetailedLog("`1174`");
_3c=this.TranslateBooleanIntoCMI(Control.IsContinueRequestValid());
break;
case "adl.nav.request_valid.previous":
this.WriteDetailedLog("`1175`");
_3c=this.TranslateBooleanIntoCMI(Control.IsPreviousRequestValid());
break;
case "adl.nav.request_valid.choice":
this.WriteDetailedLog("`1323`");
Debug.AssertError("Entered invalid case in RunTimeApi_RetrieveGetValueData");
break;
default:
if(_38.indexOf("ssp")===0&&SSP_ENABLED){
_3c=this.SSPApi.RetrieveGetValueData(_37,_38,_39,_3a);
}else{
Debug.AssertError("Entered default case in RunTimeApi_RetrieveGetValueData");
_3c="";
}
break;
}
return _3c;
}
function RunTimeApi_StoreValue(_3e,_3f,_40,_41,_42){
this.WriteDetailedLog("`1724`"+_3e+", "+_3f+", "+_40+", "+_41+", "+_42+") ");
var _43=true;
var _44;
switch(_40){
case "cmi._version":
this.WriteDetailedLog("`1587`");
break;
case "cmi.comments_from_learner._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._children");
_43=false;
break;
case "cmi.comments_from_learner._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._count");
_43=false;
break;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1225`");
this.CheckCommentsCollectionLength(_41);
this.RunTimeData.Comments[_41].SetCommentValue(_3f);
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1178`");
this.CheckCommentsCollectionLength(_41);
this.RunTimeData.Comments[_41].Location=_3f;
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1154`");
this.CheckCommentsCollectionLength(_41);
this.RunTimeData.Comments[_41].Timestamp=_3f;
break;
case "cmi.comments_from_lms._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._children");
_43=false;
break;
case "cmi.comments_from_lms._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._count");
_43=false;
break;
case "cmi.comments_from_lms.n.comment":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.comment");
_43=false;
break;
case "cmi.comments_from_lms.n.location":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.location");
_43=false;
break;
case "cmi.comments_from_lms.n.timestamp":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.timestamp");
_43=false;
break;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
_44={ev:"Set",k:"completion",v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.CompletionStatus,_3f);
this.RunTimeData.CompletionStatus=_3f;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.completion_threshold":
Debug.AssertError("ERROR - Element is Read Only, cmi.completion_threshold");
_43=false;
break;
case "cmi.credit":
Debug.AssertError("ERROR - Element is Read Only, cmi.credit");
_43=false;
break;
case "cmi.entry":
Debug.AssertError("ERROR - Element is Read Only, cmi.entry");
_43=false;
break;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
_44={ev:"Set",k:"cmi.exit",v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.RunTimeData.Exit=_3f;
break;
case "cmi.interactions._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._children");
_43=false;
break;
case "cmi.interactions._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._count");
_43=false;
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1464`");
_44={ev:"Set",k:"interactions id",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].Id=_3f;
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1420`");
_44={ev:"Set",k:"interactions type",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_41].Id){
_44.intid=this.RunTimeData.Interactions[_41].Id;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].Type=_3f;
break;
case "cmi.interactions.n.objectives._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.objectives._count");
_43=false;
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1263`");
_44={ev:"Set",k:"interactions objectives id",i:_41,si:_42,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionObjectivesCollectionLength(_41,_42);
this.RunTimeData.Interactions[_41].Objectives[_42]=_3f;
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1326`");
_44={ev:"Set",k:"interactions timestamp",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_41].Id){
_44.intid=this.RunTimeData.Interactions[_41].Id;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].Timestamp=_3f;
break;
case "cmi.interactions.n.correct_responses._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.correct_responses._count");
_43=false;
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`1018`");
_44={ev:"Set",k:"interactions correct_responses pattern",i:_41,si:_42,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCorrectResponsesCollectionLength(_41,_42);
this.RunTimeData.Interactions[_41].CorrectResponses[_42]=_3f;
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1327`");
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].Weighting=_3f;
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1208`");
_44={ev:"Set",k:"interactions learner_response",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_41].Id){
_44.intid=this.RunTimeData.Interactions[_41].Id;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].LearnerResponse=_3f;
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1382`");
_44={ev:"Set",k:"interactions result",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_41].Id){
_44.intid=this.RunTimeData.Interactions[_41].Id;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].Result=_3f;
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1363`");
_44={ev:"Set",k:"interactions latency",i:_41,vh:ConvertIso8601TimeSpanToHundredths(_3f)};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_41].Id){
_44.intid=this.RunTimeData.Interactions[_41].Id;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].Latency=_3f;
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1293`");
_44={ev:"Set",k:"interactions description",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_41].Id){
_44.intid=this.RunTimeData.Interactions[_41].Id;
}
this.WriteHistoryLog("",_44);
this.CheckInteractionsCollectionLength(_41);
this.RunTimeData.Interactions[_41].Description=_3f;
break;
case "cmi.launch_data":
Debug.AssertError("ERROR - Element is Read Only, cmi.launch_data");
_43=false;
break;
case "cmi.learner_id":
Debug.AssertError("ERROR - Element is Read Only, cmi.learner_id");
_43=false;
break;
case "cmi.learner_name":
Debug.AssertError("ERROR - Element is Read Only, cmi.learner_name");
_43=false;
break;
case "cmi.learner_preference._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.learner_preference._children");
_43=false;
break;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1516`");
this.RunTimeData.AudioLevel=_3f;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.AudioLevel=_3f;
}
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1589`");
this.RunTimeData.LanguagePreference=_3f;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.LanguagePreference=_3f;
}
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1501`");
this.RunTimeData.DeliverySpeed=_3f;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.DeliverySpeed=_3f;
}
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1435`");
this.RunTimeData.AudioCaptioning=_3f;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.AudioCaptioning=_3f;
}
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
this.RunTimeData.Location=_3f;
break;
case "cmi.max_time_allowed":
Debug.AssertError("ERROR - Element is Read Only, cmi.max_time_allowed");
_43=false;
break;
case "cmi.mode":
Debug.AssertError("ERROR - Element is Read Only, cmi.mode");
_43=false;
break;
case "cmi.objectives._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._children");
_43=false;
break;
case "cmi.objectives._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._count");
_43=false;
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1505`");
_44={ev:"Set",k:"objectives id",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.CheckObjectivesCollectionLength(_41);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].Identifier,_3f);
this.RunTimeData.Objectives[_41].Identifier=_3f;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.score._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.objectives.n.score._children");
_43=false;
break;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1310`");
this.CheckObjectivesCollectionLength(_41);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].ScoreScaled,_3f);
this.RunTimeData.Objectives[_41].ScoreScaled=_3f;
this.RunTimeData.Objectives[_41].MeasureChangedDuringRuntime=true;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1367`");
this.CheckObjectivesCollectionLength(_41);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].ScoreRaw,_3f);
}
this.RunTimeData.Objectives[_41].ScoreRaw=_3f;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1366`");
this.CheckObjectivesCollectionLength(_41);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].ScoreMin,_3f);
}
this.RunTimeData.Objectives[_41].ScoreMin=_3f;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1365`");
this.CheckObjectivesCollectionLength(_41);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].ScoreMax,_3f);
}
this.RunTimeData.Objectives[_41].ScoreMax=_3f;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1284`");
_44={ev:"Set",k:"objectives success",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Objectives[_41].Identifier){
_44.intid=this.RunTimeData.Objectives[_41].Identifier;
}
this.WriteHistoryLog("",_44);
this.CheckObjectivesCollectionLength(_41);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].SuccessStatus,_3f);
this.RunTimeData.Objectives[_41].SuccessStatus=_3f;
this.RunTimeData.Objectives[_41].SuccessStatusChangedDuringRuntime=true;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1229`");
_44={ev:"Set",k:"objectives completion",i:_41,v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Objectives[_41].Identifier){
_44.intid=this.RunTimeData.Objectives[_41].Identifier;
}
this.WriteHistoryLog("",_44);
this.CheckObjectivesCollectionLength(_41);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].CompletionStatus,_3f);
this.RunTimeData.Objectives[_41].CompletionStatus=_3f;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1246`");
this.CheckObjectivesCollectionLength(_41);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_41].ProgressMeasure,_3f);
this.RunTimeData.Objectives[_41].ProgressMeasure=_3f;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1328`");
this.CheckObjectivesCollectionLength(_41);
this.RunTimeData.Objectives[_41].Description=_3f;
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1439`");
this.RunTimeData.ProgressMeasure=_3f;
break;
case "cmi.scaled_passing_score":
Debug.AssertError("ERROR - Element is Read Only, cmi.scaled_passing_score");
_43=false;
break;
case "cmi.score._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.score._children");
_43=false;
break;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
_44={ev:"Set",k:"score.scaled",v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreScaled,_3f);
this.RunTimeData.ScoreScaled=_3f;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
_44={ev:"Set",k:"score.raw",v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreRaw,_3f);
}
this.RunTimeData.ScoreRaw=_3f;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
_44={ev:"Set",k:"score.max",v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMax,_3f);
}
this.RunTimeData.ScoreMax=_3f;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
_44={ev:"Set",k:"score.min",v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMin,_3f);
}
this.RunTimeData.ScoreMin=_3f;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.session_time":
this.WriteDetailedLog("`1521`");
_44={ev:"Set",k:"session time",vh:ConvertIso8601TimeSpanToHundredths(_3f)};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.RunTimeData.SessionTime=_3f;
break;
case "cmi.success_status":
this.WriteDetailedLog("`1485`");
_44={ev:"Set",k:"success",v:_3f};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.SuccessStatus,_3f);
this.RunTimeData.SuccessStatus=_3f;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1525`");
this.RunTimeData.SuspendData=_3f;
break;
case "cmi.time_limit_action":
Debug.AssertError("ERROR - Element is Read Only, cmi.time_limit_action");
_43=false;
break;
case "cmi.total_time":
Debug.AssertError("ERROR - Element is Read Only, cmi.total_time");
_43=false;
break;
case "adl.nav.request":
this.WriteDetailedLog("`1463`");
_44={ev:"Set",k:"nav.request"};
if(this.Activity){
_44.ai=this.Activity.ItemIdentifier;
}
var _45=_3f.match(/target\s*=\s*(\S+)\s*}\s*choice/);
if(_45){
_44.tai=_45[1];
_44.tat=Control.Activities.GetActivityFromIdentifier(_45[1]).LearningObject.Title;
_44.v="choice";
}else{
_44.v=_3f;
}
this.WriteHistoryLog("",_44);
this.RunTimeData.NavRequest=_3f;
break;
case "adl.nav.request_valid.continue":
Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.continue");
break;
case "adl.nav.request_valid.previous":
Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.previous");
break;
case "adl.nav.request_valid.choice":
Debug.AssertError("ERROR - Should never get here...handled above - Element is Read Only, adl.nav.request_valid.choice");
break;
default:
if(_40.indexOf("ssp")===0){
if(SSP_ENABLED){
return this.SSPApi.StoreValue(_3e,_3f,_40,_41,_42);
}
}
Debug.AssertError("ERROR reached default case in RunTimeApi_StoreValue");
returnData="";
break;
}
return _43;
}
function RunTimeApi_CheckCommentsCollectionLength(_46){
if(this.RunTimeData.Comments.length<=_46){
this.WriteDetailedLog("`1124`"+_46);
this.RunTimeData.Comments[_46]=new ActivityRunTimeComment(null,null,null,null,null);
}
}
function RunTimeApi_CheckInteractionsCollectionLength(_47){
if(this.RunTimeData.Interactions.length<=_47){
this.WriteDetailedLog("`1305`"+_47);
this.RunTimeData.Interactions[_47]=new ActivityRunTimeInteraction(null,null,null,null,null,null,null,null,null,new Array(),new Array());
}
}
function RunTimeApi_CheckInteractionObjectivesCollectionLength(_48,_49){
if(this.RunTimeData.Interactions[_48].Objectives.length<=_49){
this.WriteDetailedLog("`1107`"+_49);
this.RunTimeData.Interactions[_48].Objectives[_49]=null;
}
}
function RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength(_4a,_4b){
if(this.RunTimeData.Interactions[_4a].CorrectResponses.length<=_4b){
this.WriteDetailedLog("`984`"+_4b);
this.RunTimeData.Interactions[_4a].CorrectResponses[_4b]=null;
}
}
function RunTimeApi_CheckObjectivesCollectionLength(_4c){
if(this.RunTimeData.Objectives.length<=_4c){
this.WriteDetailedLog("`1346`"+_4c);
this.RunTimeData.Objectives[_4c]=new ActivityRunTimeObjective(null,"unknown","unknown",null,null,null,null,null,null);
}
}
function RunTimeApi_SetErrorState(_4d,_4e){
if(_4d!=SCORM2004_NO_ERROR){
this.WriteDetailedLog("`1285`"+_4d+" - "+_4e);
}
this.ErrorNumber=_4d;
this.ErrorString=SCORM2004_ErrorStrings[_4d];
this.ErrorDiagnostic=_4e;
}
function RunTimeApi_ClearErrorState(){
this.SetErrorState(SCORM2004_NO_ERROR,"");
}
function RunTimeApi_CheckForInitializeError(arg){
this.WriteDetailedLog("`1412`");
if(this.Initialized){
this.SetErrorState(SCORM2004_ALREADY_INTIAILIZED_ERROR,"Initialize has already been called and may only be called once per session.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR,"Initialize cannot be called after Terminate has already beeen called.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR,"The argument to Initialize must be an empty string (\"\"). The argument '"+arg+"' is invalid.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckForTerminateError(arg){
this.WriteDetailedLog("`1432`");
if(!this.Initialized){
this.SetErrorState(SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR,"Terminate cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR,"Terminate cannot be called after Terminate has already beeen called.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR,"The argument to Terminate must be an empty string (\"\"). The argument '"+arg+"' is invalid.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckForCommitError(arg){
this.WriteDetailedLog("`1496`");
if(!this.Initialized){
this.SetErrorState(SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR,"Commit cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_COMMIT_AFTER_TERMINATION_ERROR,"Commit cannot be called after Terminate has already beeen called.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR,"The argument to Commit must be an empty string (\"\"). The argument '"+arg+"' is invalid.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckMaxLength(_52,_53){
switch(_52){
case "cmi.comments_from_learner.n.comment":
this.CheckLengthAndWarn(_53,4250);
break;
case "cmi.comments_from_learner.n.location":
this.CheckLengthAndWarn(_53,250);
break;
case "cmi.interactions.n.id":
this.CheckLengthAndWarn(_53,4000);
break;
case "cmi.interactions.n.objectives.n.id":
this.CheckLengthAndWarn(_53,4000);
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.CheckLengthAndWarn(_53,7800);
break;
case "cmi.interactions.n.learner_response":
this.CheckLengthAndWarn(_53,7800);
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.CheckLengthAndWarn(_53,500);
break;
case "cmi.learner_preference.language":
this.CheckLengthAndWarn(_53,250);
break;
case "cmi.location":
this.CheckLengthAndWarn(_53,1000);
break;
case "cmi.objectives.n.id":
this.CheckLengthAndWarn(_53,4000);
break;
case "cmi.objectives.n.description":
this.CheckLengthAndWarn(_53,500);
break;
case "cmi.suspend_data":
this.CheckLengthAndWarn(_53,Control.Package.Properties.SuspendDataMaxLength);
break;
default:
break;
}
return;
}
function RunTimeApi_CheckLengthAndWarn(str,len){
if(str.length>len){
this.SetErrorState(SCORM2004_NO_ERROR,"The string was trimmed to fit withing the SPM of "+len+" characters.");
}
return;
}
function RunTimeApi_CheckForGetValueError(_56,_57,_58,_59){
this.WriteDetailedLog("`1453`");
if(!this.Initialized){
this.SetErrorState(SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR,"GetValue cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR,"GetValue cannot be called after Terminate has already beeen called.");
return false;
}
if(_56.length===0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The data model element for GetValue was not specified.");
return false;
}
if(_58!==""){
if(_57.indexOf("cmi.comments_from_learner")>=0){
if(_58>=this.RunTimeData.Comments.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Comments From Learner collection does not have an element at index "+_58+", the current element count is "+this.RunTimeData.Comments.length+".");
return false;
}
}else{
if(_57.indexOf("cmi.comments_from_lms")>=0){
if(_58>=this.RunTimeData.CommentsFromLMS.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Comments From LMS collection does not have an element at index "+_58+", the current element count is "+this.RunTimeData.CommentsFromLMS.length+".");
return false;
}
}else{
if(_57.indexOf("cmi.objectives")>=0){
if(_58>=this.RunTimeData.Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Objectives collection does not have an element at index "+_58+", the current element count is "+this.RunTimeData.Objectives.length+".");
return false;
}
}else{
if(_57.indexOf("cmi.interactions")>=0){
if(_58>=this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Interactions collection does not have an element at index "+_58+", the current element count is "+this.RunTimeData.Interactions.length+".");
return false;
}
if(_57.indexOf("cmi.interactions.n.correct_responses")>=0){
if(_59!==""){
if(_59>=this.RunTimeData.Interactions[_58].CorrectResponses.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Correct Responses collection for Interaction #"+_58+" does not have "+_59+" elements in it, the current element count is "+this.RunTimeData.Interactions[_58].CorrectResponses.length+".");
return false;
}
}
}else{
if(_57.indexOf("cmi.interactions.n.objectives")>=0){
if(_59!==""){
if(_59>=this.RunTimeData.Interactions[_58].Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Objectives collection for Interaction #"+_58+" does not have "+_59+" elements in it, the current element count is "+this.RunTimeData.Interactions[_58].Objectives.length+".");
return false;
}
}
}
}
}
}
}
}
}
switch(_57){
case "cmi._version":
this.WriteDetailedLog("`1606`");
break;
case "cmi.comments_from_learner._children":
this.WriteDetailedLog("`1181`");
break;
case "cmi.comments_from_learner._count":
this.WriteDetailedLog("`1226`");
break;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1156`");
if(this.RunTimeData.Comments[_58].Comment===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Comment field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1128`");
if(this.RunTimeData.Comments[_58].Location===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Location field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1113`");
if(this.RunTimeData.Comments[_58].Timestamp===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The TimeStamp field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.comments_from_lms._children":
this.WriteDetailedLog("`1241`");
break;
case "cmi.comments_from_lms._count":
this.WriteDetailedLog("`1292`");
break;
case "cmi.comments_from_lms.n.comment":
this.WriteDetailedLog("`1242`");
if(this.RunTimeData.CommentsFromLMS[_58].Comment===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Comment field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.comments_from_lms.n.location":
this.WriteDetailedLog("`1227`");
if(this.RunTimeData.CommentsFromLMS[_58].Location===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Location field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.comments_from_lms.n.timestamp":
this.WriteDetailedLog("`1207`");
if(this.RunTimeData.CommentsFromLMS[_58].Timestamp===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Timestamp field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
break;
case "cmi.completion_threshold":
this.WriteDetailedLog("`1362`");
if(this.LearningObject.CompletionThreshold===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The completion threshold for this SCO was not specificed.");
return false;
}
break;
case "cmi.credit":
this.WriteDetailedLog("`1636`");
break;
case "cmi.entry":
this.WriteDetailedLog("`1658`");
break;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The Exit data model element is write-only.");
return false;
case "cmi.interactions._children":
this.WriteDetailedLog("`1324`");
break;
case "cmi.interactions._count":
this.WriteDetailedLog("`1380`");
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1417`");
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1381`");
if(this.RunTimeData.Interactions[_58].Type===null||this.RunTimeData.Interactions[_58].Type===""){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Type field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.interactions.n.objectives._count":
this.WriteDetailedLog("`1129`");
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1182`");
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1294`");
if(this.RunTimeData.Interactions[_58].Timestamp===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Time Stamp field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.interactions.n.correct_responses._count":
this.WriteDetailedLog("`993`");
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`967`");
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1295`");
if(this.RunTimeData.Interactions[_58].Weighting===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Weighting field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1185`");
if(this.RunTimeData.Interactions[_58].LearnerResponse===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Learner Response field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1347`");
if(this.RunTimeData.Interactions[_58].Result===null||this.RunTimeData.Interactions[_58].Result===""){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Result field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1325`");
if(this.RunTimeData.Interactions[_58].Latency===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Latency field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1262`");
if(this.RunTimeData.Interactions[_58].Description===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Description field has not been initialized for the element at index "+_58);
return false;
}
break;
case "cmi.launch_data":
this.WriteDetailedLog("`1544`");
if(this.LearningObject.DataFromLms===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Launch Data field was not specified for this SCO.");
return false;
}
break;
case "cmi.learner_id":
this.WriteDetailedLog("`1559`");
break;
case "cmi.learner_name":
this.WriteDetailedLog("`1518`");
break;
case "cmi.learner_preference._children":
this.WriteDetailedLog("`1228`");
break;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1184`");
if(this.RunTimeData.AudioLevel===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Audio Level field has not been set for this SCO.");
return false;
}
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1244`");
if(this.RunTimeData.LanguagePreference===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Language Preference field has not been set for this SCO.");
return false;
}
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1114`");
if(this.RunTimeData.DeliverySpeed===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Delivery Speed field has not been set for this SCO.");
return false;
}
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1073`");
if(this.RunTimeData.AudioCaptioning===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Audio Captioning field has not been set for this SCO.");
return false;
}
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
if(this.RunTimeData.Location===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Location field has not been set for this SCO.");
return false;
}
break;
case "cmi.max_time_allowed":
this.WriteDetailedLog("`1437`");
if(this.LearningObject.SequencingData===null||this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl===false){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Max Time Allowed field was not specified in the manifest for this SCO.");
return false;
}
break;
case "cmi.mode":
this.WriteDetailedLog("`1684`");
break;
case "cmi.objectives._children":
this.WriteDetailedLog("`1364`");
break;
case "cmi.objectives._count":
this.WriteDetailedLog("`1421`");
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1467`");
break;
case "cmi.objectives.n.score._children":
this.WriteDetailedLog("`1230`");
break;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1283`");
if(this.RunTimeData.Objectives[_58].ScoreScaled===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Scaled Score field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1331`");
if(this.RunTimeData.Objectives[_58].ScoreRaw===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Raw Score field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1330`");
if(this.RunTimeData.Objectives[_58].ScoreMin===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Min Score field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1329`");
if(this.RunTimeData.Objectives[_58].ScoreMax===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Max Score field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1245`");
if(this.RunTimeData.Objectives[_58].SuccessStatus===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The SuccessStatus field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1186`");
if(this.RunTimeData.Objectives[_58].CompletionStatus===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The CompletionStatus field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1210`");
if(this.RunTimeData.Objectives[_58].ProgressMeasure===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The ProgressMeasure field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1296`");
if(this.RunTimeData.Objectives[_58].Description===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Description field has not been initialized for the objective at index "+_58);
return false;
}
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1439`");
if(this.RunTimeData.ProgressMeasure===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Progress Measure field has not been set for this SCO.");
return false;
}
break;
case "cmi.scaled_passing_score":
this.WriteDetailedLog("`1369`");
if(this.LearningObject.GetScaledPassingScore()===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Scaled Passing Score field was not specificed for this SCO.");
return false;
}
break;
case "cmi.score._children":
this.WriteDetailedLog("`1468`");
break;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
if(this.RunTimeData.ScoreScaled===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Scaled Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
if(this.RunTimeData.ScoreRaw===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Raw Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
if(this.RunTimeData.ScoreMax===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Max Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
if(this.RunTimeData.ScoreMin===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Min Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.session_time":
this.WriteDetailedLog("`1521`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The Exit data model element is write-only.");
break;
case "cmi.success_status":
this.WriteDetailedLog("`1485`");
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1525`");
if(this.RunTimeData.SuspendData===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Suspend Data field has not been set for this SCO.");
return false;
}
break;
case "cmi.time_limit_action":
this.WriteDetailedLog("`1424`");
if(this.LearningObject.TimeLimitAction===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Time Limit Action field has not been set for this SCO.");
return false;
}
break;
case "cmi.total_time":
this.WriteDetailedLog("`1564`");
break;
case "adl.nav.request":
this.WriteDetailedLog("`1463`");
break;
case "adl.nav.request_valid.continue":
this.WriteDetailedLog("`1176`");
break;
case "adl.nav.request_valid.previous":
this.WriteDetailedLog("`1177`");
break;
default:
if(_57.indexOf("adl.nav.request_valid.choice")===0){
this.WriteDetailedLog("`1224`");
return true;
}
if(_57.indexOf("ssp")===0){
if(SSP_ENABLED){
return this.SSPApi.CheckForGetValueError(_56,_57,_58,_59);
}
}
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_56+"' does not exist.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckForSetValueError(_5a,_5b,_5c,_5d,_5e){
this.WriteDetailedLog("`1537`"+_5a+", "+_5b+", "+_5c+", "+_5d+", "+_5e+") ");
if(!this.Initialized){
this.SetErrorState(SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR,"SetValue cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR,"SetValue cannot be called after Terminate has already beeen called.");
return false;
}
if(_5a.length===0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The data model element for SetValue was not specified.");
return false;
}
if(_5a.indexOf("adl.nav.request_valid.choice.{")===0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The adl.nav.request_valid.choice element is read only");
return false;
}
if(_5d!==""){
if(_5c.indexOf("cmi.comments_from_learner")>=0){
if(_5d>this.RunTimeData.Comments.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Comments From Learner collection elements must be set sequentially, the index "+_5d+", is greater than the next available index of "+this.RunTimeData.Comments.length+".");
return false;
}
}else{
if(_5c.indexOf("cmi.comments_from_lms")>=0){
if(_5d>this.RunTimeData.CommentsFromLMS.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Comments From LMS collection elements must be set sequentially, the index "+_5d+", is greater than the next available index of "+this.RunTimeData.CommentsFromLMS.length+".");
return false;
}
}else{
if(_5c.indexOf("cmi.objectives")>=0){
if(_5d>this.RunTimeData.Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Objectives collection elements must be set sequentially, the index "+_5d+", is greater than the next available index of "+this.RunTimeData.Objectives.length+".");
return false;
}
}else{
if(_5c.indexOf("cmi.interactions")>=0){
if(_5d>this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Interactions collection elements must be set sequentially, the index "+_5d+", is greater than the next available index of "+this.RunTimeData.Interactions.length+".");
return false;
}else{
if(_5c.indexOf("cmi.interactions.n.correct_responses")>=0){
if(_5d>=this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The Interactions collection elements must be set sequentially, the index "+_5d+", is greater than the next available index of "+this.RunTimeData.Interactions.length+".");
return false;
}
if(_5e!==""){
if(_5e>this.RunTimeData.Interactions[_5d].CorrectResponses.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Correct Responses collection elements for Interaction #"+_5d+" must be set sequentially the index "+_5e+" is greater than the next available index of "+this.RunTimeData.Interactions[_5d].CorrectResponses.length+".");
return false;
}
}
}else{
if(_5c.indexOf("cmi.interactions.n.objectives")>=0){
if(_5d>=this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The Interactions collection elements must be set sequentially, the index "+_5d+", is greater than the next available index of "+this.RunTimeData.Interactions.length+".");
return false;
}
if(_5e!==""){
if(_5e>this.RunTimeData.Interactions[_5d].Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Objectives collection elements for Interaction #"+_5d+" must be set sequentially the index "+_5e+" is greater than the next available index of "+this.RunTimeData.Interactions[_5d].Objectives.length+".");
return false;
}
}
}
}
}
}
}
}
}
}
var _5f;
var i;
switch(_5c){
case "cmi._version":
this.WriteDetailedLog("`1587`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi._version data model element is read-only");
return false;
case "cmi.comments_from_learner._children":
this.WriteDetailedLog("`1155`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_learner._children data model element is read-only");
return false;
case "cmi.comments_from_learner._count":
this.WriteDetailedLog("`1226`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_learner._count data model element is read-only");
return false;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1156`");
if(!this.ValidLocalizedString(_5b,4000)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.comments_from_learner.n.comment data model element is not a valid localized string type (SPM 4000)");
return false;
}
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1128`");
if(!this.ValidCharString(_5b,250)){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The cmi.comments_from_learner.n.comment data model element is not a valid char string type (SPM 250)");
return false;
}
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1113`");
if(!this.ValidTime(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.comments_from_learner.n.timestamp data model element is not a valid time");
return false;
}
break;
case "cmi.comments_from_lms._children":
this.WriteDetailedLog("`1241`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms._children data model element is read-only");
return false;
case "cmi.comments_from_lms._count":
this.WriteDetailedLog("`1292`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms._count data model element is read-only");
return false;
case "cmi.comments_from_lms.n.comment":
this.WriteDetailedLog("`1242`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms.comment data model element is read-only");
return false;
case "cmi.comments_from_lms.n.location":
this.WriteDetailedLog("`1227`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms.location data model element is read-only");
return false;
case "cmi.comments_from_lms.n.timestamp":
this.WriteDetailedLog("`1207`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms.timestamp data model element is read-only");
return false;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
if(_5b!=SCORM_STATUS_COMPLETED&&_5b!=SCORM_STATUS_INCOMPLETE&&_5b!=SCORM_STATUS_NOT_ATTEMPTED&&_5b!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The completion_status data model element must be a proper vocabulary element.");
return false;
}
break;
case "cmi.completion_threshold":
this.WriteDetailedLog("`1362`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The completion_threshold data model element is read-only");
return false;
case "cmi.credit":
this.WriteDetailedLog("`1636`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The credit data model element is read-only");
return false;
case "cmi.entry":
this.WriteDetailedLog("`1658`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The entry data model element is read-only");
return false;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
if(_5b!=SCORM_EXIT_TIME_OUT&&_5b!=SCORM_EXIT_SUSPEND&&_5b!=SCORM_EXIT_LOGOUT&&_5b!=SCORM_EXIT_NORMAL&&_5b!=SCORM_EXIT_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The exit data model element must be a proper vocabulary element.");
return false;
}
break;
case "cmi.interactions._children":
this.WriteDetailedLog("`1324`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions._children element is read-only");
return false;
case "cmi.interactions._count":
this.WriteDetailedLog("`1380`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions._count element is read-only");
return false;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1417`");
if(!this.ValidLongIdentifier(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".id value of '"+_5b+"' is not a valid long identifier.");
return false;
}
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1381`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(_5b!=SCORM_TRUE_FALSE&&_5b!=SCORM_CHOICE&&_5b!=SCORM_FILL_IN&&_5b!=SCORM_LONG_FILL_IN&&_5b!=SCORM_LIKERT&&_5b!=SCORM_MATCHING&&_5b!=SCORM_PERFORMANCE&&_5b!=SCORM_SEQUENCING&&_5b!=SCORM_NUMERIC&&_5b!=SCORM_OTHER){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".type value of '"+_5b+"' is not a valid interaction type.");
return false;
}
break;
case "cmi.interactions.n.objectives._count":
this.WriteDetailedLog("`1129`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions.objectives._count element is read-only");
return false;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1182`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidLongIdentifier(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".objectives."+_5e+".id value of '"+_5b+"' is not a valid long identifier type.");
return false;
}
for(i=0;i<this.RunTimeData.Interactions[_5d].Objectives.length;i++){
if((this.RunTimeData.Interactions[_5d].Objectives[i]==_5b)&&(i!=_5e)){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Every interaction objective identifier must be unique. The value '"+_5b+"' has already been set in objective #"+i);
return false;
}
}
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1294`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidTime(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".timestamp value of '"+_5b+"' is not a valid time type.");
return false;
}
break;
case "cmi.interactions.n.correct_responses._count":
this.WriteDetailedLog("`993`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions.correct_responses._count element is read-only");
return false;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`967`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Type===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.type element must be set before a correct response can be set.");
return false;
}
_5f=true;
if(RegistrationToDeliver.Package.Properties.ValidateInteractionResponses){
switch(this.RunTimeData.Interactions[_5d].Type){
case SCORM_TRUE_FALSE:
if(this.RunTimeData.Interactions[_5d].CorrectResponses.length>0&&_5e>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"A true-false interaction can only have one correct response.");
return false;
}
_5f=this.ValidTrueFalseResponse(_5b);
break;
case SCORM_CHOICE:
_5f=this.ValidMultipleChoiceResponse(_5b);
for(i=0;i<this.RunTimeData.Interactions[_5d].CorrectResponses.length;i++){
if(this.RunTimeData.Interactions[_5d].CorrectResponses[i]==_5b){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Every correct response to a choice interaction must be unique. The value '"+_5b+"' has already been set in correct response #"+i);
return false;
}
}
break;
case SCORM_FILL_IN:
_5f=this.ValidFillInResponse(_5b,true);
break;
case SCORM_LONG_FILL_IN:
_5f=this.ValidLongFillInResponse(_5b,true);
break;
case SCORM_LIKERT:
if(this.RunTimeData.Interactions[_5d].CorrectResponses.length>0&&_5e>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"A likert interaction can only have one correct response.");
return false;
}
_5f=this.ValidLikeRTResponse(_5b);
break;
case SCORM_MATCHING:
_5f=this.ValidMatchingResponse(_5b);
break;
case SCORM_PERFORMANCE:
_5f=this.ValidPerformanceResponse(_5b,true);
break;
case SCORM_SEQUENCING:
_5f=this.ValidSequencingResponse(_5b);
break;
case SCORM_NUMERIC:
if(this.RunTimeData.Interactions[_5d].CorrectResponses.length>0&&_5e>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"A numeric interaction can only have one correct response.");
return false;
}
_5f=this.ValidNumericResponse(_5b,true);
break;
case SCORM_OTHER:
if(this.RunTimeData.Interactions[_5d].CorrectResponses.length>0&&_5e>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"An 'other' interaction can only have one correct response.");
return false;
}
_5f=this.ValidOtheresponse(_5b);
break;
}
}
if(!_5f){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".correct_responses."+_5e+".pattern value of '"+_5b+"' is not a valid correct response to an interaction of type "+this.RunTimeData.Interactions[_5d].Type+".");
return false;
}
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1295`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".weighting value of '"+_5b+"' is not a valid real number.");
return false;
}
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1158`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(this.RunTimeData.Interactions[_5d].Type===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.type element must be set before a learner response can be set.");
return false;
}
_5f=true;
if(RegistrationToDeliver.Package.Properties.ValidateInteractionResponses){
switch(this.RunTimeData.Interactions[_5d].Type){
case "true-false":
_5f=this.ValidTrueFalseResponse(_5b);
break;
case "choice":
_5f=this.ValidMultipleChoiceResponse(_5b);
break;
case "fill-in":
_5f=this.ValidFillInResponse(_5b,false);
break;
case "long-fill-in":
_5f=this.ValidLongFillInResponse(_5b,false);
break;
case "likert":
_5f=this.ValidLikeRTResponse(_5b);
break;
case "matching":
_5f=this.ValidMatchingResponse(_5b);
break;
case "performance":
_5f=this.ValidPerformanceResponse(_5b,false);
break;
case "sequencing":
_5f=this.ValidSequencingResponse(_5b);
break;
case "numeric":
_5f=this.ValidNumericResponse(_5b,false);
break;
case "other":
_5f=this.ValidOtheresponse(_5b);
break;
}
}
if(!_5f){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".learner_response value of '"+_5b+"' is not a valid response to an interaction of type "+this.RunTimeData.Interactions[_5d].Type+".");
return false;
}
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1347`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(_5b!=SCORM_CORRECT&&_5b!=SCORM_INCORRECT&&_5b!=SCORM_UNANTICIPATED&&_5b!=SCORM_NEUTRAL){
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".result value of '"+_5b+"' is not a valid interaction result.");
return false;
}
}
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1325`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidTimeInterval(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".latency value of '"+_5b+"' is not a valid timespan.");
return false;
}
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1262`");
if(this.RunTimeData.Interactions[_5d]===undefined||this.RunTimeData.Interactions[_5d].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidLocalizedString(_5b,250)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_5d+".description value of '"+_5b+"' is not a valid localized string SPM 250.");
return false;
}
break;
case "cmi.launch_data":
this.WriteDetailedLog("`1544`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.launch_data element is read-only");
return false;
case "cmi.learner_id":
this.WriteDetailedLog("`1559`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.learner_id element is read-only");
return false;
case "cmi.learner_name":
this.WriteDetailedLog("`1518`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.learner_name element is read-only");
return false;
case "cmi.learner_preference._children":
this.WriteDetailedLog("`1228`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.learner_preference._children element is read-only");
return false;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1184`");
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.audio_level value of '"+_5b+"' is not a valid real number.");
return false;
}
if(parseFloat(_5b)<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.learner_preference.audio_level value of '"+_5b+"' must be greater than zero.");
return false;
}
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1244`");
if(!this.ValidLanguage(_5b,true)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.language value of '"+_5b+"' is not a valid language.");
return false;
}
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1114`");
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.delivery_speed value of '"+_5b+"' is not a valid real number.");
return false;
}
if(parseFloat(_5b)<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.learner_preference.delivery_speed value of '"+_5b+"' must be greater than zero.");
return false;
}
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1073`");
if(_5b!="-1"&&_5b!="0"&&_5b!="1"){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.audio_captioning value of '"+_5b+"' must be -1, 0 or 1.");
return false;
}
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
if(!this.ValidCharString(_5b,1000)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.location value of '"+_5b+"' is not a valid char string SPM 1000.");
return false;
}
break;
case "cmi.max_time_allowed":
this.WriteDetailedLog("`1437`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.max_time_allowed element is read only");
return false;
case "cmi.mode":
this.WriteDetailedLog("`1684`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.mode element is read only");
return false;
case "cmi.objectives._children":
this.WriteDetailedLog("`1364`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.objectives._children element is read only");
return false;
case "cmi.objectives._count":
this.WriteDetailedLog("`1421`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.objectives._count element is read only");
return false;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1467`");
if(!this.ValidLongIdentifier(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives.n.id value of '"+_5b+"' is not a valid long identifier.");
return false;
}
for(i=0;i<this.RunTimeData.Objectives.length;i++){
if((this.RunTimeData.Objectives[i].Identifier==_5b)&&(i!=_5d)){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Every objective identifier must be unique. The value '"+_5b+"' has already been set in objective #"+i);
return false;
}
}
break;
case "cmi.objectives.n.score._children":
this.WriteDetailedLog("`1230`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.objectives.n.score._children element is read only");
return false;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1283`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".score.scaled value of '"+_5b+"' is not a valid real number.");
return false;
}
if(parseFloat(_5b)<-1||parseFloat(_5b)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.objectives."+_5d+".score.scaled value of '"+_5b+"' must be between -1 and 1.");
return false;
}
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1331`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".score.raw value of '"+_5b+"' is not a valid real number.");
return false;
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1330`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".score.min value of '"+_5b+"' is not a valid real number.");
return false;
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1329`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".score.max value of '"+_5b+"' is not a valid real number.");
return false;
}
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1245`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(_5b!=SCORM_STATUS_PASSED&&_5b!=SCORM_STATUS_FAILED&&_5b!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".success_status value of '"+_5b+"' is not a valid success status.");
return false;
}
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1186`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(_5b!=SCORM_STATUS_COMPLETED&&_5b!=SCORM_STATUS_INCOMPLETE&&_5b!=SCORM_STATUS_NOT_ATTEMPTED&&_5b!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".completion_status value of '"+_5b+"' is not a valid completion status.");
return false;
}
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1210`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".progress_measure value of '"+_5b+"' is not a valid real number.");
return false;
}
if(parseFloat(_5b)<0||parseFloat(_5b)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.objectives."+_5d+".progress_measure value of '"+_5b+"' must be between 0 and 1.");
return false;
}
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1296`");
if(this.RunTimeData.Objectives[_5d]===undefined||this.RunTimeData.Objectives[_5d].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidLocalizedString(_5b,250)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_5d+".description value of '"+_5b+"' is not a valid localized string SPM 250.");
return false;
}
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1439`");
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.progress_measure value of '"+_5b+"' is not a valid real number.");
return false;
}
if(parseFloat(_5b)<0||parseFloat(_5b)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.pogress_measure value of '"+_5b+"' must be between 0 and 1.");
return false;
}
break;
case "cmi.scaled_passing_score":
this.WriteDetailedLog("`1369`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.scaled_passing_score element is read only");
return false;
case "cmi.score._children":
this.WriteDetailedLog("`1468`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.score._children element is read only");
return false;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.scaled value of '"+_5b+"' is not a valid real number.");
return false;
}
if(parseFloat(_5b)<-1||parseFloat(_5b)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi..score.scaled value of '"+_5b+"' must be between -1 and 1.");
return false;
}
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.raw value of '"+_5b+"' is not a valid real number.");
return false;
}
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.raw value of '"+_5b+"' is not a valid real number.");
return false;
}
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
if(!this.ValidReal(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.raw value of '"+_5b+"' is not a valid real number.");
return false;
}
break;
case "cmi.session_time":
this.WriteDetailedLog("`1521`");
if(!this.ValidTimeInterval(_5b)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.session_time value of '"+_5b+"' is not a valid time intervals.");
return false;
}
break;
case "cmi.success_status":
this.WriteDetailedLog("`1485`");
if(_5b!=SCORM_STATUS_PASSED&&_5b!=SCORM_STATUS_FAILED&&_5b!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.success_status value of '"+_5b+"' is not a valid success status.");
return false;
}
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1525`");
if(!this.ValidCharString(_5b,Control.Package.Properties.SuspendDataMaxLength)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.suspend_data value of '"+_5b+"' is not a valid char string SPM"+Control.Package.Properties.SuspendDataMaxLength+".");
return false;
}
break;
case "cmi.time_limit_action":
this.WriteDetailedLog("`1424`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.time_limit_action element is read only");
return false;
case "cmi.total_time":
this.WriteDetailedLog("`1564`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.total_time element is read only");
return false;
case "adl.nav.request":
this.WriteDetailedLog("`1463`");
if(_5b.substring(0,1)=="{"){
var _61=_5b.substring(0,_5b.indexOf("}")+1);
if(Control.IsTargetValid(_61)===false){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value '"+_61+"' is not a valid target of a choice request.");
return false;
}
if(_5b.indexOf("choice")!=_61.length){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"A target may only be provided for a choice request.");
return false;
}
}else{
if(_5b!=SCORM_RUNTIME_NAV_REQUEST_CONTINUE&&_5b!=SCORM_RUNTIME_NAV_REQUEST_PREVIOUS&&_5b!=SCORM_RUNTIME_NAV_REQUEST_CHOICE&&_5b!=SCORM_RUNTIME_NAV_REQUEST_EXIT&&_5b!=SCORM_RUNTIME_NAV_REQUEST_EXITALL&&_5b!=SCORM_RUNTIME_NAV_REQUEST_ABANDON&&_5b!=SCORM_RUNTIME_NAV_REQUEST_ABANDONALL&&_5b!=SCORM_RUNTIME_NAV_REQUEST_NONE){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The adl.nav.request value of '"+_5b+"' is not a valid nav request.");
return false;
}
}
break;
case "adl.nav.request_valid.continue":
this.WriteDetailedLog("`1176`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The adl.nav.request_valid.continue element is read only");
return false;
case "adl.nav.request_valid.previous":
this.WriteDetailedLog("`1177`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The adl.nav.request_valid.previous element is read only");
return false;
case "adl.nav.request_valid.choice":
this.WriteDetailedLog("`1224`");
break;
default:
if(_5c.indexOf("ssp")===0){
if(SSP_ENABLED){
return this.SSPApi.CheckForSetValueError(_5a,_5b,_5c,_5d,_5e);
}
}
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_5a+"' is not defined in SCORM 2004");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_ValidCharString(str,_63){
this.WriteDetailedLog("`1486`");
return true;
}
function RunTimeApi_ValidLocalizedString(str,_65){
this.WriteDetailedLog("`1383`");
var _66;
var _67=new String();
var _68;
_66=str;
if(str.indexOf("{lang=")===0){
_68=str.indexOf("}");
if(_68>0){
_67=str.substr(0,_68);
_67=_67.replace(/\{lang=/,"");
_67=_67.replace(/\}/,"");
if(!this.ValidLanguage(_67,false)){
return false;
}
if(str.length>=(_68+2)){
_66=str.substring(_68+1);
}else{
_66="";
}
}
}
return true;
}
function RunTimeApi_ExtractLanguageDelimiterFromLocalizedString(str){
var _6a;
var _6b="";
if(str.indexOf("{lang=")===0){
_6a=str.indexOf("}");
if(_6a>0){
_6b=str.substr(0,_6a+1);
}
}
return _6b;
}
function RunTimeApi_ValidLanguage(str,_6d){
this.WriteDetailedLog("`1529`");
var _6e;
if(str.length===0){
if(_6d){
return true;
}else{
return false;
}
}
_6e=str.split("-");
for(var i=0;i<_6e.length;i++){
if(_6e[i].length>8){
return false;
}
if(_6e[i].length<2){
if(_6e[i]!="i"&&_6e[i]!="x"){
return false;
}
}
}
var _70=new Iso639LangCodes_LangCodes();
if(!_70.IsValid(_6e[0].toLowerCase())){
return false;
}
if(str.length>250){
return false;
}
return true;
}
function RunTimeApi_ValidLongIdentifier(str){
this.WriteDetailedLog("`1402`");
str=str.trim();
if(!this.ValidIdentifier(str)){
return false;
}
return true;
}
function RunTimeApi_ValidShortIdentifier(str){
this.WriteDetailedLog("`1385`");
if(!this.ValidIdentifier(str)){
return false;
}
return true;
}
function RunTimeApi_ValidIdentifier(str){
this.WriteDetailedLog("`1487`");
str=str.trim();
if(str.length===0){
return false;
}
if(str.toLowerCase().indexOf("urn:")===0){
return this.IsValidUrn(str);
}
if(str.search(/\w/)<0){
return false;
}
if(str.search(/[^\w\-\(\)\+\.\:\=\@\;\$\_\!\*\'\%\/]/)>=0){
return false;
}
return true;
}
function RunTimeApi_IsValidUrn(str){
this.WriteDetailedLog("`1575`");
var _75=str.split(":");
var nid=new String("");
var nss="";
if(_75.length>1){
nid=_75[1];
}else{
return false;
}
if(_75.length>2){
nss=_75[2];
}
if(nid.length===0){
return false;
}
if(nid.indexOf(" ")>0||nss.indexOf(" ")>0){
return false;
}
return true;
}
function RunTimeApi_ValidReal(str){
this.WriteDetailedLog("`1595`");
if(str.search(/[^.\d-]/)>-1){
return false;
}
if(str.search("-")>-1){
if(str.indexOf("-",1)>-1){
return false;
}
}
if(str.indexOf(".")!=str.lastIndexOf(".")){
return false;
}
if(str.search(/\d/)<0){
return false;
}
return true;
}
function RunTimeApi_ValidTime(str){
this.WriteDetailedLog("`1596`");
var _7a="";
var _7b="";
var day="";
var _7d="";
var _7e="";
var _7f="";
var _80="";
var _81="";
var _82="";
var _83="";
var _84;
str=new String(str);
var _85=/^(\d\d\d\d)(-(\d\d)(-(\d\d)(T(\d\d)(:(\d\d)(:(\d\d))?)?)?)?)?/;
if(str.search(_85)!==0){
return false;
}
if(str.substr(str.length-1,1).search(/[\-T\:]/)>=0){
return false;
}
var len=str.length;
if(len!=4&&len!=7&&len!=10&&len!=13&&len!=16&&len<19){
return false;
}
if(len>=5){
if(str.substr(4,1)!="-"){
return false;
}
}
if(len>=8){
if(str.substr(7,1)!="-"){
return false;
}
}
if(len>=11){
if(str.substr(10,1)!="T"){
return false;
}
}
if(len>=14){
if(str.substr(13,1)!=":"){
return false;
}
}
if(len>=17){
if(str.substr(16,1)!=":"){
return false;
}
}
var _87=str.match(_85);
_7a=_87[1];
_7b=_87[3];
day=_87[5];
_7d=_87[7];
_7e=_87[9];
_7f=_87[11];
if(str.length>19){
if(str.length<21){
return false;
}
if(str.substr(19,1)!="."){
return false;
}
_84=str.substr(20,1);
if(_84.search(/\d/)<0){
return false;
}else{
_80+=_84;
}
for(var i=21;i<str.length;i++){
_84=str.substr(i,1);
if((i==21)&&(_84.search(/\d/)===0)){
_80+=_84;
}else{
_81+=_84;
}
}
}
if(_81.length===0){
}else{
if(_81.length==1){
if(_81!="Z"){
return false;
}
}else{
if(_81.length==3){
if(_81.search(/[\+\-]\d\d/)!==0){
return false;
}else{
_82=_81.substr(1,2);
}
}else{
if(_81.length==6){
if(_81.search(/[\+\-]\d\d:\d\d/)!==0){
return false;
}else{
_82=_81.substr(1,2);
_83=_81.substr(4,2);
}
}else{
return false;
}
}
}
}
if(_7a<1970||_7a>2038){
return false;
}
if(_7b!==undefined&&_7b!==""){
_7b=parseInt(_7b,10);
if(_7b<1||_7b>12){
return false;
}
}
if(day!==undefined&&day!==""){
var dtm=new Date(_7a,(_7b-1),day);
if(dtm.getDate()!=day){
return false;
}
}
if(_7d!==undefined&&_7d!==""){
_7d=parseInt(_7d,10);
if(_7d<0||_7d>23){
return false;
}
}
if(_7e!==undefined&&_7e!==""){
_7e=parseInt(_7e,10);
if(_7e<0||_7e>59){
return false;
}
}
if(_7f!==undefined&&_7f!==""){
_7f=parseInt(_7f,10);
if(_7f<0||_7f>59){
return false;
}
}
if(_82!==undefined&&_82!==""){
_82=parseInt(_82,10);
if(_82<0||_82>23){
return false;
}
}
if(_83!==undefined&&_83!==""){
_83=parseInt(_83,10);
if(_83<0||_83>59){
return false;
}
}
return true;
}
function RunTimeApi_ValidTimeInterval(str){
this.WriteDetailedLog("`1445`");
var _8b=/^P(\d+Y)?(\d+M)?(\d+D)?(T(\d+H)?(\d+M)?(\d+(.\d\d?)?S)?)?$/;
if(str=="P"){
return false;
}
if(str.lastIndexOf("T")==(str.length-1)){
return false;
}
if(str.search(_8b)<0){
return false;
}
return true;
}
function RunTimeApi_ValidTrueFalseResponse(str){
this.WriteDetailedLog("`1354`");
var _8d=/^(true|false)$/;
if(str.search(_8d)<0){
return false;
}
return true;
}
function RunTimeApi_ValidMultipleChoiceResponse(str){
this.WriteDetailedLog("`1268`");
if(str.length===0){
return true;
}
return (this.IsValidArrayOfShortIdentifiers(str,36,true)||this.IsValidCommaDelimitedArrayOfShortIdentifiers(str,36,true));
}
function RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers(str,_90,_91){
this.WriteDetailedLog("`1215`");
var _92=",";
var _93=str.split(_92);
for(var i=0;i<_93.length;i++){
if(!this.ValidShortIdentifier(_93[i])){
return false;
}
if(_91){
for(var j=0;j<_93.length;j++){
if(j!=i){
if(_93[j]==_93[i]){
return false;
}
}
}
}
}
return true;
}
function RunTimeApi_IsValidArrayOfShortIdentifiers(str,_97,_98){
this.WriteDetailedLog("`1215`");
var _99="[,]";
var _9a=str.split(_99);
for(var i=0;i<_9a.length;i++){
if(!this.ValidShortIdentifier(_9a[i])){
return false;
}
if(_98){
for(var j=0;j<_9a.length;j++){
if(j!=i){
if(_9a[j]==_9a[i]){
return false;
}
}
}
}
}
return true;
}
function RunTimeApi_IsValidArrayOfLocalizedStrings(str,_9e,_9f){
this.WriteDetailedLog("`1214`");
var _a0="[,]";
var _a1=str.split(_a0);
for(var i=0;i<_a1.length;i++){
if(!this.ValidLocalizedString(_a1[i],0)){
return false;
}
if(_9f){
for(var j=0;j<_a1.length;j++){
if(j!=i){
if(_a1[j]==_a1[i]){
return false;
}
}
}
}
}
return true;
}
function RunTimeApi_ValidFillInResponse(str,_a5){
this.WriteDetailedLog("`1400`");
if(str.length===0){
return true;
}
var _a6=/^\{case_matters=/;
var _a7=/^\{order_matters=/;
var _a8=/^\{lang=[\w\-]+\}\{/;
var _a9=/^\{case_matters=(true|false)\}/;
var _aa=/^\{order_matters=(true|false)\}/;
var _ab=new String(str);
if(_a5){
if(_ab.search(_a6)>=0){
if(_ab.search(_a9)<0){
return false;
}
_ab=_ab.replace(_a9,"");
}
if(_ab.search(_a7)>=0){
if(_ab.search(_aa)<0){
return false;
}
_ab=_ab.replace(_aa,"");
}
if(_ab.search(_a6)>=0){
if(_ab.search(_a9)<0){
return false;
}
_ab=_ab.replace(_a9,"");
}
}
return this.IsValidArrayOfLocalizedStrings(_ab,10,false);
}
function RunTimeApi_ValidLongFillInResponse(str,_ad){
this.WriteDetailedLog("`1336`");
var _ae=/^\{case_matters=/;
var _af=/^\{case_matters=(true|false)\}/;
var _b0=new String(str);
if(_ad){
if(_b0.search(_ae)>=0){
if(_b0.search(_af)<0){
return false;
}
_b0=_b0.replace(_af,"");
}
}
return this.ValidLocalizedString(_b0,4000);
}
function RunTimeApi_ValidLikeRTResponse(str){
this.WriteDetailedLog("`1401`");
return this.ValidShortIdentifier(str);
}
function RunTimeApi_ValidMatchingResponse(str){
this.WriteDetailedLog("`1374`");
var _b3="[,]";
var _b4="[.]";
var _b5;
var _b6;
_b5=str.split(_b3);
for(var i=0;i<_b5.length;i++){
_b6=_b5[i].split(_b4);
if(_b6.length!=2){
return false;
}
if(!this.ValidShortIdentifier(_b6[0])){
return false;
}
if(!this.ValidShortIdentifier(_b6[1])){
return false;
}
}
return true;
}
function RunTimeApi_ValidPerformanceResponse(str,_b9){
this.WriteDetailedLog("`1314`");
var _ba=/^\{order_matters=/;
var _bb=/^\{order_matters=(true|false)\}/;
var _bc;
var _bd;
var _be;
var _bf;
var _c0;
var _c1=new String(str);
if(str.length===0){
return false;
}
if(_b9){
if(_c1.search(_ba)>=0){
if(_c1.search(_bb)<0){
return false;
}
_c1=_c1.replace(_bb,"");
}
}
_bc=_c1.split("[,]");
if(_bc.length===0){
return false;
}
for(var i=0;i<_bc.length;i++){
_bd=_bc[i];
if(_bd.length===0){
return false;
}
_be=_bd.split("[.]");
if(_be.length==2){
_bf=_be[0];
_c0=_be[1];
if(_bf.length===0&&_c0===0){
return false;
}
if(_bf.length>0){
if(!this.ValidShortIdentifier(_bf)){
return false;
}
}
}else{
return false;
}
}
return true;
}
function RunTimeApi_ValidSequencingResponse(str){
this.WriteDetailedLog("`1337`");
return this.IsValidArrayOfShortIdentifiers(str,36,false);
}
function RunTimeApi_ValidNumericResponse(str,_c5){
this.WriteDetailedLog("`1384`");
var _c6="[:]";
var _c7=str.split(_c6);
if(_c5){
if(_c7.length>2){
return false;
}
}else{
if(_c7.length>1){
return false;
}
}
for(var i=0;i<_c7.length;i++){
if(!this.ValidReal(_c7[i])){
return false;
}
}
if(_c7.length>=2){
if(_c7[0].length>0&&_c7[1].length>0){
if(parseFloat(_c7[0])>parseFloat(_c7[1])){
return false;
}
}
}
return true;
}
function RunTimeApi_ValidOtheresponse(str){
this.WriteDetailedLog("`1444`");
return true;
}
function RunTimeApi_TranslateBooleanIntoCMI(_ca){
if(_ca===true){
return SCORM_TRUE;
}else{
if(_ca===false){
return SCORM_FALSE;
}else{
return SCORM_UNKNOWN;
}
}
}
function RunTimeApi_InitTrackedTimeStart(_cb){
this.TrackedStartDate=new Date();
this.StartSessionTotalTime=_cb.RunTime.TotalTime;
}
function RunTimeApi_AccumulateTotalTimeTracked(){
this.TrackedEndDate=new Date();
var _cc=Math.round((this.TrackedEndDate-this.TrackedStartDate)/10);
var _cd=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTimeTracked);
var _ce=_cc+_cd;
this.RunTimeData.TotalTimeTracked=ConvertHundredthsToIso8601TimeSpan(_ce);
var _cf=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTimeTracked);
var _d0=_cc+_cf;
this.RunTimeData.SessionTimeTracked=ConvertHundredthsToIso8601TimeSpan(_d0);
this.Activity.ActivityEndedDate=this.TrackedEndDate;
var _d1=GetDateFromUtcIso8601Time(this.Activity.GetActivityStartTimestampUtc());
var _d2=GetDateFromUtcIso8601Time(this.Activity.GetAttemptStartTimestampUtc());
this.Activity.SetActivityAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate-_d1)/10));
this.Activity.SetAttemptAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate-_d2)/10));
var _d3=ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationTracked());
var _d4=ConvertHundredthsToIso8601TimeSpan(_d3+_cc);
this.Activity.SetActivityExperiencedDurationTracked(_d4);
var _d5=ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationReported());
var _d6=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime)-ConvertIso8601TimeSpanToHundredths(this.StartSessionTotalTime);
var _d7=ConvertHundredthsToIso8601TimeSpan(_d5+_d6);
this.Activity.SetActivityExperiencedDurationReported(_d7);
var _d8=ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationTracked());
var _d9=ConvertHundredthsToIso8601TimeSpan(_d8+_cc);
this.Activity.SetAttemptExperiencedDurationTracked(_d9);
var _da=ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationReported());
var _db=ConvertHundredthsToIso8601TimeSpan(_da+_d6);
this.Activity.SetAttemptExperiencedDurationReported(_db);
}
function RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded(_dc,_dd){
if(this.IsLookAheadSequencerDataDirty==false&&_dc!=_dd){
this.IsLookAheadSequencerDataDirty=true;
}
}
function RunTimeApi_RunLookAheadSequencerIfNeeded(_de){
if((Control.Package.Properties.LookaheadSequencerMode!=LOOKAHEAD_SEQUENCER_MODE_REALTIME&&_de!==true)||Control.Package.Properties.LookaheadSequencerMode==LOOKAHEAD_SEQUENCER_MODE_DISABLE){
return;
}
if(this.RunTimeData!=null){
this.LookAheadSessionClose();
}
if(this.IsLookAheadSequencerDataDirty===true&&!this.IsLookAheadSequencerRunning){
this.IsLookAheadSequencerDataDirty=false;
this.IsLookAheadSequencerRunning=true;
window.setTimeout("Control.EvaluatePossibleNavigationRequests(true, false);",150);
}
}
var TERMINATION_REQUEST_EXIT="EXIT";
var TERMINATION_REQUEST_EXIT_ALL="EXIT ALL";
var TERMINATION_REQUEST_SUSPEND_ALL="SUSPEND ALL";
var TERMINATION_REQUEST_ABANDON="ABANDON";
var TERMINATION_REQUEST_ABANDON_ALL="ABANDON ALL";
var TERMINATION_REQUEST_EXIT_PARENT="EXIT PARENT";
var TERMINATION_REQUEST_NOT_VALID="INVALID";
var SEQUENCING_REQUEST_START="START";
var SEQUENCING_REQUEST_RESUME_ALL="RESUME ALL";
var SEQUENCING_REQUEST_CONTINUE="CONTINUE";
var SEQUENCING_REQUEST_PREVIOUS="PREVIOUS";
var SEQUENCING_REQUEST_CHOICE="CHOICE";
var SEQUENCING_REQUEST_RETRY="RETRY";
var SEQUENCING_REQUEST_EXIT="EXIT";
var SEQUENCING_REQUEST_NOT_VALID="INVALID";
var RULE_SET_POST_CONDITION="POST_CONDITION";
var RULE_SET_EXIT="EXIT";
var RULE_SET_HIDE_FROM_CHOICE="HIDE_FROM_CHOICE";
var RULE_SET_STOP_FORWARD_TRAVERSAL="STOP_FORWARD_TRAVERSAL";
var RULE_SET_DISABLED="DISABLED";
var RULE_SET_SKIPPED="SKIPPED";
var RULE_SET_SATISFIED="SATISFIED";
var RULE_SET_NOT_SATISFIED="NOT_SATISFIED";
var RULE_SET_COMPLETED="COMPLETED";
var RULE_SET_INCOMPLETE="INCOMPLETE";
var SEQUENCING_RULE_ACTION_SKIP="Skip";
var SEQUENCING_RULE_ACTION_DISABLED="Disabled";
var SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE="Hidden From Choice";
var SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL="Stop Forward Traversal";
var SEQUENCING_RULE_ACTION_EXIT="Exit";
var SEQUENCING_RULE_ACTION_EXIT_PARENT="Exit Parent";
var SEQUENCING_RULE_ACTION_EXIT_ALL="Exit All";
var SEQUENCING_RULE_ACTION_RETRY="Retry";
var SEQUENCING_RULE_ACTION_RETRY_ALL="Retry All";
var SEQUENCING_RULE_ACTION_CONTINUE="Continue";
var SEQUENCING_RULE_ACTION_PREVIOUS="Previous";
var FLOW_DIRECTION_FORWARD="FORWARD";
var FLOW_DIRECTION_BACKWARD="BACKWARD";
var RULE_CONDITION_OPERATOR_NOT="Not";
var RULE_CONDITION_COMBINATION_ALL="All";
var RULE_CONDITION_COMBINATION_ANY="Any";
var RESULT_UNKNOWN="unknown";
var SEQUENCING_RULE_CONDITION_SATISFIED="Satisfied";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN="Objective Status Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN="Objective Measure Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN="Objective Measure Greater Than";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN="Objective Measure Less Than";
var SEQUENCING_RULE_CONDITION_COMPLETED="Completed";
var SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN="Activity Progress Known";
var SEQUENCING_RULE_CONDITION_ATTEMPTED="Attempted";
var SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED="Attempt Limit Exceeded";
var SEQUENCING_RULE_CONDITION_ALWAYS="Always";
var ROLLUP_RULE_ACTION_SATISFIED="Satisfied";
var ROLLUP_RULE_ACTION_NOT_SATISFIED="Not Satisfied";
var ROLLUP_RULE_ACTION_COMPLETED="Completed";
var ROLLUP_RULE_ACTION_INCOMPLETE="Incomplete";
var CHILD_ACTIVITY_SET_ALL="All";
var CHILD_ACTIVITY_SET_ANY="Any";
var CHILD_ACTIVITY_SET_NONE="None";
var CHILD_ACTIVITY_SET_AT_LEAST_COUNT="At Least Count";
var CHILD_ACTIVITY_SET_AT_LEAST_PERCENT="At Least Percent";
var ROLLUP_RULE_CONDITION_SATISFIED="Satisfied";
var ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN="Objective Status Known";
var ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN="Objective Measure Known";
var ROLLUP_RULE_CONDITION_COMPLETED="Completed";
var ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN="Activity Progress Known";
var ROLLUP_RULE_CONDITION_ATTEMPTED="Attempted";
var ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED="Attempt Limit Exceeded";
var ROLLUP_RULE_CONDITION_NEVER="Never";
var ROLLUP_CONSIDERATION_ALWAYS="Always";
var ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED="If Not Suspended";
var ROLLUP_CONSIDERATION_IF_ATTEMPTED="If Attempted";
var ROLLUP_CONSIDERATION_IF_NOT_SKIPPED="If Not Skipped";
var TIMING_NEVER="Never";
var TIMING_ONCE="Once";
var TIMING_ON_EACH_NEW_ATTEMPT="On Each New Attempt";
function Sequencer(_df,_e0){
this.LookAhead=_df;
this.Activities=_e0;
this.NavigationRequest=null;
this.ChoiceTargetIdentifier=null;
this.SuspendedActivity=null;
this.CurrentActivity=null;
this.Exception=null;
this.ExceptionText=null;
this.GlobalObjectives=new Array();
this.ReturnToLmsInvoked=false;
}
Sequencer.prototype.OverallSequencingProcess=Sequencer_OverallSequencingProcess;
Sequencer.prototype.SetSuspendedActivity=Sequencer_SetSuspendedActivity;
Sequencer.prototype.GetSuspendedActivity=Sequencer_GetSuspendedActivity;
Sequencer.prototype.Start=Sequencer_Start;
Sequencer.prototype.InitialRandomizationAndSelection=Sequencer_InitialRandomizationAndSelection;
Sequencer.prototype.GetCurrentActivity=Sequencer_GetCurrentActivity;
Sequencer.prototype.GetExceptionText=Sequencer_GetExceptionText;
Sequencer.prototype.GetExitAction=Sequencer_GetExitAction;
Sequencer.prototype.EvaluatePossibleNavigationRequests=Sequencer_EvaluatePossibleNavigationRequests;
Sequencer.prototype.InitializePossibleNavigationRequestAbsolutes=Sequencer_InitializePossibleNavigationRequestAbsolutes;
Sequencer.prototype.SetAllDescendentsToDisabled=Sequencer_SetAllDescendentsToDisabled;
Sequencer.prototype.ContentDeliveryEnvironmentActivityDataSubProcess=Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess;
function Sequencer_SetSuspendedActivity(_e1){
this.SuspendedActivity=_e1;
}
function Sequencer_GetSuspendedActivity(_e2){
var _e3=this.SuspendedActivity;
if(_e2!==null&&_e2!==undefined){
this.LogSeq("`1567`"+_e3,_e2);
}
return _e3;
}
function Sequencer_Start(){
if(this.SuspendedActivity===null){
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_START,null,"");
}else{
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_RESUME_ALL,null,"");
}
this.OverallSequencingProcess();
}
function Sequencer_InitialRandomizationAndSelection(){
var _e4=this.LogSeqAudit("`1313`");
if(this.SuspendedActivity===null){
for(var _e5 in this.Activities.ActivityList){
this.SelectChildrenProcess(this.Activities.ActivityList[_e5],_e4);
this.RandomizeChildrenProcess(this.Activities.ActivityList[_e5],false,_e4);
}
}
}
function Sequencer_GetCurrentActivity(){
return this.CurrentActivity;
}
function Sequencer_GetExceptionText(){
if(this.ExceptionText!==null&&this.ExceptionText!==undefined){
return this.ExceptionText;
}else{
return "";
}
}
function Sequencer_GetExitAction(_e6,_e7){
return EXIT_ACTION_DISPLAY_MESSAGE;
}
Sequencer.prototype.NavigationRequestProcess=Sequencer_NavigationRequestProcess;
Sequencer.prototype.SequencingExitActionRulesSubprocess=Sequencer_SequencingExitActionRulesSubprocess;
Sequencer.prototype.SequencingPostConditionRulesSubprocess=Sequencer_SequencingPostConditionRulesSubprocess;
Sequencer.prototype.TerminationRequestProcess=Sequencer_TerminationRequestProcess;
Sequencer.prototype.MeasureRollupProcess=Sequencer_MeasureRollupProcess;
Sequencer.prototype.ObjectiveRollupProcess=Sequencer_ObjectiveRollupProcess;
Sequencer.prototype.ObjectiveRollupUsingDefaultProcess=Sequencer_ObjectiveRollupUsingDefaultProcess;
Sequencer.prototype.ObjectiveRollupUsingMeasureProcess=Sequencer_ObjectiveRollupUsingMeasureProcess;
Sequencer.prototype.ObjectiveRollupUsingRulesProcess=Sequencer_ObjectiveRollupUsingRulesProcess;
Sequencer.prototype.ActivityProgressRollupProcess=Sequencer_ActivityProgressRollupProcess;
Sequencer.prototype.ActivityProgressRollupProcessUsingDefault=Sequencer_ActivityProgressRollupProcessUsingDefault;
Sequencer.prototype.RollupRuleCheckSubprocess=Sequencer_RollupRuleCheckSubprocess;
Sequencer.prototype.EvaluateRollupConditionsSubprocess=Sequencer_EvaluateRollupConditionsSubprocess;
Sequencer.prototype.CheckChildForRollupSubprocess=Sequencer_CheckChildForRollupSubprocess;
Sequencer.prototype.OverallRollupProcess=Sequencer_OverallRollupProcess;
Sequencer.prototype.SelectChildrenProcess=Sequencer_SelectChildrenProcess;
Sequencer.prototype.RandomizeChildrenProcess=Sequencer_RandomizeChildrenProcess;
Sequencer.prototype.FlowTreeTraversalSubprocess=Sequencer_FlowTreeTraversalSubprocess;
Sequencer.prototype.FlowActivityTraversalSubprocess=Sequencer_FlowActivityTraversalSubprocess;
Sequencer.prototype.FlowSubprocess=Sequencer_FlowSubprocess;
Sequencer.prototype.ChoiceActivityTraversalSubprocess=Sequencer_ChoiceActivityTraversalSubprocess;
Sequencer.prototype.StartSequencingRequestProcess=Sequencer_StartSequencingRequestProcess;
Sequencer.prototype.ResumeAllSequencingRequestProcess=Sequencer_ResumeAllSequencingRequestProcess;
Sequencer.prototype.ContinueSequencingRequestProcess=Sequencer_ContinueSequencingRequestProcess;
Sequencer.prototype.PreviousSequencingRequestProcess=Sequencer_PreviousSequencingRequestProcess;
Sequencer.prototype.ChoiceSequencingRequestProcess=Sequencer_ChoiceSequencingRequestProcess;
Sequencer.prototype.ChoiceFlowSubprocess=Sequencer_ChoiceFlowSubprocess;
Sequencer.prototype.ChoiceFlowTreeTraversalSubprocess=Sequencer_ChoiceFlowTreeTraversalSubprocess;
Sequencer.prototype.RetrySequencingRequestProcess=Sequencer_RetrySequencingRequestProcess;
Sequencer.prototype.ExitSequencingRequestProcess=Sequencer_ExitSequencingRequestProcess;
Sequencer.prototype.SequencingRequestProcess=Sequencer_SequencingRequestProcess;
Sequencer.prototype.DeliveryRequestProcess=Sequencer_DeliveryRequestProcess;
Sequencer.prototype.ContentDeliveryEnvironmentProcess=Sequencer_ContentDeliveryEnvironmentProcess;
Sequencer.prototype.ClearSuspendedActivitySubprocess=Sequencer_ClearSuspendedActivitySubprocess;
Sequencer.prototype.LimitConditionsCheckProcess=Sequencer_LimitConditionsCheckProcess;
Sequencer.prototype.SequencingRulesCheckProcess=Sequencer_SequencingRulesCheckProcess;
Sequencer.prototype.SequencingRulesCheckSubprocess=Sequencer_SequencingRulesCheckSubprocess;
Sequencer.prototype.TerminateDescendentAttemptsProcess=Sequencer_TerminateDescendentAttemptsProcess;
Sequencer.prototype.EndAttemptProcess=Sequencer_EndAttemptProcess;
Sequencer.prototype.CheckActivityProcess=Sequencer_CheckActivityProcess;
Sequencer.prototype.EvaluateSequencingRuleCondition=Sequencer_EvaluateSequencingRuleCondition;
Sequencer.prototype.ResetException=Sequencer_ResetException;
Sequencer.prototype.LogSeq=Sequencer_LogSeq;
Sequencer.prototype.LogSeqAudit=Sequencer_LogSeqAudit;
Sequencer.prototype.LogSeqReturn=Sequencer_LogSeqReturn;
Sequencer.prototype.WriteHistoryLog=Sequencer_WriteHistoryLog;
Sequencer.prototype.WriteHistoryReturnValue=Sequencer_WriteHistoryReturnValue;
Sequencer.prototype.SetCurrentActivity=Sequencer_SetCurrentActivity;
Sequencer.prototype.IsCurrentActivityDefined=Sequencer_IsCurrentActivityDefined;
Sequencer.prototype.IsSuspendedActivityDefined=Sequencer_IsSuspendedActivityDefined;
Sequencer.prototype.ClearSuspendedActivity=Sequencer_ClearSuspendedActivity;
Sequencer.prototype.GetRootActivity=Sequencer_GetRootActivity;
Sequencer.prototype.DoesActivityExist=Sequencer_DoesActivityExist;
Sequencer.prototype.GetActivityFromIdentifier=Sequencer_GetActivityFromIdentifier;
Sequencer.prototype.AreActivitiesSiblings=Sequencer_AreActivitiesSiblings;
Sequencer.prototype.FindCommonAncestor=Sequencer_FindCommonAncestor;
Sequencer.prototype.GetActivityPath=Sequencer_GetActivityPath;
Sequencer.prototype.GetPathToAncestorExclusive=Sequencer_GetPathToAncestorExclusive;
Sequencer.prototype.GetPathToAncestorInclusive=Sequencer_GetPathToAncestorInclusive;
Sequencer.prototype.ActivityHasSuspendedChildren=Sequencer_ActivityHasSuspendedChildren;
Sequencer.prototype.CourseIsSingleSco=Sequencer_CourseIsSingleSco;
Sequencer.prototype.TranslateSequencingRuleActionIntoSequencingRequest=Sequencer_TranslateSequencingRuleActionIntoSequencingRequest;
Sequencer.prototype.TranslateSequencingRuleActionIntoTerminationRequest=Sequencer_TranslateSequencingRuleActionIntoTerminationRequest;
Sequencer.prototype.IsActivity1BeforeActivity2=Sequencer_IsActivity1BeforeActivity2;
Sequencer.prototype.GetOrderedListOfActivities=Sequencer_GetOrderedListOfActivities;
Sequencer.prototype.PreOrderTraversal=Sequencer_PreOrderTraversal;
Sequencer.prototype.IsActivityLastOverall=Sequencer_IsActivityLastOverall;
Sequencer.prototype.GetGlobalObjectiveByIdentifier=Sequencer_GetGlobalObjectiveByIdentifier;
Sequencer.prototype.AddGlobalObjective=Sequencer_AddGlobalObjective;
Sequencer.prototype.FindActivitiesAffectedByWriteMaps=Sequencer_FindActivitiesAffectedByWriteMaps;
Sequencer.prototype.FindDistinctParentsOfActivitySet=Sequencer_FindDistinctParentsOfActivitySet;
Sequencer.prototype.GetMinimalSubsetOfActivitiesToRollup=Sequencer_GetMinimalSubsetOfActivitiesToRollup;
Sequencer.prototype.CheckForRelevantSequencingRules=Sequencer_CheckForRelevantSequencingRules;
Sequencer.prototype.DoesThisActivityHaveSequencingRulesRelevantToChoice=Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice;
function Sequencer_ResetException(){
this.Exception=null;
this.ExceptionText=null;
}
function Sequencer_LogSeq(str,_e9){
str=str+"";
if(this.LookAhead===true){
return Debug.WriteLookAheadDetailed(str,_e9);
}else{
return Debug.WriteSequencingDetailed(str,_e9);
}
}
function Sequencer_LogSeqAudit(str,_eb){
str=str+"";
if(this.LookAhead===true){
return Debug.WriteLookAheadAudit(str,_eb);
}else{
return Debug.WriteSequencingAudit(str,_eb);
}
}
function Sequencer_LogSeqReturn(str,_ed){
if(_ed===null||_ed===undefined){
Debug.AssertError("`1553`");
}
str=str+"";
if(this.LookAhead===true){
return _ed.setReturn(str);
}else{
return _ed.setReturn(str);
}
}
function Sequencer_WriteHistoryLog(str,_ef){
HistoryLog.WriteEventDetailed(str,_ef);
}
function Sequencer_WriteHistoryReturnValue(str,_f1){
HistoryLog.WriteEventDetailedReturnValue(str,_f1);
}
function Sequencer_SetCurrentActivity(_f2,_f3){
Debug.AssertError("Parent log not passed.",(_f3===undefined||_f3===null));
this.LogSeq("`1446`"+_f2,_f3);
this.CurrentActivity=_f2;
}
function Sequencer_IsCurrentActivityDefined(_f4){
Debug.AssertError("Parent log not passed.",(_f4===undefined||_f4===null));
var _f5=this.GetCurrentActivity();
var _f6=(_f5!==null);
if(_f6){
this.LogSeq("`1460`",_f4);
}else{
this.LogSeq("`1378`",_f4);
}
return _f6;
}
function Sequencer_IsSuspendedActivityDefined(_f7){
Debug.AssertError("Parent log not passed.",(_f7===undefined||_f7===null));
var _f8=this.GetSuspendedActivity(_f7);
var _f9=(_f8!==null);
if(_f9){
this.LogSeq("`1426`",_f7);
}else{
this.LogSeq("`1355`",_f7);
}
return _f9;
}
function Sequencer_ClearSuspendedActivity(_fa){
Debug.AssertError("Parent log not passed.",(_fa===undefined||_fa===null));
this.LogSeq("`1454`",_fa);
this.SuspendedActivity=null;
}
function Sequencer_GetRootActivity(_fb){
Debug.AssertError("Parent log not passed.",(_fb===undefined||_fb===null));
var _fc=this.Activities.GetRootActivity();
this.LogSeq("`1661`"+_fc,_fb);
return _fc;
}
function Sequencer_DoesActivityExist(_fd,_fe){
Debug.AssertError("Parent log not passed.",(_fe===undefined||_fe===null));
var _ff=this.Activities.DoesActivityExist(_fd,_fe);
if(_ff){
this.LogSeq("`1689`"+_fd+"`1389`",_fe);
}else{
this.LogSeq("`1689`"+_fd+"`1255`",_fe);
}
return _ff;
}
function Sequencer_GetActivityFromIdentifier(_100,_101){
Debug.AssertError("Parent log not passed.",(_101===undefined||_101===null));
var _102=this.Activities.GetActivityFromIdentifier(_100,_101);
if(_102!==null){
this.LogSeq("`1689`"+_100+"`1475`"+_102,_101);
}else{
this.LogSeq("`1689`"+_100+"`1223`",_101);
}
return _102;
}
function Sequencer_AreActivitiesSiblings(_103,_104,_105){
Debug.AssertError("Parent log not passed.",(_105===undefined||_105===null));
if(_103===null||_103===undefined||_104===null||_104===undefined){
return false;
}
var _106=_103.ParentActivity;
var _107=_104.ParentActivity;
var _108=(_106==_107);
if(_108){
this.LogSeq("`1700`"+_103+"`1744`"+_104+"`1710`",_105);
}else{
this.LogSeq("`1700`"+_103+"`1744`"+_104+"`1633`",_105);
}
return _108;
}
function Sequencer_FindCommonAncestor(_109,_10a,_10b){
Debug.AssertError("Parent log not passed.",(_10b===undefined||_10b===null));
var _10c=new Array();
var _10d=new Array();
if(_109!==null&&_109.IsTheRoot()){
this.LogSeq(_109+"`940`"+_109+"`1744`"+_10a+"`1746`"+_109,_10b);
return _109;
}
if(_10a!==null&&_10a.IsTheRoot()){
this.LogSeq(_10a+"`940`"+_109+"`1744`"+_10a+"`1746`"+_10a,_10b);
return _10a;
}
if(_109!==null){
_10c=this.Activities.GetActivityPath(_109,false);
}
if(_10a!==null){
_10d=this.Activities.GetActivityPath(_10a,false);
}
for(var i=0;i<_10c.length;i++){
for(var j=0;j<_10d.length;j++){
if(_10c[i]==_10d[j]){
this.LogSeq("`1338`"+_109+"`1744`"+_10a+"`1746`"+_10c[i],_10b);
return _10c[i];
}
}
}
this.LogSeq("`1725`"+_109+"`1744`"+_10a+"`1388`",_10b);
return null;
}
function Sequencer_GetActivityPath(_110,_111){
return this.Activities.GetActivityPath(_110,_111);
}
function Sequencer_GetPathToAncestorExclusive(_112,_113,_114){
var _115=new Array();
var _116=0;
if(_112!==null&&_113!==null&&_112!==_113){
if(_114===true){
_115[_116]=_112;
_116++;
}
while(_112.ParentActivity!==null&&_112.ParentActivity!==_113){
_112=_112.ParentActivity;
_115[_116]=_112;
_116++;
}
}
return _115;
}
function Sequencer_GetPathToAncestorInclusive(_117,_118){
var _119=new Array();
var _11a=0;
_119[_11a]=_117;
_11a++;
while(_117.ParentActivity!==null&&_117!=_118){
_117=_117.ParentActivity;
_119[_11a]=_117;
_11a++;
}
return _119;
}
function Sequencer_ActivityHasSuspendedChildren(_11b,_11c){
Debug.AssertError("Parent log not passed.",(_11c===undefined||_11c===null));
var _11d=_11b.GetChildren();
var _11e=false;
for(var i=0;i<_11d.length;i++){
if(_11d[i].IsSuspended()){
_11e=true;
}
}
if(_11e){
this.LogSeq("`1718`"+_11b+"`1511`",_11c);
}else{
this.LogSeq("`1718`"+_11b+"`1319`",_11c);
}
return _11e;
}
function Sequencer_CourseIsSingleSco(){
if(this.Activities.ActivityList.length<=2){
return true;
}else{
return false;
}
}
function Sequencer_TranslateSequencingRuleActionIntoSequencingRequest(_120){
switch(_120){
case SEQUENCING_RULE_ACTION_RETRY:
return SEQUENCING_REQUEST_RETRY;
case SEQUENCING_RULE_ACTION_CONTINUE:
return SEQUENCING_REQUEST_CONTINUE;
case SEQUENCING_RULE_ACTION_PREVIOUS:
return SEQUENCING_REQUEST_PREVIOUS;
default:
Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoSequencingRequest - should never have an untranslatable sequencing request. ruleAction="+_120);
return null;
}
}
function Sequencer_TranslateSequencingRuleActionIntoTerminationRequest(_121){
switch(_121){
case SEQUENCING_RULE_ACTION_EXIT_PARENT:
return TERMINATION_REQUEST_EXIT_PARENT;
case SEQUENCING_RULE_ACTION_EXIT_ALL:
return TERMINATION_REQUEST_EXIT_ALL;
default:
Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoTerminationRequest - should never have an untranslatable sequencing request. ruleAction="+_121);
return null;
}
}
function Sequencer_IsActivity1BeforeActivity2(_122,_123,_124){
Debug.AssertError("Parent log not passed.",(_124===undefined||_124===null));
var _125=this.GetOrderedListOfActivities(_124);
for(var i=0;i<_125.length;i++){
if(_125[i]==_122){
this.LogSeq("`1718`"+_122+"`1512`"+_123,_124);
return true;
}
if(_125[i]==_123){
this.LogSeq("`1718`"+_122+"`1534`"+_123,_124);
return false;
}
}
Debug.AssertError("ERROR IN Sequencer_IsActivity1BeforeActivity2");
return null;
}
function Sequencer_GetOrderedListOfActivities(_127){
Debug.AssertError("Parent log not passed.",(_127===undefined||_127===null));
var list;
var root=this.GetRootActivity(_127);
list=this.PreOrderTraversal(root);
return list;
}
function Sequencer_PreOrderTraversal(_12a){
var list=new Array();
list[0]=_12a;
var _12c=_12a.GetAvailableChildren();
var _12d;
for(var i=0;i<_12c.length;i++){
_12d=this.PreOrderTraversal(_12c[i]);
list=list.concat(_12d);
}
return list;
}
function Sequencer_IsActivityLastOverall(_12f,_130){
Debug.AssertError("Parent log not passed.",(_130===undefined||_130===null));
var _131=this.GetOrderedListOfActivities(_130);
if(_12f==_131[_131.length-1]){
this.LogSeq("`1718`"+_12f+"`1409`",_130);
return true;
}
this.LogSeq("`1718`"+_12f+"`1345`",_130);
return false;
}
function Sequencer_GetGlobalObjectiveByIdentifier(_132){
for(var obj in this.GlobalObjectives){
if(this.GlobalObjectives[obj].ID==_132){
return this.GlobalObjectives[obj];
}
}
return null;
}
function Sequencer_AddGlobalObjective(ID,_135,_136,_137,_138){
var _139=this.GlobalObjectives.length;
var obj=new GlobalObjective(_139,ID,_135,_136,_137,_138);
this.GlobalObjectives[_139]=obj;
this.GlobalObjectives[_139].SetDirtyData();
}
function Sequencer_FindActivitiesAffectedByWriteMaps(_13b){
var _13c=new Array();
var _13d;
var _13e=_13b.GetObjectives();
var _13f=new Array();
var i;
var j;
for(i=0;i<_13e.length;i++){
_13d=_13e[i].GetMaps();
for(j=0;j<_13d.length;j++){
if(_13d[j].WriteSatisfiedStatus===true||_13d[j].WriteNormalizedMeasure===true){
_13c[_13c.length]=_13d[j].TargetObjectiveId;
}
}
}
if(_13c.length===0){
return _13f;
}
var _142;
var _143;
var _144;
var _145;
for(var _146 in this.Activities.ActivityList){
_142=this.Activities.ActivityList[_146];
if(_142!=_13b){
_143=_142.GetObjectives();
for(var _147=0;_147<_143.length;_147++){
_144=_143[_147].GetMaps();
for(var map=0;map<_144.length;map++){
if(_144[map].ReadSatisfiedStatus===true||_144[map].ReadNormalizedMeasure===true){
_145=_144[map].TargetObjectiveId;
for(var _149=0;_149<_13c.length;_149++){
if(_13c[_149]==_145){
_13f[_13f.length]=_142;
}
}
}
}
}
}
}
return _13f;
}
function Sequencer_FindDistinctParentsOfActivitySet(_14a){
var _14b=new Array();
var _14c;
var _14d;
for(var _14e in _14a){
_14d=true;
_14c=this.Activities.GetParentActivity(_14a[_14e]);
if(_14c!==null){
for(var i=0;i<_14b.length;i++){
if(_14b[i]==_14c){
_14d=false;
break;
}
}
if(_14d){
_14b[_14b.length]=_14c;
}
}
}
return _14b;
}
function Sequencer_GetMinimalSubsetOfActivitiesToRollup(_150,_151){
var _152=new Array();
var _153=new Array();
var _154;
var _155;
var _156;
if(_151!==null){
_152=_152.concat(_151);
}
for(var _157 in _150){
_155=_150[_157];
_156=false;
for(var _158 in _152){
if(_152[_158]==_155){
_156=true;
break;
}
}
if(_156===false){
_153[_153.length]=_155;
_154=this.GetActivityPath(_155,true);
_152=_152.concat(_154);
}
}
return _153;
}
function Sequencer_EvaluatePossibleNavigationRequests(_159){
var _15a=this.LogSeqAudit("`985`");
var _15b;
var _15c=null;
var _15d;
var _15e;
var id;
for(id in _159){
if(_159[id].WillAlwaysSucceed===true){
_159[id].WillSucceed=true;
}else{
if(_159[id].WillNeverSucceed===true){
_159[id].WillSucceed=false;
_159[id].Exception="NB.2.1-10";
_159[id].ExceptionText=IntegrationImplementation.GetString("Your selection is not permitted. Please select 'Next' or 'Previous' to move through '{0}.'");
}else{
_159[id].WillSucceed=null;
}
}
_159[id].Hidden=false;
_159[id].Disabled=false;
}
this.LogSeq("`788`",_15a);
for(id in _159){
if(_159[id].WillSucceed===null){
_15b=this.NavigationRequestProcess(_159[id].NavigationRequest,_159[id].TargetActivityItemIdentifier,_15a);
if(_15b.NavigationRequest==NAVIGATION_REQUEST_NOT_VALID){
this.LogSeq("`755`",_15a);
_159[id].WillSucceed=false;
_159[id].TargetActivity=this.GetActivityFromIdentifier(_159[id].TargetActivityItemIdentifier,_15a);
_159[id].Exception=_15b.Exception;
_159[id].ExceptionText=_15b.ExceptionText;
}else{
this.LogSeq("`723`",_15a);
_159[id].WillSucceed=true;
_159[id].TargetActivity=_15b.TargetActivity;
_159[id].SequencingRequest=_15b.SequencingRequest;
_159[id].Exception="";
_159[id].ExceptionText="";
}
}
}
this.LogSeq("`215`",_15a);
var _160=this.GetCurrentActivity();
if(_160!==null&&_160.IsActive()===true){
this.LogSeq("`955`",_15a);
_15c=this.TerminationRequestProcess(TERMINATION_REQUEST_EXIT,_15a);
this.LogSeq("`912`",_15a);
if(_15c.TerminationRequest==TERMINATION_REQUEST_NOT_VALID){
this.LogSeq("`717`",_15a);
if(_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed){
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed=false;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception=_15c.Exception;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText=_15c.ExceptionText;
}
if(_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed){
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed=false;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].Exception=_15c.Exception;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].ExceptionText=_15c.ExceptionText;
}
if(_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed){
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed=false;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].Exception=_15c.Exception;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].ExceptionText=_15c.ExceptionText;
}
for(id=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;id<_159.length;id++){
if(_159[id].WillSucceed){
_159[id].WillSucceed=false;
_159[id].Exception=_15c.Exception;
_159[id].ExceptionText=terminatonRequestResult.ExceptionText;
}else{
_159[id].TerminationSequencingRequest=_15c.SequencingRequest;
}
}
}
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].TerminationSequencingRequest=_15c.SequencingRequest;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].TerminationSequencingRequest=_15c.SequencingRequest;
_159[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].TerminationSequencingRequest=_15c.SequencingRequest;
for(id=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;id<_159.length;id++){
_159[id].TerminationSequencingRequest=_15c.SequencingRequest;
}
}
this.LogSeq("`659`",_15a);
for(id in _159){
if(id>=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE&&_159[id].WillSucceed===true&&_159[id].WillAlwaysSucceed===false&&_159[id].WillNeverSucceed===false){
this.LogSeq("`866`",_15a);
var _161=this.CheckActivityProcess(_159[id].TargetActivity,_15a);
if(_161===true){
this.LogSeq("`745`",_15a);
_159[id].WillSucceed=false;
_159[id].Disabled=true;
this.SetAllDescendentsToDisabled(_159,_159[id].TargetActivity);
}
}
}
this.LogSeq("`677`",_15a);
var _162=null;
for(id in _159){
if(_159[id].WillAlwaysSucceed===false&&_159[id].WillNeverSucceed===false){
this.LogSeq("`624`",_15a);
if(_159[id].TerminationSequencingRequest!==null){
this.LogSeq("`418`",_15a);
if(_162===null){
_15d=this.SequencingRequestProcess(_159[id].TerminationSequencingRequest,null,_15a);
}else{
_15d=_162;
}
if(id>=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE){
this.LogSeq("`1036`",_15a);
var _163=this.SequencingRulesCheckProcess(_159[id].TargetActivity,RULE_SET_HIDE_FROM_CHOICE,_15a);
if(_163!==null){
_159[id].Exception="SB.2.9-3";
_159[id].ExceptionText="The activity "+_159[id].TargetActivity.GetTitle()+" should be hidden and is not a valid selection";
_159[id].Hidden=true;
}
}
}else{
this.LogSeq("`1639`",_15a);
this.LogSeq("`718`",_15a);
_15d=this.SequencingRequestProcess(_159[id].SequencingRequest,_159[id].TargetActivity,_15a);
}
this.LogSeq("`837`",_15a);
if(_15d.Exception!==null){
this.LogSeq("`1288`",_15a);
_159[id].WillSucceed=false;
_159[id].Exception=_15d.Exception;
_159[id].ExceptionText=_15d.ExceptionText;
_159[id].Hidden=_15d.Hidden;
}else{
if(_159[id].WillSucceed===true&&_15d.DeliveryRequest!==null){
this.LogSeq("`1117`",_15a);
_15e=this.DeliveryRequestProcess(_15d.DeliveryRequest,_15a);
this.LogSeq("`705`"+_15e.Valid+")",_15a);
_159[id].WillSucceed=_15e.Valid;
}
}
}
}
this.LogSeqReturn("",_15a);
return _159;
}
function Sequencer_SetAllDescendentsToDisabled(_164,_165){
for(var i=0;i<_165.ChildActivities.length;i++){
var _167=Control.FindPossibleChoiceRequestForActivity(_165.ChildActivities[i]);
_167.WillSucceed=false;
_167.Disabled=true;
this.SetAllDescendentsToDisabled(_164,_165.ChildActivities[i]);
}
}
function Sequencer_InitializePossibleNavigationRequestAbsolutes(_168,_169,_16a){
var _16b=(Control.Package.Properties.LookaheadSequencerMode===LOOKAHEAD_SEQUENCER_MODE_DISABLE);
this.CheckForRelevantSequencingRules(_169,false);
var _16c;
var _16d;
for(var _16e in _16a){
_16c=_16a[_16e];
if(_16c.GetSequencingControlChoice()===false){
for(var i=0;i<_16c.ChildActivities.length;i++){
_16d=Control.FindPossibleChoiceRequestForActivity(_16c.ChildActivities[i]);
_16d.WillNeverSucceed=true;
}
}
_16d=Control.FindPossibleChoiceRequestForActivity(_16c);
if(_16c.IsDeliverable()===false&&_16c.GetSequencingControlFlow()===false){
_16d.WillNeverSucceed=true;
}
if(_16c.HasChildActivitiesDeliverableViaFlow===false){
_16d.WillNeverSucceed=true;
}
if(_16c.HasSeqRulesRelevantToChoice===false&&_16d.WillNeverSucceed===false){
_16d.WillAlwaysSucceed=true;
}else{
_16d.WillAlwaysSucceed=false;
}
}
}
function Sequencer_CheckForRelevantSequencingRules(_170,_171){
if(_171===true){
_170.HasSeqRulesRelevantToChoice=true;
}else{
if(this.DoesThisActivityHaveSequencingRulesRelevantToChoice(_170)){
_170.HasSeqRulesRelevantToChoice=true;
}else{
_170.HasSeqRulesRelevantToChoice=false;
}
}
var _172=false;
for(var i=0;i<_170.ChildActivities.length;i++){
this.CheckForRelevantSequencingRules(_170.ChildActivities[i],_170.HasSeqRulesRelevantToChoice);
_172=(_172||_170.ChildActivities[i].HasChildActivitiesDeliverableViaFlow);
}
_170.HasChildActivitiesDeliverableViaFlow=(_170.IsDeliverable()||(_170.GetSequencingControlFlow()&&_172));
}
function Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice(_174){
if(_174.GetSequencingControlForwardOnly()===true){
return true;
}
if(_174.GetPreventActivation()===true){
return true;
}
if(_174.GetConstrainedChoice()===true){
return true;
}
if(_174.GetSequencingControlChoiceExit()===false){
return true;
}
var _175=_174.GetPreConditionRules();
for(var i=0;i<_175.length;i++){
if(_175[i].Action==SEQUENCING_RULE_ACTION_DISABLED||_175[i].Action==SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE||_175[i].Action==SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL){
return true;
}
}
return false;
}
function Sequencer_ActivityProgressRollupProcess(_177,_178){
Debug.AssertError("Calling log not passed.",(_178===undefined||_178===null));
var _179=this.LogSeqAudit("`1170`"+_177+")",_178);
var _17a;
this.LogSeq("`336`",_179);
_17a=this.RollupRuleCheckSubprocess(_177,RULE_SET_INCOMPLETE,_179);
this.LogSeq("`849`",_179);
if(_17a===true){
this.LogSeq("`806`",_179);
_177.SetAttemptProgressStatus(true);
this.LogSeq("`770`",_179);
_177.SetAttemptCompletionStatus(false);
}
this.LogSeq("`350`",_179);
_17a=this.RollupRuleCheckSubprocess(_177,RULE_SET_COMPLETED,_179);
this.LogSeq("`851`",_179);
if(_17a===true){
this.LogSeq("`807`",_179);
_177.SetAttemptProgressStatus(true);
this.LogSeq("`780`",_179);
_177.SetAttemptCompletionStatus(true);
}
if(Sequencer_GetApplicableSetofRollupRules(_177,RULE_SET_INCOMPLETE).length===0&&Sequencer_GetApplicableSetofRollupRules(_177,RULE_SET_COMPLETED).length===0){
this.LogSeq("`1167`",_179);
this.ActivityProgressRollupProcessUsingDefault(_177,_179);
}
this.LogSeq("`1063`",_179);
this.LogSeqReturn("",_179);
return;
}
function Sequencer_ActivityProgressRollupProcessUsingDefault(_17b,_17c){
var _17d=this.LogSeqAudit("`907`"+_17b+")",_17c);
var _17e;
var _17f;
var _180;
this.LogSeq("`1273`",_17d);
if(_17b.IsALeaf()){
this.LogSeq("`1290`",_17d);
this.LogSeqReturn("",_17d);
return;
}
this.LogSeq("`1087`",_17d);
var _181=_17b.GetChildren();
this.LogSeq("`1100`",_17d);
var _182=true;
this.LogSeq("`1218`",_17d);
var _183=true;
this.LogSeq("`1274`",_17d);
var _184=true;
for(var i=0;i<_181.length;i++){
this.LogSeq("`1357`"+_181[i]+"`1720`",_17d);
if(_181[i].IsTracked()){
this.LogSeq("`1046`",_17d);
_17e=_181[i].IsCompleted();
this.LogSeq("`1047`",_17d);
_17f=_181[i].IsAttempted();
this.LogSeq("`769`",_17d);
_180=(_17e===false||_17f===true);
this.LogSeq("`881`",_17d);
if(this.CheckChildForRollupSubprocess(_181[i],ROLLUP_RULE_ACTION_COMPLETED,_17d)){
this.LogSeq("`882`",_17d);
_183=(_183&&(_17e===true));
_184=false;
}
this.LogSeq("`874`",_17d);
if(this.CheckChildForRollupSubprocess(_181[i],ROLLUP_RULE_ACTION_INCOMPLETE,_17d)){
this.LogSeq("`847`",_17d);
_182=(_182&&_180);
_184=false;
}
}
}
if(_184&&Control.Package.Properties.RollupEmptySetToUnknown){
this.LogSeq("`542`"+Control.Package.Properties.RollupEmptySetToUnknown+")",_17d);
}else{
this.LogSeq("`1406`",_17d);
if(_182===true){
this.LogSeq("`778`",_17d);
_17b.SetAttemptProgressStatus(true);
this.LogSeq("`746`",_17d);
_17b.SetAttemptCompletionStatus(false);
}
this.LogSeq("`1427`",_17d);
if(_183===true){
this.LogSeq("`779`",_17d);
_17b.SetAttemptProgressStatus(true);
this.LogSeq("`758`",_17d);
_17b.SetAttemptCompletionStatus(true);
}
}
this.LogSeqReturn("",_17d);
}
function Sequencer_CheckActivityProcess(_186,_187){
Debug.AssertError("Calling log not passed.",(_187===undefined||_187===null));
var _188=this.LogSeqAudit("`1392`"+_186+")",_187);
this.LogSeq("`313`",_188);
var _189=this.SequencingRulesCheckProcess(_186,RULE_SET_DISABLED,_188);
this.LogSeq("`783`",_188);
if(_189!==null){
this.LogSeq("`721`",_188);
this.LogSeqReturn("`1749`",_188);
return true;
}
this.LogSeq("`396`",_188);
var _18a=this.LimitConditionsCheckProcess(_186,_188);
this.LogSeq("`864`",_188);
if(_18a){
this.LogSeq("`614`",_188);
this.LogSeqReturn("`1749`",_188);
return true;
}
this.LogSeq("`752`",_188);
this.LogSeqReturn("`1745`",_188);
return false;
}
function Sequencer_CheckChildForRollupSubprocess(_18b,_18c,_18d){
Debug.AssertError("Calling log not passed.",(_18d===undefined||_18d===null));
var _18e=this.LogSeqAudit("`1108`"+_18b+", "+_18c+")",_18d);
var _18f;
this.LogSeq("`1342`",_18e);
var _190=false;
this.LogSeq("`814`",_18e);
if(_18c==ROLLUP_RULE_ACTION_SATISFIED||_18c==ROLLUP_RULE_ACTION_NOT_SATISFIED){
this.LogSeq("`406`",_18e);
if(_18b.GetRollupObjectiveSatisfied()===true){
this.LogSeq("`591`",_18e);
_190=true;
var _191=_18b.GetRequiredForSatisfied();
var _192=_18b.GetRequiredForNotSatisfied();
this.LogSeq("`97`",_18e);
if((_18c==ROLLUP_RULE_ACTION_SATISFIED&&_191==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)||(_18c==ROLLUP_RULE_ACTION_NOT_SATISFIED&&_192==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)){
this.LogSeq("`278`",_18e);
if(_18b.GetAttemptCount()>0&&_18b.IsSuspended()===true){
this.LogSeq("`1194`",_18e);
_190=false;
}
}else{
this.LogSeq("`1583`",_18e);
this.LogSeq("`104`",_18e);
if((_18c==ROLLUP_RULE_ACTION_SATISFIED&&_191==ROLLUP_CONSIDERATION_IF_ATTEMPTED)||(_18c==ROLLUP_RULE_ACTION_NOT_SATISFIED&&_192==ROLLUP_CONSIDERATION_IF_ATTEMPTED)){
this.LogSeq("`679`",_18e);
if(_18b.GetAttemptCount()===0){
this.LogSeq("`1137`",_18e);
_190=false;
}
}else{
this.LogSeq("`1551`",_18e);
this.LogSeq("`98`",_18e);
if((_18c==ROLLUP_RULE_ACTION_SATISFIED&&_191==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)||(_18c==ROLLUP_RULE_ACTION_NOT_SATISFIED&&_192==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)){
this.LogSeq("`467`",_18e);
_18f=this.SequencingRulesCheckProcess(_18b,RULE_SET_SKIPPED,_18e);
this.LogSeq("`633`",_18e);
if(_18f!==null){
this.LogSeq("`1102`",_18e);
_190=false;
}
}
}
}
}
}
this.LogSeq("`852`",_18e);
if(_18c==ROLLUP_RULE_ACTION_COMPLETED||_18c==ROLLUP_RULE_ACTION_INCOMPLETE){
this.LogSeq("`419`",_18e);
if(_18b.RollupProgressCompletion()===true){
this.LogSeq("`592`",_18e);
_190=true;
var _193=_18b.GetRequiredForCompleted();
var _194=_18b.GetRequiredForIncomplete();
this.LogSeq("`106`",_18e);
if((_18c==ROLLUP_RULE_ACTION_COMPLETED&&_193==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)||(_18c==ROLLUP_RULE_ACTION_INCOMPLETE&&_194==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)){
this.LogSeq("`279`",_18e);
if(_18b.GetAttemptCount()>0&&_18b.IsSuspended()===true){
this.LogSeq("`1375`",_18e);
_190=false;
}
}else{
this.LogSeq("`1584`",_18e);
this.LogSeq("`117`",_18e);
if((_18c==ROLLUP_RULE_ACTION_COMPLETED&&_193==ROLLUP_CONSIDERATION_IF_ATTEMPTED)||(_18c==ROLLUP_RULE_ACTION_INCOMPLETE&&_194==ROLLUP_CONSIDERATION_IF_ATTEMPTED)){
this.LogSeq("`680`",_18e);
if(_18b.GetAttemptCount()===0){
this.LogSeq("`1138`",_18e);
_190=false;
}
}else{
this.LogSeq("`1552`",_18e);
this.LogSeq("`107`",_18e);
if((_18c==ROLLUP_RULE_ACTION_COMPLETED&&_193==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)||(_18c==ROLLUP_RULE_ACTION_INCOMPLETE&&_194==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)){
this.LogSeq("`468`",_18e);
_18f=this.SequencingRulesCheckProcess(_18b,RULE_SET_SKIPPED,_18e);
this.LogSeq("`634`",_18e);
if(_18f!==null){
this.LogSeq("`1103`",_18e);
_190=false;
}
}
}
}
}
}
this.LogSeq("`602`",_18e);
this.LogSeqReturn(_190,_18e);
return _190;
}
function Sequencer_ChoiceActivityTraversalSubprocess(_195,_196,_197){
Debug.AssertError("Calling log not passed.",(_197===undefined||_197===null));
var _198=this.LogSeqAudit("`1095`"+_195+", "+_196+")",_197);
var _199=null;
var _19a=null;
var _19b;
this.LogSeq("`981`",_198);
if(_196==FLOW_DIRECTION_FORWARD){
this.LogSeq("`445`",_198);
_199=this.SequencingRulesCheckProcess(_195,RULE_SET_STOP_FORWARD_TRAVERSAL,_198);
this.LogSeq("`731`",_198);
if(_199!==null){
this.LogSeq("`558`",_198);
_19b=new Sequencer_ChoiceActivityTraversalSubprocessResult(false,"SB.2.4-1",IntegrationImplementation.GetString("You are not allowed to move into {0} yet.",_195.GetTitle()));
this.LogSeqReturn(_19b,_198);
return _19b;
}
this.LogSeq("`611`",_198);
_19b=new Sequencer_ChoiceActivityTraversalSubprocessResult(true,null);
this.LogSeqReturn(_19b,_198);
return _19b;
}
this.LogSeq("`972`",_198);
if(_196==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`1105`",_198);
if(!_195.IsTheRoot()){
_19a=this.Activities.GetParentActivity(_195);
this.LogSeq("`584`",_198);
if(_19a.GetSequencingControlForwardOnly()){
this.LogSeq("`548`",_198);
_19b=new Sequencer_ChoiceActivityTraversalSubprocessResult(false,"SB.2.4-2",IntegrationImplementation.GetString("You must start {0} at the beginning.",_19a.GetTitle()));
this.LogSeqReturn(_19b,_198);
return _19b;
}
}else{
this.LogSeq("`1626`",_198);
this.LogSeq("`237`",_198);
_19b=new Sequencer_ChoiceActivityTraversalSubprocessResult(false,"SB.2.4-3",IntegrationImplementation.GetString("You have reached the beginning of the course."));
this.LogSeqReturn(_19b,_198);
return _19b;
}
this.LogSeq("`612`",_198);
_19b=new Sequencer_ChoiceActivityTraversalSubprocessResult(true,null);
this.LogSeqReturn(_19b,_198);
return _19b;
}
}
function Sequencer_ChoiceActivityTraversalSubprocessResult(_19c,_19d,_19e){
this.Reachable=_19c;
this.Exception=_19d;
this.ExceptionText=_19e;
}
Sequencer_ChoiceActivityTraversalSubprocessResult.prototype.toString=function(){
return "Reachable="+this.Reachable+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_ChoiceFlowSubprocess(_19f,_1a0,_1a1){
Debug.AssertError("Calling log not passed.",(_1a1===undefined||_1a1===null));
var _1a2=this.LogSeqAudit("`1320`"+_19f+", "+_1a0+")",_1a1);
this.LogSeq("`128`",_1a2);
var _1a3=this.ChoiceFlowTreeTraversalSubprocess(_19f,_1a0,_1a2);
this.LogSeq("`732`",_1a2);
if(_1a3===null){
this.LogSeq("`710`",_1a2);
this.LogSeqReturn(_19f,_1a2);
return _19f;
}else{
this.LogSeq("`1678`",_1a2);
this.LogSeq("`338`",_1a2);
this.LogSeqReturn(_1a3,_1a2);
return _1a3;
}
}
function Sequencer_ChoiceFlowTreeTraversalSubprocess(_1a4,_1a5,_1a6){
Debug.AssertError("Calling log not passed.",(_1a6===undefined||_1a6===null));
var _1a7=this.LogSeqAudit("`1031`"+_1a4+", "+_1a5+")",_1a6);
var _1a8=this.Activities.GetParentActivity(_1a4);
var _1a9=null;
var _1aa=null;
var _1ab=null;
this.LogSeq("`961`",_1a7);
if(_1a5==FLOW_DIRECTION_FORWARD){
this.LogSeq("`257`",_1a7);
if(this.IsActivityLastOverall(_1a4,_1a7)){
this.LogSeq("`683`",_1a7);
this.LogSeqReturn("`1748`",_1a7);
return null;
}
this.LogSeq("`479`",_1a7);
if(_1a8.IsActivityTheLastAvailableChild(_1a4)){
this.LogSeq("`137`",_1a7);
_1a9=this.ChoiceFlowTreeTraversalSubprocess(_1a8,FLOW_DIRECTION_FORWARD,_1a7);
this.LogSeq("`143`",_1a7);
this.LogSeqReturn(_1a9,_1a7);
return _1a9;
}else{
this.LogSeq("`1627`",_1a7);
this.LogSeq("`301`",_1a7);
_1aa=_1a4.GetNextSibling();
this.LogSeq("`446`",_1a7);
this.LogSeqReturn(_1aa,_1a7);
return _1aa;
}
}
this.LogSeq("`952`",_1a7);
if(_1a5==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`456`",_1a7);
if(_1a4.IsTheRoot()){
this.LogSeq("`684`",_1a7);
this.LogSeqReturn("`1748`",_1a7);
return null;
}
this.LogSeq("`472`",_1a7);
if(_1a8.IsActivityTheFirstAvailableChild(_1a4)){
this.LogSeq("`135`",_1a7);
_1a9=this.ChoiceFlowTreeTraversalSubprocess(_1a8,FLOW_DIRECTION_BACKWARD,_1a7);
this.LogSeq("`138`",_1a7);
this.LogSeqReturn(_1a9,_1a7);
return _1a9;
}else{
this.LogSeq("`1628`",_1a7);
this.LogSeq("`268`",_1a7);
_1ab=_1a4.GetPreviousSibling();
this.LogSeq("`447`",_1a7);
this.LogSeqReturn(_1ab,_1a7);
return _1ab;
}
}
}
function Sequencer_ChoiceSequencingRequestProcess(_1ac,_1ad){
Debug.AssertError("Calling log not passed.",(_1ad===undefined||_1ad===null));
var _1ae=this.LogSeqAudit("`1153`"+_1ac+")",_1ad);
var _1af=null;
var _1b0;
var _1b1=null;
var _1b2=null;
var _1b3=null;
var _1b4=null;
var _1b5;
var i;
var _1b7;
this.LogSeq("`502`"+_1ac.LearningObject.ItemIdentifier,_1ae);
if(_1ac===null){
this.LogSeq("`448`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-1",IntegrationImplementation.GetString("Your selection is not permitted.  Please select an available menu item to continue."),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`735`",_1ae);
if(_1ac.IsTheRoot()===false){
_1af=this.Activities.GetParentActivity(_1ac);
this.LogSeq("`217`",_1ae);
if(_1af.IsActivityAnAvailableChild(_1ac)===false){
this.LogSeq("`423`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-2",IntegrationImplementation.GetString("The activity '{0}' is not currently available in {1}.",_1ac,_1af.GetTitle()),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
this.LogSeq("`316`",_1ae);
_1b0=this.GetActivityPath(_1ac,true);
this.LogSeq("`1050`",_1ae);
for(i=(_1b0.length-1);i>=0;i--){
this.LogSeq("`254`",_1ae);
_1b1=this.SequencingRulesCheckProcess(_1b0[i],RULE_SET_HIDE_FROM_CHOICE,_1ae);
this.LogSeq("`737`",_1ae);
if(_1b1!==null){
this.LogSeq("`425`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-3","The activity "+_1ac.GetTitle()+" should be hidden and is not a valid selection",true);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
this.LogSeq("`750`",_1ae);
if(!_1ac.IsTheRoot()){
this.LogSeq("`222`",_1ae);
if(_1af.GetSequencingControlChoice()===false){
this.LogSeq("`426`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-4",IntegrationImplementation.GetString("The activity '{0}' should be hidden and is not a valid selection.",_1af.GetTitle()),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
this.LogSeq("`580`",_1ae);
if(this.IsCurrentActivityDefined(_1ae)){
this.LogSeq("`638`",_1ae);
_1b3=this.GetCurrentActivity();
_1b2=this.FindCommonAncestor(_1b3,_1ac,_1ae);
}else{
this.LogSeq("`1708`",_1ae);
this.LogSeq("`374`",_1ae);
_1b2=this.GetRootActivity(_1ae);
}
if(_1b3!==null&&_1b3.LearningObject.ItemIdentifier==_1ac.LearningObject.ItemIdentifier){
this.LogSeq("`504`",_1ae);
this.LogSeq("`939`",_1ae);
}else{
if(this.AreActivitiesSiblings(_1b3,_1ac,_1ae)){
this.LogSeq("`364`",_1ae);
this.LogSeq("`11`",_1ae);
var _1b8=_1af.GetActivityListBetweenChildren(_1b3,_1ac,false);
this.LogSeq("`831`",_1ae);
if(_1b8.length===0){
this.LogSeq("`428`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to open"),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`450`",_1ae);
if(_1b8[0].LearningObject.ItemIdentifier==_1b3.LearningObject.ItemIdentifier){
this.LogSeq("`1344`",_1ae);
_1b4=FLOW_DIRECTION_FORWARD;
}else{
this.LogSeq("`1680`",_1ae);
this.LogSeq("`1318`",_1ae);
_1b4=FLOW_DIRECTION_BACKWARD;
_1b8.reverse();
}
this.LogSeq("`1007`",_1ae);
for(i=0;i<_1b8.length;i++){
this.LogSeq("`519`",_1ae);
_1b5=this.ChoiceActivityTraversalSubprocess(_1b8[i],_1b4,_1ae);
this.LogSeq("`713`",_1ae);
if(_1b5.Reachable===false){
this.LogSeq("`142`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,_1b5.Exception,"",false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
this.LogSeq("`1451`",_1ae);
}else{
if(_1b3===null||_1b3.LearningObject.ItemIdentifier==_1b2.LearningObject.ItemIdentifier){
this.LogSeq("`210`",_1ae);
this.LogSeq("`242`",_1ae);
_1b0=this.GetPathToAncestorInclusive(_1ac,_1b2);
this.LogSeq("`1066`",_1ae);
if(_1b0.length===0){
this.LogSeq("`410`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to open"),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`990`",_1ae);
for(i=_1b0.length-1;i>=0;i--){
this.LogSeq("`515`",_1ae);
_1b5=this.ChoiceActivityTraversalSubprocess(_1b0[i],FLOW_DIRECTION_FORWARD,_1ae);
this.LogSeq("`702`",_1ae);
if(_1b5.Reachable===false){
this.LogSeq("`139`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,_1b5.Exception,_1b5.ExceptionText,false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`18`",_1ae);
if(_1b0[i].IsActive()===false&&_1b0[i].LearningObject.ItemIdentifier!=_1b2.LearningObject.ItemIdentifier&&_1b0[i].GetPreventActivation()===true){
this.LogSeq("`394`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-6",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1b0[i].GetTitle()),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
this.LogSeq("`1428`",_1ae);
}else{
if(_1ac.LearningObject.ItemIdentifier==_1b2.LearningObject.ItemIdentifier){
this.LogSeq("`288`",_1ae);
this.LogSeq("`346`",_1ae);
_1b0=this.GetPathToAncestorInclusive(_1b3,_1b2);
this.LogSeq("`1067`",_1ae);
if(_1b0.length===0){
this.LogSeq("`411`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to deliver"),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`991`",_1ae);
for(i=0;i<_1b0.length;i++){
this.LogSeq("`663`",_1ae);
if(i!=(_1b0.length-1)){
this.LogSeq("`197`",_1ae);
if(_1b0[i].GetSequencingControlChoiceExit()===false){
this.LogSeq("`377`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-7",IntegrationImplementation.GetString("Your selection is not permitted.  Please select 'Next' or 'Previous' to move through '{0}'.",_1b0[i]),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
}
this.LogSeq("`1429`",_1ae);
}else{
this.LogSeq("`290`",_1ae);
this.LogSeq("`347`",_1ae);
_1b0=this.GetPathToAncestorInclusive(_1b3,_1b2);
this.LogSeq("`1069`",_1ae);
if(_1b0.length===0){
this.LogSeq("`413`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to deliver"),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`1004`",_1ae);
var _1b9=null;
this.LogSeq("`578`",_1ae);
for(i=0;i<_1b0.length;i++){
this.LogSeq("`665`",_1ae);
if(i!=(_1b0.length-1)){
this.LogSeq("`199`",_1ae);
if(_1b0[i].GetSequencingControlChoiceExit()===false){
this.LogSeq("`378`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-7",IntegrationImplementation.GetString("You are not allowed to jump out of {0}.",_1b0[i].GetTitle()),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
this.LogSeq("`403`",_1ae);
if(_1b9===null){
this.LogSeq("`734`",_1ae);
if(_1b0[i].GetConstrainedChoice()===true){
this.LogSeq("`962`",_1ae);
_1b9=_1b0[i];
}
}
}
this.LogSeq("`983`",_1ae);
if(_1b9!==null){
this.LogSeq("`470`",_1ae);
if(this.IsActivity1BeforeActivity2(_1b9,_1ac,_1ae)){
this.LogSeq("`530`",_1ae);
_1b4=FLOW_DIRECTION_FORWARD;
}else{
this.LogSeq("`1601`",_1ae);
this.LogSeq("`517`",_1ae);
_1b4=FLOW_DIRECTION_BACKWARD;
}
this.LogSeq("`524`",_1ae);
var _1ba=this.ChoiceFlowSubprocess(_1b9,_1b4,_1ae);
this.LogSeq("`560`",_1ae);
var _1bb=_1ba;
this.LogSeq("`6`",_1ae);
if((!_1bb.IsActivityAnAvailableDescendent(_1ac))&&(_1ac!=_1b9&&_1ac!=_1bb)){
this.LogSeq("`531`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-8",IntegrationImplementation.GetString("You are not allowed to jump out of {0}.",_1b9.GetTitle()),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
this.LogSeq("`244`",_1ae);
_1b0=this.GetPathToAncestorInclusive(this.Activities.GetParentActivity(_1ac),_1b2);
this.LogSeq("`1070`",_1ae);
if(_1b0.length===0){
this.LogSeq("`414`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to open"),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`306`",_1ae);
if(this.IsActivity1BeforeActivity2(_1b3,_1ac,_1ae)){
this.LogSeq("`976`",_1ae);
for(i=(_1b0.length-1);i>=0;i--){
this.LogSeq("`509`",_1ae);
_1b5=this.ChoiceActivityTraversalSubprocess(_1b0[i],FLOW_DIRECTION_FORWARD,_1ae);
this.LogSeq("`686`",_1ae);
if(_1b5.Reachable===false){
this.LogSeq("`133`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,_1b5.Exception,_1b5.ExceptionText,false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`16`",_1ae);
if((_1b0[i].IsActive()===false)&&(_1b0[i]!=_1b2)&&(_1b0[i].GetPreventActivation()===true)){
this.LogSeq("`379`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-6",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1b0[i].GetTitle()),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
}else{
this.LogSeq("`1654`",_1ae);
this.LogSeq("`977`",_1ae);
for(i=(_1b0.length-1);i>=0;i--){
this.LogSeq("`14`",_1ae);
if((_1b0[i].IsActive()===false)&&(_1b0[i]!=_1b2)&&(_1b0[i].GetPreventActivation()===true)){
this.LogSeq("`380`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-6",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1b0[i].GetTitle()),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
}
this.LogSeq("`1408`",_1ae);
}
}
}
}
this.LogSeq("`927`",_1ae);
if(_1ac.IsALeaf()===true){
this.LogSeq("`493`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(_1ac,null,"",false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
this.LogSeq("`52`",_1ae);
var _1bc=this.FlowSubprocess(_1ac,FLOW_DIRECTION_FORWARD,true,_1ae);
this.LogSeq("`253`",_1ae);
if(_1bc.Deliverable===false){
if(this.LookAhead===false){
this.LogSeq("`647`",_1ae);
this.TerminateDescendentAttemptsProcess(_1b2,_1ae);
this.LogSeq("`840`",_1ae);
this.EndAttemptProcess(_1b2,false,_1ae);
this.LogSeq("`885`",_1ae);
this.SetCurrentActivity(_1ac,_1ae);
}
this.LogSeq("`439`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-9",IntegrationImplementation.GetString("Please select another item from the menu."),false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}else{
this.LogSeq("`1693`",_1ae);
this.LogSeq("`311`",_1ae);
_1b7=new Sequencer_ChoiceSequencingRequestProcessResult(_1bc.IdentifiedActivity,null,"",false);
this.LogSeqReturn(_1b7,_1ae);
return _1b7;
}
}
function Sequencer_ChoiceSequencingRequestProcessResult(_1bd,_1be,_1bf,_1c0){
if(_1c0===undefined){
Debug.AssertError("no value passed for hidden");
}
this.DeliveryRequest=_1bd;
this.Exception=_1be;
this.ExceptionText=_1bf;
this.Hidden=_1c0;
}
Sequencer_ChoiceSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", Hidden="+this.Hidden;
};
function Sequencer_ClearSuspendedActivitySubprocess(_1c1,_1c2){
Debug.AssertError("Calling log not passed.",(_1c2===undefined||_1c2===null));
var _1c3=this.LogSeqAudit("`1109`"+_1c1+")",_1c2);
var _1c4=null;
var _1c5=null;
var _1c6=null;
this.LogSeq("`604`",_1c3);
if(this.IsSuspendedActivityDefined(_1c3)){
this.LogSeq("`598`",_1c3);
_1c5=this.GetSuspendedActivity(_1c3);
_1c4=this.FindCommonAncestor(_1c1,_1c5,_1c3);
this.LogSeq("`342`",_1c3);
_1c6=this.GetPathToAncestorInclusive(_1c5,_1c4);
this.LogSeq("`996`",_1c3);
if(_1c6.length>0){
this.LogSeq("`334`",_1c3);
for(var i=0;i<_1c6.length;i++){
this.LogSeq("`1075`",_1c3);
if(_1c6[i].IsALeaf()){
this.LogSeq("`787`",_1c3);
_1c6[i].SetSuspended(false);
}else{
this.LogSeq("`1577`",_1c3);
this.LogSeq("`398`",_1c3);
if(_1c6[i].HasSuspendedChildren()===false){
this.LogSeq("`766`",_1c3);
_1c6[i].SetSuspended(false);
}
}
}
}
this.LogSeq("`607`",_1c3);
this.ClearSuspendedActivity(_1c3);
}
this.LogSeq("`997`",_1c3);
this.LogSeqReturn("",_1c3);
return;
}
function Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess(_1c8,_1c9){
if(_1c9===undefined||_1c9===null){
_1c9=this.LogSeqAudit("Content Delivery Environment Activity Data SubProcess for "+activity.StringIdentifier);
}
var _1ca=(Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK||Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
if(_1ca){
var _1cb=this.PreviousActivity;
}else{
var _1cb=this.CurrentActivity;
}
var _1cc=this.GetSuspendedActivity(_1c9);
var _1cd=this.GetRootActivity(_1c9);
var _1ce=null;
var _1cf=false;
this.LogSeq("`208`",_1c9);
if(_1cc!=_1c8){
this.LogSeq("`554`",_1c9);
this.ClearSuspendedActivitySubprocess(_1c8,_1c9);
}
this.LogSeq("`230`",_1c9);
this.TerminateDescendentAttemptsProcess(_1c8,_1c9);
this.LogSeq("`66`",_1c9);
_1ce=this.GetPathToAncestorInclusive(_1c8,_1cd);
this.LogSeq("`1076`",_1c9);
var _1d0=ConvertDateToIso8601String(new Date());
for(var i=(_1ce.length-1);i>=0;i--){
this.LogSeq("`1531`"+_1ce[i]+"`1169`",_1c9);
if(_1ca){
var _1d2=_1ce[i].WasActiveBeforeLaunchOnClick;
}else{
var _1d2=_1ce[i].IsActive();
}
if(_1d2===false){
this.LogSeq("`978`",_1c9);
if(_1ce[i].IsTracked()){
this.LogSeq("`114`",_1c9);
if(_1ce[i].IsSuspended()){
this.LogSeq("`811`",_1c9);
_1ce[i].SetSuspended(false);
}else{
this.LogSeq("`1611`",_1c9);
this.LogSeq("`485`",_1c9);
_1ce[i].IncrementAttemptCount();
this.LogSeq("`357`",_1c9);
if(_1ce[i].GetAttemptCount()==1){
this.LogSeq("`767`",_1c9);
_1ce[i].SetActivityProgressStatus(true);
_1cf=true;
}
this.LogSeq("`161`",_1c9);
_1ce[i].InitializeForNewAttempt(true,true);
var atts={ev:"AttemptStart",an:_1ce[i].GetAttemptCount(),ai:_1ce[i].ItemIdentifier,at:_1ce[i].LearningObject.Title};
this.WriteHistoryLog("",atts);
_1ce[i].SetAttemptStartTimestampUtc(_1d0);
_1ce[i].SetAttemptAbsoluteDuration("PT0H0M0S");
_1ce[i].SetAttemptExperiencedDurationTracked("PT0H0M0S");
_1ce[i].SetAttemptExperiencedDurationReported("PT0H0M0S");
if(Control.Package.Properties.ResetRunTimeDataTiming==RESET_RT_DATA_TIMING_ON_EACH_NEW_SEQUENCING_ATTEMPT){
if(_1ce[i].IsDeliverable()===true){
if(_1cf===false){
var atts={ev:"ResetRuntime",ai:_1ce[i].ItemIdentifier,at:_1ce[i].LearningObject.Title};
this.WriteHistoryLog("",atts);
}
_1ce[i].RunTime.ResetState();
}
}
}
}
}
}
}
function Sequencer_ContentDeliveryEnvironmentProcess(_1d4,_1d5){
Debug.AssertError("Calling log not passed.",(_1d5===undefined||_1d5===null));
var _1d6=this.LogSeqAudit("`1125`"+_1d4+")",_1d5);
var _1d7=(Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK||Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
var _1d8=this.GetCurrentActivity();
var _1d9=this.GetSuspendedActivity(_1d6);
var _1da=this.GetRootActivity(_1d6);
var _1db=null;
var _1dc;
this.LogSeq("`200`",_1d6);
if(_1d8!==null&&_1d8.IsActive()){
this.LogSeq("`264`",_1d6);
_1dc=new Sequencer_ContentDeliveryEnvironmentProcessResult(false,"DB.2.1",IntegrationImplementation.GetString("The previous activity must be terminated before a new activity may be attempted"));
this.LogSeqReturn(_1dc,_1d6);
return _1dc;
}
if(!_1d7){
this.ContentDeliveryEnvironmentActivityDataSubProcess(_1d4,_1d5);
}else{
this.LogSeq("`224`",_1d6);
}
this.LogSeq("`66`",_1d6);
_1db=this.GetPathToAncestorInclusive(_1d4,_1da);
this.LogSeq("`1076`",_1d6);
for(var i=(_1db.length-1);i>=0;i--){
if(_1d7){
_1db[i].WasActiveBeforeLaunchOnClick=_1db[i].IsActive();
}
this.LogSeq("`1531`"+_1db[i]+"`1169`",_1d6);
if(_1db[i].IsActive()===false){
this.LogSeq("`888`",_1d6);
_1db[i].SetActive(true);
}
}
this.LogSeq("`231`"+_1d4.GetItemIdentifier(),_1d6);
if(_1d7){
this.PreviousActivity=_1d8;
}
this.SetCurrentActivity(_1d4,_1d6);
this.LogSeq("`820`",_1d6);
_1dc=new Sequencer_ContentDeliveryEnvironmentProcessResult(true,null,"");
this.LogSeqReturn(_1dc,_1d6);
Control.DeliverActivity(_1d4);
return _1dc;
}
function Sequencer_ContentDeliveryEnvironmentProcessResult(_1de,_1df,_1e0){
this.Valid=_1de;
this.Exception=_1df;
this.ExceptionText=_1e0;
}
Sequencer_ContentDeliveryEnvironmentProcessResult.prototype.toString=function(){
return "Valid="+this.Valid+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_ContinueSequencingRequestProcess(_1e1){
Debug.AssertError("Calling log not passed.",(_1e1===undefined||_1e1===null));
var _1e2=this.LogSeqAudit("`1126`",_1e1);
var _1e3;
this.LogSeq("`500`",_1e2);
if(!this.IsCurrentActivityDefined(_1e2)){
this.LogSeq("`422`",_1e2);
_1e3=new Sequencer_ContinueSequencingRequestProcessResult(null,"SB.2.7-1",IntegrationImplementation.GetString("The sequencing session has not begun yet."));
this.LogSeqReturn(_1e3,_1e2);
return _1e3;
}
var _1e4=this.GetCurrentActivity();
this.LogSeq("`708`",_1e2);
if(!_1e4.IsTheRoot()){
var _1e5=this.Activities.GetParentActivity(_1e4);
this.LogSeq("`299`",_1e2);
if(_1e5.GetSequencingControlFlow()===false){
this.LogSeq("`585`",_1e2);
_1e3=new Sequencer_ContinueSequencingRequestProcessResult(null,"SB.2.7-2",IntegrationImplementation.GetString("You cannot use 'Next' to enter {0}. Please select a menu item to continue.",_1e5.GetTitle()));
this.LogSeqReturn(_1e3,_1e2);
return _1e3;
}
}
this.LogSeq("`136`",_1e2);
var _1e6=this.FlowSubprocess(_1e4,FLOW_DIRECTION_FORWARD,false,_1e2);
this.LogSeq("`988`",_1e2);
if(_1e6.Deliverable===false){
this.LogSeq("`228`",_1e2);
_1e3=new Sequencer_ContinueSequencingRequestProcessResult(null,_1e6.Exception,_1e6.ExceptionText);
this.LogSeqReturn(_1e3,_1e2);
return _1e3;
}else{
this.LogSeq("`1705`",_1e2);
this.LogSeq("`319`",_1e2);
_1e3=new Sequencer_ContinueSequencingRequestProcessResult(_1e6.IdentifiedActivity,null,"");
this.LogSeqReturn(_1e3,_1e2);
return _1e3;
}
}
function Sequencer_ContinueSequencingRequestProcessResult(_1e7,_1e8,_1e9){
this.DeliveryRequest=_1e7;
this.Exception=_1e8;
this.ExceptionText=_1e9;
}
Sequencer_ContinueSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_DeliveryRequestProcess(_1ea,_1eb){
Debug.AssertError("Calling log not passed.",(_1eb===undefined||_1eb===null));
var _1ec=this.LogSeqAudit("`1322`"+_1ea+")",_1eb);
var _1ed;
var _1ee;
this.LogSeq("`872`"+_1ea+"`953`",_1ec);
if(!_1ea.IsALeaf()){
this.LogSeq("`581`",_1ec);
_1ee=new Sequencer_DeliveryRequestProcessResult(false,"DB.1.1-1",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1ea.GetTitle()));
this.LogSeqReturn(_1ee,_1ec);
return _1ee;
}
this.LogSeq("`207`",_1ec);
var _1ef=this.GetActivityPath(_1ea,true);
this.LogSeq("`836`",_1ec);
if(_1ef.length===0){
this.LogSeq("`582`",_1ec);
_1ee=new Sequencer_DeliveryRequestProcessResult(false,"DB.1.1-2",IntegrationImplementation.GetString("Nothing to open"));
this.LogSeqReturn(_1ee,_1ec);
return _1ee;
}
this.LogSeq("`528`",_1ec);
for(var i=0;i<_1ef.length;i++){
this.LogSeq("`857`"+_1ef[i],_1ec);
_1ed=this.CheckActivityProcess(_1ef[i],_1ec);
this.LogSeq("`900`",_1ec);
if(_1ed===true){
this.LogSeq("`563`",_1ec);
_1ee=new Sequencer_DeliveryRequestProcessResult(false,"DB.1.1-3",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1ea.GetTitle()));
this.LogSeqReturn(_1ee,_1ec);
return _1ee;
}
}
this.LogSeq("`658`",_1ec);
_1ee=new Sequencer_DeliveryRequestProcessResult(true,null,"");
this.LogSeqReturn(_1ee,_1ec);
return _1ee;
}
function Sequencer_DeliveryRequestProcessResult(_1f1,_1f2,_1f3){
this.Valid=_1f1;
this.Exception=_1f2;
this.ExceptionText=_1f3;
}
Sequencer_DeliveryRequestProcessResult.prototype.toString=function(){
return "Valid="+this.Valid+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_EndAttemptProcess(_1f4,_1f5,_1f6,_1f7){
Debug.AssertError("Calling log not passed.",(_1f6===undefined||_1f6===null));
if(_1f7===undefined||_1f7===null){
_1f7=false;
}
var _1f8=this.LogSeqAudit("`1470`"+_1f4+", "+_1f5+")",_1f6);
this.LogSeq("`1493`"+_1f4.GetItemIdentifier()+"`1682`",_1f8);
var i;
var _1fa=new Array();
if(_1f4.IsALeaf()){
this.LogSeq("`1013`",_1f8);
if(_1f4.IsTracked()&&_1f4.WasLaunchedThisSession()){
this.LogSeq("`862`",_1f8);
_1f4.TransferRteDataToActivity();
this.LogSeq("`312`",_1f8);
if(_1f4.IsSuspended()===false){
this.LogSeq("`284`",_1f8);
if(_1f4.IsCompletionSetByContent()===false){
this.LogSeq("`245`",_1f8);
if(_1f4.GetAttemptProgressStatus()===false){
this.LogSeq("`743`",_1f8);
_1f4.SetAttemptProgressStatus(true);
this.LogSeq("`715`",_1f8);
_1f4.SetAttemptCompletionStatus(true);
_1f4.WasAutoCompleted=true;
}
}
this.LogSeq("`297`",_1f8);
if(_1f4.IsObjectiveSetByContent()===false){
this.LogSeq("`596`",_1f8);
var _1fb=_1f4.GetPrimaryObjective();
this.LogSeq("`192`",_1f8);
if(_1fb.GetProgressStatus(_1f4,false)===false){
this.LogSeq("`667`",_1f8);
_1fb.SetProgressStatus(true,false,_1f4);
this.LogSeq("`657`",_1f8);
_1fb.SetSatisfiedStatus(true,false,_1f4);
_1f4.WasAutoSatisfied=true;
}
}
}
}
}else{
this.LogSeq("`1220`",_1f8);
this.LogSeq("`109`",_1f8);
if(this.ActivityHasSuspendedChildren(_1f4,_1f8)){
this.LogSeq("`833`",_1f8);
_1f4.SetSuspended(true);
}else{
this.LogSeq("`1709`",_1f8);
this.LogSeq("`819`",_1f8);
_1f4.SetSuspended(false);
}
}
if(_1f7===false){
this.LogSeq("`462`",_1f8);
_1f4.SetActive(false);
}
var _1fc;
if(_1f5===false){
this.LogSeq("`250`",_1f8);
_1fc=this.OverallRollupProcess(_1f4,_1f8);
}else{
this.LogSeq("`527`",_1f8);
_1fa[0]=_1f4;
}
this.LogSeq("`235`",_1f8);
var _1fd=this.FindActivitiesAffectedByWriteMaps(_1f4);
var _1fe=this.FindDistinctParentsOfActivitySet(_1fd);
if(_1f5===false){
this.LogSeq("`457`",_1f8);
var _1ff=this.GetMinimalSubsetOfActivitiesToRollup(_1fe,_1fc);
for(i=0;i<_1ff.length;i++){
if(_1ff[i]!==null){
this.OverallRollupProcess(_1ff[i],_1f8);
}
}
}else{
this.LogSeq("`218`",_1f8);
_1fa=_1fa.concat(_1fe);
}
if(this.LookAhead===false&&_1f7===false){
this.RandomizeChildrenProcess(_1f4,true,_1f8);
}
this.LogSeq("`1302`",_1f8);
this.LogSeqReturn("",_1f8);
return _1fa;
}
function Sequencer_EvaluateRollupConditionsSubprocess(_200,_201,_202){
Debug.AssertError("Calling log not passed.",(_202===undefined||_202===null));
var _203=this.LogSeqAudit("`1033`"+_200+", "+_201+")",_202);
var _204;
var _205;
this.LogSeq("`387`",_203);
var _206=new Array();
var i;
this.LogSeq("`791`",_203);
for(i=0;i<_201.Conditions.length;i++){
this.LogSeq("`36`",_203);
_204=Sequencer_EvaluateRollupRuleCondition(_200,_201.Conditions[i]);
this.LogSeq("`369`",_203);
if(_201.Conditions[i].Operator==RULE_CONDITION_OPERATOR_NOT&&_204!=RESULT_UNKNOWN){
this.LogSeq("`1136`",_203);
_204=(!_204);
}
this.LogSeq("`968`"+_204+"`532`",_203);
_206[_206.length]=_204;
}
this.LogSeq("`308`",_203);
if(_206.length===0){
this.LogSeq("`691`",_203);
return RESULT_UNKNOWN;
}
this.LogSeq("`1101`"+_201.ConditionCombination+"`285`",_203);
if(_201.ConditionCombination==RULE_CONDITION_COMBINATION_ANY){
_205=false;
for(i=0;i<_206.length;i++){
_205=Sequencer_LogicalOR(_205,_206[i]);
}
}else{
_205=true;
for(i=0;i<_206.length;i++){
_205=Sequencer_LogicalAND(_205,_206[i]);
}
}
this.LogSeq("`497`",_203);
this.LogSeqReturn(_205,_203);
return _205;
}
function Sequencer_EvaluateRollupRuleCondition(_208,_209){
var _20a=null;
switch(_209.Condition){
case ROLLUP_RULE_CONDITION_SATISFIED:
_20a=_208.IsSatisfied("");
break;
case ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
_20a=_208.IsObjectiveStatusKnown("",false);
break;
case ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
_20a=_208.IsObjectiveMeasureKnown("",false);
break;
case ROLLUP_RULE_CONDITION_COMPLETED:
_20a=_208.IsCompleted("",false);
break;
case ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
_20a=_208.IsActivityProgressKnown("",false);
break;
case ROLLUP_RULE_CONDITION_ATTEMPTED:
_20a=_208.IsAttempted();
break;
case ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
_20a=_208.IsAttemptLimitExceeded();
break;
case ROLLUP_RULE_CONDITION_NEVER:
_20a=false;
break;
default:
this.LogSeq("`1359`",logParent);
break;
}
return _20a;
}
function Sequencer_ExitSequencingRequestProcess(_20b){
Debug.AssertError("Calling log not passed.",(_20b===undefined||_20b===null));
var _20c=this.LogSeqAudit("`1211`",_20b);
var _20d;
this.LogSeq("`490`",_20c);
if(!this.IsCurrentActivityDefined(_20c)){
this.LogSeq("`512`",_20c);
_20d=new Sequencer_ExitSequencingRequestProcessResult(false,"SB.2.11-1",IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed until the sequencing session has begun."));
this.LogSeqReturn(_20d,_20c);
return _20d;
}
var _20e=this.GetCurrentActivity();
this.LogSeq("`323`",_20c);
if(_20e.IsActive()){
this.LogSeq("`513`",_20c);
_20d=new Sequencer_ExitSequencingRequestProcessResult(false,"SB.2.11-2",IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed while an activity is still active."));
this.LogSeqReturn(_20d,_20c);
return _20d;
}
this.LogSeq("`762`",_20c);
if(_20e.IsTheRoot()||this.CourseIsSingleSco()===true){
this.LogSeq("`219`",_20c);
_20d=new Sequencer_ExitSequencingRequestProcessResult(true,null,"");
this.LogSeqReturn(_20d,_20c);
return _20d;
}
this.LogSeq("`556`",_20c);
_20d=new Sequencer_ExitSequencingRequestProcessResult(false,null,"");
this.LogSeqReturn(_20d,_20c);
return _20d;
}
function Sequencer_ExitSequencingRequestProcessResult(_20f,_210,_211){
this.EndSequencingSession=_20f;
this.Exception=_210;
this.ExceptionText=_211;
}
Sequencer_ExitSequencingRequestProcessResult.prototype.toString=function(){
return "EndSequencingSession="+this.EndSequencingSession+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_FlowActivityTraversalSubprocess(_212,_213,_214,_215){
Debug.AssertError("Calling log not passed.",(_215===undefined||_215===null));
var _216=this.LogSeqAudit("`1130`"+_212+", "+_213+", "+_214+")",_215);
var _217;
var _218;
var _219;
var _21a;
var _21b;
var _21c=this.Activities.GetParentActivity(_212);
this.LogSeq("`458`",_216);
if(_21c.GetSequencingControlFlow()===false){
this.LogSeq("`388`",_216);
_21b=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_212,"SB.2.2-1",IntegrationImplementation.GetString("Please select a menu item to continue with {0}.",_21c.GetTitle()));
this.LogSeqReturn(_21b,_216);
return _21b;
}
this.LogSeq("`535`",_216);
_217=this.SequencingRulesCheckProcess(_212,RULE_SET_SKIPPED,_216);
this.LogSeq("`358`",_216);
if(_217!==null){
this.LogSeq("`185`",_216);
_218=this.FlowTreeTraversalSubprocess(_212,_213,_214,false,_216);
this.LogSeq("`635`",_216);
if(_218.NextActivity===null){
this.LogSeq("`157`",_216);
_21b=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_212,_218.Exception,_218.ExceptionText);
this.LogSeqReturn(_21b,_216);
return _21b;
}else{
this.LogSeq("`1676`",_216);
this.LogSeq("`67`",_216);
if(_214==FLOW_DIRECTION_BACKWARD&&_218.TraversalDirection==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`35`",_216);
_219=this.FlowActivityTraversalSubprocess(_218.NextActivity,_218.TraversalDirection,null,_216);
}else{
this.LogSeq("`1624`",_216);
this.LogSeq("`9`",_216);
_219=this.FlowActivityTraversalSubprocess(_218.NextActivity,_213,_214,_216);
}
this.LogSeq("`232`",_216);
_21b=_219;
this.LogSeqReturn(_21b,_216);
return _21b;
}
}
this.LogSeq("`565`",_216);
_21a=this.CheckActivityProcess(_212,_216);
this.LogSeq("`923`",_216);
if(_21a===true){
this.LogSeq("`389`",_216);
_21b=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_212,"SB.2.2-2",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_212.GetTitle()));
this.LogSeqReturn(_21b,_216);
return _21b;
}
this.LogSeq("`280`",_216);
if(_212.IsALeaf()===false){
this.LogSeq("`158`",_216);
_218=this.FlowTreeTraversalSubprocess(_212,_213,null,true,_216);
this.LogSeq("`636`",_216);
if(_218.NextActivity===null){
this.LogSeq("`159`",_216);
_21b=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_212,_218.Exception,_218.ExceptionText);
this.LogSeqReturn(_21b,_216);
return _21b;
}else{
this.LogSeq("`1677`",_216);
this.LogSeq("`44`",_216);
if(_213==FLOW_DIRECTION_BACKWARD&&_218.TraversalDirection==FLOW_DIRECTION_FORWARD){
this.LogSeq("`22`",_216);
_219=this.FlowActivityTraversalSubprocess(_218.NextActivity,FLOW_DIRECTION_FORWARD,FLOW_DIRECTION_BACKWARD,_216);
}else{
this.LogSeq("`1625`",_216);
this.LogSeq("`29`",_216);
_219=this.FlowActivityTraversalSubprocess(_218.NextActivity,_213,null,_216);
}
this.LogSeq("`227`",_216);
_21b=_219;
this.LogSeqReturn(_21b,_216);
return _21b;
}
}
this.LogSeq("`359`",_216);
_21b=new Sequencer_FlowActivityTraversalSubprocessReturnObject(true,_212,null,"");
this.LogSeqReturn(_21b,_216);
return _21b;
}
function Sequencer_FlowActivityTraversalSubprocessReturnObject(_21d,_21e,_21f,_220){
this.Deliverable=_21d;
this.NextActivity=_21e;
this.Exception=_21f;
this.ExceptionText=_220;
}
Sequencer_FlowActivityTraversalSubprocessReturnObject.prototype.toString=function(){
return "Deliverable="+this.Deliverable+", NextActivity="+this.NextActivity+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_FlowSubprocess(_221,_222,_223,_224){
Debug.AssertError("Calling log not passed.",(_224===undefined||_224===null));
var _225=this.LogSeqAudit("`1506`"+_221+", "+_222+", "+_223+")",_224);
var _226;
this.LogSeq("`508`",_225);
var _227=_221;
this.LogSeq("`4`",_225);
var _228=this.FlowTreeTraversalSubprocess(_227,_222,null,_223,_225);
this.LogSeq("`491`",_225);
if(_228.NextActivity===null){
this.LogSeq("`205`",_225);
_226=new Sequencer_FlowSubprocessResult(_227,false,_228.Exception,_228.ExceptionText);
this.LogSeqReturn(_226,_225);
return _226;
}else{
this.LogSeq("`1704`",_225);
this.LogSeq("`557`",_225);
_227=_228.NextActivity;
this.LogSeq("`48`",_225);
var _229=this.FlowActivityTraversalSubprocess(_227,_222,null,_225);
this.LogSeq("`17`",_225);
_226=new Sequencer_FlowSubprocessResult(_229.NextActivity,_229.Deliverable,_229.Exception,_229.ExceptionText);
this.LogSeqReturn(_226,_225);
return _226;
}
}
function Sequencer_FlowSubprocessResult(_22a,_22b,_22c,_22d){
this.IdentifiedActivity=_22a;
this.Deliverable=_22b;
this.Exception=_22c;
this.ExceptionText=_22d;
}
Sequencer_FlowSubprocessResult.prototype.toString=function(){
return "IdentifiedActivity="+this.IdentifiedActivity+", Deliverable="+this.Deliverable+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_FlowTreeTraversalSubprocess(_22e,_22f,_230,_231,_232){
Debug.AssertError("Calling log not passed.",(_232===undefined||_232===null));
var _233=this.LogSeqAudit("`1232`"+_22e+", "+_22f+", "+_230+", "+_231+")",_232);
var _234;
var _235;
var _236;
var _237;
var _238;
var _239;
var _23a=this.Activities.GetParentActivity(_22e);
this.LogSeq("`1196`",_233);
_234=false;
this.LogSeq("`24`",_233);
if(_230!==null&&_230==FLOW_DIRECTION_BACKWARD&&_23a.IsActivityTheLastAvailableChild(_22e)){
this.LogSeq("`1149`",_233);
_22f=FLOW_DIRECTION_BACKWARD;
this.LogSeq("`552`",_233);
_22e=_23a.GetFirstAvailableChild();
this.LogSeq("`1168`",_233);
_234=true;
}
this.LogSeq("`980`",_233);
if(_22f==FLOW_DIRECTION_FORWARD){
this.LogSeq("`266`",_233);
if((this.IsActivityLastOverall(_22e,_233))||(_231===false&&_22e.IsTheRoot()===true)){
this.LogSeq("`436`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-1",IntegrationImplementation.GetString("You have reached the end of the course."));
this.LogSeqReturn(_239,_233);
return _239;
}
this.LogSeq("`763`",_233);
if(_22e.IsALeaf()||_231===false){
this.LogSeq("`478`",_233);
if(_23a.IsActivityTheLastAvailableChild(_22e)){
this.LogSeq("`28`",_233);
_235=this.FlowTreeTraversalSubprocess(_23a,FLOW_DIRECTION_FORWARD,null,false,_233);
this.LogSeq("`225`",_233);
_239=_235;
this.LogSeqReturn(_239,_233);
return _239;
}else{
this.LogSeq("`1620`",_233);
this.LogSeq("`298`",_233);
_236=_22e.GetNextSibling();
this.LogSeq("`201`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_236,_22f,null,"");
this.LogSeqReturn(_239,_233);
return _239;
}
}else{
this.LogSeq("`1150`",_233);
this.LogSeq("`392`",_233);
_237=_22e.GetAvailableChildren();
if(_237.length>0){
this.LogSeq("`332`"+_237[0]+"); Traversal Direction: traversal direction ("+_22f+"); Exception: n/a )",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_237[0],_22f,null,"");
this.LogSeqReturn(_239,_233);
return _239;
}else{
this.LogSeq("`1621`",_233);
this.LogSeq("`421`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-2",IntegrationImplementation.GetString("The activity '{0}' does not have any available children to deliver.",_22e.GetTitle()));
this.LogSeqReturn(_239,_233);
return _239;
}
}
}
this.LogSeq("`971`",_233);
if(_22f==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`465`",_233);
if(_22e.IsTheRoot()){
this.LogSeq("`437`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-3",IntegrationImplementation.GetString("You have reached the beginning of the course."));
this.LogSeqReturn(_239,_233);
return _239;
}
this.LogSeq("`764`",_233);
if(_22e.IsALeaf()||_231===false){
this.LogSeq("`337`",_233);
if(_234===false){
this.LogSeq("`317`",_233);
if(_23a.GetSequencingControlForwardOnly()===true){
this.LogSeq("`393`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-4",IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.",_23a.GetTitle()));
this.LogSeqReturn(_239,_233);
return _239;
}
}
this.LogSeq("`471`",_233);
if(_23a.IsActivityTheFirstAvailableChild(_22e)){
this.LogSeq("`25`",_233);
_235=this.FlowTreeTraversalSubprocess(_23a,FLOW_DIRECTION_BACKWARD,null,false,_233);
this.LogSeq("`226`",_233);
_239=_235;
this.LogSeqReturn(_239,_233);
return _239;
}else{
this.LogSeq("`1622`",_233);
this.LogSeq("`267`",_233);
_238=_22e.GetPreviousSibling();
this.LogSeq("`808`"+_238+"`1535`"+_22f+"`1632`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_238,_22f,null,"");
this.LogSeqReturn(_239,_233);
return _239;
}
}else{
this.LogSeq("`1088`",_233);
this.LogSeq("`376`",_233);
_237=_22e.GetAvailableChildren();
if(_237.length>0){
this.LogSeq("`668`",_233);
if(_22e.GetSequencingControlForwardOnly()===true){
this.LogSeq("`49`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_237[0],FLOW_DIRECTION_FORWARD,null,"");
this.LogSeqReturn(_239,_233);
return _239;
}else{
this.LogSeq("`1585`",_233);
this.LogSeq("`43`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_237[_237.length-1],FLOW_DIRECTION_BACKWARD,null,"");
this.LogSeqReturn(_239,_233);
return _239;
}
}else{
this.LogSeq("`1623`",_233);
this.LogSeq("`408`",_233);
_239=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-2",IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.",_23a.GetTitle()));
this.LogSeqReturn(_239,_233);
return _239;
}
}
}
}
function Sequencer_FlowTreeTraversalSubprocessReturnObject(_23b,_23c,_23d,_23e){
this.NextActivity=_23b;
this.TraversalDirection=_23c;
this.Exception=_23d;
this.ExceptionText=_23e;
}
Sequencer_FlowTreeTraversalSubprocessReturnObject.prototype.toString=function(){
return "NextActivity="+this.NextActivity+", TraversalDirection="+this.TraversalDirection+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_LimitConditionsCheckProcess(_23f,_240){
Debug.AssertError("Calling log not passed.",(_240===undefined||_240===null));
var _241=this.LogSeqAudit("`1265`"+_23f+")",_240);
this.LogSeq("`384`",_241);
if(_23f.IsTracked()===false){
this.LogSeq("`296`",_241);
this.LogSeqReturn("`1745`",_241);
return false;
}
this.LogSeq("`144`",_241);
if(_23f.IsActive()||_23f.IsSuspended()){
this.LogSeq("`687`",_241);
this.LogSeqReturn("`1745`",_241);
return false;
}
this.LogSeq("`714`",_241);
if(_23f.GetLimitConditionAttemptControl()===true){
this.LogSeq("`89`",_241);
var _242=_23f.GetAttemptCount();
var _243=_23f.GetLimitConditionAttemptLimit();
if(_23f.GetActivityProgressStatus()===true&&(_242>=_243)){
this.LogSeq("`429`",_241);
this.LogSeqReturn("`1749`",_241);
return true;
}
}
this.LogSeq("`543`",_241);
this.LogSeq("`417`",_241);
this.LogSeqReturn("`1745`",_241);
return false;
}
function Sequencer_MeasureRollupProcess(_244,_245){
Debug.AssertError("Calling log not passed.",(_245===undefined||_245===null));
var _246=this.LogSeqAudit("`1372`"+_244+")",_245);
this.LogSeq("`956`",_246);
var _247=0;
this.LogSeq("`1341`",_246);
var _248=false;
this.LogSeq("`1039`",_246);
var _249=0;
this.LogSeq("`1057`",_246);
var _24a=null;
var i;
this.LogSeq("`626`",_246);
var _24a=_244.GetPrimaryObjective();
this.LogSeq("`1099`",_246);
if(_24a!==null){
this.LogSeq("`1165`",_246);
var _24c=_244.GetChildren();
var _24d=null;
var _24e;
var _24f;
var _250;
for(i=0;i<_24c.length;i++){
this.LogSeq("`555`"+_24c[i].IsTracked(),_246);
if(_24c[i].IsTracked()){
this.LogSeq("`979`",_246);
_24d=null;
this.LogSeq("`1166`",_246);
var _24d=_24c[i].GetPrimaryObjective();
this.LogSeq("`957`",_246);
if(_24d!==null){
this.LogSeq("`545`",_246);
_24f=_24c[i].GetRollupObjectiveMeasureWeight();
_249+=_24f;
this.LogSeq("`600`",_246);
if(_24d.GetMeasureStatus(_24c[i],false)===true){
this.LogSeq("`121`",_246);
_250=_24d.GetNormalizedMeasure(_24c[i],false);
this.LogSeq("`827`"+_250+"`1452`"+_24f,_246);
_248=true;
_247+=(_250*_24f);
}
}else{
this.LogSeq("`1581`",_246);
this.LogSeq("`495`",_246);
Debug.AssertError("Measure Rollup Process encountered an activity with no primary objective.");
this.LogSeqReturn("",_246);
return;
}
}
}
this.LogSeq("`1237`",_246);
if(_248===false||_249==0){
this.LogSeq("`103`"+_249+")",_246);
_24a.SetMeasureStatus(false,_244);
}else{
this.LogSeq("`1670`",_246);
this.LogSeq("`678`",_246);
_24a.SetMeasureStatus(true,_244);
this.LogSeq("`487`"+_247+"`1377`"+_249+"`1734`"+(_247/_249),_246);
var _251=(_247/_249);
_251=RoundToPrecision(_251,7);
_24a.SetNormalizedMeasure(_251,_244);
}
this.LogSeq("`1191`",_246);
this.LogSeqReturn("",_246);
return;
}
this.LogSeq("`539`",_246);
this.LogSeqReturn("",_246);
return;
}
function Sequencer_NavigationRequestProcess(_252,_253,_254){
Debug.AssertError("Calling log not passed.",(_254===undefined||_254===null));
var _255=this.LogSeqAudit("`1298`"+_252+", "+_253+")",_254);
var _256=this.GetCurrentActivity();
var _257=null;
if(_256!==null){
_257=_256.ParentActivity;
}
var _258="";
if(_257!==null){
_258=_257.GetTitle();
}
var _259;
switch(_252){
case NAVIGATION_REQUEST_START:
this.LogSeq("`1162`",_255);
this.LogSeq("`463`",_255);
if(!this.IsCurrentActivityDefined(_255)){
this.LogSeq("`209`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,null,SEQUENCING_REQUEST_START,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1663`",_255);
this.LogSeq("`176`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-1",null,IntegrationImplementation.GetString("The sequencing session has already been started."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_RESUME_ALL:
this.LogSeq("`1037`",_255);
this.LogSeq("`464`",_255);
if(!this.IsCurrentActivityDefined(_255)){
this.LogSeq("`335`",_255);
if(this.IsSuspendedActivityDefined(_255)){
this.LogSeq("`170`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,null,SEQUENCING_REQUEST_RESUME_ALL,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1599`",_255);
this.LogSeq("`163`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-3",null,IntegrationImplementation.GetString("There is no suspended activity to resume."));
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1664`",_255);
this.LogSeq("`177`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-1",null,IntegrationImplementation.GetString("The sequencing session has already been started."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_CONTINUE:
this.LogSeq("`1079`",_255);
this.LogSeq("`480`",_255);
if(!this.IsCurrentActivityDefined(_255)){
this.LogSeq("`178`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-1",null,IntegrationImplementation.GetString("Cannot continue until the sequencing session has begun."));
this.LogSeqReturn(_259,_255);
return _259;
}
this.LogSeq("`40`",_255);
if((!_256.IsTheRoot())&&(_257.LearningObject.SequencingData.ControlFlow===true)){
this.LogSeq("`212`",_255);
if(_256.IsActive()){
this.LogSeq("`183`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_CONTINUE,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1613`",_255);
this.LogSeq("`186`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,null,SEQUENCING_REQUEST_CONTINUE,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1665`",_255);
this.LogSeq("`34`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-4",null,IntegrationImplementation.GetString("Please select a menu item to continue with {0}.",_258));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_PREVIOUS:
this.LogSeq("`1080`",_255);
this.LogSeq("`481`",_255);
if(!this.IsCurrentActivityDefined(_255)){
this.LogSeq("`184`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("Cannot move backwards until the sequencing session has begun."));
this.LogSeqReturn(_259,_255);
return _259;
}
this.LogSeq("`239`",_255);
if(!_256.IsTheRoot()){
this.LogSeq("`12`",_255);
if(_257.LearningObject.SequencingData.ControlFlow===true&&_257.LearningObject.SequencingData.ControlForwardOnly===false){
this.LogSeq("`202`",_255);
if(_256.IsActive()){
this.LogSeq("`171`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_PREVIOUS,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1578`",_255);
this.LogSeq("`179`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,null,SEQUENCING_REQUEST_PREVIOUS,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1614`",_255);
this.LogSeq("`100`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-5",null,IntegrationImplementation.GetString("Please select a menu item to continue with {0}.",_257.GetTitle()));
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1666`",_255);
this.LogSeq("`50`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-6",null,IntegrationImplementation.GetString("You have reached the beginning of the course."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_FORWARD:
this.LogSeq("`798`",_255);
this.LogSeq("`187`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-7",null,IntegrationImplementation.GetString("The 'Forward' navigation request is not supported, try using 'Continue'."));
this.LogSeqReturn(_259,_255);
return _259;
case NAVIGATION_REQUEST_BACKWARD:
this.LogSeq("`790`",_255);
this.LogSeq("`188`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-7",null,IntegrationImplementation.GetString("The 'Backward' navigation request is not supported, try using 'Previous'."));
this.LogSeqReturn(_259,_255);
return _259;
case NAVIGATION_REQUEST_CHOICE:
this.LogSeq("`1097`",_255);
this.LogSeq("`195`",_255);
if(this.DoesActivityExist(_253,_255)){
var _25a=this.GetActivityFromIdentifier(_253,_255);
var _25b=this.Activities.GetParentActivity(_25a);
if(_25a.IsAvailable()===false){
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-7",null,IntegrationImplementation.GetString("The activity '{0}' was not selected to be delivered in this attempt.",_25a));
this.LogSeqReturn(_259,_255);
return _259;
}
this.LogSeq("`2`",_255);
if(_25a.IsTheRoot()||_25b.LearningObject.SequencingData.ControlChoice===true){
this.LogSeq("`443`",_255);
if(!this.IsCurrentActivityDefined(_255)){
this.LogSeq("`59`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,null,SEQUENCING_REQUEST_CHOICE,null,_25a,"");
this.LogSeqReturn(_259,_255);
return _259;
}
this.LogSeq("`124`",_255);
if(!this.AreActivitiesSiblings(_256,_25a,_255)){
this.LogSeq("`365`",_255);
var _25c=this.FindCommonAncestor(_256,_25a,_255);
this.LogSeq("`1`",_255);
var _25d=this.GetPathToAncestorExclusive(_256,_25c,true);
this.LogSeq("`930`",_255);
if(_25d.length>0){
this.LogSeq("`96`",_255);
for(var i=0;i<_25d.length;i++){
if(_25d[i].LearningObject.ItemIdentifier==_25c.ItemIdentifier){
break;
}
this.LogSeq("`216`"+_25d[i].LearningObject.ItemIdentifier+")",_255);
if(_25d[i].IsActive()===true&&_25d[i].LearningObject.SequencingData.ControlChoiceExit===false){
this.LogSeq("`86`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-8",null,IntegrationImplementation.GetString("You must complete '{0}' before you can select another item.",_25d[i]));
this.LogSeqReturn(_259,_255);
return _259;
}
}
}else{
this.LogSeq("`1548`",_255);
this.LogSeq("`145`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-9",null,IntegrationImplementation.GetString("Nothing to open"));
this.LogSeqReturn(_259,_255);
return _259;
}
}
this.LogSeq("`203`",_255);
if(_256.IsActive()){
this.LogSeq("`56`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_CHOICE,null,_25a,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1579`",_255);
this.LogSeq("`60`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,null,SEQUENCING_REQUEST_CHOICE,null,_25a,"");
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1615`",_255);
this.LogSeq("`99`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-10",null,IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.",_25b.GetTitle()));
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1667`",_255);
this.LogSeq("`87`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-11",null,IntegrationImplementation.GetString("The activity you selected ({0}) does not exist.",_253));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_EXIT:
this.LogSeq("`1163`",_255);
this.LogSeq("`507`",_255);
if(this.IsCurrentActivityDefined(_255)){
this.LogSeq("`292`",_255);
if(_256.IsActive()){
this.LogSeq("`193`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1616`",_255);
this.LogSeq("`75`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-12",null,IntegrationImplementation.GetString("The Exit navigation request is invalid because the current activity ({0}) is no longer active.",_256.GetTitle()));
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1668`",_255);
this.LogSeq("`173`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The Exit navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_EXIT_ALL:
this.LogSeq("`1081`",_255);
this.LogSeq("`269`",_255);
if(this.IsCurrentActivityDefined(_255)){
this.LogSeq("`194`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_EXIT_ALL,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1669`",_255);
this.LogSeq("`180`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The Exit All navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_ABANDON:
this.LogSeq("`1078`",_255);
this.LogSeq("`506`",_255);
if(this.IsCurrentActivityDefined(_255)){
this.LogSeq("`286`",_255);
if(_256.IsActive()){
this.LogSeq("`182`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_ABANDON,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1598`",_255);
this.LogSeq("`153`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-12",null,IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because the current activity '{0}' is no longer active.",_256.GetTitle()));
this.LogSeqReturn(_259,_255);
return _259;
}
}else{
this.LogSeq("`1612`",_255);
this.LogSeq("`166`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_ABANDON_ALL:
this.LogSeq("`998`",_255);
this.LogSeq("`277`",_255);
if(this.IsCurrentActivityDefined(_255)){
this.LogSeq("`167`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_ABANDON_ALL,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1640`",_255);
this.LogSeq("`162`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("You cannot use 'Abandon All' if no item is currently open."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
case NAVIGATION_REQUEST_SUSPEND_ALL:
this.LogSeq("`999`",_255);
this.LogSeq("`538`",_255);
if(this.IsCurrentActivityDefined(_255)){
this.LogSeq("`168`",_255);
_259=new Sequencer_NavigationRequestProcessResult(_252,TERMINATION_REQUEST_SUSPEND_ALL,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_259,_255);
return _259;
}else{
this.LogSeq("`1641`",_255);
this.LogSeq("`169`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The 'Suspend All' navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_259,_255);
return _259;
}
break;
default:
this.LogSeq("`94`",_255);
_259=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-13",null,IntegrationImplementation.GetString("Undefined Navigation Request"));
this.LogSeqReturn(_259,_255);
return _259;
}
}
function Sequencer_NavigationRequestProcessResult(_25f,_260,_261,_262,_263,_264){
this.NavigationRequest=_25f;
this.TerminationRequest=_260;
this.SequencingRequest=_261;
this.Exception=_262;
this.TargetActivity=_263;
this.ExceptionText=_264;
}
Sequencer_NavigationRequestProcessResult.prototype.toString=function(){
return "NavigationRequest="+this.NavigationRequest+", TerminationRequest="+this.TerminationRequest+", SequencingRequest="+this.SequencingRequest+", Exception="+this.Exception+", TargetActivity="+this.TargetActivity+", ExceptionText="+this.ExceptionText;
};
function Sequencer_ObjectiveRollupProcess(_265,_266){
Debug.AssertError("Calling log not passed.",(_266===undefined||_266===null));
var _267=this.LogSeqAudit("`1351`"+_265+")",_266);
this.LogSeq("`1061`",_267);
var _268=null;
this.LogSeq("`628`",_267);
var _268=_265.GetPrimaryObjective();
this.LogSeq("`1058`",_267);
if(_268!==null){
this.LogSeq("`690`",_267);
if(_268.GetSatisfiedByMeasure()===true){
this.LogSeq("`867`",_267);
this.ObjectiveRollupUsingMeasureProcess(_265,_267);
this.LogSeq("`1134`",_267);
this.LogSeqReturn("",_267);
return;
}
this.LogSeq("`590`",_267);
if(Sequencer_GetApplicableSetofRollupRules(_265,RULE_SET_SATISFIED).length>0||Sequencer_GetApplicableSetofRollupRules(_265,RULE_SET_NOT_SATISFIED).length>0){
this.LogSeq("`879`",_267);
this.ObjectiveRollupUsingRulesProcess(_265,_267);
this.LogSeq("`1135`",_267);
this.LogSeqReturn("",_267);
return;
}
this.LogSeq("`386`",_267);
this.ObjectiveRollupUsingDefaultProcess(_265,_267);
this.LogSeq("`1193`",_267);
this.LogSeqReturn("",_267);
return;
}else{
this.LogSeq("`1671`",_267);
this.LogSeq("`482`",_267);
this.LogSeqReturn("",_267);
return;
}
}
function Sequencer_ObjectiveRollupUsingDefaultProcess(_269,_26a){
Debug.AssertError("Calling log not passed.",(_26a===undefined||_26a===null));
var _26b=this.LogSeqAudit("`1020`"+_269+")",_26a);
var _26c;
var _26d;
var _26e;
this.LogSeq("`1238`",_26b);
if(_269.IsALeaf()){
this.LogSeq("`1249`",_26b);
this.LogSeqReturn("",_26b);
return;
}
this.LogSeq("`1026`",_26b);
var _26f=null;
var i;
this.LogSeq("`619`",_26b);
var _26f=_269.GetPrimaryObjective();
this.LogSeq("`1082`",_26b);
var _271=_269.GetChildren();
this.LogSeq("`1042`",_26b);
var _272=true;
this.LogSeq("`1118`",_26b);
var _273=true;
this.LogSeq("`1272`",_26b);
var _274=true;
for(i=0;i<_271.length;i++){
this.LogSeq("`1250`"+(i+1)+" - "+_271[i],_26b);
this.LogSeq("`1083`",_26b);
_26c=_271[i].IsSatisfied();
this.LogSeq("`1084`",_26b);
_26d=_271[i].IsAttempted();
this.LogSeq("`757`",_26b);
_26e=(_26c===false||_26d===true);
this.LogSeq("`1550`"+_26c+"`1711`"+_26d+"`1695`"+_26e,_26b);
if(this.CheckChildForRollupSubprocess(_271[i],ROLLUP_RULE_ACTION_SATISFIED,_26b)){
this.LogSeq("`919`",_26b);
_273=(_273&&(_26c===true));
_274=false;
}
if(this.CheckChildForRollupSubprocess(_271[i],ROLLUP_RULE_ACTION_NOT_SATISFIED,_26b)){
this.LogSeq("`804`",_26b);
_272=(_272&&_26e);
_274=false;
}
}
if(_274&&Control.Package.Properties.RollupEmptySetToUnknown){
this.LogSeq("`542`"+Control.Package.Properties.RollupEmptySetToUnknown+")",_26b);
}else{
this.LogSeq("`1002`"+_272+")",_26b);
if(_272===true){
this.LogSeq("`673`",_26b);
_26f.SetProgressStatus(true,false,_269);
this.LogSeq("`655`",_26b);
_26f.SetSatisfiedStatus(false,false,_269);
}
this.LogSeq("`1085`"+_273+")",_26b);
if(_273===true){
this.LogSeq("`656`",_26b);
_26f.SetProgressStatus(true,false,_269);
this.LogSeq("`644`",_26b);
_26f.SetSatisfiedStatus(true,false,_269);
}
}
this.LogSeqReturn("",_26b);
}
function Sequencer_ObjectiveRollupUsingMeasureProcess(_275,_276){
Debug.AssertError("Calling log not passed.",(_276===undefined||_276===null));
var _277=this.LogSeqAudit("`1021`"+_275+")",_276);
this.LogSeq("`1025`",_277);
var _278=null;
this.LogSeq("`616`",_277);
var _278=_275.GetPrimaryObjective();
this.LogSeq("`1058`",_277);
if(_278!==null){
this.LogSeq("`127`",_277);
if(_278.GetSatisfiedByMeasure()===true){
this.LogSeq("`303`",_277);
if(_278.GetMeasureStatus(_275,false)===false){
this.LogSeq("`627`",_277);
_278.SetProgressStatus(false,false,_275);
}else{
this.LogSeq("`1582`",_277);
this.LogSeq("`130`",_277);
if(_275.IsActive()===false||_275.GetMeasureSatisfactionIfActive()===true){
this.LogSeq("`105`",_277);
if(_278.GetNormalizedMeasure(_275,false)>=_278.GetMinimumSatisfiedNormalizedMeasure()){
this.LogSeq("`609`",_277);
_278.SetProgressStatus(true,false,_275);
this.LogSeq("`605`",_277);
_278.SetSatisfiedStatus(true,false,_275);
}else{
this.LogSeq("`1508`",_277);
this.LogSeq("`610`",_277);
_278.SetProgressStatus(true,false,_275);
this.LogSeq("`601`",_277);
_278.SetSatisfiedStatus(false,false,_275);
}
}else{
this.LogSeq("`1549`",_277);
this.LogSeq("`270`",_277);
_278.SetProgressStatus(false,false,_275);
}
}
}
this.LogSeq("`915`",_277);
this.LogSeqReturn("",_277);
return;
}else{
this.LogSeq("`1671`",_277);
this.LogSeq("`391`",_277);
this.LogSeqReturn("",_277);
return;
}
}
function Sequencer_ObjectiveRollupUsingRulesProcess(_279,_27a){
Debug.AssertError("Calling log not passed.",(_27a===undefined||_27a===null));
var _27b=this.LogSeqAudit("`1054`"+_279+")",_27a);
var _27c;
this.LogSeq("`1040`",_27b);
var _27d=null;
this.LogSeq("`617`",_27b);
var _27d=_279.GetPrimaryObjective();
this.LogSeq("`1059`",_27b);
if(_27d!==null){
this.LogSeq("`294`",_27b);
_27c=this.RollupRuleCheckSubprocess(_279,RULE_SET_NOT_SATISFIED,_27b);
this.LogSeq("`800`",_27b);
if(_27c===true){
this.LogSeq("`651`",_27b);
_27d.SetProgressStatus(true,false,_279);
this.LogSeq("`631`",_27b);
_27d.SetSatisfiedStatus(false,false,_279);
}
this.LogSeq("`327`",_27b);
_27c=this.RollupRuleCheckSubprocess(_279,RULE_SET_SATISFIED,_27b);
this.LogSeq("`801`",_27b);
if(_27c===true){
this.LogSeq("`652`",_27b);
_27d.SetProgressStatus(true,false,_279);
this.LogSeq("`642`",_27b);
_27d.SetSatisfiedStatus(true,false,_279);
}
this.LogSeq("`946`",_27b);
this.LogSeqReturn("",_27b);
return;
}else{
this.LogSeq("`1672`",_27b);
this.LogSeq("`431`",_27b);
this.LogSeqReturn("",_27b);
return;
}
}
function Sequencer_OverallRollupProcess(_27e,_27f){
Debug.AssertError("Calling log not passed.",(_27f===undefined||_27f===null));
var _280=this.LogSeqAudit("`1373`"+_27e+")",_27f);
this.LogSeq("`256`",_280);
var _281=this.GetActivityPath(_27e,true);
this.LogSeq("`1121`",_280);
if(_281.length===0){
this.LogSeq("`894`",_280);
this.LogSeqReturn("",_280);
return;
}
this.LogSeq("`1048`",_280);
var _282;
var _283;
var _284;
var _285;
var _286;
var _287;
var _288;
var _289;
var _28a;
var _28b;
var _28c;
var _28d;
var _28e;
var _28f=new Array();
var _290=false;
for(var i=0;i<_281.length;i++){
if(!_281[i].IsALeaf()){
_281[i].RollupDurations();
}
if(_290){
continue;
}
_282=_281[i].GetPrimaryObjective();
_283=_282.GetMeasureStatus(_281[i],false);
_284=_282.GetNormalizedMeasure(_281[i],false);
_285=_282.GetProgressStatus(_281[i],false);
_286=_282.GetSatisfiedStatus(_281[i],false);
_287=_281[i].GetAttemptProgressStatus();
_288=_281[i].GetAttemptCompletionStatus();
this.LogSeq("`551`",_280);
if(!_281[i].IsALeaf()){
this.LogSeq("`564`",_280);
this.MeasureRollupProcess(_281[i],_280);
}
this.LogSeq("`115`",_280);
this.ObjectiveRollupProcess(_281[i],_280);
this.LogSeq("`126`",_280);
this.ActivityProgressRollupProcess(_281[i],_280);
_289=_282.GetMeasureStatus(_281[i],false);
_28a=_282.GetNormalizedMeasure(_281[i],false);
_28b=_282.GetProgressStatus(_281[i],false);
_28c=_282.GetSatisfiedStatus(_281[i],false);
_28d=_281[i].GetAttemptProgressStatus();
_28e=_281[i].GetAttemptCompletionStatus();
if(!this.LookAhead&&_281[i].IsTheRoot()){
if(_28d!=_287||_28e!=_288){
var _292=(_28d?(_28e?SCORM_STATUS_COMPLETED:SCORM_STATUS_INCOMPLETE):SCORM_STATUS_NOT_ATTEMPTED);
this.WriteHistoryLog("",{ev:"Rollup Completion",v:_292,ai:_281[i].ItemIdentifier});
}
if(_28b!=_285||_28c!=_286){
var _293=(_28b?(_28c?SCORM_STATUS_PASSED:SCORM_STATUS_FAILED):SCORM_STATUS_UNKNOWN);
this.WriteHistoryLog("",{ev:"Rollup Satisfaction",v:_293,ai:_281[i].ItemIdentifier});
}
}
if(_28c!=_286){
_281[i].WasAutoSatisfied=_27e.WasAutoSatisfied;
}
if(_28e!=_288){
_281[i].WasAutoCompleted=_27e.WasAutoCompleted;
}
if(i>0&&_289==_283&&_28a==_284&&_28b==_285&&_28c==_286&&_28d==_287&&_28e==_288){
this.LogSeq("`903`",_280);
_290=true;
}else{
this.LogSeq("`868`",_280);
_28f[_28f.length]=_281[i];
}
}
this.LogSeq("`1275`",_280);
this.LogSeqReturn("",_280);
return _28f;
}
function Sequencer_OverallSequencingProcess(_294){
try{
var _295=null;
var _296=null;
var _297=null;
var _298=null;
var _299=null;
this.ResetException();
var _29a=this.LogSeqAudit("`1352`");
this.LogSeq("`1404`"+this.NavigationRequest,_29a);
if(this.NavigationRequest===null){
var _29b=this.GetExitAction(this.GetCurrentActivity(),_29a);
this.LogSeq("`1038`"+_29b,_29a);
var _29c="";
if(_29b==EXIT_ACTION_EXIT_CONFIRMATION||_29b==EXIT_ACTION_DISPLAY_MESSAGE){
var _29d=Control.Activities.GetRootActivity();
var _29e=(_29d.IsCompleted()||_29d.IsSatisfied());
if(_29e===true){
_29c=IntegrationImplementation.GetString("The course is now complete. Please make a selection to continue.");
}else{
_29c=IntegrationImplementation.GetString("Please make a selection.");
}
}
switch(_29b){
case (EXIT_ACTION_EXIT_NO_CONFIRMATION):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
break;
case (EXIT_ACTION_EXIT_CONFIRMATION):
if(confirm("Would you like to exit the course now?")){
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
}else{
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_29c);
}
break;
case (EXIT_ACTION_GO_TO_NEXT_SCO):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_CONTINUE,null,"");
break;
case (EXIT_ACTION_DISPLAY_MESSAGE):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_29c);
break;
case (EXIT_ACTION_DO_NOTHING):
this.NavigationRequest=null;
break;
case (EXIT_ACTION_REFRESH_PAGE):
Control.RefreshPage();
break;
}
}
if(this.NavigationRequest==null){
this.LogSeqReturn("`1399`",_29a);
return;
}
if(this.NavigationRequest.Type==NAVIGATION_REQUEST_DISPLAY_MESSAGE){
this.LogSeq("`689`",_29a);
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT,null,"");
}
if(this.NavigationRequest.Type==NAVIGATION_REQUEST_EXIT_PLAYER){
this.LogSeq("`813`",_29a);
Control.ExitScormPlayer("Sequencer");
return;
}
this.LogSeq("`756`",_29a);
var _29f=this.NavigationRequestProcess(this.NavigationRequest.Type,this.NavigationRequest.TargetActivity,_29a);
this.LogSeq("`625`",_29a);
if(_29f.NavigationRequest==NAVIGATION_REQUEST_NOT_VALID){
this.LogSeq("`725`",_29a);
this.Exception=_29f.Exception;
this.ExceptionText=_29f.ExceptionText;
this.LogSeq("`846`",_29a);
this.LogSeqReturn("`1745`",_29a);
return false;
}
_295=_29f.TerminationRequest;
_296=_29f.SequencingRequest;
_297=_29f.TargetActivity;
this.LogSeq("`368`",_29a);
if(_295!==null){
this.LogSeq("`706`",_29a);
var _2a0=this.TerminationRequestProcess(_295,_29a);
this.LogSeq("`599`",_29a);
if(_2a0.TerminationRequest==TERMINATION_REQUEST_NOT_VALID){
this.LogSeq("`698`",_29a);
this.Exception=_2a0.Exception;
this.ExceptionText=_2a0.ExceptionText;
this.LogSeq("`822`",_29a);
this.LogSeqReturn("`1745`",_29a);
return false;
}
this.LogSeq("`699`",_29a);
if(_2a0.SequencingRequest!==null){
this.LogSeq("`39`",_29a);
_296=_2a0.SequencingRequest;
}
}
this.LogSeq("`1056`",_29a);
if(_296!==null){
this.LogSeq("`726`",_29a);
var _2a1=this.SequencingRequestProcess(_296,_297,_29a);
this.LogSeq("`608`",_29a);
if(_2a1.SequencingRequest==SEQUENCING_REQUEST_NOT_VALID){
this.LogSeq("`707`",_29a);
this.Exception=_2a1.Exception;
this.ExceptionText=_2a1.ExceptionText;
this.LogSeq("`823`",_29a);
this.LogSeqReturn("`1745`",_29a);
return false;
}
this.LogSeq("`534`",_29a);
if(_2a1.EndSequencingSession===true){
this.LogSeq("`76`",_29a);
Control.ExitScormPlayer("Sequencer");
this.LogSeqReturn("",_29a);
return;
}
this.LogSeq("`583`",_29a);
if(_2a1.DeliveryRequest===null){
this.LogSeq("`824`",_29a);
this.Exception="OP.1.4";
this.ExceptionText=IntegrationImplementation.GetString("Please make a selection.");
this.LogSeqReturn("",_29a);
return;
}
this.LogSeq("`571`",_29a);
_298=_2a1.DeliveryRequest;
}
this.LogSeq("`1098`",_29a);
if(_298!==null){
this.LogSeq("`776`",_29a);
var _2a2=this.DeliveryRequestProcess(_298,_29a);
this.LogSeq("`629`",_29a);
if(_2a2.Valid===false){
this.LogSeq("`727`",_29a);
this.Exception="OP.1.5";
this.ExceptionText=IntegrationImplementation.GetString("Please make a selection.");
this.LogSeq("`825`",_29a);
this.LogSeqReturn("`1745`",_29a);
return false;
}
this.LogSeq("`650`",_29a);
this.ContentDeliveryEnvironmentProcess(_298,_29a);
}
this.LogSeq("`944`",_29a);
this.LogSeqReturn("",_29a);
return;
}
catch(error){
var _2a3="Error in OverallSequencingProcess for SCORM 2004 2nd Edition: ";
if(typeof RegistrationToDeliver!="undefined"&&typeof RegistrationToDeliver.Id!="undefined"){
_2a3=_2a3+"RegistrationId: "+RegistrationToDeliver.Id+", ";
}
Control.Comm.LogOnServer(_2a3,error);
throw error;
}
}
function Sequencer_PreviousSequencingRequestProcess(_2a4){
Debug.AssertError("Calling log not passed.",(_2a4===undefined||_2a4===null));
var _2a5=this.LogSeqAudit("`1131`",_2a4);
var _2a6;
this.LogSeq("`501`",_2a5);
if(!this.IsCurrentActivityDefined(_2a5)){
this.LogSeq("`409`",_2a5);
_2a6=new Sequencer_PreviousSequencingRequestProcessResult(null,"SB.2.8-1",IntegrationImplementation.GetString("You cannot use 'Previous' at this time."));
this.LogSeqReturn(_2a6,_2a5);
return _2a6;
}
var _2a7=this.GetCurrentActivity();
this.LogSeq("`709`",_2a5);
if(!_2a7.IsTheRoot()){
var _2a8=this.Activities.GetParentActivity(_2a7);
this.LogSeq("`300`",_2a5);
if(_2a8.GetSequencingControlFlow()===false){
this.LogSeq("`593`",_2a5);
_2a6=new Sequencer_PreviousSequencingRequestProcessResult(null,"SB.2.8-2",IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.",_2a8.GetTitle()));
this.LogSeqReturn(_2a6,_2a5);
return _2a6;
}
}
this.LogSeq("`131`",_2a5);
var _2a9=this.FlowSubprocess(_2a7,FLOW_DIRECTION_BACKWARD,false,_2a5);
this.LogSeq("`989`",_2a5);
if(_2a9.Deliverable===false){
this.LogSeq("`229`",_2a5);
_2a6=new Sequencer_PreviousSequencingRequestProcessResult(null,_2a9.Exception,_2a9.ExceptionText);
this.LogSeqReturn(_2a6,_2a5);
return _2a6;
}else{
this.LogSeq("`1706`",_2a5);
this.LogSeq("`324`",_2a5);
_2a6=new Sequencer_PreviousSequencingRequestProcessResult(_2a9.IdentifiedActivity,null,"");
this.LogSeqReturn(_2a6,_2a5);
return _2a6;
}
}
function Sequencer_PreviousSequencingRequestProcessResult(_2aa,_2ab,_2ac){
this.DeliveryRequest=_2aa;
this.Exception=_2ab;
this.ExceptionText=_2ac;
}
Sequencer_PreviousSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_RandomizeChildrenProcess(_2ad,_2ae,_2af){
Debug.AssertError("Calling log not passed.",(_2af===undefined||_2af===null));
var _2b0=this.LogSeqAudit("`1335`"+_2ad+")",_2af);
var _2b1;
this.LogSeq("`537`",_2b0);
if(_2ad.IsALeaf()){
this.LogSeq("`1197`",_2b0);
this.LogSeqReturn("",_2b0);
return;
}
this.LogSeq("`155`",_2b0);
if(_2ad.IsActive()===true||_2ad.IsSuspended()===true){
this.LogSeq("`1198`",_2b0);
this.LogSeqReturn("",_2b0);
return;
}
var _2b2=_2ad.GetRandomizationTiming();
switch(_2b2){
case TIMING_NEVER:
this.LogSeq("`853`",_2b0);
this.LogSeq("`1199`",_2b0);
break;
case TIMING_ONCE:
this.LogSeq("`860`",_2b0);
this.LogSeq("`782`",_2b0);
if(_2ad.GetRandomizedChildren()===false){
this.LogSeq("`441`",_2b0);
if(_2ad.GetActivityProgressStatus()===false){
this.LogSeq("`861`",_2b0);
if(_2ad.GetRandomizeChildren()===true){
this.LogSeq("`568`",_2b0);
_2b1=Sequencer_RandomizeArray(_2ad.GetAvailableChildren());
_2ad.SetAvailableChildren(_2b1);
_2ad.SetRandomizedChildren(true);
}
}
}
this.LogSeq("`1200`",_2b0);
break;
case TIMING_ON_EACH_NEW_ATTEMPT:
this.LogSeq("`695`",_2b0);
this.LogSeq("`875`",_2b0);
if(_2ad.GetRandomizeChildren()===true){
this.LogSeq("`586`",_2b0);
_2b1=Sequencer_RandomizeArray(_2ad.GetAvailableChildren());
_2ad.SetAvailableChildren(_2b1);
_2ad.SetRandomizedChildren(true);
if(_2ae===true){
Control.RedrawChildren(_2ad);
}
}
this.LogSeq("`1201`",_2b0);
break;
default:
this.LogSeq("`832`",_2b0);
break;
}
this.LogSeqReturn("",_2b0);
return;
}
function Sequencer_RandomizeArray(ary){
var _2b4=ary.length;
var orig;
var swap;
for(var i=0;i<_2b4;i++){
var _2b8=Math.floor(Math.random()*_2b4);
orig=ary[i];
swap=ary[_2b8];
ary[i]=swap;
ary[_2b8]=orig;
}
return ary;
}
function Sequencer_ResumeAllSequencingRequestProcess(_2b9){
Debug.AssertError("Calling log not passed.",(_2b9===undefined||_2b9===null));
var _2ba=this.LogSeqAudit("`1096`",_2b9);
var _2bb;
this.LogSeq("`499`",_2ba);
if(this.IsCurrentActivityDefined(_2ba)){
this.LogSeq("`400`",_2ba);
_2bb=new Sequencer_ResumeAllSequencingRequestProcessResult(null,"SB.2.6-1",IntegrationImplementation.GetString("A 'Resume All' sequencing request cannot be processed while there is a current activity defined."));
this.LogSeqReturn(_2bb,_2ba);
return _2bb;
}
this.LogSeq("`397`",_2ba);
if(!this.IsSuspendedActivityDefined(_2ba)){
this.LogSeq("`401`",_2ba);
_2bb=new Sequencer_ResumeAllSequencingRequestProcessResult(null,"SB.2.6-2",IntegrationImplementation.GetString("There is no suspended activity to resume."));
this.LogSeqReturn(_2bb,_2ba);
return _2bb;
}
this.LogSeq("`58`",_2ba);
var _2bc=this.GetSuspendedActivity(_2ba);
_2bb=new Sequencer_ResumeAllSequencingRequestProcessResult(_2bc,null,"");
this.LogSeqReturn(_2bb,_2ba);
return _2bb;
}
function Sequencer_ResumeAllSequencingRequestProcessResult(_2bd,_2be,_2bf){
this.DeliveryRequest=_2bd;
this.Exception=_2be;
this.ExceptionText=_2bf;
}
Sequencer_ResumeAllSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_RetrySequencingRequestProcess(_2c0){
Debug.AssertError("Calling log not passed.",(_2c0===undefined||_2c0===null));
var _2c1=this.LogSeqAudit("`1187`",_2c0);
var _2c2;
var _2c3;
this.LogSeq("`488`",_2c1);
if(!this.IsCurrentActivityDefined(_2c1)){
this.LogSeq("`433`",_2c1);
_2c2=new Sequencer_RetrySequencingRequestProcessResult(null,"SB.2.10-1",IntegrationImplementation.GetString("You cannot use 'Resume All' while the current item is open."));
this.LogSeqReturn(_2c2,_2c1);
return _2c2;
}
var _2c4=this.GetCurrentActivity();
this.LogSeq("`101`",_2c1);
if(_2c4.IsActive()||_2c4.IsSuspended()){
this.LogSeq("`434`",_2c1);
_2c2=new Sequencer_RetrySequencingRequestProcessResult(null,"SB.2.10-2",IntegrationImplementation.GetString("A 'Retry' sequencing request cannot be processed while there is an active or suspended activity."));
this.LogSeqReturn(_2c2,_2c1);
return _2c2;
}
this.LogSeq("`970`",_2c1);
if(!_2c4.IsALeaf()){
this.LogSeq("`372`",_2c1);
flowSubProcessResult=this.FlowSubprocess(_2c4,FLOW_DIRECTION_FORWARD,true,_2c1);
this.LogSeq("`949`",_2c1);
if(flowSubProcessResult.Deliverable===false){
this.LogSeq("`407`",_2c1);
_2c2=new Sequencer_RetrySequencingRequestProcessResult(null,"SB.2.10-3",IntegrationImplementation.GetString("You cannot 'Retry' this item because: {1}",_2c4.GetTitle(),flowSubProcessResult.ExceptionText));
this.LogSeqReturn(_2c2,_2c1);
return _2c2;
}else{
this.LogSeq("`1643`",_2c1);
this.LogSeq("`322`",_2c1);
_2c2=new Sequencer_RetrySequencingRequestProcessResult(flowSubProcessResult.IdentifiedActivity,null,"");
this.LogSeqReturn(_2c2,_2c1);
return _2c2;
}
}else{
this.LogSeq("`1690`",_2c1);
this.LogSeq("`489`",_2c1);
_2c2=new Sequencer_RetrySequencingRequestProcessResult(_2c4,null,"");
this.LogSeqReturn(_2c2,_2c1);
return _2c2;
}
}
function Sequencer_RetrySequencingRequestProcessResult(_2c5,_2c6,_2c7){
this.DeliveryRequest=_2c5;
this.Exception=_2c6;
this.ExceptionText=_2c7;
}
Sequencer_RetrySequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_RollupRuleCheckSubprocess(_2c8,_2c9,_2ca){
Debug.AssertError("Calling log not passed.",(_2ca===undefined||_2ca===null));
var _2cb=this.LogSeqAudit("`1267`"+_2c8+", "+_2c9+")",_2ca);
var _2cc;
var _2cd;
var _2ce;
var _2cf;
var _2d0=0;
var _2d1=0;
var _2d2=0;
this.LogSeq("`331`",_2cb);
var _2d3=Sequencer_GetApplicableSetofRollupRules(_2c8,_2c9);
if(_2d3.length>0){
this.LogSeq("`214`",_2cb);
_2cc=_2c8.GetChildren();
this.LogSeq("`1139`",_2cb);
for(var i=0;i<_2d3.length;i++){
this.LogSeq("`747`",_2cb);
contributingChldren=new Array();
_2d0=0;
_2d1=0;
_2d2=0;
this.LogSeq("`1120`",_2cb);
for(var j=0;j<_2cc.length;j++){
this.LogSeq("`969`",_2cb);
if(_2cc[j].IsTracked()===true){
this.LogSeq("`236`",_2cb);
_2cd=this.CheckChildForRollupSubprocess(_2cc[j],_2d3[i].Action,_2cb);
this.LogSeq("`748`",_2cb);
if(_2cd===true){
this.LogSeq("`156`",_2cb);
_2ce=this.EvaluateRollupConditionsSubprocess(_2cc[j],_2d3[i],_2cb);
this.LogSeq("`309`",_2cb);
if(_2ce==RESULT_UNKNOWN){
this.LogSeq("`720`",_2cb);
_2d2++;
if(_2d3[i].ChildActivitySet==CHILD_ACTIVITY_SET_ALL||_2d3[i].ChildActivitySet==CHILD_ACTIVITY_SET_NONE){
j=_2cc.length;
}
}else{
this.LogSeq("`1509`",_2cb);
this.LogSeq("`681`",_2cb);
if(_2ce===true){
this.LogSeq("`771`",_2cb);
_2d0++;
if(_2d3[i].ChildActivitySet==CHILD_ACTIVITY_SET_ANY||_2d3[i].ChildActivitySet==CHILD_ACTIVITY_SET_NONE){
j=_2cc.length;
}
}else{
this.LogSeq("`1510`",_2cb);
this.LogSeq("`761`",_2cb);
_2d1++;
if(_2d3[i].ChildActivitySet==CHILD_ACTIVITY_SET_ALL){
j=_2cc.length;
}
}
}
}
}
}
switch(_2d3[i].ChildActivitySet){
case CHILD_ACTIVITY_SET_ALL:
this.LogSeq("`933`",_2cb);
this.LogSeq("`540`",_2cb);
if(_2d1===0&&_2d2===0){
this.LogSeq("`1140`",_2cb);
_2cf=true;
}
break;
case CHILD_ACTIVITY_SET_ANY:
this.LogSeq("`935`",_2cb);
this.LogSeq("`692`",_2cb);
if(_2d0>0){
this.LogSeq("`1141`",_2cb);
_2cf=true;
}
break;
case CHILD_ACTIVITY_SET_NONE:
this.LogSeq("`921`",_2cb);
this.LogSeq("`546`",_2cb);
if(_2d0===0&&_2d2===0){
this.LogSeq("`1142`",_2cb);
_2cf=true;
}
break;
case CHILD_ACTIVITY_SET_AT_LEAST_COUNT:
this.LogSeq("`815`",_2cb);
this.LogSeq("`271`",_2cb);
if(_2d0>=_2d3[i].MinimumCount){
this.LogSeq("`1143`",_2cb);
_2cf=true;
}
break;
case CHILD_ACTIVITY_SET_AT_LEAST_PERCENT:
this.LogSeq("`792`",_2cb);
this.LogSeq("`118`",_2cb);
var _2d6=(_2d0/(_2d0+_2d1+_2d2));
if(_2d6>=_2d3[i].MinimumPercent){
this.LogSeq("`1144`",_2cb);
_2cf=true;
}
break;
default:
break;
}
this.LogSeq("`1145`",_2cb);
if(_2cf===true){
this.LogSeq("`265`",_2cb);
this.LogSeqReturn("`1749`",_2cb);
return true;
}
}
}
this.LogSeq("`420`",_2cb);
this.LogSeqReturn("`1745`",_2cb);
return false;
}
function Sequencer_GetApplicableSetofRollupRules(_2d7,_2d8){
var _2d9=new Array();
var _2da=_2d7.GetRollupRules();
for(var i=0;i<_2da.length;i++){
switch(_2d8){
case RULE_SET_SATISFIED:
if(_2da[i].Action==ROLLUP_RULE_ACTION_SATISFIED){
_2d9[_2d9.length]=_2da[i];
}
break;
case RULE_SET_NOT_SATISFIED:
if(_2da[i].Action==ROLLUP_RULE_ACTION_NOT_SATISFIED){
_2d9[_2d9.length]=_2da[i];
}
break;
case RULE_SET_COMPLETED:
if(_2da[i].Action==ROLLUP_RULE_ACTION_COMPLETED){
_2d9[_2d9.length]=_2da[i];
}
break;
case RULE_SET_INCOMPLETE:
if(_2da[i].Action==ROLLUP_RULE_ACTION_INCOMPLETE){
_2d9[_2d9.length]=_2da[i];
}
break;
}
}
return _2d9;
}
function Sequencer_SelectChildrenProcess(_2dc,_2dd){
Debug.AssertError("Calling log not passed.",(_2dd===undefined||_2dd===null));
var _2de=this.LogSeqAudit("`1386`"+_2dc+")",_2dd);
this.LogSeq("`561`",_2de);
if(_2dc.IsALeaf()){
this.LogSeq("`1251`",_2de);
this.LogSeqReturn("",_2de);
return;
}
this.LogSeq("`175`",_2de);
if(_2dc.IsActive()===true||_2dc.IsSuspended()===true){
this.LogSeq("`1252`",_2de);
this.LogSeqReturn("",_2de);
return;
}
var _2df=_2dc.GetSelectionTiming();
switch(_2df){
case TIMING_NEVER:
this.LogSeq("`886`",_2de);
this.LogSeq("`1253`",_2de);
break;
case TIMING_ONCE:
this.LogSeq("`895`",_2de);
this.LogSeq("`817`",_2de);
if(_2dc.GetSelectedChildren()===false){
this.LogSeq("`440`",_2de);
if(_2dc.GetActivityProgressStatus()===false){
this.LogSeq("`772`",_2de);
if(_2dc.GetSelectionCountStatus()===true){
this.LogSeq("`887`",_2de);
var _2e0=new Array();
var _2e1=_2dc.GetChildren();
var _2e2=_2dc.GetSelectionCount();
if(_2e2<_2e1.length){
var _2e3=Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_2e2,0,_2e1.length-1);
this.LogSeq("`869`",_2de);
for(var i=0;i<_2e3.length;i++){
this.LogSeq("`536`",_2de);
this.LogSeq("`339`",_2de);
_2e0[i]=_2e1[_2e3[i]];
}
}else{
_2e0=_2e1;
}
this.LogSeq("`773`",_2de);
_2dc.SetAvailableChildren(_2e0);
_2dc.SetSelectedChildren(true);
}
}
}
this.LogSeq("`1254`",_2de);
break;
case TIMING_ON_EACH_NEW_ATTEMPT:
this.LogSeq("`738`",_2de);
this.LogSeq("`896`",_2de);
break;
default:
this.LogSeq("`841`",_2de);
break;
}
this.LogSeqReturn("",_2de);
}
function Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_2e5,_2e6,_2e7){
if(_2e5===null||_2e5===undefined||_2e5<_2e6){
_2e5=_2e6;
}
if(_2e5>_2e7){
_2e5=_2e7;
}
var _2e8=new Array(_2e5);
var _2e9;
var _2ea;
for(var i=0;i<_2e5;i++){
_2ea=true;
while(_2ea){
_2e9=Sequencer_GetRandomNumberWithinRange(_2e6,_2e7);
_2ea=Sequencer_IsNumberAlreadyInArray(_2e9,_2e8);
}
_2e8[i]=_2e9;
}
_2e8.sort();
return _2e8;
}
function Sequencer_GetRandomNumberWithinRange(_2ec,_2ed){
var diff=_2ed-_2ec;
return Math.floor(Math.random()*(diff+_2ec+1));
}
function Sequencer_IsNumberAlreadyInArray(_2ef,_2f0){
for(var i=0;i<_2f0.length;i++){
if(_2f0[i]==_2ef){
return true;
}
}
return false;
}
function Sequencer_SequencingExitActionRulesSubprocess(_2f2){
Debug.AssertError("Calling log not passed.",(_2f2===undefined||_2f2===null));
var _2f3=this.LogSeqAudit("`1055`",_2f2);
this.LogSeq("`249`",_2f3);
var _2f4=this.GetCurrentActivity();
var _2f5=this.Activities.GetParentActivity(_2f4);
var _2f6;
if(_2f5!==null){
_2f6=this.GetActivityPath(_2f5,true);
}else{
_2f6=this.GetActivityPath(_2f4,true);
}
this.LogSeq("`1219`",_2f3);
var _2f7=null;
var _2f8=null;
this.LogSeq("`307`",_2f3);
for(var i=(_2f6.length-1);i>=0;i--){
this.LogSeq("`553`",_2f3);
_2f8=this.SequencingRulesCheckProcess(_2f6[i],RULE_SET_EXIT,_2f3);
this.LogSeq("`739`",_2f3);
if(_2f8!==null){
this.LogSeq("`415`",_2f3);
_2f7=_2f6[i];
this.LogSeq("`1533`",_2f3);
break;
}
}
this.LogSeq("`1202`",_2f3);
if(_2f7!==null){
this.LogSeq("`352`",_2f3);
this.TerminateDescendentAttemptsProcess(_2f7,_2f3);
this.LogSeq("`466`",_2f3);
this.EndAttemptProcess(_2f7,false,_2f3);
this.LogSeq("`348`",_2f3);
this.SetCurrentActivity(_2f7,_2f3);
}
this.LogSeq("`963`",_2f3);
this.LogSeqReturn("",_2f3);
return;
}
function Sequencer_SequencingPostConditionRulesSubprocess(_2fa){
Debug.AssertError("Calling log not passed.",(_2fa===undefined||_2fa===null));
var _2fb=this.LogSeqAudit("`994`",_2fa);
var _2fc;
this.LogSeq("`340`",_2fb);
var _2fd=this.GetCurrentActivity();
if(_2fd.IsSuspended()){
this.LogSeq("`897`",_2fb);
_2fc=new Sequencer_SequencingPostConditionRulesSubprocessResult(null,null);
this.LogSeqReturn(_2fc,_2fb);
return _2fc;
}
this.LogSeq("`190`",_2fb);
var _2fe=this.SequencingRulesCheckProcess(_2fd,RULE_SET_POST_CONDITION,_2fb);
this.LogSeq("`765`",_2fb);
if(_2fe!==null){
this.LogSeq("`587`",_2fb);
if(_2fe==SEQUENCING_RULE_ACTION_RETRY||_2fe==SEQUENCING_RULE_ACTION_CONTINUE||_2fe==SEQUENCING_RULE_ACTION_PREVIOUS){
this.LogSeq("`47`",_2fb);
_2fc=new Sequencer_SequencingPostConditionRulesSubprocessResult(this.TranslateSequencingRuleActionIntoSequencingRequest(_2fe),null);
this.LogSeqReturn(_2fc,_2fb);
return _2fc;
}
this.LogSeq("`620`",_2fb);
if(_2fe==SEQUENCING_RULE_ACTION_EXIT_PARENT||_2fe==SEQUENCING_RULE_ACTION_EXIT_ALL){
this.LogSeq("`85`",_2fb);
_2fc=new Sequencer_SequencingPostConditionRulesSubprocessResult(null,this.TranslateSequencingRuleActionIntoTerminationRequest(_2fe));
this.LogSeqReturn(_2fc,_2fb);
return _2fc;
}
this.LogSeq("`751`",_2fb);
if(_2fe==SEQUENCING_RULE_ACTION_RETRY_ALL){
this.LogSeq("`30`",_2fb);
_2fc=new Sequencer_SequencingPostConditionRulesSubprocessResult(SEQUENCING_REQUEST_RETRY,TERMINATION_REQUEST_EXIT_ALL);
this.LogSeqReturn(_2fc,_2fb);
return _2fc;
}
}
this.LogSeq("`484`",_2fb);
_2fc=new Sequencer_SequencingPostConditionRulesSubprocessResult(null,null);
this.LogSeqReturn(_2fc,_2fb);
return _2fc;
}
function Sequencer_SequencingPostConditionRulesSubprocessResult(_2ff,_300){
this.TerminationRequest=_300;
this.SequencingRequest=_2ff;
}
Sequencer_SequencingPostConditionRulesSubprocessResult.prototype.toString=function(){
return "TerminationRequest="+this.TerminationRequest+", SequencingRequest="+this.SequencingRequest;
};
function Sequencer_SequencingRequestProcess(_301,_302,_303){
Debug.AssertError("Calling log not passed.",(_303===undefined||_303===null));
var _304=this.LogSeqAudit("`1286`"+_301+", "+_302+")",_303);
var _305;
switch(_301){
case SEQUENCING_REQUEST_START:
this.LogSeq("`1122`",_304);
this.LogSeq("`950`",_304);
var _306=this.StartSequencingRequestProcess(_304);
this.LogSeq("`694`",_304);
if(_306.Exception!==null){
this.LogSeq("`81`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_306.Exception,_306.ExceptionText,false);
this.LogSeqReturn(_305,_304);
return _305;
}else{
this.LogSeq("`1644`",_304);
this.LogSeq("`122`",_304);
_305=new Sequencer_SequencingRequestProcessResult(_301,_306.DeliveryRequest,null,null,"",false);
this.LogSeqReturn(_305,_304);
return _305;
}
break;
case SEQUENCING_REQUEST_RESUME_ALL:
this.LogSeq("`1028`",_304);
this.LogSeq("`883`",_304);
var _307=this.ResumeAllSequencingRequestProcess(_304);
this.LogSeq("`645`",_304);
if(_307.Exception!==null){
this.LogSeq("`71`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_307.Exception,_307.ExceptionText,false);
this.LogSeqReturn(_305,_304);
return _305;
}else{
this.LogSeq("`1645`",_304);
this.LogSeq("`108`",_304);
_305=new Sequencer_SequencingRequestProcessResult(_301,_307.DeliveryRequest,null,null,"",false);
this.LogSeqReturn(_305,_304);
return _305;
}
break;
case SEQUENCING_REQUEST_EXIT:
this.LogSeq("`1147`",_304);
this.LogSeq("`959`",_304);
var _308=this.ExitSequencingRequestProcess(_304);
this.LogSeq("`700`",_304);
if(_308.Exception!==null){
this.LogSeq("`83`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_308.Exception,_308.ExceptionText,false);
this.LogSeqReturn(_305,_304);
return _305;
}else{
this.LogSeq("`1646`",_304);
this.LogSeq("`125`",_304);
_305=new Sequencer_SequencingRequestProcessResult(_301,null,_308.EndSequencingSession,null,"",false);
this.LogSeqReturn(_305,_304);
return _305;
}
break;
case SEQUENCING_REQUEST_RETRY:
this.LogSeq("`1123`",_304);
this.LogSeq("`951`",_304);
var _309=this.RetrySequencingRequestProcess(_304);
if(_309.Exception!==null){
this.LogSeq("`82`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_309.Exception,_309.ExceptionText,false);
this.LogSeqReturn(_305,_304);
return _305;
}else{
this.LogSeq("`1647`",_304);
this.LogSeq("`116`",_304);
_305=new Sequencer_SequencingRequestProcessResult(_301,_309.DeliveryRequest,null,null,"",false);
this.LogSeqReturn(_305,_304);
return _305;
}
break;
case SEQUENCING_REQUEST_CONTINUE:
this.LogSeq("`1064`",_304);
this.LogSeq("`904`",_304);
var _30a=this.ContinueSequencingRequestProcess(_304);
this.LogSeq("`660`",_304);
if(_30a.Exception!==null){
this.LogSeq("`72`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_30a.Exception,_30a.ExceptionText,false);
this.LogSeqReturn(_305,_304);
return _305;
}else{
this.LogSeq("`1648`",_304);
this.LogSeq("`112`",_304);
_305=new Sequencer_SequencingRequestProcessResult(_301,_30a.DeliveryRequest,null,null,"",false);
this.LogSeqReturn(_305,_304);
return _305;
}
break;
case SEQUENCING_REQUEST_PREVIOUS:
this.LogSeq("`1065`",_304);
this.LogSeq("`905`",_304);
var _30b=this.PreviousSequencingRequestProcess(_304);
this.LogSeq("`661`",_304);
if(_30b.Exception!==null){
this.LogSeq("`73`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_30b.Exception,_30b.ExceptionText,false);
this.LogSeqReturn(_305,_304);
return _305;
}else{
this.LogSeq("`1649`",_304);
this.LogSeq("`113`",_304);
_305=new Sequencer_SequencingRequestProcessResult(_301,_30b.DeliveryRequest,null,null,"",false);
this.LogSeqReturn(_305,_304);
return _305;
}
break;
case SEQUENCING_REQUEST_CHOICE:
this.LogSeq("`1104`",_304);
this.LogSeq("`937`",_304);
var _30c=this.ChoiceSequencingRequestProcess(_302,_304);
this.LogSeq("`682`",_304);
if(_30c.Exception!==null){
this.LogSeq("`77`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_30c.Exception,_30c.ExceptionText,_30c.Hidden);
this.LogSeqReturn(_305,_304);
return _305;
}else{
this.LogSeq("`1650`",_304);
this.LogSeq("`120`",_304);
_305=new Sequencer_SequencingRequestProcessResult(_301,_30c.DeliveryRequest,null,null,"",_30c.Hidden);
this.LogSeqReturn(_305,_304);
return _305;
}
break;
}
this.LogSeq("`150`",_304);
_305=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,"SB.2.12-1","The sequencing request ("+_301+") is not recognized.",false);
this.LogSeqReturn(_305,_304);
return _305;
}
function Sequencer_SequencingRequestProcessResult(_30d,_30e,_30f,_310,_311,_312){
if(_312===undefined){
Debug.AssertError("undefined hidden value");
}
this.SequencingRequest=_30d;
this.DeliveryRequest=_30e;
this.EndSequencingSession=_30f;
this.Exception=_310;
this.ExceptionText=_311;
this.Hidden=_312;
}
Sequencer_SequencingRequestProcessResult.prototype.toString=function(){
return "SequencingRequest="+this.SequencingRequest+", DeliveryRequest="+this.DeliveryRequest+", EndSequencingSession="+this.EndSequencingSession+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", Hidden="+this.Hidden;
};
function Sequencer_SequencingRulesCheckProcess(_313,_314,_315){
Debug.AssertError("Calling log not passed.",(_315===undefined||_315===null));
var _316=this.LogSeqAudit("`1269`"+_313+", "+_314+")",_315);
var _317;
var _318=Sequencer_GetApplicableSetofSequencingRules(_313,_314);
this.LogSeq("`304`",_316);
if(_318.length>0){
this.LogSeq("`191`",_316);
this.LogSeq("`1203`",_316);
for(var i=0;i<_318.length;i++){
this.LogSeq("`416`",_316);
_317=this.SequencingRulesCheckSubprocess(_313,_318[i],_316);
this.LogSeq("`795`",_316);
if(_317===true){
this.LogSeq("`211`",_316);
this.LogSeqReturn(_318[i].Action,_316);
return _318[i].Action;
}
}
}
this.LogSeq("`460`",_316);
this.LogSeqReturn("`1748`",_316);
return null;
}
function Sequencer_GetApplicableSetofSequencingRules(_31a,_31b){
var _31c=new Array();
if(_31b==RULE_SET_POST_CONDITION){
_31c=_31a.GetPostConditionRules();
}else{
if(_31b==RULE_SET_EXIT){
_31c=_31a.GetExitRules();
}else{
var _31d=_31a.GetPreConditionRules();
for(var i=0;i<_31d.length;i++){
switch(_31b){
case RULE_SET_HIDE_FROM_CHOICE:
if(_31d[i].Action==SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE){
_31c[_31c.length]=_31d[i];
}
break;
case RULE_SET_STOP_FORWARD_TRAVERSAL:
if(_31d[i].Action==SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL){
_31c[_31c.length]=_31d[i];
}
break;
case RULE_SET_DISABLED:
if(_31d[i].Action==SEQUENCING_RULE_ACTION_DISABLED){
_31c[_31c.length]=_31d[i];
}
break;
case RULE_SET_SKIPPED:
if(_31d[i].Action==SEQUENCING_RULE_ACTION_SKIP){
_31c[_31c.length]=_31d[i];
}
break;
default:
Debug.AssertError("ERROR - invalid sequencing rule set - "+_31b);
return null;
}
}
}
}
return _31c;
}
function Sequencer_SequencingRulesCheckSubprocess(_31f,rule,_321){
Debug.AssertError("Calling log not passed.",(_321===undefined||_321===null));
var _322=this.LogSeqAudit("`1160`"+_31f+", "+rule+")",_321);
this.LogSeq("`326`",_322);
var _323=new Array();
var _324;
var _325;
var i;
this.LogSeq("`741`",_322);
for(i=0;i<rule.RuleConditions.length;i++){
this.LogSeq("`102`",_322);
_324=this.EvaluateSequencingRuleCondition(_31f,rule.RuleConditions[i],_322);
this.LogSeq("`703`",_322);
if(rule.RuleConditions[i].Operator==RULE_CONDITION_OPERATOR_NOT){
this.LogSeq("`666`",_322);
if(_324!="unknown"){
_324=(!_324);
}
}
this.LogSeq("`291`",_322);
_323[_323.length]=_324;
}
this.LogSeq("`375`",_322);
if(_323.length===0){
this.LogSeq("`613`",_322);
this.LogSeqReturn(RESULT_UNKNOWN,_322);
return RESULT_UNKNOWN;
}
this.LogSeq("`62`",_322);
if(rule.ConditionCombination==RULE_CONDITION_COMBINATION_ANY){
_325=false;
for(i=0;i<_323.length;i++){
_325=Sequencer_LogicalOR(_325,_323[i]);
}
}else{
_325=true;
for(i=0;i<_323.length;i++){
_325=Sequencer_LogicalAND(_325,_323[i]);
}
}
this.LogSeq("`621`",_322);
this.LogSeqReturn(_325,_322);
return _325;
}
function Sequencer_EvaluateSequencingRuleCondition(_327,_328,_329){
Debug.AssertError("Calling log not passed.",(_329===undefined||_329===null));
var _32a=this.LogSeqAudit("`1311`"+_327+", "+_328+")",_329);
var _32b=null;
switch(_328.Condition){
case SEQUENCING_RULE_CONDITION_SATISFIED:
_32b=_327.IsSatisfied(_328.ReferencedObjective);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
_32b=_327.IsObjectiveStatusKnown(_328.ReferencedObjective,false);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
_32b=_327.IsObjectiveMeasureKnown(_328.ReferencedObjective,false);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN:
_32b=_327.IsObjectiveMeasureGreaterThan(_328.ReferencedObjective,_328.MeasureThreshold,false);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN:
_32b=_327.IsObjectiveMeasureLessThan(_328.ReferencedObjective,_328.MeasureThreshold,false);
break;
case SEQUENCING_RULE_CONDITION_COMPLETED:
_32b=_327.IsCompleted(_328.ReferencedObjective,false);
break;
case SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
_32b=_327.IsActivityProgressKnown(_328.ReferencedObjective,false);
break;
case SEQUENCING_RULE_CONDITION_ATTEMPTED:
_32b=_327.IsAttempted();
break;
case SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
_32b=_327.IsAttemptLimitExceeded();
break;
case SEQUENCING_RULE_CONDITION_ALWAYS:
_32b=true;
break;
default:
Debug.AssertError("ERROR - Encountered unsupported rule condition - "+_328);
_32b=RESULT_UNKNOWN;
break;
}
_32a.setReturn(_32b+"",_32a);
return _32b;
}
function Sequencer_LogicalOR(_32c,_32d){
if(_32c==RESULT_UNKNOWN){
if(_32d===true){
return true;
}else{
return RESULT_UNKNOWN;
}
}else{
if(_32d==RESULT_UNKNOWN){
if(_32c===true){
return true;
}else{
return RESULT_UNKNOWN;
}
}else{
return (_32c||_32d);
}
}
}
function Sequencer_LogicalAND(_32e,_32f){
if(_32e==RESULT_UNKNOWN){
if(_32f===false){
return false;
}else{
return RESULT_UNKNOWN;
}
}else{
if(_32f==RESULT_UNKNOWN){
if(_32e===false){
return false;
}else{
return RESULT_UNKNOWN;
}
}else{
return (_32e&&_32f);
}
}
}
function Sequencer_StartSequencingRequestProcess(_330){
Debug.AssertError("Calling log not passed.",(_330===undefined||_330===null));
var _331=this.LogSeqAudit("`1216`",_330);
var _332;
this.LogSeq("`498`",_331);
if(this.IsCurrentActivityDefined(_331)){
this.LogSeq("`455`",_331);
_332=new Sequencer_StartSequencingRequestProcessResult(null,"SB.2.5-1",IntegrationImplementation.GetString("You cannot 'Start' an item that is already open."));
this.LogSeqReturn(_332,_331);
return _332;
}
this.LogSeq("`318`",_331);
var _333=this.GetRootActivity(_331);
if(_333.IsALeaf()){
this.LogSeq("`240`",_331);
_332=new Sequencer_StartSequencingRequestProcessResult(_333,null,"");
this.LogSeqReturn(_332,_331);
return _332;
}else{
if(Control.Package.Properties.AlwaysFlowToFirstSco===true||Control.Package.Properties.ShowCourseStructure==false){
this.LogSeq("`315`",_331);
this.LogSeq("`1049`",_331);
var _334=this.GetOrderedListOfActivities(_331);
this.LogSeq("`924`",_331);
for(var _335 in _334){
if(_334[_335].IsDeliverable()===true){
_332=new Sequencer_StartSequencingRequestProcessResult(_334[_335],null,"");
this.LogSeqReturn(_332,_331);
return _332;
}
}
_332=new Sequencer_StartSequencingRequestProcessResult(null,"SB.2.5-2.5","There are no deliverable activities in this course.");
this.LogSeqReturn(_332,_331);
return _332;
}else{
this.LogSeq("`1691`",_331);
this.LogSeq("`164`",_331);
var _336=this.FlowSubprocess(_333,FLOW_DIRECTION_FORWARD,true,_331);
this.LogSeq("`973`",_331);
if(_336.Deliverable===false){
this.LogSeq("`233`",_331);
_332=new Sequencer_StartSequencingRequestProcessResult(null,_336.Exception,_336.ExceptionText);
this.LogSeqReturn(_332,_331);
return _332;
}else{
this.LogSeq("`1652`",_331);
this.LogSeq("`325`",_331);
_332=new Sequencer_StartSequencingRequestProcessResult(_336.IdentifiedActivity,null,"");
this.LogSeqReturn(_332,_331);
return _332;
}
}
}
}
function Sequencer_StartSequencingRequestProcessResult(_337,_338,_339){
this.DeliveryRequest=_337;
this.Exception=_338;
this.ExceptionText=_339;
}
Sequencer_StartSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_TerminateDescendentAttemptsProcess(_33a,_33b){
Debug.AssertError("Calling log not passed.",(_33b===undefined||_33b===null));
var _33c=this.LogSeqAudit("`1115`"+_33a+")",_33b);
this.LogSeq("`688`"+this.GetCurrentActivity()+"`1376`"+_33a+")",_33c);
var _33d=this.FindCommonAncestor(_33a,this.GetCurrentActivity(),_33c);
this.LogSeq("`152`"+_33d+"`964`",_33c);
var _33e=this.GetPathToAncestorExclusive(this.GetCurrentActivity(),_33d,false);
var _33f=new Array();
this.LogSeq("`526`",_33c);
if(_33e.length>0){
this.LogSeq("`1051`",_33c);
for(var i=0;i<_33e.length;i++){
this.LogSeq("`474`"+_33e[i].LearningObject.ItemIdentifier,_33c);
_33f=_33f.concat(this.EndAttemptProcess(_33e[i],true,_33c));
}
}
this.LogSeq("`742`",_33c);
var _341=this.GetMinimalSubsetOfActivitiesToRollup(_33f,null);
for(var _342 in _341){
this.OverallRollupProcess(_341[_342],_33c);
}
this.LogSeq("`1012`",_33c);
this.LogSeqReturn("",_33c);
return;
}
function Sequencer_TerminationRequestProcess(_343,_344){
Debug.AssertError("Calling log not passed.",(_344===undefined||_344===null));
var _345=this.LogSeqAudit("`1287`"+_343+")",_344);
var _346;
var _347=this.GetCurrentActivity();
var _348=this.Activities.GetParentActivity(_347);
var _349=this.GetRootActivity(_345);
var _34a;
var _34b=null;
var _34c=false;
this.LogSeq("`367`",_345);
if(!this.IsCurrentActivityDefined(_345)){
this.LogSeq("`381`",_345);
_346=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-1",IntegrationImplementation.GetString("You cannot use 'Terminate' because no item is currently open."));
this.LogSeqReturn(_346,_345);
return _346;
}
this.LogSeq("`88`",_345);
if((_343==TERMINATION_REQUEST_EXIT||_343==TERMINATION_REQUEST_ABANDON)&&(_347.IsActive()===false)){
this.LogSeq("`382`",_345);
_346=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-2",IntegrationImplementation.GetString("The current activity has already been terminated."));
this.LogSeqReturn(_346,_345);
return _346;
}
switch(_343){
case TERMINATION_REQUEST_EXIT:
this.LogSeq("`1151`",_345);
this.LogSeq("`383`",_345);
this.EndAttemptProcess(_347,false,_345);
this.LogSeq("`241`",_345);
this.SequencingExitActionRulesSubprocess(_345);
this.LogSeq("`1629`",_345);
var _34d;
do{
this.LogSeq("`1106`",_345);
_34d=false;
this.LogSeq("`588`"+this.GetCurrentActivity()+")",_345);
_34b=this.SequencingPostConditionRulesSubprocess(_345);
this.LogSeq("`475`",_345);
if(_34b.TerminationRequest==TERMINATION_REQUEST_EXIT_ALL){
this.LogSeq("`906`",_345);
_343=TERMINATION_REQUEST_EXIT_ALL;
this.LogSeq("`674`",_345);
_34c=true;
break;
}
this.LogSeq("`53`",_345);
if(_34b.TerminationRequest==TERMINATION_REQUEST_EXIT_PARENT){
this.LogSeq("`281`",_345);
if(this.GetCurrentActivity()!==null&&this.GetCurrentActivity().IsTheRoot()===false){
this.LogSeq("`675`",_345);
this.SetCurrentActivity(this.Activities.GetParentActivity(this.GetCurrentActivity()),_345);
this.LogSeq("`774`",_345);
this.EndAttemptProcess(this.GetCurrentActivity(),false,_345);
this.LogSeq("`494`",_345);
_34d=true;
}else{
this.LogSeq("`1586`",_345);
this.LogSeq("`355`",_345);
_346=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-4",IntegrationImplementation.GetString("An 'Exit Parent' sequencing request cannot be processed on the root of the activity tree."));
this.LogSeqReturn(_346,_345);
return _346;
}
}else{
this.LogSeq("`1630`",_345);
this.LogSeq("`8`",_345);
if(this.GetCurrentActivity()!==null&&this.GetCurrentActivity().IsTheRoot()===true&&_34b.SequencingRequest!=SEQUENCING_REQUEST_RETRY){
this.LogSeq("`404`",_345);
_346=new Sequencer_TerminationRequestProcessResult(_343,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_346,_345);
return _346;
}
}
this.LogSeq("`910`"+_34d+")",_345);
}while(_34d!==false);
if(!_34c){
this.LogSeq("`54`",_345);
_346=new Sequencer_TerminationRequestProcessResult(_343,_34b.SequencingRequest,null,"");
this.LogSeqReturn(_346,_345);
return _346;
break;
}
case TERMINATION_REQUEST_EXIT_ALL:
this.LogSeq("`1071`",_345);
this.LogSeq("`238`",_345);
if(_347.IsActive()){
this.LogSeq("`818`",_345);
this.EndAttemptProcess(_347,false,_345);
}
this.LogSeq("`589`",_345);
this.TerminateDescendentAttemptsProcess(_349,_345);
this.LogSeq("`740`",_345);
this.EndAttemptProcess(_349,false,_345);
this.LogSeq("`353`",_345);
this.SetCurrentActivity(_349,_345);
this.LogSeq("`3`",_345);
if(_34b!==null&&_34b.SequencingRequest!==null){
this.LogSeq("`451`",_345);
_346=new Sequencer_TerminationRequestProcessResult(_343,_34b.SequencingRequest,null,"");
this.LogSeqReturn(_346,_345);
return _346;
}else{
this.LogSeq("`1030`",_345);
_346=new Sequencer_TerminationRequestProcessResult(_343,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_346,_345);
return _346;
}
break;
case TERMINATION_REQUEST_SUSPEND_ALL:
this.LogSeq("`1008`",_345);
this.LogSeq("`45`",_345);
this.LogSeq("`510`",_345);
this.EndAttemptProcess(_347,false,_345,true);
if(_347.IsActive()||_347.IsSuspended()){
this.LogSeq("`854`",_345);
this.SetSuspendedActivity(_347);
}else{
this.LogSeq("`1681`",_345);
this.LogSeq("`258`",_345);
if(!_347.IsTheRoot()){
this.LogSeq("`676`",_345);
this.SetSuspendedActivity(_348);
}else{
this.LogSeq("`1631`",_345);
this.LogSeq("`263`",_345);
Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-3","The suspend all termination request failed because there is no activity to suspend");
}
}
this.LogSeq("`273`",_345);
_34a=this.GetActivityPath(this.GetSuspendedActivity(_345),true);
this.LogSeq("`1091`",_345);
if(_34a.length===0){
this.LogSeq("`274`",_345);
_346=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-5",IntegrationImplementation.GetString("Nothing to suspend"));
this.LogSeqReturn(_346,_345);
return _346;
}
this.LogSeq("`1009`",_345);
for(var i=0;i<_34a.length;i++){
this.LogSeq("`639`"+_34a[i].GetItemIdentifier()+")",_345);
_34a[i].SetActive(false);
this.LogSeq("`856`",_345);
_34a[i].SetSuspended(true);
}
this.LogSeq("`354`",_345);
this.SetCurrentActivity(_349,_345);
this.LogSeq("`160`",_345);
_346=new Sequencer_TerminationRequestProcessResult(_343,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_346,_345);
return _346;
break;
case TERMINATION_REQUEST_ABANDON:
this.LogSeq("`1092`",_345);
this.LogSeq("`809`",_345);
_347.SetActive(false);
this.LogSeq("`459`",_345);
_346=new Sequencer_TerminationRequestProcessResult(_343,null,null,"");
this.LogSeqReturn(_346,_345);
return _346;
break;
case TERMINATION_REQUEST_ABANDON_ALL:
this.LogSeq("`1010`",_345);
this.LogSeq("`282`",_345);
_34a=this.GetActivityPath(_347,true);
this.LogSeq("`1093`",_345);
if(_34a.length===0){
this.LogSeq("`283`",_345);
_346=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-6",IntegrationImplementation.GetString("Nothing to close"));
this.LogSeqReturn(_346,_345);
return _346;
}
this.LogSeq("`1011`",_345);
for(var i=0;i<_34a.length;i++){
this.LogSeq("`870`",_345);
_34a[i].SetActive(false);
}
this.LogSeq("`360`",_345);
this.SetCurrentActivity(_349,_345);
this.LogSeq("`165`",_345);
_346=new Sequencer_TerminationRequestProcessResult(_343,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_346,_345);
return _346;
break;
default:
this.LogSeq("`255`",_345);
_346=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-7",IntegrationImplementation.GetString("The 'Termination' request {0} is not recognized.",_343));
this.LogSeqReturn(_346,_345);
return _346;
break;
}
}
function Sequencer_TerminationRequestProcessResult(_34f,_350,_351,_352){
this.TerminationRequest=_34f;
this.SequencingRequest=_350;
this.Exception=_351;
this.ExceptionText=_352;
}
Sequencer_TerminationRequestProcessResult.prototype.toString=function(){
return "TerminationRequest="+this.TerminationRequest+", SequencingRequest="+this.SequencingRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function SSPApi(_353,_354){
this.MaxSSPStorage=parseInt(_353,10);
this.ApiInstance=_354;
}
SSPApi.prototype.InitializeBuckets=SSPApi_InitializeBuckets;
SSPApi.prototype.CheckForGetValueError=SSPApi_CheckForGetValueError;
SSPApi.prototype.CheckForSetValueError=SSPApi_CheckForSetValueError;
SSPApi.prototype.RetrieveGetValueData=SSPApi_RetrieveGetValueData;
SSPApi.prototype.StoreValue=SSPApi_StoreValue;
SSPApi.prototype.GetBucketById=SSPApi_GetBucketById;
SSPApi.prototype.GetBucketByIndex=SSPApi_GetBucketByIndex;
SSPApi.prototype.GetAccessibleBucketCount=SSPApi_GetAccessibleBucketCount;
SSPApi.prototype.GetDelimiterValues=SSPApi_GetDelimiterValues;
SSPApi.prototype.RemoveDelimitersFromElementName=SSPApi_RemoveDelimitersFromElementName;
SSPApi.prototype.RemoveDelimitersFromValue=SSPApi_RemoveDelimitersFromValue;
SSPApi.prototype.GetDelimiterValues=SSPApi_GetDelimiterValues;
SSPApi.prototype.GetCurrentSCOItemIdentifier=SSPApi_GetCurrentSCOItemIdentifier;
SSPApi.prototype.AllocateBucket=SSPApi_AllocateBucket;
SSPApi.prototype.GetStorageAllowedByLms=SSPApi_GetStorageAllowedByLms;
SSPApi.prototype.ResetBucketsForActivity=SSPApi_ResetBucketsForActivity;
SSPApi.prototype.SetErrorState=SSPApi_SetErrorState;
SSPApi.prototype.WriteDetailedLog=SSPApi_WriteDetailedLog;
function SSPApi_InitializeBuckets(){
var _355;
var _356;
var _357;
for(var i=0;i<Control.SSPBuckets.length;i++){
_355=Control.SSPBuckets[i];
if(_355.AllocationSuccess==SSP_ALLOCATION_SUCCESS_NOT_ATTEMPTED){
_356=this.GetStorageAllowedByLms(_355.SizeMin,_355.SizeRequested);
if(_356==null){
_357=SSP_ALLOCATION_SUCCESS_FAILURE;
}else{
if(_356==_355.SizeMin){
_357=SSP_ALLOCATION_SUCCESS_MINIMUM;
}else{
if(_356==_355.SizeRequested){
_357=SSP_ALLOCATION_SUCCESS_REQUESTED;
}else{
Debug.AssertError("Invalid allocation");
}
}
}
_355.AllocationSuccess=_357;
}
}
}
function SSPApi_CheckForGetValueError(_359,_35a,_35b,_35c){
var _35d=this.RemoveDelimitersFromElementName(_35a);
var _35e=this.GetDelimiterValues(_359);
var _35f;
var _360;
var size;
if(_35b!==""){
var _362=this.GetAccessibleBucketCount();
if(_35b>=_362){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The SSP Bucket collection does not have an element at index "+_35b+", the current element count is "+_362+".");
return false;
}
}
switch(_35d){
case "ssp._count":
this.WriteDetailedLog("`1560`");
break;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The ssp.allocate data model element is write-only.");
return false;
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
break;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
break;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
break;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
_35f=this.GetBucketByIndex(_35b);
_360=_35e["offset"];
size=_35e["size"];
if(_35f.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_360!=null){
_360=new String(_360);
if(_360.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_360=parseInt(_360,10);
if(_360%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_360>=_35f.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_35f.SizeAllocated()+" bytes of storage. Bytes started at offset "+_360+"were requested.");
return false;
}
}
if(size!=null){
size=new String(size);
if(size.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be a valid even integer greater than 0.");
return false;
}
size=parseInt(size,10);
if(size%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be an even integer.");
return false;
}
if((_360+size)>=_35f.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Requested data exceeds available data. This bucket currently has allocated "+_35f.SizeAllocated()+" bytes of storage. "+size+" bytes starting at offset "+_360+" were requested. Size + Offset = "+(size+_360));
return false;
}
}
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The ssp.n.appendData data model element is write-only.");
return false;
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
if(_35e["bucketID"]==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_35f=this.GetBucketById(_35e["bucketID"],true);
if(_35f==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_35e["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
_360=_35e["offset"];
size=_35e["size"];
if(_35f.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_360!=null){
_360=new String(_360);
if(_360.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_360=parseInt(_360,10);
if(_360%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_360>=_35f.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_35f.SizeAllocated()+" bytes of storage. Bytes starting at offset "+_360+" were requested.");
return false;
}
}
if(size!=null){
size=new String(size);
if(size.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be a valid even integer greater than 0.");
return false;
}
size=parseInt(size,10);
if(size%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be an even integer.");
return false;
}
if((_360+size)>=_35f.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Requested data exceeds available data. This bucket currently has allocated "+_35f.SizeAllocated()+" bytes of storage. "+size+" bytes started at offset "+_360+" were requested. Size + Offset = "+(size+_360));
return false;
}
}
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
var _363=_35e["bucketID"];
if(_363==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_35f=this.GetBucketById(_363,true);
if(_35f==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_35e["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
if(_35f.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket improperly declared.");
}
break;
case "ssp.appendData":
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The ssp.appendData data model element is write-only.");
return false;
break;
default:
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_359+"' does not exist.");
return false;
break;
}
this.WriteDetailedLog("`1547`");
return true;
}
function SSPApi_CheckForSetValueError(_364,_365,_366,_367,_368){
var _369=this.RemoveDelimitersFromElementName(_366);
var _36a=this.GetDelimiterValues(_365);
_365=this.RemoveDelimitersFromValue(_365);
var _36b;
var _36c;
var _36d;
if(_367!==""){
var _36e=this.GetAccessibleBucketCount();
if(_367>=_36e){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The SSP Bucket collection does not have an element at index "+_367+", the current element count is "+_36e+".");
return false;
}
}
switch(_369){
case "ssp._count":
this.WriteDetailedLog("`1560`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp._count data model element is read-only");
return false;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
var _36f=_36a["bucketID"];
var _370=_36a["minimum"];
var _371=_36a["requested"];
var _372=_36a["reducible"];
var _373=_36a["persistence"];
var type=_36a["type"];
if(_36f==null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The bucketID delimiter must be included in calls to ssp.allocate.");
return false;
}
_36f=new String(_36f);
if(_36f.length>4000){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The bucketID can only have a maximum of 4000 characters.");
return false;
}
if(_371==null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The requested delimiter must be included in calls to ssp.allocate.");
return false;
}
_371=new String(_371);
if(_371.search(/\D/)>=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested must be a valid integer greater than or equal to 0.");
return false;
}
_371=parseInt(_371,10);
if(_371<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested must be greater than or equal to 0.");
return false;
}
if(_371%2!=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested must be an even number.");
return false;
}
var _375=(Math.pow(2,32)-1);
if(_371>_375){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested is bigger than the max size this LMS allows of "+_375+".");
return false;
}
if(_370!=null){
_370=new String(_370);
if(_370.search(/\D/)>=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum must be a valid integer greater than or equal to 0.");
return false;
}
_370=parseInt(_370,10);
if(_370<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum must be greater than or equal to 0.");
return false;
}
if(_370%2!=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum must be an even number.");
return false;
}
if(_370>_375){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum is bigger than the max size this LMS allows of "+_375+".");
return false;
}
if(_370>_371){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The minimum requested amount of storage ("+_370+") cannot be greater than the requested amount ("+_371+").");
return false;
}
}
if(_372!=null){
_372=new String(_372);
if(_372!="true"&&_372!="false"){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The reducible delimiter ('"+_372+"') must be 'true' or 'false'.");
return false;
}
}
if(_373!=null){
_373=new String(_373);
if(_373!=SSP_PERSISTENCE_LEARNER&&_373!=SSP_PERSISTENCE_COURSE&&_373!=SSP_PERSISTENCE_SESSION){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The persistence delimiter ('"+_373+"') must be "+SSP_PERSISTENCE_SESSION+", '"+SSP_PERSISTENCE_COURSE+"' or '"+SSP_PERSISTENCE_LEARNER+"'.");
return false;
}
}
type=new String(type);
if(type.length>3000){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The bucket type can only have a maximum of 3000 characters.");
return false;
}
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.n.allocation_success data model element is read-only");
return false;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.n.bucket_id data model element is read-only");
return false;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.n.bucket_state data model element is read-only");
return false;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
_36d=this.GetBucketByIndex(_367);
_36c=_36a["offset"];
if(_36d.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_36c!=null){
_36c=new String(_36c);
if(_36c.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_36c=parseInt(_36c,10);
if(_36c%2!=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_36c>=_36d.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_36d.SizeAllocated()+" bytes of storage. Setting bytes started at offset "+_36c+" was requested.");
return false;
}
if(_36c>=_36d.CurrentlyUsedStorage()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket not packed. There are currently "+_36d.CurrentlyUsedStorage()+" bytes of data stored in this bucket. The offset must be "+"less than this value.");
return false;
}
}else{
_36c=0;
}
_36b=_36c+(_365.length*2);
if(_36b>_36d.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_365.length*2)+" bytes (each character is 2 bytes). Added to an offset of "+_36c+" bytes, gives a total size of "+_36b+", which is greater than the allocated size of this bucket ("+_36d.SizeAllocated()+" bytes).");
return false;
}
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
_36d=this.GetBucketByIndex(_367);
if(_36d.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
_36b=_36d.CurrentlyUsedStorage()+(_365.length*2);
if(_36b>_36d.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_365.length*2)+" bytes (each character is 2 bytes). Added to the current value of size "+_36d.CurrentlyUsedStorage()+" bytes, gives a total size of "+_36b+", which is greater than the allocated size of this bucket ("+_36d.SizeAllocated()+" bytes).");
return false;
}
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
if(_36a["bucketID"]==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_36d=this.GetBucketById(_36a["bucketID"],true);
if(_36d==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_36a["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
_36c=_36a["offset"];
if(_36d.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_36c!=null){
_36c=new String(_36c);
if(_36c.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_36c=parseInt(_36c,10);
if(_36c%2!=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_36c>=_36d.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_36d.SizeAllocated()+" bytes of storage. Setting bytes started at offset "+_36c+" was requested.");
return false;
}
if(_36c>=_36d.CurrentlyUsedStorage()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket not packed. There are currently "+_36d.CurrentlyUsedStorage()+" bytes of data stored in this bucket. The offset must be "+"less than this value.");
return false;
}
}else{
_36c=0;
}
_36b=_36c+(_365.length*2);
if(_36b>_36d.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_365.length*2)+" bytes (each character is 2 bytes). Added to an offset of "+_36c+" bytes, gives a total size of "+_36b+", which is greater than the allocated size of this bucket ("+_36d.SizeAllocated()+" bytes).");
return false;
}
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.bucket_state data model element is read-only");
return false;
case "ssp.appendData":
this.WriteDetailedLog("`1483`");
if(_36a["bucketID"]==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_36d=this.GetBucketById(_36a["bucketID"],true);
if(_36d==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_36a["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
if(_36d.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
_36b=_36d.CurrentlyUsedStorage()+(_365.length*2);
if(_36b>_36d.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_365.length*2)+" bytes (each character is 2 bytes). Added to the current value of size "+_36d.CurrentlyUsedStorage()+" bytes, gives a total size of "+_36b+", which is greater than the allocated size of this bucket ("+_36d.SizeAllocated()+" bytes).");
return false;
}
break;
default:
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_364+"' does not exist.");
return false;
break;
}
this.WriteDetailedLog("`1547`");
return true;
}
function SSPApi_RetrieveGetValueData(_376,_377,_378,_379){
var _37a=this.RemoveDelimitersFromElementName(_377);
var _37b=this.GetDelimiterValues(_376);
var _37c="";
switch(_37a){
case "ssp._count":
this.WriteDetailedLog("`1560`");
_37c=this.GetAccessibleBucketCount();
break;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
Debug.AssertError("ERROR - Element is Write Only, ssp.allocate");
blnReturn=false;
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
var _37d=this.GetBucketByIndex(_378);
_37c=_37d.AllocationSuccess;
break;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
_37d=this.GetBucketByIndex(_378);
_37c=_37d.Id;
break;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
_37d=this.GetBucketByIndex(_378);
_37c=_37d.GetBucketState();
break;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
_37d=this.GetBucketByIndex(_378);
_37c=_37d.GetData(_37b["offset"],_37b["size"]);
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
Debug.AssertError("ERROR - Element is Write Only, ssp.n.appendData");
blnReturn=false;
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
_37d=this.GetBucketById(_37b["bucketID"],true);
_37c=_37d.GetData(_37b["offset"],_37b["size"]);
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
_37d=this.GetBucketById(_37b["bucketID"],true);
_37c=_37d.GetBucketState();
break;
case "ssp.appendData":
Debug.AssertError("ERROR - Element is Write Only, ssp.appendData");
blnReturn=false;
break;
default:
Debug.AssertError("ERROR - Unrecognized data model element:"+_37a);
blnReturn=false;
break;
}
return _37c;
}
function SSPApi_StoreValue(_37e,_37f,_380,_381,_382){
var _383=this.RemoveDelimitersFromElementName(_380);
var _384=this.GetDelimiterValues(_37f);
_37f=this.RemoveDelimitersFromValue(_37f);
var _385=true;
switch(_383){
case "ssp._count":
this.WriteDetailedLog("`1560`");
Debug.AssertError("ERROR - Element is Read Only, ssp._count");
_385=false;
break;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
this.AllocateBucket(_384["bucketID"],_384["minimum"],_384["requested"],_384["reducible"],_384["persistence"],_384["type"]);
_385=true;
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
Debug.AssertError("ERROR - Element is Read Only, ssp._count");
_385=false;
break;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
_385=false;
break;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_state");
_385=false;
break;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
bucket=this.GetBucketByIndex(_381);
bucket.WriteData(_384["offset"],_37f);
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
bucket=this.GetBucketByIndex(_381);
bucket.AppendData(_37f);
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
bucket=this.GetBucketById(_384["bucketID"],true);
bucket.WriteData(_384["offset"],_37f);
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
_385=false;
break;
case "ssp.appendData":
this.WriteDetailedLog("`1483`");
bucket=this.GetBucketById(_384["bucketID"],true);
bucket.AppendData(_37f);
break;
default:
Debug.AssertError("ERROR - Unrecognized data model element:"+_383);
_385=false;
break;
}
return _385;
}
function SSPApi_GetBucketById(_386,_387){
var _388=null;
for(var _389 in Control.SSPBuckets){
if((_387==false)||Control.SSPBuckets[_389].IsVisible(this.GetCurrentSCOItemIdentifier())){
if(Control.SSPBuckets[_389].Id==_386){
return Control.SSPBuckets[_389];
}
}
}
return _388;
}
function SSPApi_GetBucketByIndex(_38a){
var _38b=null;
i=0;
for(var _38c in Control.SSPBuckets){
if(Control.SSPBuckets[_38c].IsVisible(this.GetCurrentSCOItemIdentifier())){
if(i==_38a){
return Control.SSPBuckets[_38c];
}
i++;
}
}
return _38b;
}
function SSPApi_GetAccessibleBucketCount(){
var _38d=0;
for(var _38e in Control.SSPBuckets){
if(Control.SSPBuckets[_38e].IsVisible(this.GetCurrentSCOItemIdentifier())){
_38d++;
}
}
return _38d;
}
function SSPApi_RemoveDelimitersFromElementName(_38f){
var _390;
var _391;
_38f=new String(_38f);
_391=_38f;
_390=_38f.indexOf("{");
if(_390>0){
_391=_38f.substr(0,_390-1);
}
return _391.toString();
}
function SSPApi_RemoveDelimitersFromValue(_392){
var _393=/^\{\w+=[^\s\}]+\}/;
_392=new String(_392);
while(_392.match(_393)){
_392=_392.replace(_393,"");
}
return _392;
}
function SSPApi_GetDelimiterValues(_394){
var _395=/\{\w+=[^\s\}]+\}/g;
var _396=_394.match(_395);
var _397=new Array();
if(_396!=null){
for(var i=0;i<_396.length;i++){
var _399=_396[i].slice(1,-1);
var _39a=_399.split("=");
_397[_39a[0]]=[_39a[1]];
}
}
return _397;
}
function SSPApi_GetCurrentSCOItemIdentifier(){
return Control.Sequencer.GetCurrentActivity().ItemIdentifier;
}
function SSPApi_AllocateBucket(_39b,_39c,_39d,_39e,_39f,type){
var _3a1=this.GetBucketById(_39b,false);
var _3a2;
if(_39c==undefined||type=="minimum"){
_39c=0;
}
if(_39e==undefined||type=="reducible"){
redicible=false;
}
if(_39f==undefined||type=="persistence"){
_39f="learner";
}
if(type==undefined||type=="undefined"){
type="";
}
if(_3a1!=null){
if(_3a1.SizeMin!=_39c||_3a1.SizeRequested!=_39d||_3a1.Reducible!=_39e||_3a1.Persistence!=_39f||_3a1.BucketType!=type){
_3a2=Control.SSPBuckets.length;
Control.SSPBuckets[_3a2]=new SSPBucket(_3a2,_39b,type,_39f,_39c,_39d,_39e,this.GetCurrentSCOItemIdentifier(),SSP_ALLOCATION_SUCCESS_FAILURE,"");
Control.SSPBuckets[_3a2].SetDirtyData();
}
}else{
var _3a3=this.GetStorageAllowedByLms(_39c,_39d);
var _3a4;
if(_3a3==null){
_3a4=SSP_ALLOCATION_SUCCESS_FAILURE;
}else{
if(_3a3==_39c){
_3a4=SSP_ALLOCATION_SUCCESS_MINIMUM;
}else{
if(_3a3==_39d){
_3a4=SSP_ALLOCATION_SUCCESS_REQUESTED;
}else{
Debug.AssertError("Invalid allocation");
}
}
}
_3a2=Control.SSPBuckets.length;
Control.SSPBuckets[_3a2]=new SSPBucket(_3a2,_39b,type,_39f,_39c,_39d,_39e,(_39f==SSP_PERSISTENCE_SESSION?this.GetCurrentSCOItemIdentifier():""),_3a4,"");
Control.SSPBuckets[_3a2].SetDirtyData();
}
}
function SSPApi_GetStorageAllowedByLms(_3a5,_3a6){
_3a5=parseInt(_3a5,10);
_3a6=parseInt(_3a6,10);
var _3a7=0;
for(var i=0;i<Control.SSPBuckets.length;i++){
_3a7+=Control.SSPBuckets[i].SizeAllocated();
}
if((_3a7+_3a6)<=this.MaxSSPStorage){
return _3a6;
}else{
if(_3a5>0&&((_3a7+_3a5)<=this.MaxSSPStorage)){
return _3a5;
}else{
return null;
}
}
}
function SSPApi_ResetBucketsForActivity(_3a9){
var _3aa;
for(var i=0;i<Control.SSPBuckets.length;i++){
_3aa=Control.SSPBuckets[i];
if(_3aa.LocalActivityId==_3a9&&_3aa.Persistence==SSP_PERSISTENCE_SESSION){
_3aa.ResetData();
}
}
}
function SSPApi_SetErrorState(_3ac,_3ad){
this.ApiInstance.SetErrorState(_3ac,_3ad);
}
function SSPApi_WriteDetailedLog(str){
this.ApiInstance.WriteDetailedLog(str);
}

