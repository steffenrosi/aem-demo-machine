/**********************************************************
PropertiesEditor.js

Rustici Software

To embed the properties editor, include the following in your web page:

<script type="text/javascript">
    var PropsEditorHelperUrl = '<ScormEngineUrl from SCORMEngineSettings>' + '</EngineUtilsHelper.aspx or /EngineUtilsHelper.jsp>';
    var ScormEngineScriptsUrl = '<same as in your SCORMEngineSettings.config>';
    var packageId = '<the ExternalPackageId string of the package you want to edit properties for>';
    var PropertiesEditorStylesUrl = "<optional setting if you choose to override the default styles - otherwise leave this line out>";
</script>
<script src="<%=ScormEngineScriptsUrl%>/thirdparty/jquery-1.4.3.min.js" type="text/javascript"></script>
<script type="text/javascript" src="http://localhost/ScormEngineTrunk/ScormEngine/scripts_src/EngineUtils/PropertiesEditor.js"></script>
<div id="PropertiesControl"></div>

***********************************************************/

var Properties;
var Presets;
var LearningStandard;

// Now properly passing along externalConfig.  This should be defined by the hosting page, but for older users of the control which don't have
// this defined we'll default it to empty string so they don't break.
if (typeof(externalConfig) == "undefined") {
    var externalConfig = "";
}

// In case Prototype is also being used on this page
jQuery.noConflict();

(function($pe){
    if (typeof(PropertiesEditorStylesUrl) != 'undefined') {
        $pe('head').append('<link href="' + PropertiesEditorStylesUrl + '" type="text/css" rel="stylesheet" />');
    } else {
        $pe('head').append('<link href="' + ScormEngineScriptsUrl + '/EngineUtils/PropertiesEditor.css" type="text/css" rel="stylesheet" />');
    }


    // Load the Properties Editor strings.
    var useDefaultLanguage = (typeof languageCode === 'undefined' || languageCode == null || languageCode.length == 0 || languageCode == "default");

    function LoadDefaultStrings(deferred) {
        GetCachedScript(ScormEngineScriptsUrl + '/resources/EngineUtilsStrings.js')
            .done(deferred.resolve)
            .fail(deferred.reject);
    }

    var stringsLoaded = $pe.Deferred();
    if (useDefaultLanguage) {
        LoadDefaultStrings(stringsLoaded);
    } else {
        GetCachedScript(ScormEngineScriptsUrl + '/resources/EngineUtilsStrings.' + languageCode + '.js')
            .done(stringsLoaded.resolve)
            .fail(function() {
                LoadDefaultStrings(stringsLoaded);
            });
    }


    // Once everything is loaded, kick it off.
    $pe.when(
        GetCachedScript(ScormEngineScriptsUrl + '/thirdparty/jquery.hoverIntent.minified.js'),
        GetCachedScript(ScormEngineScriptsUrl + '/EngineUtils/rs.tooltips.js'),
        stringsLoaded
    ).fail(function() {
        alert("Failed to load Properties Editor resources.");
    }).done(function() {
        PE_BuildEditor();
    })


    function PE_BuildEditor() {
        //wait until the document is loaded...
        $pe(function() {
            $pe("#pe_Message").html("Loading Properties...");
            $pe.ajax({
                type: "POST",
                url: PropsEditorHelperUrl,
                dataType: "xml",
                data: "method=GetPackagePropertiesXml&externalPkgId=" + packageId + "&externalConfig=" + externalConfig,
                //contentType: "text/xml",
                success: function(xml) {
                    if (xml.firstChild == undefined) {
                        Properties = xml.childNodes[1]; //ie
                    } else {
                        Properties = xml.firstChild;//firefox
                    }

                    PE_GetLearningStandard();
                    PE_BuildPropertiesForm();
                    PE_GetPropertyPresets();
                    PE_GetPackageTitle();

                    helpTextDictionary = HelpStrings;
                    tooltip($pe('#pe_PropertiesEditor'));
                } //close success
            });
        });
    }


    function PE_GetPropertyPresets() {
        $pe.ajax({
            type: "POST",
            url: PropsEditorHelperUrl,
            dataType: "xml",
            data: "method=GetPackagePropertiesPresets&externalPkgId=" + packageId + "&externalConfig=" + externalConfig,
            //contentType: "text/xml",
            success: function(xml) {
                if(xml.firstChild == undefined) {
                    Presets = xml.childNodes[1]; //ie
                } else {
                    Presets = xml.firstChild; //firefox
                }
                AddPropertyPresets();
            } //close success
        });
    }


    function PE_GetPackageTitle() {
        $pe.ajax({
            type: "POST",
            url: PropsEditorHelperUrl,
            dataType: "html",
            data: "method=GetPackageTitle&externalPkgId=" + packageId + "&externalConfig=" + externalConfig,
            //contentType: "text/xml",
            success: function(title) {
                $pe("#pe_PackageTitleText").html($pe.trim(title)); //ie
            } //close success
        });
    }


    function PE_GetLearningStandard() {
        $pe.ajax({
            type: "POST",
            url: PropsEditorHelperUrl,
            dataType: "html",
            data: "method=GetPackageLearningStandard&externalPkgId=" + packageId + "&externalConfig=" + externalConfig,
            //contentType: "text/xml",
            success: function(html) {
                //alert(xml.documentElement.firstChild.nodeValue);
                LearningStandard = $pe.trim(html);
                //alert(LearningStandard);
                $pe("#pe_LearningStandardText").text(LearningStandard);

                SetLearningStandardClass();
                UpdateForLearningStandard();
                $pe("#pe_ddlScormEdition option").each(function() {
                    if ($pe(this).text() == LearningStandard) {
                        $pe("#pe_ddlScormEdition").attr('originalval', $pe(this).val());
                        $pe(this).prop("selected", true);
                    }
                });

                ActivateTab($pe('.pe_tablink:visible:first'));
            } //close success
        });
    }


    /*********************************************
     ***           Update Functions
     **********************************************/
    function UpdateForLearningStandard() {
        if ($pe("#pe_PropertiesEditor").hasClass('notscorm2004')) {
            //remove items that only appear for scorm2004
            $pe("#pe_ReturnToLmsAction").hide();
        } else if($pe("#pe_PropertiesEditor").hasClass('scorm2004')) {
            //remove items that only appear for !scorm2004
            $pe("#pe_ShowChoiceNav").hide();
            $pe("#pe_ckbShowChoiceNav").hide();
        }
    }


    function SetPropertyXml(propertyXml) {
        if (typeof updateAllVersions == 'undefined') {
            updateAllVersions = true;
        }

        $pe("#pe_Message").html("Saving Changes...");
        $pe.ajax({
            type: "POST",
            url: PropsEditorHelperUrl,
            dataType: "json",
            data: "method=SetPackagePropertiesXml&externalPkgId=" + packageId + "&externalConfig=" + externalConfig + "&propertyXml=" + propertyXml + "&updateAllVersions=" + updateAllVersions,
            //contentType: "application/json",
            success: function(msg) {
                //alert(msg);
                //var Properties = eval("(" + msg + ")");
                SetOriginalValues();
                $pe("#pe_Message").html("Changes Saved");
            }
        });
    }


    function UpdatePackageLearningStandard(LearningStandardValue) {
        $pe("#pe_Message").html("Saving Changes...");
        $pe.ajax({
            type: "POST",
            url: PropsEditorHelperUrl,
            dataType: "json",
            data: "method=UpdatePackageLearningStandard&externalPkgId=" + packageId + "&externalConfig=" + externalConfig + "&NewLearningStandardString=" + LearningStandardValue
            //contentType: "application/json",
            //success: function(msg){}
        });
    }


    function AddPropertyPreset(presetname, propertyXml) {
        $pe("#pe_Message").html("Adding Preset");
        $pe.ajax({
            type: "POST",
            url: PropsEditorHelperUrl,
            dataType: "json",
            data: "method=AddPackagePropertiesPreset&externalPkgId=" + packageId + "&externalConfig=" + externalConfig + "&presetTitle=" + presetname + "&propertyXml=" + propertyXml,
            //contentType: "application/json",
            success: function(msg) {
                //alert(msg);
                //var Properties = eval("(" + msg + ")");
                $pe("#pe_Message").html("Preset Added");
                PE_GetPropertyPresets();
            }
        });
    }


    function DeletePropertyPreset(presetId) {
        $pe("#pe_Message").html("Deleting Preset");
        $pe.ajax({
            type: "POST",
            url: PropsEditorHelperUrl,
            dataType: "json",
            data: "method=DeletePackagePropertiesPreset&externalConfig=" + externalConfig + "&presetid=" + presetId,
            //contentType: "application/json",
            success: function(msg) {
                //alert(msg);
                //var Properties = eval("(" + msg + ")");
                $pe("#pe_Message").html("Preset Deleted");
            }
        });
    }


    function PopulateForm(propertiesXml) {
        $pe(propertiesXml).find("controls").each(function() {
            $pe("#pe_ckbShowNavBar").attr("checked", ConvertYesNo($pe(this).find('showNavBar').text()));
            $pe("#pe_ckbShowFinishButton").attr("checked", ConvertYesNo($pe(this).find('showFinishButton').text()));
            $pe("#pe_ckbShowCloseItem").attr("checked", ConvertYesNo($pe(this).find('showCloseItem').text()));
            $pe("#pe_ckbShowProgressBar").attr("checked", ConvertYesNo($pe(this).find('showProgressBar').text()));
            $pe("#pe_ckbUseMeasureProgressBar").attr("checked", ConvertYesNo($pe(this).find('useMeasureProgressBar').text()));
            $pe("#pe_ckbShowHelp").attr("checked", ConvertYesNo($pe(this).find('showHelp').text()));
            $pe("#pe_ckbShowTitleBar").attr("checked", ConvertYesNo($pe(this).find('showTitleBar').text()));

            $pe("#pe_ckbShowChoiceNav").attr("checked", ConvertYesNo($pe(this).find('enableChoiceNav').text()));
            $pe("#pe_ckbShowPrevNext").attr("checked", ConvertYesNo($pe(this).find('enableFlowNav').text()));

            $pe("#pe_ckbShowCourseStructure").attr("checked", ConvertYesNo($pe(this).find('showCourseStructure').text()));
            $pe("#pe_ckbCourseStructureStartsOpen").attr("checked", ConvertYesNo($pe(this).find('courseStructureStartsOpen').text()));
            $pe("#pe_ddlStatusDisplayPreference").val($pe(this).find('statusDisplay').text());

            $pe("#pe_ckbForceDisableRootChoice").attr("checked", ConvertYesNo($pe(this).find("launch").children("forceDisableRootChoice").text()));
            //$pe("#").attr("checked",ConvertYesNo($pe(this).find('enableFlowNav').text()));
            //$pe("#").attr("checked",ConvertYesNo($pe(this).find('enableChoiceNav').text()));
        });

        $pe(propertiesXml).find("appearence").each(function() {
            $pe("#pe_txtCourseStructureWidth").attr("value", $pe(this).find('courseStructureWidth').text());

            if ($pe(this).find('displayStage').children('required').children('width').text() > 0 && $pe(this).find('displayStage').children('required').children('height').text() > 0) {
                $pe("#pe_ckbRequiredDems").attr("checked", true);
                $pe("#pe_txtWidthForContent").val($pe(this).find('displayStage').children('required').children('width').text());
                $pe("#pe_txtHeightForContent").val($pe(this).find('displayStage').children('required').children('height').text());
            } else {
                $pe("#pe_ckbRequiredDems").attr("checked",false);
                $pe("#pe_txtWidthForContent").val($pe(this).find('displayStage').children('desired').children('width').text());
                $pe("#pe_txtHeightForContent").val($pe(this).find('displayStage').children('desired').children('height').text());
            }

            // Check for fullscreen
            if (ConvertYesNo($pe(this).find('displayStage').children('desired').children('fullscreen').text()) || ConvertYesNo($pe(this).find('displayStage').children('required').children('fullscreen').text())) {
                $pe("#pe_rdoFullScreen").attr("checked", true);
                $pe("#pe_txtWidthForContent").attr("disabled", true);
                $pe("#pe_txtHeightForContent").attr("disabled", true);
            } else {
                $pe("#pe_rdoFullScreen").attr("checked", false);
                if ($pe(this).find('displayStage').children('desired').children('width').text() == "0" && $pe(this).find('displayStage').children('required').children('width').text() == "0") {
                    // not fullscreen and no desired or required width set - must be User Defined
                    $pe("#pe_rdoSpecifyNewWindowDems").attr("checked", false);
                    $pe("#pe_txtWidthForContent").attr("disabled", true);
                    $pe("#pe_txtHeightForContent").attr("disabled", true);
                } else {
                    $pe("#pe_rdoSpecifyNewWindowDems").attr("checked", true);
                    $pe("#pe_txtWidthForContent").attr("disabled", false);
                    $pe("#pe_txtHeightForContent").attr("disabled", false);
                }
            }
        });

        $pe(propertiesXml).find("behavior").each(function() {
            $pe("#pe_ckbPreventRightClick").attr("checked", ConvertYesNo($pe(this).find('disableRightClick').text()));
            $pe("#pe_ckbPreventWindowResize").attr("checked", ConvertYesNo($pe(this).find('preventWindowResize').text()));
            $pe("#pe_ckbIsAvailableOffline").attr("checked", ConvertYesNo($pe(this).find('isAvailableOffline').text()));
            $pe("#pe_ddlInvalidMenuItemAction").val($pe(this).find('invalidMenuItemAction').text());
            $pe("#pe_ddlScoLaunchType").val($pe(this).find("launch").children("sco").text());
            $pe("#pe_ddlPlayerLaunchType").val($pe(this).find("launch").children("player").text());
            $pe("#pe_ckbFinishCausesImmediateCommit").attr("checked", ConvertYesNo($pe(this).find("finishCausesImmediateCommit").text()));
            $pe("#pe_ckbLogoutCausesPlayerExit").attr("checked", ConvertYesNo($pe(this).find("logoutCausesPlayerExit").text()));
            $pe("#pe_ckbWrapSCOWindowWithAPI").attr("checked", ConvertYesNo($pe(this).find("launch").children("wrapScoWindowWithApi").text()));
            $pe("#pe_ckbAlwaysFlowToFirstSCO").attr("checked", ConvertYesNo($pe(this).find("alwaysFlowToFirstSco").text()));
            $pe("#pe_ckbValidateInteractionResponses").attr("checked", ConvertYesNo($pe(this).find("validateInteractionTypes").text()));
            $pe("#pe_ckbScoreOverridesStatus").attr("checked", ConvertYesNo($pe(this).find("scoreOverridesStatus").text()));
            $pe("#pe_ckbAllowCompleteStatusChange").attr("checked", ConvertYesNo($pe(this).find("allowCompleteStatusChange").text()));
            $pe("#pe_ckbRawScoreCanActAsScaledScore").attr("checked", ConvertYesNo($pe(this).find("scaleRawScore").text()));
            $pe("#pe_ckbRollupEmptySetToUnknown").attr("checked", ConvertYesNo($pe(this).find("rollupEmptySetToUnknown").text()));
            $pe("#pe_ddlIeCompatibilityMode").val($pe(this).find("ieCompatibilityMode").text());

            //Sequencer Mode
            $pe("#pe_ddlSequencerMode").val($pe(this).find("lookaheadSequencerMode").text());
            $pe("#pe_ckbUseQuickLookaheadSeq").attr("checked", ConvertYesNo($pe(this).find("useQuickLookaheadSequencer").text()));

            //Reset Runtime Data Timing
            $pe("#pe_ddlResetRunTimeDataTiming").val($pe(this).find("resetRtTiming").text());

            //SCORM 2004 Edition - handled via ajaxw
            //Return to LMS Action
            $pe("#pe_ddlReturnToLmsAction").val($pe(this).find("returnToLmsAction").text());

            //Maximum Suspend Data Size
            $pe("#pe_txtMaximumSuspendDataSize").val($pe(this).find("suspendDataMaxLength").text());

            $pe("#pe_ddlCompletionStatOfFailedSuccessStat").val($pe(this).find("completionStatOfFailedSuccessStat").text());

            $pe("#pe_ckbRollupRuntimeAtScoUnload").attr("checked", ConvertYesNo($pe(this).find("rollupRuntimeAtScoUnload").text()));
            $pe("#pe_ckbForceObjectiveCompletionSetByContent").attr("checked", ConvertYesNo($pe(this).find("forceObjectiveCompletionSetByContent").text()));
            $pe("#pe_ckbInvokeRollupAtSuspendAll").attr("checked", ConvertYesNo($pe(this).find("invokeRollupAtSuspendAll").text()));
            $pe("#pe_ckbSatisfiedCausesCompletion").attr("checked", ConvertYesNo($pe(this).find("satisfiedCausesCompletion").text()));
            $pe("#pe_ckbMakeStudentPrefsGlobalToCourse").attr("checked", ConvertYesNo($pe(this).find("makeStudentPrefsGlobalToCourse").text()));
            $pe("#pe_ckbLaunchCompletedRegsAsNoCredit").attr("checked", ConvertYesNo($pe(this).find("launchCompletedRegsAsNoCredit").text()));

            //MaxFailedAttempts
            $pe("#pe_txtMaximumFailedAttempts").val($pe(this).find("communications").children("maxFailedSubmissions").text());

            //Commit Frequency
            $pe("#pe_txtCommitFrequency").val($pe(this).find("communications").children("commitFrequency").text());

            //Time Limit
            $pe("#pe_txtTimeLimit").val($pe(this).find("timeLimit").text());

            //Debugger Options
            $pe("#pe_rdoControlOff").attr("checked", true); // set this one by default

            if ($pe(this).find('controlAudit').text() == "true") {
                $pe("#pe_rdoControlAudit").attr("checked", true);
            }

            if ($pe(this).find('controlDetailed').text() == "true") {
                $pe("#pe_rdoControlDetailed").attr("checked", true);
            }

            $pe("#pe_rdoRuntimeOff").attr("checked", true); // set this one by default

            if ($pe(this).find('runtimeAudit').text() == "true") {
                $pe("#pe_rdoRuntimeAudit").attr("checked", true);
            }

            if ($pe(this).find('runtimeDetailed').text() == "true") {
                $pe("#pe_rdoRuntimeDetailed").attr("checked", true);
            }

            $pe("#pe_rdoSequencingOff").attr("checked", true); //set this one by default

            if ($pe(this).find('sequencingAudit').text() == "true") {
                $pe("#pe_rdoSequencingAudit").attr("checked",true);
            }

            if ($pe(this).find('sequencingDetailed').text() == "true") {
                $pe("#pe_rdoSequencingDetailed").attr("checked", true);
            }

            if ($pe(this).find("sequencingSimple").text() == 'true') {
                $pe("#pe_ckbDebugSequencingSimple").attr("checked", true);
            } else {
                $pe("#pe_ckbDebugSequencingSimple").attr("checked", false);
            }

            $pe("#pe_rdoLookOff").attr("checked", true); //set this one by default

            if ($pe(this).find('lookaheadAudit').text() == "true") {
                $pe("#pe_rdoLookAudit").attr("checked", true);
            }

            if ($pe(this).find('lookaheadDetailed').text() == "true") {
                $pe("#pe_rdoLookDetailed").attr("checked",true);
            }

            if ($pe(this).find("includeTimestamps").text() == 'true') {
                $pe("#pe_ckbIncludeTimestamps").attr("checked", true);
            } else {
                $pe("#pe_ckbIncludeTimestamps").attr("checked", false);
            }

            // Exit Actions
            // alert($pe(this).find("exitActions").children("intermediateSco").children("satisfied").children("normal").text());
            $pe("#pe_ddlIntNormalSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("satisfied").children("normal").text());
            $pe("#pe_ddlIntNormalNotSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("notSatisfied").children("normal").text());
            $pe("#pe_ddlIntSuspendSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("satisfied").children("suspend").text());
            $pe("#pe_ddlIntSuspendNotSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("notSatisfied").children("suspend").text());
            $pe("#pe_ddlIntTimeoutSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("satisfied").children("timeout").text());
            $pe("#pe_ddlIntTimeoutNotSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("notSatisfied").children("timeout").text());
            $pe("#pe_ddlIntLogoutSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("satisfied").children("logout").text());
            $pe("#pe_ddlIntLogoutNotSatisfied").val($pe(this).find("exitActions").children("intermediateSco").children("notSatisfied").children("logout").text());

            $pe("#pe_ddlFinalNormalSatisfied").val($pe(this).find("exitActions").children("finalSco").children("satisfied").children("normal").text());
            $pe("#pe_ddlFinalNormalNotSatisfied").val($pe(this).find("exitActions").children("finalSco").children("notSatisfied").children("normal").text());
            $pe("#pe_ddlFinalSuspendSatisfied").val($pe(this).find("exitActions").children("finalSco").children("satisfied").children("suspend").text());
            $pe("#pe_ddlFinalSuspendNotSatisfied").val($pe(this).find("exitActions").children("finalSco").children("notSatisfied").children("suspend").text());
            $pe("#pe_ddlFinalTimeoutSatisfied").val($pe(this).find("exitActions").children("finalSco").children("satisfied").children("timeout").text());
            $pe("#pe_ddlFinalTimeoutNotSatisfied").val($pe(this).find("exitActions").children("finalSco").children("notSatisfied").children("timeout").text());
            $pe("#pe_ddlFinalLogoutSatisfied").val($pe(this).find("exitActions").children("finalSco").children("satisfied").children("logout").text());
            $pe("#pe_ddlFinalLogoutNotSatisfied").val($pe(this).find("exitActions").children("finalSco").children("notSatisfied").children("logout").text());

            //rudimentaty rollup
            $pe("#pe_ddlScoreRollupMode").val($pe(this).find("scoreRollupMode").text());
            $pe("#pe_txtNumScoringObjects").val($pe(this).find("numberOfScoringObjects").text());

            $pe("#pe_ddlStatusRollupMode").val($pe(this).find("statusRollupMode").text());
            $pe("#pe_txtThresholdScoreForCompletion").val($pe(this).find("thresholdScoreForCompletion").text());
            $pe("#pe_ckbApplyRollupStatusToSuccess").attr("checked", ConvertYesNo($pe(this).find("applyRollupStatusToSuccess").text()));
            $pe("#pe_ckbFirstScoIsPretest").attr("checked", ConvertYesNo($pe(this).find("firstScoIsPretest").text()));

            $pe(this).find("history").each(function() {
                $pe("#pe_ckbCaptureHistory").attr("checked", ConvertYesNo($pe(this).find('captureHistory').text()));
                $pe("#pe_ckbCaptureDetailedHistory").attr("checked", ConvertYesNo($pe(this).find('captureHistoryDetailed').text()));
            });
        }); //end behavior each

        $pe(propertiesXml).find("heuristics").each(function() {
            $pe("#pe_ckbIsCompletionTracked").attr("checked", ConvertYesNo($pe(this).find('isCompletionTracked').text()));
            $pe("#pe_ckbIsSatisfactionTracked").attr("checked", ConvertYesNo($pe(this).find('isSatisfactionTracked').text()));
            $pe("#pe_ckbIsScoreTracked").attr("checked", ConvertYesNo($pe(this).find('isScoreTracked').text()));
            $pe("#pe_ckbIsIncompleteScoreMeaningful").attr("checked", ConvertYesNo($pe(this).find('isIncompleteScoreMeaningful').text()));
            $pe("#pe_ckbIsIncompleteSatisfactionMeaningful").attr("checked", ConvertYesNo($pe(this).find('isIncompleteSatisfactionMeaningful').text()));
        }); //end heuristics each
    }


    function UpdatePropertiesFromCurrentSettings(xmlProperties)
    {
        UpdateYesNoField(xmlProperties, "pe_ckbShowNavBar"," showNavBar");
        UpdateYesNoField(xmlProperties, "pe_ckbShowFinishButton", "showFinishButton");
        UpdateYesNoField(xmlProperties, "pe_ckbShowCloseItem", "showCloseItem");
        UpdateYesNoField(xmlProperties, "pe_ckbShowPrevNext", "enableFlowNav");
        UpdateYesNoField(xmlProperties, "pe_ckbShowChoiceNav", "enableChoiceNav");
        UpdateYesNoField(xmlProperties, "pe_ckbShowProgressBar", "showProgressBar");
        UpdateYesNoField(xmlProperties, "pe_ckbUseMeasureProgressBar", "useMeasureProgressBar");
        UpdateYesNoField(xmlProperties, "pe_ckbShowHelp", "showHelp");
        UpdateYesNoField(xmlProperties, "pe_ckbShowTitleBar", "showTitleBar");
        UpdateYesNoField(xmlProperties, "pe_ckbPreventRightClick", "disableRightClick");
        UpdateYesNoField(xmlProperties, "pe_ckbShowCourseStructure", "showCourseStructure");
        UpdateYesNoField(xmlProperties, "pe_ckbCourseStructureStartsOpen", "courseStructureStartsOpen");

        $pe(xmlProperties).find('courseStructureWidth').text($pe('#pe_txtCourseStructureWidth').val());
        $pe(xmlProperties).find('statusDisplay').text($pe('#pe_ddlStatusDisplayPreference').val());
        $pe(xmlProperties).find('invalidMenuItemAction').text($pe("#pe_ddlInvalidMenuItemAction").val());

        UpdateYesNoField(xmlProperties, "pe_ckbForceDisableRootChoice", "forceDisableRootChoice");

        // Set Properties for Launch Behavior
        $pe(xmlProperties).find('launch').children('sco').text($pe("#pe_ddlScoLaunchType").val());
        $pe(xmlProperties).find('launch').children('player').text($pe("#pe_ddlPlayerLaunchType").val());

        // Full Screen
        if ($pe("#pe_rdoFullScreen:checked").val() == undefined) {
            // it's been unchecked
            $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("fullscreen").text('no');
            $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("fullscreen").text('no');
        } else if ($pe("#pe_rdoFullScreen:checked").val() == 'on') {
            // it's been checked
            if ($pe("#pe_ckbRequiredDems:checked").val() == 'on') {
                $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("fullscreen").text('yes');
                $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("fullscreen").text('no');
            } else {
                $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("fullscreen").text('yes');
                $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("fullscreen").text('no');
            }
        }

        // New Window Dems
        if ($pe("#pe_rdoSpecifyNewWindowDems:checked").val() == undefined) {
            // it's been unchecked
        } else if ($pe("#pe_rdoSpecifyNewWindowDems:checked").val() == 'on') {
            // it's been checked
            // remove fullscreen
            $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("fullscreen").text('no');
            $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("fullscreen").text('no');
            // add the width and height where appropriate
            if ($pe("#pe_ckbRequiredDems").is(':checked')) {
                $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("width").text($pe("#pe_txtWidthForContent").val());
                $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("height").text($pe("#pe_txtHeightForContent").val());
                //set the others to zero
                $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("width").text("0");
                $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("height").text("0");
            } else {
                $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("width").text($pe("#pe_txtWidthForContent").val());
                $pe(xmlProperties).find("appearence").children("displayStage").children("desired").children("height").text($pe("#pe_txtHeightForContent").val());
                //set the others to zero
                $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("width").text("0");
                $pe(xmlProperties).find("appearence").children("displayStage").children("required").children("height").text("0");
            }
        }

        UpdateYesNoField(xmlProperties, "pe_ckbPreventWindowResize", "preventWindowResize");
        UpdateYesNoField(xmlProperties, "pe_ckbIsAvailableOffline", "isAvailableOffline");
        UpdateYesNoField(xmlProperties, "pe_ckbFinishCausesImmediateCommit", "finishCausesImmediateCommit");
        UpdateYesNoField(xmlProperties, "pe_ckbLogoutCausesPlayerExit", "logoutCausesPlayerExit");
        UpdateYesNoField(xmlProperties, "pe_ckbWrapSCOWindowWithAPI", "wrapScoWindowWithApi");
        UpdateYesNoField(xmlProperties, "pe_ckbAlwaysFlowToFirstSCO", "alwaysFlowToFirstSco");
        UpdateYesNoField(xmlProperties, "pe_ckbValidateInteractionResponses", "validateInteractionTypes");
        UpdateYesNoField(xmlProperties, "pe_ckbScoreOverridesStatus", "scoreOverridesStatus");
        UpdateYesNoField(xmlProperties, "pe_ckbAllowCompleteStatusChange", "allowCompleteStatusChange");
        UpdateYesNoField(xmlProperties, "pe_ckbRawScoreCanActAsScaledScore", "scaleRawScore");
        UpdateYesNoField(xmlProperties, "pe_ckbRollupEmptySetToUnknown", "rollupEmptySetToUnknown");

        $pe(xmlProperties).find("lookaheadSequencerMode").text($pe("#pe_ddlSequencerMode").val());
        $pe(xmlProperties).find("resetRtTiming").text($pe("#pe_ddlResetRunTimeDataTiming").val());

        $pe(xmlProperties).find("completionStatOfFailedSuccessStat").text($pe("#pe_ddlCompletionStatOfFailedSuccessStat").val());

        UpdateYesNoField(xmlProperties, "pe_ckbUseQuickLookaheadSeq", "useQuickLookaheadSequencer");

        $pe(xmlProperties).find("returnToLmsAction").text($pe("#pe_ddlReturnToLmsAction").val());

        $pe(xmlProperties).find("ieCompatibilityMode").text($pe("#pe_ddlIeCompatibilityMode").val());

        $pe(xmlProperties).find("suspendDataMaxLength").text($pe("#pe_txtMaximumSuspendDataSize").val());

        // rollupRuntimeAtScoUnload
        UpdateYesNoField(xmlProperties, "pe_ckbRollupRuntimeAtScoUnload", "rollupRuntimeAtScoUnload");
        UpdateYesNoField(xmlProperties, "pe_ckbForceObjectiveCompletionSetByContent", "forceObjectiveCompletionSetByContent");
        UpdateYesNoField(xmlProperties, "pe_ckbInvokeRollupAtSuspendAll", "invokeRollupAtSuspendAll");
        UpdateYesNoField(xmlProperties, "pe_ckbSatisfiedCausesCompletion", "satisfiedCausesCompletion");
        UpdateYesNoField(xmlProperties, "pe_ckbMakeStudentPrefsGlobalToCourse", "makeStudentPrefsGlobalToCourse");
        UpdateYesNoField(xmlProperties, "pe_ckbLaunchCompletedRegsAsNoCredit", "launchCompletedRegsAsNoCredit");

        //MaxFailedAttempts
        $pe(xmlProperties).find("maxFailedSubmissions").text($pe("#pe_txtMaximumFailedAttempts").val());

        //Commit Frequency
        $pe(xmlProperties).find("commitFrequency").text($pe("#pe_txtCommitFrequency").val());

        //Time Limit
        $pe(xmlProperties).find("timeLimit").text($pe("#pe_txtTimeLimit").val());

        // Debugger Options
        if ($pe("#pe_rdoControlOff:checked").val() == 'on') {
            $pe(xmlProperties).find('controlAudit').text("false");
            $pe(xmlProperties).find('controlDetailed').text("false");
        } else {
            if ($pe("#pe_rdoControlAudit:checked").val() == 'on') {
                $pe(xmlProperties).find('controlAudit').text("true");
                $pe(xmlProperties).find('controlDetailed').text("false");
            } else {
                $pe(xmlProperties).find('controlAudit').text("false");
                $pe(xmlProperties).find('controlDetailed').text("true");
            }
        }

        if ($pe("#pe_rdoRuntimeOff:checked").val() == 'on') {
            $pe(xmlProperties).find('runtimeAudit').text("false");
            $pe(xmlProperties).find('runtimeDetailed').text("false");
        } else {
            if ($pe("#pe_rdoRuntimeAudit:checked").val() == 'on') {
                $pe(xmlProperties).find('runtimeAudit').text("true");
                $pe(xmlProperties).find('runtimeDetailed').text("false");
            } else {
                $pe(xmlProperties).find('runtimeAudit').text("false");
                $pe(xmlProperties).find('runtimeDetailed').text("true");
            }
        }

        if ($pe("#pe_rdoSequencingOff:checked").val() == 'on') {
            $pe(xmlProperties).find('sequencingAudit').text("false");
            $pe(xmlProperties).find('sequencingDetailed').text("false");
        } else {
            if ($pe("#pe_rdoSequencingAudit:checked").val()=='on') {
                $pe(xmlProperties).find('sequencingAudit').text("true");
                $pe(xmlProperties).find('sequencingDetailed').text("false");
            } else {
                $pe(xmlProperties).find('sequencingAudit').text("false");
                $pe(xmlProperties).find('sequencingDetailed').text("true");
            }
        }

        if($pe("#pe_ckbDebugSequencingSimple:checked").val() == 'on') {
            $pe(xmlProperties).find('sequencingSimple').text("true");
        } else {
            $pe(xmlProperties).find('sequencingSimple').text("false");
        }

        if ($pe("#pe_rdoLookOff:checked").val() == 'on')
        {
            $pe(xmlProperties).find('lookaheadAudit').text("false");
            $pe(xmlProperties).find('lookaheadDetailed').text("false");
        } else {
            if ($pe("#pe_rdoLookAudit:checked").val() == 'on') {
                $pe(xmlProperties).find('lookaheadAudit').text("true");
                $pe(xmlProperties).find('lookaheadDetailed').text("false");
            } else {
                $pe(xmlProperties).find('lookaheadAudit').text("false");
                $pe(xmlProperties).find('lookaheadDetailed').text("true");
            }
        }

        UpdateYesNoField(xmlProperties, "pe_ckbIncludeTimestamps", "includeTimestamps");

        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('satisfied').children('normal').text($pe('#pe_ddlIntNormalSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('notSatisfied').children('normal').text($pe('#pe_ddlIntNormalNotSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('satisfied').children('suspend').text($pe('#pe_ddlIntSuspendSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('notSatisfied').children('suspend').text($pe('#pe_ddlIntSuspendNotSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('satisfied').children('timeout').text($pe('#pe_ddlIntTimeoutSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('notSatisfied').children('timeout').text($pe('#pe_ddlIntTimeoutNotSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('satisfied').children('logout').text($pe('#pe_ddlIntLogoutSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('intermediateSco').children('notSatisfied').children('logout').text($pe('#pe_ddlIntLogoutNotSatisfied').val());

        $pe(xmlProperties).find('exitActions').children('finalSco').children('satisfied').children('normal').text($pe('#pe_ddlFinalNormalSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('finalSco').children('notSatisfied').children('normal').text($pe('#pe_ddlFinalNormalNotSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('finalSco').children('satisfied').children('suspend').text($pe('#pe_ddlFinalSuspendSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('finalSco').children('notSatisfied').children('suspend').text($pe('#pe_ddlFinalSuspendNotSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('finalSco').children('satisfied').children('timeout').text($pe('#pe_ddlFinalTimeoutSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('finalSco').children('notSatisfied').children('timeout').text($pe('#pe_ddlFinalTimeoutNotSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('finalSco').children('satisfied').children('logout').text($pe('#pe_ddlFinalLogoutSatisfied').val());
        $pe(xmlProperties).find('exitActions').children('finalSco').children('notSatisfied').children('logout').text($pe('#pe_ddlFinalLogoutNotSatisfied').val());

        $pe(xmlProperties).find('scoreRollupMode').text($pe('#pe_ddlScoreRollupMode').val());
        $pe(xmlProperties).find('numberOfScoringObjects').text($pe('#pe_txtNumScoringObjects').val());
        $pe(xmlProperties).find('statusRollupMode').text($pe('#pe_ddlStatusRollupMode').val());
        $pe(xmlProperties).find('thresholdScoreForCompletion').text($pe('#pe_txtThresholdScoreForCompletion').val());
        UpdateYesNoField(xmlProperties, "pe_ckbApplyRollupStatusToSuccess", "applyRollupStatusToSuccess");
        UpdateYesNoField(xmlProperties, "pe_ckbFirstScoIsPretest", "firstScoIsPretest");

        UpdateYesNoField(xmlProperties, "pe_ckbCaptureHistory", "captureHistory");
        UpdateYesNoField(xmlProperties, "pe_ckbCaptureDetailedHistory", "captureHistoryDetailed");

        UpdateYesNoField(xmlProperties, "pe_ckbIsCompletionTracked", "isCompletionTracked");
        UpdateYesNoField(xmlProperties, "pe_ckbIsSatisfactionTracked", "isSatisfactionTracked");
        UpdateYesNoField(xmlProperties, "pe_ckbIsScoreTracked", "isScoreTracked");
        UpdateYesNoField(xmlProperties, "pe_ckbIsIncompleteScoreMeaningful", "isIncompleteScoreMeaningful");
        UpdateYesNoField(xmlProperties, "pe_ckbIsIncompleteSatisfactionMeaningful", "isIncompleteSatisfactionMeaningful");
    }


    function UpdateYesNoField(xmlProperties, controlId, xmlNodeName) {
        if ($pe("#" + controlId + ":checked").val() == undefined) {
            // it's been unchecked
            $pe(xmlProperties).find(xmlNodeName).text('false')
        } else {
            if ($pe("#" + controlId + ":checked").val() == 'on') {
                // it's been checked
                $pe(xmlProperties).find(xmlNodeName).text('true')
            }
        }
    }


    function SetupEvents() {
        $pe('.pe_tablink').click(function(){ActivateTab($pe(this));});

        $pe('[hover]').hover(function(){$pe(this).addClass($pe(this).attr('hover'));},function(){$pe(this).removeClass($pe(this).attr('hover'));});

        $pe('[tooltipid]').addClass('pe_helpenabled');

        $pe('.pe_moreinfo.off').hide();
        $pe('.pe_infoLink a').click(function() {
            toggleDiv = $pe(this).parent().siblings('.pe_moreinfo');
            if (toggleDiv.hasClass('off')) {
                //$pe(this).text($pe(this).attr('ontxt'));
                toggleDiv.removeClass('off');
                toggleDiv.slideDown('fast');
            } else {
                //$pe(this).text($pe(this).attr('offtxt'));
                toggleDiv.addClass('off');
                toggleDiv.slideUp('fast');
            }
        });

        $pe('#all-intermediate').click(function() {
            $pe('select#pe_ddlIntNormalNotSatisfied').val($pe('#pe_ddlIntNormalSatisfied option:selected').val());
            $pe('#pe_ddlIntNormalNotSatisfied').change();

            $pe('select#pe_ddlIntSuspendSatisfied').val($pe('#pe_ddlIntNormalSatisfied option:selected').val());
            $pe('#pe_ddlIntSuspendSatisfied').change();

            $pe('select#pe_ddlIntSuspendNotSatisfied').val($pe('#pe_ddlIntNormalSatisfied option:selected').val());
            $pe('#pe_ddlIntSuspendNotSatisfied').change();

            $pe('select#pe_ddlIntTimeoutSatisfied').val($pe('#pe_ddlIntNormalSatisfied option:selected').val());
            $pe('#pe_ddlIntTimeoutSatisfied').change();

            $pe('select#pe_ddlIntTimeoutNotSatisfied').val($pe('#pe_ddlIntNormalSatisfied option:selected').val());
            $pe('#pe_ddlIntTimeoutNotSatisfied').change();

            $pe('select#pe_ddlIntLogoutSatisfied').val($pe('#pe_ddlIntNormalSatisfied option:selected').val());
            $pe('#pe_ddlIntLogoutSatisfied').change();

            $pe('select#pe_ddlIntLogoutNotSatisfied').val($pe('#pe_ddlIntNormalSatisfied option:selected').val());
            $pe('#pe_ddlIntLogoutNotSatisfied').change();
        });

        $pe('#all-final').click(function() {
            $pe('select#pe_ddlFinalNormalNotSatisfied').val($pe('#pe_ddlFinalNormalSatisfied option:selected').val());
            $pe('#pe_ddlFinalNormalNotSatisfied').change();

            $pe('select#pe_ddlFinalSuspendSatisfied').val($pe('#pe_ddlFinalNormalSatisfied option:selected').val());
            $pe('#pe_ddlFinalSuspendSatisfied').change();

            $pe('select#pe_ddlFinalSuspendNotSatisfied').val($pe('#pe_ddlFinalNormalSatisfied option:selected').val());
            $pe('#pe_ddlFinalSuspendNotSatisfied').change();

            $pe('select#pe_ddlFinalTimeoutSatisfied').val($pe('#pe_ddlFinalNormalSatisfied option:selected').val());
            $pe('#pe_ddlFinalTimeoutSatisfied').change();

            $pe('select#pe_ddlFinalTimeoutNotSatisfied').val($pe('#pe_ddlFinalNormalSatisfied option:selected').val());
            $pe('#pe_ddlFinalTimeoutNotSatisfied').change();

            $pe('select#pe_ddlFinalLogoutSatisfied').val($pe('#pe_ddlFinalNormalSatisfied option:selected').val());
            $pe('#pe_ddlFinalLogoutSatisfied').change();

            $pe('select#pe_ddlFinalLogoutNotSatisfied').val($pe('#pe_ddlFinalNormalSatisfied option:selected').val());
            $pe('#pe_ddlFinalLogoutNotSatisfied').change();
        });

        $pe("#pe_rdoFullScreen").click(function() {
            $pe("#pe_txtWidthForContent").attr("disabled", true);
            $pe("#pe_txtHeightForContent").attr("disabled", true);
            $pe("#pe_ckbRequiredDems").attr("disabled", true);
        });

        $pe("#pe_rdoSpecifyNewWindowDems").click(function(){
            $pe("#pe_txtWidthForContent").attr("disabled", false);
            $pe("#pe_txtHeightForContent").attr("disabled", false);
            $pe("#pe_ckbRequiredDems").attr("disabled", false);
        });

        SetOriginalValues();

        $pe('.pe_controlswrapper input[type="text"]').change(function() {
            //alert($pe(this).val());
            if ($pe(this).attr('originalval') == $pe(this).val()) {
                $pe(this).removeClass('pe_changed');
            } else {
                $pe(this).addClass('pe_changed');
            }
            CheckPendingMessage();
        });

        $pe('.pe_controlswrapper input[type="checkbox"]').click(function() {
            //alert($pe(this).val());
            if ((!$pe(this).is(':checked') && $pe(this).attr('originalval') == 'notchecked') || ($pe(this).is(':checked')&& $pe(this).attr('originalval') == 'checked')) {
                $pe(this).siblings('label').removeClass('pe_changed');
            } else {
                $pe(this).siblings('label').addClass('pe_changed');
            }
            CheckPendingMessage();
        });

        $pe('.pe_controlswrapper input[type="radio"]').click(function() {
            $pe('.pe_controlswrapper input[name="' + $pe(this).attr('name') + '"]').each(function() {
                $pe('.pe_controlswrapper label[for="' + $pe(this).attr('id') + '"]').removeClass('pe_changed');
            });
            if ($pe(this).attr('originalval')=='notchecked') {
                $pe('.pe_controlswrapper label[for="' + $pe(this).attr('id') + '"]').addClass('pe_changed');
            }
            CheckPendingMessage();
        });

        $pe('.pe_controlswrapper select').change(function() {
            if ($pe(this).attr('originalval') == $pe(this).val()) {
                $pe(this).removeClass('pe_changed');
            } else {
                $pe(this).addClass('pe_changed');
            }
            CheckPendingMessage();
        });

        $pe("#pe_btnSave").click(function() {
            $pe("#pe_Message").html("Saving Changes...");

            // Set Properties for controls
            UpdatePropertiesFromCurrentSettings(Properties);

            if ($pe("#pe_PropertiesEditor").hasClass('scorm2004') && $pe("#pe_ddlScormEdition option:selected").text() != LearningStandard) {
                UpdatePackageLearningStandard($pe("#pe_ddlScormEdition").val());
                LearningStandard = $pe("#pe_ddlScormEdition option:selected").text();
                SetLearningStandardClass();
            }

            // now build the string from the xml and send it back...
            var string;
            if (typeof(window.XMLSerializer) != undefined && window.XMLSerializer != null) {
                try {
                    oXmlSerializer =  new XMLSerializer();
                    if (typeof oXmlSerializer.serializeToString != "undefined") {
                        string = oXmlSerializer.serializeToString(Properties);
                    } else if(typeof Properties.xml != "undefined") {
                        string = Properties.xml;
                    }
                } catch(ex) {
                    string = Properties.xml;
                }
            } else {
                string = Properties.xml;
            }
            //alert(string);
            SetPropertyXml(string);
        });

        $pe('#pe_BtnAddPreset').click(function() {
            var pName = $pe('#pe_txtPresetName').val();
            var presetProps = $pe(Properties).clone(false);
            UpdatePropertiesFromCurrentSettings(presetProps);
            var stringProps;
            if (window.XMLSerializer) {
               	var serializer = new XMLSerializer();
                if (typeof serializer.serializeToString !== "undefined") {
                    stringProps = serializer.serializeToString(presetProps.get(0));
                } else if(typeof presetProps.get(0).xml != "undefined") {
                    stringProps = presetProps.get(0).xml;
                }
            } else {
                stringProps = presetProps.get(0).xml;
            }
            AddPropertyPreset(pName, stringProps);
            $pe('#pe_txtPresetName').val('');
        });
    }


    function ActivateTab(tabObj) {
        $pe('.pe_tablink').removeClass('active');
        tabObj.addClass('active');
        $pe('.pe_tabcontents').removeClass('active');
        contentid = tabObj.attr('content');
        $pe(contentid).addClass('active');
    }


    function SetOriginalValues() {
        $pe('.pe_changed').removeClass('pe_changed');

        $pe('.pe_controlswrapper input[type="text"]').each(function(){$pe(this).attr('originalval', $pe(this).val());});
        $pe('.pe_controlswrapper input[type="checkbox"]:checked').attr('originalval', 'checked');
        $pe('.pe_controlswrapper input[type="checkbox"]:not(:checked)').attr('originalval', 'notchecked');
        $pe('.pe_controlswrapper input[type="radio"]:checked').attr('originalval', 'checked');
        $pe('.pe_controlswrapper input[type="radio"]:not(:checked)').attr('originalval', 'notchecked');
        $pe('.pe_controlswrapper select').each(function(){$pe(this).attr('originalval', $pe(this).val());});
    }


    function ShowControlChanges() {
        $pe('.pe_controlswrapper input[type="text"]').each(function() {
            //alert($pe(this).val());
            if ($pe(this).attr('originalval') == $pe(this).val()) {
                $pe(this).removeClass('pe_changed');
            } else {
                $pe(this).addClass('pe_changed');
            }
        });

        $pe('.pe_controlswrapper input[type="checkbox"]').each(function() {
            //alert($pe(this).val());
            if ((!$pe(this).is(':checked') && $pe(this).attr('originalval') == 'notchecked') || ($pe(this).is(':checked') && $pe(this).attr('originalval') == 'checked')) {
                $pe(this).siblings('label').removeClass('pe_changed');
            } else {
                $pe(this).siblings('label').addClass('pe_changed');
            }
        });

        $pe('.pe_controlswrapper input[type="radio"]').each(function() {
            $pe('.pe_controlswrapper label[for="' + $pe(this).attr('id') + '"]').removeClass('pe_changed');
            if ($pe(this).is(':checked') && $pe(this).attr('originalval') == 'notchecked') {
                $pe('.pe_controlswrapper label[for="' + $pe(this).attr('id') + '"]').addClass('pe_changed');
            }
        });

        $pe('.pe_controlswrapper select').each(function() {
            if ($pe(this).attr('originalval') == $pe(this).val()) {
                $pe(this).removeClass('pe_changed');
            } else {
                $pe(this).addClass('pe_changed');
            }
        });

        CheckPendingMessage();
    }

    function CheckPendingMessage() {
        if ($pe('.pe_changed').length > 0) {
            $pe("#pe_Message").text("Changes Pending (click save to apply changes)");
        } else if ($pe("#pe_Message").text() == "Changes Pending (click save to apply changes)" ) {
            $pe("#pe_Message").text("");
        }
    }

    function SetLearningStandardClass() {
        var classname = "";
        //DE - For now, make properties editor look like AICC for RTWS
        if (LearningStandard == "AICC" || LearningStandard == "RTWS 1.0") {
            classname = "AICC notscorm2004";
        } else if (LearningStandard == "SCORM 1.1") {
            classname = "SCORM11 notscorm2004";
        } else if (LearningStandard == "SCORM 1.2") {
            classname = "SCORM12 notscorm2004";
        } else if (LearningStandard == "SCORM 2004 2nd Edition") {
            classname = "scorm20042ndedition scorm2004";
        } else if (LearningStandard == "SCORM 2004 3rd Edition") {
            classname = "scorm20043rdedition scorm2004";
        } else if (LearningStandard == "SCORM 2004 4th Edition") {
            classname = "scorm20044thedition scorm2004";
        } else if (LearningStandard == "Tin Can") {
            classname = "tincan";
        }

        $pe("#pe_PropertiesEditor").removeClass().addClass(classname);
    }


    /*************************************
     ***
     ***      HTML Writer Code
     ***
     **************************************/
    function PE_BuildPropertiesForm() {
        var PropertiesControlHtml = "<div id=\"pe_PropertiesEditor\">";
        PropertiesControlHtml += BuildHeaderBar();
        PropertiesControlHtml += "<div id=\"pe_PropertyContainer\">";
        PropertiesControlHtml += BuildNavigationBar();
        PropertiesControlHtml += "<div class=\"pe_tabContentwrapper\">";
        PropertiesControlHtml += BuildNavigationalControls();
        PropertiesControlHtml += BuildLaunchBehavior();
        PropertiesControlHtml += BuildRudimentarySequencing();
        PropertiesControlHtml += BuildRudimentaryRollup();
        PropertiesControlHtml += BuildCompatibilitySettings();
        PropertiesControlHtml += BuildCommunicationSettings();
        PropertiesControlHtml += BuildDebuggerOptions();
        PropertiesControlHtml += BuildHistoryOptions();
        //PropertiesControlHtml += BuildOtherBehaviorOptions();
        PropertiesControlHtml += BuildReportingHeuristics();
        PropertiesControlHtml += BuildPresets();
        PropertiesControlHtml += "</div>";
        PropertiesControlHtml += BuildSaveBar();
        PropertiesControlHtml += "</div></div>";

        $pe("#PropertiesControl").html(PropertiesControlHtml);

        PopulateForm(Properties);

        //$pe("#pe_Message").html(PE_GetString("Properties Loaded."));

        //setup editor events
        SetupEvents();
    }


    function BuildHeaderBar() {
        var HeaderHtml = "<div id=\"pe_header\">";
        HeaderHtml += "<div id=\"pe_HeaderTitle\" >" + PE_GetString("Package Properties Editor") + "</div>";
        HeaderHtml += "<div id=\"pe_PackageTitle\" >";
        HeaderHtml += "<span id=\"pe_PackageTitleText\"></span>";
        HeaderHtml += " (<span id=\"pe_LearningStandardText\"></span>)";
        HeaderHtml += "</div><div style=\"clear:both;\"></div></div>";

        return HeaderHtml;
    }


    function BuildNavigationBar() {
        var NavBar = "<div class=\"pe_tabNavWrapper\"><ul class=\"pe_tabs\">";
        NavBar += "<li id=\"pe_TabNavControls\" hover=\"hover\" content=\"#pe_NavControls\" class=\"pe_tablink\"><span>" + PE_GetString("Navigational Controls") + "</span></li>";
        NavBar += "<li id=\"pe_TabLaunchBehavior\" hover=\"hover\" content=\"#pe_LaunchBehavior\" class=\"pe_tablink\"><span>" + PE_GetString("Launch Behavior") + "</span></li>";
        NavBar += "<li id=\"pe_TabRudSequencing\" hover=\"hover\" content=\"#pe_RudSequencing\" class=\"pe_tablink\"><span>" + PE_GetString("Rudimentary Sequencing") + "</span></li>";
        NavBar += "<li id=\"pe_TabRudRollup\" hover=\"hover\" content=\"#pe_RudRollup\" class=\"pe_tablink\"><span>" + PE_GetString("Rudimentary Rollup") + "</span></li>";
        NavBar += "<li id=\"pe_TabCompSettings\" hover=\"hover\" content=\"#pe_CompSettings\" class=\"pe_tablink\"><span>" + PE_GetString("Compatibility Settings") + "</span></li>";
        NavBar += "<li id=\"pe_TabCommSettings\" hover=\"hover\" content=\"#pe_CommSettings\" class=\"pe_tablink\"><span>" + PE_GetString("Communication Settings") + "</span></li>";
        NavBar += "<li id=\"pe_TabDebuggerOpts\" hover=\"hover\" content=\"#pe_DebuggerOpts\" class=\"pe_tablink\"><span>" + PE_GetString("Debugger Options") + "</span></li>";
        NavBar += "<li id=\"pe_TabHistoryOpts\" hover=\"hover\" content=\"#pe_HistoryOpts\" class=\"pe_tablink\"><span>" + PE_GetString("History Options") + "</span></li>";
        //NavBar += "<li id=\"pe_TabOtherBehaviorOpts\" hover=\"hover\" content=\"#pe_OtherBehaviorOpts\" class=\"pe_tablink\"><span>" + PE_GetString("Other Behavioral Options") + "</span></li>";
        NavBar += "<li id=\"pe_TabHeuristics\" hover=\"hover\" content=\"#pe_Heuristics\" class=\"pe_tablink\"><span>" + PE_GetString("Reporting Heuristics") + "</span></li>";
        NavBar += "<li id=\"pe_TabPresets\" hover=\"hover\" content=\"#pe_Presets\" class=\"pe_tablink\"><span>" + PE_GetString("Presets") + "</span></li>";
        NavBar += "</ul><div style=\"clear:both;\"></div></div>";

        return NavBar;
    }


    function BuildNavigationalControls() {
        var NavControls = "<div id=\"pe_NavControls\" class=\"pe_tabcontents\">";
        NavControls += "<div class=\"pe_tabtitle\">";
        NavControls += "<span class=\"\">" + PE_GetString("Navigational Controls") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        NavControls += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings determine the availability of navigational controls in the SCORM Player.") + "</div></div>";
        NavControls += "<hr />";
        NavControls += "<div class=\"pe_controlswrapper\">";
        NavControls += "<div class=\"pe_col50\">";
        NavControls += "<div id=\"pe_ShowNavBar\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbShowNavBar\" /><label tooltipid=\"ShowNavBar.Help\" for=\"pe_ckbShowNavBar\">" + PE_GetString("Show Navigation Bar") + "</label></div>";
        NavControls += "<div id=\"pe_ShowFinishButton\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbShowFinishButton\" /><label tooltipid=\"ShowFinishButton.Help\" for=\"pe_ckbShowFinishButton\">" + PE_GetString("Show Finish Button") + "</label></div>";
        NavControls += "<div id=\"pe_ShowCloseItem\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbShowCloseItem\" /><label tooltipid=\"ShowCloseItem.Help\" for=\"pe_ckbShowCloseItem\">" + PE_GetString("Show Close SCO Button") + "</label></div>";
        NavControls += "<div id=\"pe_ShowPrevNext\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbShowPrevNext\" /><label tooltipid=\"EnableFlowNav.Help\" for=\"pe_ckbShowPrevNext\">" + PE_GetString("Enable Previous/Next") + "</label></div>";
        NavControls += "<div id=\"pe_ShowProgressBar\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbShowProgressBar\" /><label tooltipid=\"ShowProgressBar.Help\" for=\"pe_ckbShowProgressBar\">" + PE_GetString("Show Progress Bar") + "</label></div>";
        NavControls += "<div id=\"pe_UseMeasureProgressBar\" class=\"pe_propertycontrol pe_indent2\"><input type=\"checkbox\" id=\"pe_ckbUseMeasureProgressBar\" /><label tooltipid=\"UseMeasureProgressBar.Help\" for=\"pe_ckbUseMeasureProgressBar\">" + PE_GetString("Use Measure For Progress Bar") + "</label></div>";
        NavControls += "<div id=\"pe_ShowHelp\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbShowHelp\" /><label tooltipid=\"ShowHelp.Help\" for=\"pe_ckbShowHelp\">" + PE_GetString("Show Help") + "</label></div>";
        NavControls += "<div id=\"pe_ShowTitleBar\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbShowTitleBar\" /><label tooltipid=\"ShowTitleBar.Help\" for=\"pe_ckbShowTitleBar\">" + PE_GetString("Show Title Bar") + "</label></div>";
        NavControls += "<div id=\"pe_PreventRightClick\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbPreventRightClick\" /><label tooltipid=\"PreventRightClick.Help\" for=\"pe_ckbPreventRightClick\">" + PE_GetString("Prevent Right Click") + "</label></div>";

        NavControls += "</div><div class=\"pe_col50\">";

        NavControls += "<div id=\"pe_ShowCourseStructure\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbShowCourseStructure\" /><label tooltipid=\"ShowCourseStructure.Help\" for=\"pe_ckbShowCourseStructure\">" + PE_GetString("Show Course Structure") + "</label></div>";
        NavControls += "<div id=\"pe_CourseStructureStartsOpen\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbCourseStructureStartsOpen\" /><label tooltipid=\"CourseStructureStartsOpen.Help\" for=\"pe_ckbCourseStructureStartsOpen\">" + PE_GetString("Course Structure Starts Open") + "</label></div>";

        NavControls += "<div id=\"pe_ShowChoiceNav\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbShowChoiceNav\" /><label tooltipid=\"EnableChoiceNav.Help\" for=\"pe_ckbShowChoiceNav\">" + PE_GetString("Enable Choice Navigation") + "</label></div>";

        NavControls += "<div id=\"pe_CourseStructureWidth\" class=\"pe_propertycontrol pe_indent1\"><label tooltipid=\"CourseStructureWidth.Help\" for=\"pe_txtCourseStructureWidth\">" + PE_GetString("Course Structure Width: ") + "</label><input type=\"text\" id=\"pe_txtCourseStructureWidth\" class=\"pe_smTxtBox\" /> " + PE_GetString("pixels") + "</div>";
        NavControls += "<div id=\"pe_StatusDisplayPreference\" class=\"pe_propertycontrol pe_indent1\"><label tooltipid=\"StatusDisplay.Help\" for=\"pe_ddlStatusDisplayPreference\">" + PE_GetString("Structure Status Display: ") + "</label>";
        NavControls += "<select id=\"pe_ddlStatusDisplayPreference\">";
        NavControls += "<option value=\"success only\">" + PE_GetString("Success Only") + "</option>";
        NavControls += "<option value=\"completion only\">" + PE_GetString("Completion Only") + "</option>";
        NavControls += "<option value=\"separate\">" + PE_GetString("Separate") + "</option>";
        NavControls += "<option value=\"combined\">" + PE_GetString("Combined") + "</option>";
        NavControls += "<option value=\"none\">" + PE_GetString("None") + "</option>";
        NavControls += "</select></div>";
        NavControls += "<div id=\"pe_InvalidMenuItemAction\" class=\"pe_propertycontrol pe_indent1\"><label tooltipid=\"InvalidMenuItemAction.Help\" for=\"pe_ddlInvalidMenuItemAction\">" + PE_GetString("Invalid Menu Item Action: ") + "</label>";
        NavControls += "<select id=\"pe_ddlInvalidMenuItemAction\">";
        NavControls += "<option value=\"show\">" + PE_GetString("Show and Enable Links") + "</option>";
        NavControls += "<option value=\"hide\">" + PE_GetString("Hide") + "</option>";
        NavControls += "<option value=\"disable\">" + PE_GetString("Show but Disable Links") + "</option>";
        NavControls += "</select></div>";

        NavControls += "</div><div style=\"clear:both;\"></div></div></div>";

        return NavControls;
    }


    function BuildLaunchBehavior() {
        var LaunchBehavior = "<div id=\"pe_LaunchBehavior\" class=\"pe_tabcontents\">";
        LaunchBehavior += "<div class=\"pe_tabtitle\">";
        LaunchBehavior += "<span class=\"\">" + PE_GetString("Launch Behavior") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        LaunchBehavior += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings determine how the parts of the SCORM Player will be launched.") + "</div></div>";
        LaunchBehavior += "<hr />";
        LaunchBehavior += "<div class=\"pe_controlswrapper\">";

        LaunchBehavior += "<div id=\"pe_ScoLaunchType\" class=\"pe_propertycontrol\"><label tooltipid=\"ScoLaunchType.Help\" for=\"pe_ckbShowNavBar\">" + PE_GetString("SCO Launch Type") + " </label>";
        LaunchBehavior += "<select id=\"pe_ddlScoLaunchType\">";
        LaunchBehavior += "<option value=\"frameset\">" + PE_GetString("Frameset") + "</option>";
        LaunchBehavior += "<option value=\"new window\">" + PE_GetString("New Window") + "</option>";
        LaunchBehavior += "<option value=\"new window,after click\">" + PE_GetString("New Window After Click") + "</option>";
        LaunchBehavior += "<option value=\"new window without browser toolbar\">" + PE_GetString("New Window Without Browser Toolbar") + "</option>";
        LaunchBehavior += "<option value=\"new window,after click,without browser toolbar\">" + PE_GetString("New Window Without Browser Toolbar After Click") + "</option>";
        LaunchBehavior += "</select></div>";

        LaunchBehavior += "<div id=\"pe_PlayerLaunchType\" class=\"pe_propertycontrol\"><label tooltipid=\"PlayerLaunchType.Help\" for=\"pe_ckbShowNavBar\">" + PE_GetString("Player Launch Type") + " </label>";
        LaunchBehavior += "<select id=\"pe_ddlPlayerLaunchType\">";
        LaunchBehavior += "<option value=\"frameset\">" + PE_GetString("Frameset") + "</option>";
        LaunchBehavior += "<option value=\"new window\">" + PE_GetString("New Window") + "</option>";
        LaunchBehavior += "<option value=\"new window,after click\">" + PE_GetString("New Window After Click") + "</option>";
        LaunchBehavior += "<option value=\"new window without browser toolbar\">" + PE_GetString("New Window Without Browser Toolbar") + "</option>";
        LaunchBehavior += "<option value=\"new window,after click,without browser toolbar\">" + PE_GetString("New Window Without Browser Toolbar After Click") + "</option>";
        LaunchBehavior += "</select></div>";

        LaunchBehavior += "<div id=\"pe_NewWindowOptions\" ><b tooltipid=\"NewWindowDisplayOptions.Help\">" + PE_GetString("New Window Options:") + "</b>";
        LaunchBehavior += "<div id=\"pe_FullScreen\" class=\"pe_propertycontrol pe_indent1\"><input name=\"NewWindowOptions\" type=\"radio\" id=\"pe_rdoFullScreen\" /><label tooltipid=\"NewWindowDisplayOptions.Help\" for=\"pe_rdoFullScreen\">" + PE_GetString("Full Screen") + "</label></div>";
        LaunchBehavior += "<div id=\"pe_SpecifyNewWindowDems\" class=\"pe_propertycontrol pe_indent1\"><input name=\"NewWindowOptions\" type=\"radio\" id=\"pe_rdoSpecifyNewWindowDems\" /><label tooltipid=\"NewWindowDisplayOptions.Help\" for=\"pe_rdoSpecifyNewWindowDems\">" + PE_GetString("Specify New Window Dimensions") + "</label></div>";
        LaunchBehavior += "</div>";

        LaunchBehavior += "<div id=\"pe_WidthForContent\" class=\"pe_propertycontrol pe_indent2\"><label tooltipid=\"DesiredWidth.Help\" for=\"pe_txtWidthForContent\">" + PE_GetString("Width for content:") + "</label> <input type=\"text\" id=\"pe_txtWidthForContent\" class=\"pe_smTxtBox\" /> " + PE_GetString("pixels") + "</div>";
        LaunchBehavior += "<div id=\"pe_HeightForContent\" class=\"pe_propertycontrol pe_indent2\"><label tooltipid=\"DesiredHeight.Help\" for=\"pe_txtHeightForContent\">" + PE_GetString("Height for content:") + "</label> <input type=\"text\" id=\"pe_txtHeightForContent\" class=\"pe_smTxtBox\" /> " + PE_GetString("pixels") + "</div>";

        LaunchBehavior += "<div id=\"pe_RequiredDems\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbRequiredDems\" /><label tooltipid=\"RequiredDimensions.Help\" for=\"pe_ckbRequiredDems\">" + PE_GetString("REQUIRED: Above dimensions are required for <br />the course to function properly.") + "</label></div>";
        LaunchBehavior += "<div id=\"pe_PreventWindowResize\" class=\"pe_propertycontrol \"><input type=\"checkbox\" id=\"pe_ckbPreventWindowResize\" /><label tooltipid=\"PreventWindowResize.Help\" for=\"pe_ckbPreventWindowResize\">" + PE_GetString("Prevent Window Resize") + "</label></div>";

        LaunchBehavior += "<div id=\"pe_IsAvailableOffline\" class=\"pe_propertycontrol \"><input type=\"checkbox\" id=\"pe_ckbIsAvailableOffline\" /><label tooltipid=\"IsAvailableOffline.Help\" for=\"pe_ckbIsAvailableOffline\">" + PE_GetString("Available Offline") + "</label></div>";

        LaunchBehavior += "<div id=\"pe_TimeLimit\" class=\"pe_propertycontrol\"><label tooltipid=\"TimeLimit.Help\" for=\"pe_txtTimeLimit\">" + PE_GetString("Time Limit:") + " </label><input type=\"text\" id=\"pe_txtTimeLimit\" class=\"pe_smTxtBox\" /> " + " (minutes, 0 for no limit)" + "</div>";

        LaunchBehavior += "</div></div>";

        return LaunchBehavior;
    }


    function BuildCompatibilitySettings() {
        var CompatibilitySettings = "<div id=\"pe_CompSettings\" class=\"pe_tabcontents\">";
        CompatibilitySettings += "<div class=\"pe_tabtitle\">";
        CompatibilitySettings += "<span class=\"\">" + PE_GetString("Compatibility Settings") + "</span>";
        CompatibilitySettings += "</div>";
        CompatibilitySettings += "<hr />";
        CompatibilitySettings += "<div class=\"pe_controlswrapper\">";
        CompatibilitySettings += "<div class=\"pe_col50\">";

        CompatibilitySettings += "<div id=\"pe_FinishCausesImmediateCommit\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbFinishCausesImmediateCommit\" /><label tooltipid=\"FinishCausesImmediateCommit.Help\" for=\"pe_ckbFinishCausesImmediateCommit\">" + PE_GetString("Finish Causes Immediate Commit") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_LogoutCausesPlayerExit\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbLogoutCausesPlayerExit\" /><label tooltipid=\"LogoutCausesPlayerExit.Help\" for=\"pe_ckbLogoutCausesPlayerExit\">" + PE_GetString("Logout Causes Player Exit") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_WrapSCOWindowWithAPI\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbWrapSCOWindowWithAPI\" /><label tooltipid=\"WrapScoWindowWithApi.Help\" for=\"pe_ckbWrapSCOWindowWithAPI\">" + PE_GetString("Wrap SCO Window with API") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_AlwaysFlowToFirstSCO\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbAlwaysFlowToFirstSCO\" /><label tooltipid=\"AlwaysFlowToFirstSco.Help\" for=\"pe_ckbAlwaysFlowToFirstSCO\">" + PE_GetString("Always Flow to First SCO") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_ValidateInteractionResponses\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbValidateInteractionResponses\" /><label tooltipid=\"ValidateInteractionResponses.Help\" for=\"pe_ckbValidateInteractionResponses\">" + PE_GetString("Enable Validation of SCORM Interaction Results") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_ScoreOverridesStatus\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbScoreOverridesStatus\" /><label tooltipid=\"ScoreOverridesStatus.Help\" for=\"pe_ckbScoreOverridesStatus\">" + PE_GetString("Mastery Score Overrides Lesson Status") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_AllowCompleteStatusChange\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbAllowCompleteStatusChange\" /><label tooltipid=\"AllowCompleteStatusChange.Help\" for=\"pe_ckbAllowCompleteStatusChange\">" + PE_GetString("Allow Complete Lesson Status To Change") + "</label></div>";

        CompatibilitySettings += "<div id=\"pe_RawScoreCanActAsScaledScore\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbRawScoreCanActAsScaledScore\" /><label tooltipid=\"ScaleRawScore.Help\" for=\"pe_ckbRawScoreCanActAsScaledScore\">" + PE_GetString("Raw Score Can Act as Scaled Score") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_RollupEmptySetToUnknown\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbRollupEmptySetToUnknown\" /><label tooltipid=\"RollupEmptySetToUnknown.Help\" for=\"pe_ckbRollupEmptySetToUnknown\">" + PE_GetString("Rollup Empty Set to Unknown") + "</label></div>";

        CompatibilitySettings += "</div><div class=\"pe_col50\">";

        CompatibilitySettings += "<div id=\"pe_ForceDisableRootChoice\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbForceDisableRootChoice\" /><label tooltipid=\"ForceDisableRootChoice.Help\" for=\"pe_ckbForceDisableRootChoice\">" + PE_GetString("Disable Root Activity") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_RollupRuntimeAtScoUnload\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbRollupRuntimeAtScoUnload\" /><label tooltipid=\"RollupRuntimeAtScoUnload.Help\" for=\"pe_ckbRollupRuntimeAtScoUnload\">" + PE_GetString("Rollup At SCO Unload") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_ForceObjectiveCompletionSetByContent\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbForceObjectiveCompletionSetByContent\" /><label tooltipid=\"ForceObjectiveCompletionSetByContent.Help\" for=\"pe_ckbForceObjectiveCompletionSetByContent\">" + PE_GetString("Override Objective and Completion Set By Content to True") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_InvokeRollupAtSuspendAll\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbInvokeRollupAtSuspendAll\" /><label tooltipid=\"InvokeRollupAtSuspendAll.Help\" for=\"pe_ckbInvokeRollupAtSuspendAll\">" + PE_GetString("Invoke Rollup at Suspend All") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_SatisfiedCausesCompletion\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbSatisfiedCausesCompletion\" /><label tooltipid=\"SatisfiedCausesCompletion.Help\" for=\"pe_ckbSatisfiedCausesCompletion\">" + PE_GetString("Satisfaction causes completion") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_MakeStudentPrefsGlobalToCourse\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbMakeStudentPrefsGlobalToCourse\" /><label tooltipid=\"MakeStudentPrefsGlobalToCourse.Help\" for=\"pe_ckbMakeStudentPrefsGlobalToCourse\">" + PE_GetString("Make Student Preferences Global to Course") + "</label></div>";
        CompatibilitySettings += "<div id=\"pe_LaunchCompletedRegsAsNoCredit\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbLaunchCompletedRegsAsNoCredit\" /><label tooltipid=\"LaunchCompletedRegsAsNoCredit.Help\" for=\"pe_ckbLaunchCompletedRegsAsNoCredit\">" + PE_GetString("Launch Completed Registrations as no-credit") + "</label></div>";

        CompatibilitySettings += "</div><div style=\"clear:both;\"></div>";

        CompatibilitySettings += "<div id=\"pe_CompletionStatOfFailedSuccessStat\" class=\"pe_propertycontrol\"><label tooltipid=\"CompletionStatOfFailedSuccessStat.Help\" for=\"pe_ddlCompletionStatOfFailedSuccessStat\">" + PE_GetString("Completion Status of failed Success Status:") + " </label>";
        CompatibilitySettings += "<select id=\"pe_ddlCompletionStatOfFailedSuccessStat\">";
        CompatibilitySettings += "<option value=\"completed\">" + PE_GetString("Completed") + "</option>";
        CompatibilitySettings += "<option value=\"incomplete\">" + PE_GetString("Incomplete") + "</option>";
        CompatibilitySettings += "<option value=\"unknown\">" + PE_GetString("Unknown") + "</option>";
        CompatibilitySettings += "</select>";
        CompatibilitySettings += "</div>";

        CompatibilitySettings += "<div id=\"pe_SequencerMode\" class=\"pe_propertycontrol\"><label tooltipid=\"LookaheadSequencerMode.Help\" for=\"pe_ddlSequencerMode\">" + PE_GetString("Lookahead Sequencer Mode:") + " </label>";
        CompatibilitySettings += "<select id=\"pe_ddlSequencerMode\">";
        CompatibilitySettings += "<option value=\"disabled\">" + PE_GetString("Disabled") + "</option>";
        CompatibilitySettings += "<option value=\"enabled\">" + PE_GetString("Enabled") + "</option>";
        CompatibilitySettings += "<option value=\"realtime\">" + PE_GetString("RealTime") + "</option>";
        CompatibilitySettings += "</select>";
        CompatibilitySettings += "</div>";
        CompatibilitySettings += "<div id=\"pe_UseQuickLookaheadSeq\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbUseQuickLookaheadSeq\" /><label tooltipid=\"UseQuickLookaheadSequencer.Help\" for=\"pe_ckbUseQuickLookaheadSeq\">" + PE_GetString("Use Quick Lookahead Sequencer") + "</label></div>";

        CompatibilitySettings += "<div id=\"pe_ResetRunTimeDataTiming\" class=\"pe_propertycontrol\"><label tooltipid=\"ResetRunTimeDataTiming.Help\" for=\"pe_ddlResetRunTimeDataTiming\">" + PE_GetString("Reset RunTime Data Timing:") + " </label>";
        CompatibilitySettings += "<select id=\"pe_ddlResetRunTimeDataTiming\">";
        CompatibilitySettings += "<option value=\"never\">" + PE_GetString("Never") + "</option>";
        CompatibilitySettings += "<option value=\"when exit is not suspend\">" + PE_GetString("When Exit Is Not Suspend") + "</option>";
        CompatibilitySettings += "<option value=\"on each new sequencing attempt\">" + PE_GetString("On Each New Sequencing Attempt") + "</option>";
        CompatibilitySettings += "</select>";
        CompatibilitySettings += "</div>";

        CompatibilitySettings += "<div id=\"pe_ReturnToLmsAction\" class=\"pe_propertycontrol\"><label tooltipid=\"ReturnToLmsAction.Help\" for=\"pe_ddlReturnToLmsAction\">" + PE_GetString("Return To LMS Action:") + " </label>";
        CompatibilitySettings += "<select id=\"pe_ddlReturnToLmsAction\">";
        CompatibilitySettings += "<option value=\"legacy\">" + PE_GetString("Legacy") + "</option>";
        CompatibilitySettings += "<option value=\"suspend_all\">" + PE_GetString("Suspend All") + "</option>";
        CompatibilitySettings += "<option value=\"exit_all\">" + PE_GetString("Exit All") + "</option>";
        CompatibilitySettings += "<option value=\"selectable\">" + PE_GetString("Selectable") + "</option>";
        CompatibilitySettings += "</select>";
        CompatibilitySettings += "</div>";

        CompatibilitySettings += "<div id=\"pe_MaximumSuspendDataSize\" class=\"pe_propertycontrol\"><label tooltipid=\"MaxSuspendDataSize.Help\" for=\"pe_txtMaximumSuspendDataSize\">" + PE_GetString("Maximum Suspend Data Size:") + " </label><input type=\"text\" id=\"pe_txtMaximumSuspendDataSize\" class=\"pe_smTxtBox\" /></div>";

        CompatibilitySettings += "<div id=\"pe_LearningStandardUpdate\" class=\"pe_propertycontrol\"><label tooltipid=\"ScormVersion.Help\" for=\"pe_ddlScormEdition\">" + PE_GetString("SCORM 2004 Edition:") + " </label>";
        CompatibilitySettings += "<select id=\"pe_ddlScormEdition\">";
        CompatibilitySettings += "<option value=\"scorm20042ndedition\">" + PE_GetString("SCORM 2004 2nd Edition") + "</option>";
        CompatibilitySettings += "<option value=\"scorm2004\">" + PE_GetString("SCORM 2004 3rd Edition") + "</option>";
        CompatibilitySettings += "<option value=\"scorm20044thedition\">" + PE_GetString("SCORM 2004 4th Edition") + "</option>";
        CompatibilitySettings += "</select>";
        CompatibilitySettings += "</div>";

        CompatibilitySettings += "<div id=\"pe_InternetExplorerCompatibilityMode\" class=\"pe_propertycontrol\"><label tooltipid=\"InternetExplorerCompatibilityMode.Help\" for=\"pe_ddlIeCompatibilityMode\">" + PE_GetString("Internet Explorer Compatibility Mode:") + " </label>";
        CompatibilitySettings += "<select id=\"pe_ddlIeCompatibilityMode\">";
        CompatibilitySettings += "<option value=\"none\">" + PE_GetString("None") + "</option>";
        CompatibilitySettings += "<option value=\"emulateie7\">" + PE_GetString("Emulate IE7 [Use DOCTYPE]") + "</option>";
        CompatibilitySettings += "<option value=\"7\">" + PE_GetString("IE7 [Ignore DOCTYPE, Force Standards Mode]") + "</option>";
        CompatibilitySettings += "<option value=\"emulateie8\">" + PE_GetString("Emulate IE8 [Use DOCTYPE]") + "</option>";
        CompatibilitySettings += "<option value=\"8\">" + PE_GetString("IE8 [Ignore DOCTYPE, Force Standards Mode]") + "</option>";
        CompatibilitySettings += "<option value=\"emulateie9\">" + PE_GetString("Emulate IE9 [Use DOCTYPE]") + "</option>";
        CompatibilitySettings += "<option value=\"9\">" + PE_GetString("IE9 [Ignore DOCTYPE, Force Standards Mode]") + "</option>";
	CompatibilitySettings += "<option value=\"10\">" + PE_GetString("IE10 [Ignore DOCTYPE, Force Standards Mode]") + "</option>";
        CompatibilitySettings += "<option value=\"edge\">" + PE_GetString("Edge [Use Highest Rendering Mode Available]") + "</option>";
        CompatibilitySettings += "</select>";
        CompatibilitySettings += "</div>";

        CompatibilitySettings += "</div></div>";

        return CompatibilitySettings;
    }


    function BuildCommunicationSettings() {
        var CommunicationSettings = "<div id=\"pe_CommSettings\" class=\"pe_tabcontents\">";
        CommunicationSettings += "<div class=\"pe_tabtitle\">";
        CommunicationSettings += "<span class=\"\">" + PE_GetString("Communication Settings") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        CommunicationSettings += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings affect how the player saves course status.") + "</div></div>";
        CommunicationSettings += "<hr />";
        CommunicationSettings += "<div class=\"pe_controlswrapper\">";
        CommunicationSettings += "<div id=\"pe_MaximumFailedAttempts\" class=\"pe_propertycontrol\"><label tooltipid=\"CommMaxFailedSubmissions.Help\" for=\"pe_txtMaximumFailedAttempts\">" + PE_GetString("Maximum Failed Attempts:") + " </label><input type=\"text\" id=\"pe_txtMaximumFailedAttempts\" class=\"pe_smTxtBox\" /></div>";
        CommunicationSettings += "<div id=\"pe_CommitFrequency\" class=\"pe_propertycontrol\"><label tooltipid=\"CommCommitFrequency.Help\" for=\"pe_txtCommitFrequency\">" + PE_GetString("Commit Frequency:") + " </label><input type=\"text\" id=\"pe_txtCommitFrequency\" class=\"pe_smTxtBox\" /> " + PE_GetString("milliseconds") + "</div>";
        CommunicationSettings += "</div></div>";

        return CommunicationSettings;
    }

    function BuildDebuggerOptions() {
        var DebuggerOptions = "<div id=\"pe_DebuggerOpts\" class=\"pe_tabcontents\">";
        DebuggerOptions += "<div class=\"pe_tabtitle\">";
        DebuggerOptions += "<span class=\"\">" + PE_GetString("Debugger Options") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        DebuggerOptions += "<div class=\"pe_moreinfo off\">" + HelpStrings['Debugger_Options.Help'] + "</div></div>";
        DebuggerOptions += "<hr />";
        DebuggerOptions += "<div class=\"pe_controlswrapper\">";

        DebuggerOptions += "<div id=\"pe_ControlDebugOptions\" class=\"pe_propertycontrol pe_horizRadio\"><span class=\"pe_horizLabel\" tooltipid=\"DebugControl.Help\">" + PE_GetString("Control:") + "</span> ";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-control\" id=\"pe_rdoControlOff\" /><label tooltipid=\"DebugControl.Help\" for=\"pe_rdoControlOff\">" + PE_GetString("off") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-control\" id=\"pe_rdoControlAudit\" /><label tooltipid=\"DebugControl.Help\" for=\"pe_rdoControlAudit\">" + PE_GetString("audit") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-control\" id=\"pe_rdoControlDetailed\" /><label tooltipid=\"DebugControl.Help\" for=\"pe_rdoControlDetailed\">" + PE_GetString("detailed") + "</label>";
        DebuggerOptions += "</div>";

        DebuggerOptions += "<div id=\"pe_RuntimeDebugOptions\" class=\"pe_propertycontrol pe_horizRadio\"><span class=\"pe_horizLabel\" tooltipid=\"DebugRte.Help\">" + PE_GetString("Runtime:") + "</span> ";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-runtime\" id=\"pe_rdoRuntimeOff\" /><label tooltipid=\"DebugRte.Help\" for=\"pe_rdoRuntimeOff\">" + PE_GetString("off") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-runtime\" id=\"pe_rdoRuntimeAudit\" /><label tooltipid=\"DebugRte.Help\" for=\"pe_rdoRuntimeAudit\">" + PE_GetString("audit") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-runtime\" id=\"pe_rdoRuntimeDetailed\" /><label tooltipid=\"DebugRte.Help\" for=\"pe_rdoRuntimeDetailed\">" + PE_GetString("detailed") + "</label>";
        DebuggerOptions += "</div>";

        DebuggerOptions += "<div id=\"pe_SequencingDebugOptions\" class=\"pe_propertycontrol pe_horizRadio\"><span class=\"pe_horizLabel\" tooltipid=\"DebugSequencing.Help\">" + PE_GetString("Sequencing:") + "</span> ";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-seq\" id=\"pe_rdoSequencingOff\" /><label tooltipid=\"DebugSequencing.Help\" for=\"pe_rdoSequencingOff\">" + PE_GetString("off") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-seq\" id=\"pe_rdoSequencingAudit\" /><label tooltipid=\"DebugSequencing.Help\" for=\"pe_rdoSequencingAudit\">" + PE_GetString("audit") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-seq\" id=\"pe_rdoSequencingDetailed\" /><label tooltipid=\"DebugSequencing.Help\" for=\"pe_rdoSequencingDetailed\">" + PE_GetString("detailed") + "</label>";
        DebuggerOptions += "</div>";
        DebuggerOptions += "<div id=\"pe_DebugSequencingSimple\" class=\"pe_propertycontrol pe_indent1\"><input type=\"checkbox\" id=\"pe_ckbDebugSequencingSimple\" /><label tooltipid=\"DebugSequencingSimple.Help\" for=\"pe_ckbDebugSequencingSimple\">" + PE_GetString("Show Simple Sequencing Logs") + "</label></div>";

        DebuggerOptions += "<div id=\"pe_LookaheadDebugOptions\" class=\"pe_propertycontrol pe_horizRadio\"><span class=\"pe_horizLabel\" tooltipid=\"DebugLookahead.Help\">" + PE_GetString("Look-ahead:") + "</span> ";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-lookahead\" id=\"pe_rdoLookOff\" /><label tooltipid=\"DebugLookahead.Help\" for=\"pe_rdoLookOff\">" + PE_GetString("off") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-lookahead\" id=\"pe_rdoLookAudit\" /><label tooltipid=\"DebugLookahead.Help\" for=\"pe_rdoLookAudit\">" + PE_GetString("audit") + "</label>";
        DebuggerOptions += "<input type=\"radio\" name=\"debugging-lookahead\" id=\"pe_rdoLookDetailed\" /><label tooltipid=\"DebugLookahead.Help\" for=\"pe_rdoLookDetailed\">" + PE_GetString("detailed") + "</label>";
        DebuggerOptions += "</div>";

        DebuggerOptions += "<div id=\"pe_IncludeTimestamps\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbIncludeTimestamps\" /><label tooltipid=\"DebugIncludeTimestamps.Help\" for=\"pe_ckbIncludeTimestamps\">" + PE_GetString("Include Timestamps") + "</label></div>";

        DebuggerOptions += "</div></div>";

        return DebuggerOptions;
    }


    function BuildHistoryOptions() {
        var HistoryOptions = "<div id=\"pe_HistoryOpts\" class=\"pe_tabcontents\">";
        HistoryOptions += "<div class=\"pe_tabtitle\">";
        HistoryOptions += "<span class=\"\">" + PE_GetString("History Options") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        HistoryOptions += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings affect the collection of launch history information.") + "</div></div>";
        HistoryOptions += "<hr />";
        HistoryOptions += "<div class=\"pe_controlswrapper\">";
        HistoryOptions += "<div id=\"pe_CaptureHistory\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbCaptureHistory\"  /> <label tooltipid=\"CaptureHistory.Help\" for=\"pe_ckbCaptureHistory\">" + PE_GetString("Capture History") + " </label></div>";
        HistoryOptions += "<div id=\"pe_CaptureDetailedHistory\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbCaptureDetailedHistory\"  /> <label tooltipid=\"CaptureHistoryDetailed.Help\" for=\"pe_ckbCaptureDetailedHistory\">" + PE_GetString("Capture Detailed History") + " </label></div>";
        HistoryOptions += "</div></div>";

        return HistoryOptions;
    }


    function BuildOtherBehaviorOptions() {
        var HistoryOptions = "<div id=\"pe_OtherBehaviorOpts\" class=\"pe_tabcontents\">";
        HistoryOptions += "<div class=\"pe_tabtitle\">";
        HistoryOptions += "<span class=\"\">" + PE_GetString("Other Behavioral Options") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        HistoryOptions += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings affect the behavior of the course in various ways.") + "</div></div>";
        HistoryOptions += "<hr />";
        HistoryOptions += "<div class=\"pe_controlswrapper\">";
        HistoryOptions += "<div id=\"pe_TimeLimit\" class=\"pe_propertycontrol\"><label tooltipid=\"TimeLimit.Help\" for=\"pe_txtTimeLimit\">" + PE_GetString("Time Limit:") + " </label><input type=\"text\" id=\"pe_txtTimeLimit\" class=\"pe_smTxtBox\" /> " + PE_GetString(" (minutes, 0 for no limit)") + "</div>";
        HistoryOptions += "</div></div>";

        return HistoryOptions;
    }


    function BuildReportingHeuristics() {
        var Heuristics = "<div id=\"pe_Heuristics\" class=\"pe_tabcontents\">";
        Heuristics += "<div class=\"pe_tabtitle\">";
        Heuristics += "<span class=\"\">" + PE_GetString("Reporting Heuristics") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        Heuristics += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings give hints to allow more intelligent reporting on course status.") + "</div></div>";
        Heuristics += "<hr />";
        Heuristics += "<div class=\"pe_controlswrapper\">";
        Heuristics += "<div id=\"pe_IsCompletionTracked\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbIsCompletionTracked\"  /> <label tooltipid=\"IsCompletionTracked.Help\" for=\"pe_ckbIsCompletionTracked\">" + PE_GetString("Is Completion Tracked?") + " </label></div>";
        Heuristics += "<div id=\"pe_IsSatisfactionTracked\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbIsSatisfactionTracked\"  /> <label tooltipid=\"IsSatisfactionTracked.Help\" for=\"pe_ckbIsSatisfactionTracked\">" + PE_GetString("Is Satisfaction Tracked?") + " </label></div>";
        Heuristics += "<div id=\"pe_IsScoreTracked\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbIsScoreTracked\"  /> <label tooltipid=\"IsScoreTracked.Help\" for=\"pe_ckbIsScoreTracked\">" + PE_GetString("Is Score Tracked?") + " </label></div>";
        Heuristics += "<div id=\"pe_IsIncompleteScoreMeaningful\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbIsIncompleteScoreMeaningful\"  /> <label tooltipid=\"IsIncompleteScoreMeaningful.Help\" for=\"pe_ckbIsIncompleteScoreMeaningful\">" + PE_GetString("Is Incomplete Score Meaningful?") + " </label></div>";
        Heuristics += "<div id=\"pe_IsIncompleteSatisfactionMeaningful\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbIsIncompleteSatisfactionMeaningful\"  /> <label tooltipid=\"IsIncompleteSatisfactionMeaningful.Help\" for=\"pe_ckbIsIncompleteSatisfactionMeaningful\">" + PE_GetString("Is Incomplete Satisfaction Meaningful?") + " </label></div>";
        Heuristics += "</div></div>";

        return Heuristics;
    }


    function BuildPresets() {
        var PresetMarkup = "<div id=\"pe_Presets\" class=\"pe_tabcontents\">";
        PresetMarkup += "<div class=\"pe_tabtitle\">";
        PresetMarkup += "<span class=\"\">" + PE_GetString("Presets") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        PresetMarkup += "<div class=\"pe_moreinfo off\">" + PE_GetString("Create a new preset based on your currently configured package properties or apply previously created settings.");
        PresetMarkup += "</div></div>";
        PresetMarkup += "<hr />";

        PresetMarkup += "<div id=\"pe_PresetList\" class=\"pe_controlswrapper\"></div>";

        //add a new preset
        PresetMarkup += "<div id=\"pe_AddNewPreset\" class=\"pe_propertycontrol \"><br/><div><b>Create a new preset based on current settings</b></div>";
        PresetMarkup += "<label tooltipid=\"Presets.Help\" for=\"pe_txtPresetName\">" + PE_GetString("Preset Name:") + "</label> <input type=\"text\" id=\"pe_txtPresetName\" class=\"\" />";
        PresetMarkup += " <button id=\"pe_BtnAddPreset\" type=\"button\">" + PE_GetString("Add Preset") + "</button></div>";
        PresetMarkup += "</div>";
        return PresetMarkup;
    }


    function AddPropertyPresets() {
        var PresetMarkup = "<table>";
        $pe(Presets).children("preset").each(function() {
            var pId = $pe(this).attr('id');
            var pName = $pe(this).find('name').text();
            //var pProps = $pe(this).find('packageproperties');
            PresetMarkup += "<tr><td>" + PE_GetString(pName) + "</td>";
            PresetMarkup += "<td class=\"pe_indent1\"><a class=\"pe_applyPreset\" presetid=\"" + pId + "\" href=\"javascript:void(0);\">Apply</a></td>";
            if (pId != "default") {
                PresetMarkup += "<td class=\"pe_indent1\"><a class=\"pe_deletePreset\" presetid=\"" + pId + "\" href=\"javascript:void(0);\">Delete</a></td>";
            } else {
                PresetMarkup += "<td></td>";
            }
            PresetMarkup += "</tr>";
        });

        PresetMarkup += "</table>";
        $pe('#pe_PresetList').html(PresetMarkup);

        $pe('.pe_deletePreset').click(function() {
            var pId = $pe(this).attr('presetid');
            DeletePropertyPreset(pId);
            $pe(this).parent().parent('tr').remove();
            return false;
        });

        $pe('.pe_applyPreset').click(function() {
            var pId = $pe(this).attr('presetid');
            var props = $pe(Presets).find("preset[id='" + pId + "']").children().get(1);
            PopulateForm(props);
            ShowControlChanges();
        });
    }


    function BuildSaveBar() {
        var SaveBar = "";
        SaveBar += "<div id=\"pe_SaveBar\" >";
        SaveBar += "<div id=\"pe_Message\" ></div>";
        SaveBar += "<div id=\"pe_SaveButton\" >";
        SaveBar += "<input type=\"button\" id=\"pe_btnSave\" value=\"" + PE_GetString("save") + "\" />";
        SaveBar += "</div><div style=\"clear:both;\"></div></div>";

        return SaveBar;
    }


    function BuildRudimentarySequencing() {
        var RudimentarySequencing = "<div id=\"pe_RudSequencing\" class=\"pe_tabcontents\">";
        RudimentarySequencing += "<div class=\"pe_tabtitle\">";
        RudimentarySequencing += "<span class=\"\">" + PE_GetString("Rudimentary Sequencing") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        RudimentarySequencing += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings control what action the SCORM Player will take when a SCO exits. These settings not applicable to SCORM 2004 courses since SCORM 2004 Simple Sequencing allows the content to specify these behaviors. There are three factors the SCORM Player looks at when determining the action to take when a SCO exits: the position of the SCO in the course (is it in the middle, or is it the last SCO), the state of the SCO/Course, and the SCORM exit type specified by the SCO. NOTE: These settings only take affect when the content originates an exit action by calling LMSFinish before the learner initiates an exit action by using a navigational control in the SCORM Player.");
        RudimentarySequencing += "</div></div>";
        RudimentarySequencing += "<hr />";

        RudimentarySequencing += "<div class=\"pe_controlswrapper\">";

        RudimentarySequencing += "<div id=\"pe_IntermedSCOSequencing\">";
        RudimentarySequencing += "<strong>" + PE_GetString("Intermediate SCO") + "</strong> - " + PE_GetString("These settings apply to SCOs that are in the middle of the course (every SCO except for the last SCO).");
        RudimentarySequencing += "<table class=\"pe_SeqControlsTable\">";
        RudimentarySequencing += "<tr class=\"pe_seqHeader\"><td class=\"pe_seqLabel\"></td><td tooltipid=\"CourseSatisfied.Help\">" + HelpStrings['CourseSatisfied.Help'] + "</td><td tooltipid=\"CourseNotSatisfied.Help\">" + HelpStrings['CourseNotSatisfied.Help'] + "</td></tr>";
        RudimentarySequencing += "<tr><td class=\"pe_seqLabel\" tooltipid=\"NormalAction.Help\">" + PE_GetString("Normal") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntNormalSatisfied");
        RudimentarySequencing += "<a id=\"all-intermediate\" class=\"pe_indent1\" href=\"#\">apply to all</a></td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntNormalNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr><tr>";
        RudimentarySequencing += "<td class=\"pe_seqLabel\" tooltipid=\"SuspendAction.Help\">" + PE_GetString("Suspend") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntSuspendSatisfied") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntSuspendNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr><tr>";
        RudimentarySequencing += "<td class=\"pe_seqLabel\" tooltipid=\"TimeoutAction.Help\">" + PE_GetString("Timeout") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntTimeoutSatisfied") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntTimeoutNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr><tr>";
        RudimentarySequencing += "<td class=\"pe_seqLabel\" tooltipid=\"LogoutAction.Help\">" + PE_GetString("Logout") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntLogoutSatisfied") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlIntLogoutNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr></table></div>";

        RudimentarySequencing += "<br/><div id=\"pe_FinalSCOSequencing\">";
        RudimentarySequencing += "<strong>" + PE_GetString("Final SCO") + "</strong> - " + PE_GetString("These settings apply to the last SCO of the course. In the case of a single SCO course, the SCO is always treated as the final SCO.");
        RudimentarySequencing += "<table class=\"pe_SeqControlsTable\">";
        RudimentarySequencing += "<tr class=\"pe_seqHeader\"><td class=\"pe_seqLabel\"></td><td tooltipid=\"CourseSatisfied.Help\">" + HelpStrings['CourseSatisfied.Help'] + "</td><td tooltipid=\"CourseNotSatisfied.Help\">" + HelpStrings['CourseNotSatisfied.Help'] + "</td></tr>";
        RudimentarySequencing += "<tr><td class=\"pe_seqLabel\" tooltipid=\"NormalAction.Help\">" + PE_GetString("Normal") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalNormalSatisfied");
        RudimentarySequencing += "<a id=\"all-final\" class=\"pe_indent1\" href=\"#\">apply to all</a></td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalNormalNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr><tr>";
        RudimentarySequencing += "<td class=\"pe_seqLabel\" tooltipid=\"SuspendAction.Help\">" + PE_GetString("Suspend") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalSuspendSatisfied") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalSuspendNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr><tr>";
        RudimentarySequencing += "<td class=\"pe_seqLabel\" tooltipid=\"TimeoutAction.Help\">" + PE_GetString("Timeout") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalTimeoutSatisfied") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalTimeoutNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr><tr>";
        RudimentarySequencing += "<td class=\"pe_seqLabel\" tooltipid=\"LogoutAction.Help\">" + PE_GetString("Logout") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalLogoutSatisfied") + "</td>";
        RudimentarySequencing += "<td>" + BuildSequencingSelector("pe_ddlFinalLogoutNotSatisfied") + "</td>";
        RudimentarySequencing += "</tr></table></div>";
        RudimentarySequencing += "</div></div>";

        return RudimentarySequencing;

    }


    function BuildSequencingSelector(id) {
        var seqSelector = "<select id=\"" + id + "\">";
        seqSelector += "<option value=\"exit,no confirmation\">" + PE_GetString("Exit course") + "</option>";
        seqSelector += "<option value=\"exit,confirmation\">" + PE_GetString("Exit course after confirm") + "</option>";
        seqSelector += "<option value=\"continue\">" + PE_GetString("Go to next SCO") + "</option>";
        seqSelector += "<option value=\"message page\">" + PE_GetString("Display message") + "</option>";
        seqSelector += "<option value=\"do nothing\">" + PE_GetString("Do nothing") + "</option>";
        seqSelector += "</select>";

        return seqSelector;
    }


    function BuildRudimentaryRollup() {
        var RudimentaryRollup = "<div id=\"pe_RudRollup\" class=\"pe_tabcontents\">";
        RudimentaryRollup += "<div class=\"pe_tabtitle\">";
        RudimentaryRollup += "<span class=\"\">" + PE_GetString("Rudimentary Rollup") + "</span><span class=\"pe_infoLink\"><a href=\"javascript: void(0);\">" + PE_GetString("info") + "</a></span>";
        RudimentaryRollup += "<div class=\"pe_moreinfo off\">" + PE_GetString("These settings specify how to score courses. These settings not applicable to SCORM 2004 courses since SCORM 2004 Simple Sequencing allows the content to specify these behaviors.");
        RudimentaryRollup += "</div></div>";
        RudimentaryRollup += "<hr />";

        RudimentaryRollup += "<div class=\"pe_controlswrapper\">";

        RudimentaryRollup += "<div id=\"pe_ScoreRollupMode\" class=\"pe_propertycontrol\"><label tooltipid=\"ScoreRollupMode.Help\" for=\"pe_ddlScoreRollupMode\">" + PE_GetString("Score Rollup Mode:") + " </label>";
        RudimentaryRollup += "<select id=\"pe_ddlScoreRollupMode\">";
        RudimentaryRollup += "<option value=\"score provided by course\">" + PE_GetString("Score Provided By Course (single SCO)") + "</option>";
        RudimentaryRollup += "<option value=\"average score of all units\">" + PE_GetString("Average Score of All Units") + "</option>";
        RudimentaryRollup += "<option value=\"average score of all units with scores\">" + PE_GetString("Average Score of All Units with Scores") + "</option>";
        RudimentaryRollup += "<option value=\"fixed average\">" + PE_GetString("Fixed Average") + "</option>";
        RudimentaryRollup += "<option value=\"average score of all units with non-zero scores\">" + PE_GetString("Average Score Of All Units With Non-zero Scores") + "</option>";
        RudimentaryRollup += "<option value=\"last sco score\">" + PE_GetString("Last SCO Score") + "</option>";
        RudimentaryRollup += "</select>";
        RudimentaryRollup += "</div>";

        RudimentaryRollup += "<div id=\"pe_NumScoringObjects\" class=\"pe_propertycontrol pe_indent1\"><label tooltipid=\"NumberOfScoringObjects.Help\" for=\"pe_txtNumScoringObjects\">" + PE_GetString("Number of Scoring Objects:") + " </label><input type=\"text\" id=\"pe_txtNumScoringObjects\" class=\"pe_smTxtBox\" /></div>";

        RudimentaryRollup += "<div id=\"pe_StatusRollupMode\" class=\"pe_propertycontrol\"><label tooltipid=\"StatusRollupMode.Help\" for=\"pe_ddlStatusRollupMode\">" + PE_GetString("Status Rollup Mode:") + " </label>";
        RudimentaryRollup += "<select id=\"pe_ddlStatusRollupMode\">";
        RudimentaryRollup += "<option value=\"status provided by course\">" + PE_GetString("Status Provided By Course (single SCO)") + "</option>";
        RudimentaryRollup += "<option value=\"complete when all units complete\">" + PE_GetString("Complete When All Units Complete") + "</option>";
        RudimentaryRollup += "<option value=\"complete when all units complete and not failed\">" + PE_GetString("Complete When All Units are Complete and Not Failed") + "</option>";
        RudimentaryRollup += "<option value=\"complete when threshold score is met\">" + PE_GetString("Complete When Threshold Score Is Met") + "</option>";
        RudimentaryRollup += "<option value=\"complete when all units complete and threshold score is met\">" + PE_GetString("Complete When All Units Complete And Threshold Score Is Met") + "</option>";
        RudimentaryRollup += "<option value=\"complete when all units are passed\">" + PE_GetString("Complete When All Units Are Passed") + "</option>";
        RudimentaryRollup += "</select>";
        RudimentaryRollup += "</div>";

        RudimentaryRollup += "<div id=\"pe_ThresholdScoreForCompletion\" class=\"pe_propertycontrol pe_indent1\"><label tooltipid=\"ThresholdScoreForCompletion.Help\" for=\"pe_txtThresholdScoreForCompletion\">" + PE_GetString("Threshold Score for Completion:") + " </label><input type=\"text\" id=\"pe_txtThresholdScoreForCompletion\" class=\"pe_smTxtBox\" /> " + PE_GetString("(0.0 - 1.0)") + "</div>";

        RudimentaryRollup += "<div id=\"pe_ApplyRollupStatusToSuccess\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbApplyRollupStatusToSuccess\" /><label tooltipid=\"ApplyRollupStatusToSuccess.Help\" for=\"pe_ckbApplyRollupStatusToSuccess\">" + PE_GetString("Apply Rollup Status To Success Status") + "</label></div>";
        RudimentaryRollup += "<div id=\"pe_FirstScoIsPretest\" class=\"pe_propertycontrol\"><input type=\"checkbox\" id=\"pe_ckbFirstScoIsPretest\" /><label tooltipid=\"FirstScoIsPreTest.Help\" for=\"pe_ckbFirstScoIsPretest\">" + PE_GetString("First SCO is Pretest") + "</label></div>";

        RudimentaryRollup += "</div></div>";

        return RudimentaryRollup;
    }


    /*
      Utilities
    */
    function ConvertYesNo(value) {
        if (value=='1' || value.toLowerCase()=="yes" || value == true) {
            return true;
        } else {
            return false;
        }
    }


    // Just like $.getScript(), but with caching enabled.
    function GetCachedScript(url, options) {
        options = $pe.extend(options || {}, {
            dataType: "script",
            cache: true,
            url: url
        });

        return $pe.ajax(options)
    }


    function PE_GetString(key) {
        var value = EUStrings[key];

        if (value !== undefined && value !== null && value.length > 0) {
            var str = value;
        } else {
            // If the key doesn't have a value defined for it, use the key itself as the value.  We don't
            // want to create an error situation here so the worse case is an english string is shown instead
            // of a localized string.
            var str = key;
            //alert("Resource String does not exist: " + key);
        }

        // Substitute variables if this is a formatted string with {0}, {1}, etc
        for (var i = 1; i < arguments.length; i++) {
            var regExToReplace = new RegExp("\\{" + (i-1) + "\\}", "g");
            //str = str.replace("{" + (i-1) + "}", arguments[i].toString());
            if (arguments[i] == null){
                arguments[i]="";
            }

            str = str.replace(regExToReplace, arguments[i].toString());
        }

        return str;
    }

})(jQuery);
