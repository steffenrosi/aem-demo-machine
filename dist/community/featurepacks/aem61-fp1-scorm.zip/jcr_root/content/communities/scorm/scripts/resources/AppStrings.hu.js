var AppStrings = new Object();
AppStrings['View Debug'] = 'View Debug';
AppStrings['Exit Without Saving Debug'] = 'Exit Without Saving Debug';
AppStrings['We launched your course in a new window but if you do not see it, a popup blocker may be preventing it from opening. Please disable popup blockers for this site.'] = 'Elind\u00EDtottunk a kurzus\u00E1t egy \u00FAj ablakban, de ha nem l\u00E1tja, akkor egy el\u0151ugr\u00F3ablak-blokkol\u00F3 akad\u00E1lyozhatja a megnyit\u00E1s\u00E1t. K\u00E9rj\u00FCk, kapcsolja ki az el\u0151ugr\u00F3ablak-blokkol\u00F3kat erre az oldalra.';
AppStrings['We attempted to launch your course in a new window, but a popup blocker is preventing it from opening. Please disable popup blockers for this site.'] = 'A kurzus\u00E1t megpr\u00F3b\u00E1ltuk elind\u00EDtani egy \u00FAj ablakban, de ezt megakad\u00E1lyozta egy felugr\u00F3 ablak blokkol\u00F3. K\u00E9rj\u00FCk, ezen oldal megnyit\u00E1sakor inaktiv\u00E1lja a felugr\u00F3 ablak blokkol\u00F3kat!';
