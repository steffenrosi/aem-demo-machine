var SCORM_TRUE="true";
var SCORM_FALSE="false";
var SCORM_UNKNOWN="unknown";
var SCORM2004_NO_ERROR="0";
var SCORM2004_GENERAL_EXCEPTION_ERROR="101";
var SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR="102";
var SCORM2004_ALREADY_INTIAILIZED_ERROR="103";
var SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR="104";
var SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR="111";
var SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR="112";
var SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR="113";
var SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR="122";
var SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR="123";
var SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR="132";
var SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR="133";
var SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR="142";
var SCORM2004_COMMIT_AFTER_TERMINATION_ERROR="143";
var SCORM2004_GENERAL_ARGUMENT_ERROR="201";
var SCORM2004_GENERAL_GET_FAILURE_ERROR="301";
var SCORM2004_GENERAL_SET_FAILURE_ERROR="351";
var SCORM2004_GENERAL_COMMIT_FAILURE_ERROR="391";
var SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR="401";
var SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR="402";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR="403";
var SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR="404";
var SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR="405";
var SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR="406";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR="407";
var SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR="408";
var SCORM2004_ErrorStrings=new Array();
SCORM2004_ErrorStrings[SCORM2004_NO_ERROR]="No Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_EXCEPTION_ERROR]="General Exception";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR]="General Initialization Failure";
SCORM2004_ErrorStrings[SCORM2004_ALREADY_INTIAILIZED_ERROR]="Already Initialized";
SCORM2004_ErrorStrings[SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR]="Content Instance Terminated";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR]="General Termination Failure";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR]="Termination Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR]="Termination AFter Termination";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR]="Retrieve Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR]="Retrieve Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR]="Store Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR]="Store Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR]="Commit Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_AFTER_TERMINATION_ERROR]="Commit After Termination";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_ARGUMENT_ERROR]="General Argument Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_GET_FAILURE_ERROR]="General Get Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_SET_FAILURE_ERROR]="General Set Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_COMMIT_FAILURE_ERROR]="General Commit Failure";
SCORM2004_ErrorStrings[SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR]="Undefined Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR]="Unimplemented Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR]="Data Model Element Value Not Initialized";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR]="Data Model Element Is Read Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR]="Data Model Element Is Write Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR]="Data Model Element Type Mismatch";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR]="Data Model Element Value Out Of Range";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR]="Data Model Dependency Not Established";
var SCORM2004_VERSION="1.0";
var SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN="comment,location,timestamp";
var SCORM2004_COMMENTS_FROM_LMS_CHILDREN="comment,location,timestamp";
var SCORM2004_INTERACTIONS_CHILDREN="id,type,objectives,timestamp,correct_responses,weighting,learner_response,result,latency,description";
var SCORM2004_LEARNER_PREFERENCE_CHILDREN="audio_level,language,delivery_speed,audio_captioning";
var SCORM2004_OBJECTIVES_CHILDREN="progress_measure,description,score,id,success_status,completion_status";
var SCORM2004_OBJECTIVES_SCORE_CHILDREN="scaled,raw,min,max";
var SCORM2004_SCORE_CHILDREN="scaled,min,max,raw";
function RunTimeApi(_1,_2){
this.LearnerId=_1;
this.LearnerName=_2;
this.ErrorNumber=SCORM2004_NO_ERROR;
this.ErrorString="";
this.ErrorDiagnostic="";
this.TrackedStartDate=null;
this.TrackedEndDate=null;
this.Initialized=false;
this.Terminated=false;
this.ScoCalledFinish=false;
this.CloseOutSessionCalled=false;
this.RunTimeData=null;
this.LearningObject=null;
this.Activity=null;
this.IsLookAheadSequencerDataDirty=false;
this.IsLookAheadSequencerRunning=false;
this.LearnerPrefsArray=new Object();
if(SSP_ENABLED){
this.SSPApi=new SSPApi(MAX_SSP_STORAGE,this);
}
}
RunTimeApi.prototype.GetNavigationRequest=RunTimeApi_GetNavigationRequest;
RunTimeApi.prototype.ResetState=RunTimeApi_ResetState;
RunTimeApi.prototype.InitializeForDelivery=RunTimeApi_InitializeForDelivery;
RunTimeApi.prototype.SetDirtyData=RunTimeApi_SetDirtyData;
RunTimeApi.prototype.WriteHistoryLog=RunTimeApi_WriteHistoryLog;
RunTimeApi.prototype.WriteHistoryReturnValue=RunTimeApi_WriteHistoryReturnValue;
RunTimeApi.prototype.WriteAuditLog=RunTimeApi_WriteAuditLog;
RunTimeApi.prototype.WriteAuditReturnValue=RunTimeApi_WriteAuditReturnValue;
RunTimeApi.prototype.WriteDetailedLog=RunTimeApi_WriteDetailedLog;
RunTimeApi.prototype.CloseOutSession=RunTimeApi_CloseOutSession;
RunTimeApi.prototype.NeedToCloseOutSession=RunTimeApi_NeedToCloseOutSession;
RunTimeApi.prototype.AccumulateTotalTimeTracked=RunTimeApi_AccumulateTotalTimeTracked;
RunTimeApi.prototype.InitTrackedTimeStart=RunTimeApi_InitTrackedTimeStart;
function RunTimeApi_GetNavigationRequest(){
return null;
}
function RunTimeApi_ResetState(_3){
this.TrackedStartDate=null;
this.TrackedEndDate=null;
}
function RunTimeApi_InitializeForDelivery(_4){
this.RunTimeData=_4.RunTime;
this.LearningObject=_4.LearningObject;
this.Activity=_4;
this.CloseOutSessionCalled=false;
if(Control.Package.Properties.ResetRunTimeDataTiming==RESET_RT_DATA_TIMING_WHEN_EXIT_IS_NOT_SUSPEND){
if(this.RunTimeData.Exit!=SCORM_EXIT_SUSPEND&&this.RunTimeData.Exit!=SCORM_EXIT_LOGOUT){
var _5={ev:"ResetRuntime",ai:_4.ItemIdentifier,at:_4.LearningObject.Title};
this.WriteHistoryLog("",_5);
this.RunTimeData.ResetState();
}
}
this.RunTimeData.NavRequest=SCORM_RUNTIME_NAV_REQUEST_NONE;
this.Initialized=false;
this.Terminated=false;
this.ScoCalledFinish=false;
this.TrackedStartDate=null;
this.TrackedEndDate=null;
this.ErrorNumber=SCORM2004_NO_ERROR;
this.ErrorString="";
this.ErrorDiagnostic="";
var _6;
var _7;
var _8;
for(var _9 in this.Activity.ActivityObjectives){
_8=this.Activity.ActivityObjectives[_9];
_6=_8.GetIdentifier();
if(_6!==null&&_6!==undefined&&_6.length>0){
_7=this.RunTimeData.FindObjectiveWithId(_6);
if(_7===null){
this.RunTimeData.AddObjective();
_7=this.RunTimeData.Objectives[this.RunTimeData.Objectives.length-1];
_7.Identifier=_6;
}
if(_8.GetProgressStatus(this.Activity,false)===true){
if(_8.GetSatisfiedStatus(this.Activity,false)===true){
_7.SuccessStatus=SCORM_STATUS_PASSED;
}else{
_7.SuccessStatus=SCORM_STATUS_FAILED;
}
}
if(_8.GetMeasureStatus(this.Activity,false)===true){
_7.ScoreScaled=_8.GetNormalizedMeasure(this.Activity,false);
}
_7.SuccessStatusChangedDuringRuntime=false;
_7.MeasureChangedDuringRuntime=false;
}
}
}
function RunTimeApi_SetDirtyData(){
this.Activity.DataState=DATA_STATE_DIRTY;
}
function RunTimeApi_WriteHistoryLog(_a,_b){
HistoryLog.WriteEventDetailed(_a,_b);
}
function RunTimeApi_WriteHistoryReturnValue(_c,_d){
HistoryLog.WriteEventDetailedReturnValue(_c,_d);
}
function RunTimeApi_WriteAuditLog(_e){
Debug.WriteRteAudit(_e);
}
function RunTimeApi_WriteAuditReturnValue(_f){
Debug.WriteRteAuditReturnValue(_f);
}
function RunTimeApi_WriteDetailedLog(str){
Debug.WriteRteDetailed(str);
}
function RunTimeApi_NeedToCloseOutSession(){
return !this.CloseOutSessionCalled;
}
RunTimeApi.prototype.version=SCORM2004_VERSION;
RunTimeApi.prototype.Initialize=RunTimeApi_Initialize;
RunTimeApi.prototype.Terminate=RunTimeApi_Terminate;
RunTimeApi.prototype.GetValue=RunTimeApi_GetValue;
RunTimeApi.prototype.SetValue=RunTimeApi_SetValue;
RunTimeApi.prototype.Commit=RunTimeApi_Commit;
RunTimeApi.prototype.GetLastError=RunTimeApi_GetLastError;
RunTimeApi.prototype.GetErrorString=RunTimeApi_GetErrorString;
RunTimeApi.prototype.GetDiagnostic=RunTimeApi_GetDiagnostic;
RunTimeApi.prototype.RetrieveGetValueData=RunTimeApi_RetrieveGetValueData;
RunTimeApi.prototype.StoreValue=RunTimeApi_StoreValue;
RunTimeApi.prototype.SetErrorState=RunTimeApi_SetErrorState;
RunTimeApi.prototype.ClearErrorState=RunTimeApi_ClearErrorState;
RunTimeApi.prototype.CheckMaxLength=RunTimeApi_CheckMaxLength;
RunTimeApi.prototype.CheckLengthAndWarn=RunTimeApi_CheckLengthAndWarn;
RunTimeApi.prototype.CheckForInitializeError=RunTimeApi_CheckForInitializeError;
RunTimeApi.prototype.CheckForTerminateError=RunTimeApi_CheckForTerminateError;
RunTimeApi.prototype.CheckForGetValueError=RunTimeApi_CheckForGetValueError;
RunTimeApi.prototype.CheckForSetValueError=RunTimeApi_CheckForSetValueError;
RunTimeApi.prototype.CheckForCommitError=RunTimeApi_CheckForCommitError;
RunTimeApi.prototype.CheckCommentsCollectionLength=RunTimeApi_CheckCommentsCollectionLength;
RunTimeApi.prototype.CheckInteractionsCollectionLength=RunTimeApi_CheckInteractionsCollectionLength;
RunTimeApi.prototype.CheckInteractionObjectivesCollectionLength=RunTimeApi_CheckInteractionObjectivesCollectionLength;
RunTimeApi.prototype.CheckInteractionsCorrectResponsesCollectionLength=RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength;
RunTimeApi.prototype.CheckObjectivesCollectionLength=RunTimeApi_CheckObjectivesCollectionLength;
RunTimeApi.prototype.LookAheadSessionClose=RunTimeApi_LookAheadSessionClose;
RunTimeApi.prototype.ValidOtheresponse=RunTimeApi_ValidOtheresponse;
RunTimeApi.prototype.ValidNumericResponse=RunTimeApi_ValidNumericResponse;
RunTimeApi.prototype.ValidSequencingResponse=RunTimeApi_ValidSequencingResponse;
RunTimeApi.prototype.ValidPerformanceResponse=RunTimeApi_ValidPerformanceResponse;
RunTimeApi.prototype.ValidMatchingResponse=RunTimeApi_ValidMatchingResponse;
RunTimeApi.prototype.ValidLikeRTResponse=RunTimeApi_ValidLikeRTResponse;
RunTimeApi.prototype.ValidLongFillInResponse=RunTimeApi_ValidLongFillInResponse;
RunTimeApi.prototype.ValidFillInResponse=RunTimeApi_ValidFillInResponse;
RunTimeApi.prototype.IsValidArrayOfLocalizedStrings=RunTimeApi_IsValidArrayOfLocalizedStrings;
RunTimeApi.prototype.IsValidArrayOfShortIdentifiers=RunTimeApi_IsValidArrayOfShortIdentifiers;
RunTimeApi.prototype.IsValidCommaDelimitedArrayOfShortIdentifiers=RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers;
RunTimeApi.prototype.ValidMultipleChoiceResponse=RunTimeApi_ValidMultipleChoiceResponse;
RunTimeApi.prototype.ValidTrueFalseResponse=RunTimeApi_ValidTrueFalseResponse;
RunTimeApi.prototype.ValidTimeInterval=RunTimeApi_ValidTimeInterval;
RunTimeApi.prototype.ValidTime=RunTimeApi_ValidTime;
RunTimeApi.prototype.ValidReal=RunTimeApi_ValidReal;
RunTimeApi.prototype.IsValidUrn=RunTimeApi_IsValidUrn;
RunTimeApi.prototype.ValidIdentifier=RunTimeApi_ValidIdentifier;
RunTimeApi.prototype.ValidShortIdentifier=RunTimeApi_ValidShortIdentifier;
RunTimeApi.prototype.ValidLongIdentifier=RunTimeApi_ValidLongIdentifier;
RunTimeApi.prototype.ValidLanguage=RunTimeApi_ValidLanguage;
RunTimeApi.prototype.ExtractLanguageDelimiterFromLocalizedString=RunTimeApi_ExtractLanguageDelimiterFromLocalizedString;
RunTimeApi.prototype.ValidLocalizedString=RunTimeApi_ValidLocalizedString;
RunTimeApi.prototype.ValidCharString=RunTimeApi_ValidCharString;
RunTimeApi.prototype.TranslateBooleanIntoCMI=RunTimeApi_TranslateBooleanIntoCMI;
RunTimeApi.prototype.SetLookAheadDirtyDataFlagIfNeeded=RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded;
RunTimeApi.prototype.RunLookAheadSequencerIfNeeded=RunTimeApi_RunLookAheadSequencerIfNeeded;
RunTimeApi.prototype.GetCompletionStatus=RunTimeApi_GetCompletionStatus;
RunTimeApi.prototype.GetSuccessStatus=RunTimeApi_GetSuccessStatus;
function RunTimeApi_Initialize(arg){
this.WriteAuditLog("`1722`"+arg+"')");
var _12={ev:"ApiInitialize"};
if(this.Activity){
_12.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_12);
var _13;
var _14;
this.ClearErrorState();
_13=this.CheckForInitializeError(arg);
if(!_13){
_14=SCORM_FALSE;
}else{
if(this.TrackedStartDate==null){
this.TrackedStartDate=new Date();
}
if(this.StartSessionTotalTime==null&&this.Activity){
this.StartSessionTotalTime=this.Activity.RunTime.TotalTime;
}
this.RunTimeData.Exit=SCORM_EXIT_UNKNOWN;
this.Initialized=true;
_14=SCORM_TRUE;
}
Control.ScoLoader.ScoLoaded=true;
this.WriteAuditReturnValue(_14);
return _14;
}
function RunTimeApi_Terminate(arg){
this.WriteAuditLog("`1732`"+arg+"')");
var _16;
var _17;
var _18;
this.ClearErrorState();
_16=this.CheckForTerminateError(arg);
var _19=(_16&&(this.ScoCalledFinish===false));
if(!_16){
_18=SCORM_FALSE;
}else{
var _1a={ev:"ApiTerminate"};
if(this.Activity){
_1a.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_1a);
this.CloseOutSession("Terminate");
this.RunLookAheadSequencerIfNeeded();
this.Terminated=true;
this.ScoCalledFinish=true;
this.SetDirtyData();
_18=SCORM_TRUE;
}
if(_19===true&&this.RunTimeData.NavRequest!=SCORM_RUNTIME_NAV_REQUEST_NONE&&Control.IsThereAPendingNavigationRequest()===false){
this.WriteDetailedLog("`442`"+Control.IsThereAPendingNavigationRequest());
window.setTimeout("Control.ScoHasTerminatedSoUnload();",150);
}
Control.SignalTerminated();
this.WriteAuditReturnValue(_18);
return _18;
}
function RunTimeApi_GetValue(_1b){
this.WriteAuditLog("`1735`"+_1b+"')");
var _1c;
var _1d;
this.ClearErrorState();
_1b=CleanExternalString(_1b);
var _1e=RemoveIndiciesFromCmiElement(_1b);
var _1f=ExtractIndex(_1b);
var _20=ExtractSecondaryIndex(_1b);
_1d=this.CheckForGetValueError(_1b,_1e,_1f,_20);
if(!_1d){
_1c="";
}else{
_1c=this.RetrieveGetValueData(_1b,_1e,_1f,_20);
if(_1c===null){
_1c="";
}
}
this.WriteAuditReturnValue(_1c);
return _1c;
}
function RunTimeApi_SetValue(_21,_22){
this.WriteAuditLog("`1736`"+_21+"`1747`"+_22+"')");
var _23;
var _24;
this.ClearErrorState();
_21=CleanExternalString(_21);
_22=CleanExternalString(_22);
var _25=RemoveIndiciesFromCmiElement(_21);
var _26=ExtractIndex(_21);
var _27=ExtractSecondaryIndex(_21);
this.CheckMaxLength(_25,_22);
_23=this.CheckForSetValueError(_21,_22,_25,_26,_27);
if(!_23){
_24=SCORM_FALSE;
}else{
this.StoreValue(_21,_22,_25,_26,_27);
this.SetDirtyData();
_24=SCORM_TRUE;
}
this.WriteAuditReturnValue(_24);
return _24;
}
function RunTimeApi_Commit(arg){
this.WriteAuditLog("`1739`"+arg+"')");
var _29;
var _2a;
this.ClearErrorState();
_29=this.CheckForCommitError(arg);
if(!_29){
_2a=SCORM_FALSE;
}else{
_2a=SCORM_TRUE;
}
this.RunLookAheadSequencerIfNeeded(true);
this.WriteAuditReturnValue(_2a);
return _2a;
}
function RunTimeApi_GetLastError(){
this.WriteAuditLog("`1713`");
var _2b=this.ErrorNumber;
this.WriteAuditReturnValue(_2b);
return _2b;
}
function RunTimeApi_GetErrorString(arg){
this.WriteAuditLog("`1686`"+arg+"')");
var _2d="";
if(arg===""){
_2d="";
}else{
if(SCORM2004_ErrorStrings[arg]!==null&&SCORM2004_ErrorStrings[arg]!==undefined){
_2d=SCORM2004_ErrorStrings[arg];
}
}
this.WriteAuditReturnValue(_2d);
return _2d;
}
function RunTimeApi_GetDiagnostic(arg){
this.WriteAuditLog("`1696`"+arg+"')");
var _2f;
if(this.ErrorDiagnostic===""){
_2f="No diagnostic information available";
}else{
_2f=this.ErrorDiagnostic;
}
this.WriteAuditReturnValue(_2f);
return _2f;
}
function RunTimeApi_CloseOutSession(_30){
this.WriteDetailedLog("`1656`");
this.WriteDetailedLog("`1741`"+this.RunTimeData.Mode);
this.WriteDetailedLog("`1738`"+this.RunTimeData.Credit);
this.WriteDetailedLog("`1443`"+this.RunTimeData.CompletionStatus);
this.WriteDetailedLog("`1507`"+this.RunTimeData.SuccessStatus);
this.WriteDetailedLog("`1576`"+this.LearningObject.GetScaledPassingScore());
this.WriteDetailedLog("`1740`"+this.RunTimeData.ScoreScaled);
this.WriteDetailedLog("`1538`"+this.LearningObject.CompletionThreshold);
this.WriteDetailedLog("`1608`"+this.RunTimeData.ProgressMeasure);
var _31=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTime);
var _32=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime);
var _33=_31+_32;
var _34=ConvertHundredthsToIso8601TimeSpan(_33);
this.WriteDetailedLog("`1714`"+this.RunTimeData.SessionTime+" ("+_31+"`1719`");
this.WriteDetailedLog("`1699`"+this.RunTimeData.TotalTime+" ("+_32+"`1719`");
this.WriteDetailedLog("`1687`"+_34+" ("+_33+"`1719`");
this.RunTimeData.TotalTime=_34;
this.RunTimeData.SessionTime="";
this.AccumulateTotalTimeTracked();
this.WriteDetailedLog("`1527`"+this.RunTimeData.TotalTimeTracked);
if(Control.IsThereAPendingNavigationRequest()){
if(Control.PendingNavigationRequest.Type==NAVIGATION_REQUEST_SUSPEND_ALL){
this.WriteDetailedLog("`911`");
this.RunTimeData.Exit=SCORM_EXIT_SUSPEND;
}
}else{
if(this.RunTimeData.NavRequest==SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL){
this.WriteDetailedLog("`929`");
this.RunTimeData.Exit=SCORM_EXIT_SUSPEND;
}
}
if(this.RunTimeData.Exit==SCORM_EXIT_SUSPEND||this.RunTimeData.Exit==SCORM_EXIT_LOGOUT){
this.WriteDetailedLog("`1594`");
this.RunTimeData.Entry=SCORM_ENTRY_RESUME;
}
var _35=this.GetCompletionStatus();
if(_35!=this.RunTimeData.CompletionStatus){
this.RunTimeData.CompletionStatus=_35;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
}
var _36=this.GetSuccessStatus();
if(_36!=this.RunTimeData.SuccessStatus){
this.RunTimeData.SuccessStatus=this.GetSuccessStatus();
this.RunTimeData.SuccessStatusChangedDuringRuntime=true;
}
if(this.RunTimeData.Exit==SCORM_EXIT_TIME_OUT){
this.WriteDetailedLog("`1471`");
this.RunTimeData.NavRequest=SCORM_RUNTIME_NAV_REQUEST_EXITALL;
}else{
if(this.RunTimeData.Exit==SCORM_EXIT_LOGOUT){
if(Control.Package.Properties.LogoutCausesPlayerExit===true){
this.WriteDetailedLog("`1333`");
this.RunTimeData.NavRequest=SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL;
}else{
this.WriteDetailedLog("`341`");
this.Activity.SetSuspended(true);
}
}else{
if(this.RunTimeData.Exit==SCORM_EXIT_SUSPEND){
this.WriteDetailedLog("`1609`");
this.Activity.SetSuspended(true);
}
}
}
this.CloseOutSessionCalled=true;
return true;
}
function RunTimeApi_LookAheadSessionClose(){
if(this.RunTimeData!=null){
this.RunTimeData.LookAheadCompletionStatus=this.GetCompletionStatus();
this.RunTimeData.LookAheadSuccessStatus=this.GetSuccessStatus();
}
}
function RunTimeApi_RetrieveGetValueData(_37,_38,_39,_3a){
this.WriteDetailedLog("`1565`"+_37+", "+_38+", "+_39+", "+_3a+") ");
var _3b;
var _3c="";
var _3d;
if(_37.indexOf("adl.nav.request_valid.choice")===0){
this.WriteDetailedLog("`1278`");
_3b=((_37.indexOf("{")>=0)?_37.substring(_37.indexOf("{")):"");
if(!Control.IsTargetValid(_3b)){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The target of the choice request ("+_3b+") is invalid.");
return SCORM_FALSE;
}
_3c=Control.IsChoiceRequestValid(_3b);
if(_3c==false){
var _3e=Control.ParseTargetStringIntoActivity(_3b);
var _3f=Control.FindPossibleChoiceRequestForActivity(_3e);
this.WriteDetailedLog(_3f.GetExceptionReason());
}
_3c=this.TranslateBooleanIntoCMI(_3c);
return _3c;
}
switch(_38){
case "cmi._version":
this.WriteDetailedLog("`1500`");
_3c=SCORM2004_VERSION;
break;
case "cmi.comments_from_learner._children":
this.WriteDetailedLog("`1155`");
_3c=SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN;
break;
case "cmi.comments_from_learner._count":
this.WriteDetailedLog("`1226`");
_3c=this.RunTimeData.Comments.length;
break;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1206`");
_3c=this.RunTimeData.Comments[_39].GetCommentValue();
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1180`");
_3c=this.RunTimeData.Comments[_39].Location;
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1157`");
_3c=this.RunTimeData.Comments[_39].Timestamp;
break;
case "cmi.comments_from_lms._children":
this.WriteDetailedLog("`1241`");
_3c=SCORM2004_COMMENTS_FROM_LMS_CHILDREN;
break;
case "cmi.comments_from_lms._count":
this.WriteDetailedLog("`1292`");
_3c=this.RunTimeData.CommentsFromLMS.length;
break;
case "cmi.comments_from_lms.n.comment":
this.WriteDetailedLog("`1282`");
_3c=this.RunTimeData.CommentsFromLMS[_39].GetCommentValue();
break;
case "cmi.comments_from_lms.n.location":
this.WriteDetailedLog("`1261`");
_3c=this.RunTimeData.CommentsFromLMS[_39].Location;
break;
case "cmi.comments_from_lms.n.timestamp":
this.WriteDetailedLog("`1243`");
_3c=this.RunTimeData.CommentsFromLMS[_39].Timestamp;
break;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
_3c=this.GetCompletionStatus();
break;
case "cmi.completion_threshold":
this.WriteDetailedLog("`1361`");
_3c=this.LearningObject.CompletionThreshold;
break;
case "cmi.credit":
this.WriteDetailedLog("`1636`");
_3c=this.RunTimeData.Credit;
break;
case "cmi.entry":
this.WriteDetailedLog("`1658`");
_3c=this.RunTimeData.Entry;
break;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
Debug.AssertError("Exit element is write only");
_3c="";
break;
case "cmi.interactions._children":
this.WriteDetailedLog("`1324`");
_3c=SCORM2004_INTERACTIONS_CHILDREN;
break;
case "cmi.interactions._count":
this.WriteDetailedLog("`1380`");
_3c=this.RunTimeData.Interactions.length;
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1464`");
_3c=this.RunTimeData.Interactions[_39].Id;
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1420`");
_3c=this.RunTimeData.Interactions[_39].Type;
break;
case "cmi.interactions.n.objectives._count":
this.WriteDetailedLog("`1183`");
_3c=this.RunTimeData.Interactions[_39].Objectives.length;
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1263`");
_3c=this.RunTimeData.Interactions[_39].Objectives[_3a];
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1326`");
_3c=this.RunTimeData.Interactions[_39].Timestamp;
break;
case "cmi.interactions.n.correct_responses._count":
this.WriteDetailedLog("`1053`");
_3c=this.RunTimeData.Interactions[_39].CorrectResponses.length;
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`1018`");
_3c=this.RunTimeData.Interactions[_39].CorrectResponses[_3a];
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1327`");
_3c=this.RunTimeData.Interactions[_39].Weighting;
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1208`");
_3c=this.RunTimeData.Interactions[_39].LearnerResponse;
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1382`");
_3c=this.RunTimeData.Interactions[_39].Result;
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1363`");
_3c=this.RunTimeData.Interactions[_39].Latency;
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1293`");
_3c=this.RunTimeData.Interactions[_39].Description;
break;
case "cmi.launch_data":
this.WriteDetailedLog("`1544`");
_3c=this.LearningObject.DataFromLms;
break;
case "cmi.learner_id":
this.WriteDetailedLog("`1558`");
_3c=LearnerId;
break;
case "cmi.learner_name":
this.WriteDetailedLog("`1517`");
_3c=LearnerName;
break;
case "cmi.learner_preference._children":
this.WriteDetailedLog("`1228`");
_3c=SCORM2004_LEARNER_PREFERENCE_CHILDREN;
break;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1542`");
_3c=this.RunTimeData.AudioLevel;
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1589`");
_3c=this.RunTimeData.LanguagePreference;
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1482`");
_3c=this.RunTimeData.DeliverySpeed;
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1435`");
_3c=this.RunTimeData.AudioCaptioning;
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
_3c=this.RunTimeData.Location;
var _40={ev:"Get",k:"location",v:(_3c==null?"<null>":_3c)};
if(this.Activity){
_40.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_40);
break;
case "cmi.max_time_allowed":
this.WriteDetailedLog("`1436`");
_3c="";
if(this.LearningObject.SequencingData!==null&&this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl===true){
_3c=this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationLimit;
}
break;
case "cmi.mode":
this.WriteDetailedLog("`1684`");
_3c=this.RunTimeData.Mode;
break;
case "cmi.objectives._children":
this.WriteDetailedLog("`1364`");
_3c=SCORM2004_OBJECTIVES_CHILDREN;
break;
case "cmi.objectives._count":
this.WriteDetailedLog("`1421`");
_3c=this.RunTimeData.Objectives.length;
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1505`");
_3c=this.RunTimeData.Objectives[_39].Identifier;
break;
case "cmi.objectives.n.score._children":
this.WriteDetailedLog("`1264`");
_3c=SCORM2004_OBJECTIVES_SCORE_CHILDREN;
break;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1309`");
_3c=this.RunTimeData.Objectives[_39].ScoreScaled;
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1367`");
_3c=this.RunTimeData.Objectives[_39].ScoreRaw;
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1366`");
_3c=this.RunTimeData.Objectives[_39].ScoreMin;
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1365`");
_3c=this.RunTimeData.Objectives[_39].ScoreMax;
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1284`");
_3c=this.RunTimeData.Objectives[_39].SuccessStatus;
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1229`");
_3c=this.RunTimeData.Objectives[_39].CompletionStatus;
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1246`");
_3c=this.RunTimeData.Objectives[_39].ProgressMeasure;
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1328`");
_3c=this.RunTimeData.Objectives[_39].Description;
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1438`");
_3c=this.RunTimeData.ProgressMeasure;
break;
case "cmi.scaled_passing_score":
this.WriteDetailedLog("`1368`");
_3c=this.LearningObject.GetScaledPassingScore();
if(_3c===null){
_3c="";
}
break;
case "cmi.score._children":
this.WriteDetailedLog("`1468`");
_3c=SCORM2004_SCORE_CHILDREN;
break;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
_3c=this.RunTimeData.ScoreScaled;
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
_3c=this.RunTimeData.ScoreRaw;
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
_3c=this.RunTimeData.ScoreMax;
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
_3c=this.RunTimeData.ScoreMin;
break;
case "cmi.session_time":
this.WriteDetailedLog("`1520`");
_3c="";
break;
case "cmi.success_status":
this.WriteDetailedLog("`1484`");
_3c=this.GetSuccessStatus();
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1524`");
_3c=this.RunTimeData.SuspendData;
break;
case "cmi.time_limit_action":
this.WriteDetailedLog("`1423`");
_3c=this.LearningObject.TimeLimitAction;
break;
case "cmi.total_time":
this.WriteDetailedLog("`1563`");
_3c=this.RunTimeData.TotalTime;
break;
case "adl.nav.request":
this.WriteDetailedLog("`1461`");
_3c=this.RunTimeData.NavRequest;
break;
case "adl.nav.request_valid.continue":
this.WriteDetailedLog("`1174`");
_3c=Control.IsContinueRequestValid();
if(_3c==false){
_3d=Control.GetPossibleContinueRequest();
this.WriteDetailedLog(_3d.GetExceptionReason());
}
_3c=this.TranslateBooleanIntoCMI(_3c);
break;
case "adl.nav.request_valid.previous":
this.WriteDetailedLog("`1175`");
_3c=Control.IsPreviousRequestValid();
if(_3c==false){
_3d=Control.GetPossiblePreviousRequest();
this.WriteDetailedLog(_3d.GetExceptionReason());
}
_3c=this.TranslateBooleanIntoCMI(_3c);
break;
case "adl.nav.request_valid.choice":
this.WriteDetailedLog("`1323`");
Debug.AssertError("Entered invalid case in RunTimeApi_RetrieveGetValueData");
break;
default:
if(_38.indexOf("ssp")===0&&SSP_ENABLED){
_3c=this.SSPApi.RetrieveGetValueData(_37,_38,_39,_3a);
}else{
Debug.AssertError("Entered default case in RunTimeApi_RetrieveGetValueData");
_3c="";
}
break;
}
return _3c;
}
function RunTimeApi_StoreValue(_41,_42,_43,_44,_45){
this.WriteDetailedLog("`1724`"+_41+", "+_42+", "+_43+", "+_44+", "+_45+") ");
var _46=true;
var _47;
switch(_43){
case "cmi._version":
this.WriteDetailedLog("`1587`");
break;
case "cmi.comments_from_learner._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._children");
_46=false;
break;
case "cmi.comments_from_learner._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._count");
_46=false;
break;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1225`");
this.CheckCommentsCollectionLength(_44);
this.RunTimeData.Comments[_44].SetCommentValue(_42);
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1178`");
this.CheckCommentsCollectionLength(_44);
this.RunTimeData.Comments[_44].Location=_42;
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1154`");
this.CheckCommentsCollectionLength(_44);
this.RunTimeData.Comments[_44].Timestamp=_42;
break;
case "cmi.comments_from_lms._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._children");
_46=false;
break;
case "cmi.comments_from_lms._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._count");
_46=false;
break;
case "cmi.comments_from_lms.n.comment":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.comment");
_46=false;
break;
case "cmi.comments_from_lms.n.location":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.location");
_46=false;
break;
case "cmi.comments_from_lms.n.timestamp":
Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.timestamp");
_46=false;
break;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
_47={ev:"Set",k:"completion",v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.CompletionStatus,_42);
this.RunTimeData.CompletionStatus=_42;
this.RunTimeData.CompletionStatusChangedDuringRuntime=true;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.completion_threshold":
Debug.AssertError("ERROR - Element is Read Only, cmi.completion_threshold");
_46=false;
break;
case "cmi.credit":
Debug.AssertError("ERROR - Element is Read Only, cmi.credit");
_46=false;
break;
case "cmi.entry":
Debug.AssertError("ERROR - Element is Read Only, cmi.entry");
_46=false;
break;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
_47={ev:"Set",k:"cmi.exit",v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.RunTimeData.Exit=_42;
break;
case "cmi.interactions._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._children");
_46=false;
break;
case "cmi.interactions._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._count");
_46=false;
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1464`");
_47={ev:"Set",k:"interactions id",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].Id=_42;
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1420`");
_47={ev:"Set",k:"interactions type",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_44].Id){
_47.intid=this.RunTimeData.Interactions[_44].Id;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].Type=_42;
break;
case "cmi.interactions.n.objectives._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.objectives._count");
_46=false;
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1263`");
_47={ev:"Set",k:"interactions objectives id",i:_44,si:_45,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionObjectivesCollectionLength(_44,_45);
this.RunTimeData.Interactions[_44].Objectives[_45]=_42;
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1326`");
_47={ev:"Set",k:"interactions timestamp",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_44].Id){
_47.intid=this.RunTimeData.Interactions[_44].Id;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].Timestamp=_42;
break;
case "cmi.interactions.n.correct_responses._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.correct_responses._count");
_46=false;
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`1018`");
_47={ev:"Set",k:"interactions correct_responses pattern",i:_44,si:_45,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCorrectResponsesCollectionLength(_44,_45);
this.RunTimeData.Interactions[_44].CorrectResponses[_45]=_42;
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1327`");
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].Weighting=_42;
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1208`");
_47={ev:"Set",k:"interactions learner_response",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_44].Id){
_47.intid=this.RunTimeData.Interactions[_44].Id;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].LearnerResponse=_42;
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1382`");
_47={ev:"Set",k:"interactions result",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_44].Id){
_47.intid=this.RunTimeData.Interactions[_44].Id;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].Result=_42;
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1363`");
_47={ev:"Set",k:"interactions latency",i:_44,vh:ConvertIso8601TimeSpanToHundredths(_42)};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_44].Id){
_47.intid=this.RunTimeData.Interactions[_44].Id;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].Latency=_42;
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1293`");
_47={ev:"Set",k:"interactions description",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Interactions[_44].Id){
_47.intid=this.RunTimeData.Interactions[_44].Id;
}
this.WriteHistoryLog("",_47);
this.CheckInteractionsCollectionLength(_44);
this.RunTimeData.Interactions[_44].Description=_42;
break;
case "cmi.launch_data":
Debug.AssertError("ERROR - Element is Read Only, cmi.launch_data");
_46=false;
break;
case "cmi.learner_id":
Debug.AssertError("ERROR - Element is Read Only, cmi.learner_id");
_46=false;
break;
case "cmi.learner_name":
Debug.AssertError("ERROR - Element is Read Only, cmi.learner_name");
_46=false;
break;
case "cmi.learner_preference._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.learner_preference._children");
_46=false;
break;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1516`");
this.RunTimeData.AudioLevel=_42;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.AudioLevel=_42;
}
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1589`");
this.RunTimeData.LanguagePreference=_42;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.LanguagePreference=_42;
}
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1501`");
this.RunTimeData.DeliverySpeed=_42;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.DeliverySpeed=_42;
}
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1435`");
this.RunTimeData.AudioCaptioning=_42;
if(Control.Package.Properties.MakeStudentPrefsGlobalToCourse===true){
this.LearnerPrefsArray.AudioCaptioning=_42;
}
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
this.RunTimeData.Location=_42;
break;
case "cmi.max_time_allowed":
Debug.AssertError("ERROR - Element is Read Only, cmi.max_time_allowed");
_46=false;
break;
case "cmi.mode":
Debug.AssertError("ERROR - Element is Read Only, cmi.mode");
_46=false;
break;
case "cmi.objectives._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._children");
_46=false;
break;
case "cmi.objectives._count":
Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._count");
_46=false;
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1505`");
_47={ev:"Set",k:"objectives id",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.CheckObjectivesCollectionLength(_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].Identifier,_42);
this.RunTimeData.Objectives[_44].Identifier=_42;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.score._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.objectives.n.score._children");
_46=false;
break;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1310`");
this.CheckObjectivesCollectionLength(_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreScaled,_42);
this.RunTimeData.Objectives[_44].ScoreScaled=_42;
this.RunTimeData.Objectives[_44].MeasureChangedDuringRuntime=true;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1367`");
this.CheckObjectivesCollectionLength(_44);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreRaw,_42);
}
this.RunTimeData.Objectives[_44].ScoreRaw=_42;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1366`");
this.CheckObjectivesCollectionLength(_44);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreMin,_42);
}
this.RunTimeData.Objectives[_44].ScoreMin=_42;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1365`");
this.CheckObjectivesCollectionLength(_44);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreMax,_42);
}
this.RunTimeData.Objectives[_44].ScoreMax=_42;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1284`");
_47={ev:"Set",k:"objectives success",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Objectives[_44].Identifier){
_47.intid=this.RunTimeData.Objectives[_44].Identifier;
}
this.WriteHistoryLog("",_47);
this.CheckObjectivesCollectionLength(_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].SuccessStatus,_42);
this.RunTimeData.Objectives[_44].SuccessStatus=_42;
this.RunTimeData.Objectives[_44].SuccessStatusChangedDuringRuntime=true;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1229`");
_47={ev:"Set",k:"objectives completion",i:_44,v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
if(this.RunTimeData.Objectives[_44].Identifier){
_47.intid=this.RunTimeData.Objectives[_44].Identifier;
}
this.WriteHistoryLog("",_47);
this.CheckObjectivesCollectionLength(_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].CompletionStatus,_42);
this.RunTimeData.Objectives[_44].CompletionStatus=_42;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1246`");
this.CheckObjectivesCollectionLength(_44);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ProgressMeasure,_42);
this.RunTimeData.Objectives[_44].ProgressMeasure=_42;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1328`");
this.CheckObjectivesCollectionLength(_44);
this.RunTimeData.Objectives[_44].Description=_42;
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1439`");
this.RunTimeData.ProgressMeasure=_42;
break;
case "cmi.scaled_passing_score":
Debug.AssertError("ERROR - Element is Read Only, cmi.scaled_passing_score");
_46=false;
break;
case "cmi.score._children":
Debug.AssertError("ERROR - Element is Read Only, cmi.score._children");
_46=false;
break;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
_47={ev:"Set",k:"score.scaled",v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreScaled,_42);
this.RunTimeData.ScoreScaled=_42;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
_47={ev:"Set",k:"score.raw",v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreRaw,_42);
}
this.RunTimeData.ScoreRaw=_42;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
_47={ev:"Set",k:"score.max",v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMax,_42);
}
this.RunTimeData.ScoreMax=_42;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
_47={ev:"Set",k:"score.min",v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
if(Control.Package.Properties.ScaleRawScore){
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMin,_42);
}
this.RunTimeData.ScoreMin=_42;
if(Control.Package.Properties.ScaleRawScore){
this.RunLookAheadSequencerIfNeeded();
}
break;
case "cmi.session_time":
this.WriteDetailedLog("`1521`");
_47={ev:"Set",k:"session time",vh:ConvertIso8601TimeSpanToHundredths(_42)};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.RunTimeData.SessionTime=_42;
break;
case "cmi.success_status":
this.WriteDetailedLog("`1485`");
_47={ev:"Set",k:"success",v:_42};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
this.WriteHistoryLog("",_47);
this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.SuccessStatus,_42);
this.RunTimeData.SuccessStatus=_42;
this.RunLookAheadSequencerIfNeeded();
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1525`");
this.RunTimeData.SuspendData=_42;
break;
case "cmi.time_limit_action":
Debug.AssertError("ERROR - Element is Read Only, cmi.time_limit_action");
_46=false;
break;
case "cmi.total_time":
Debug.AssertError("ERROR - Element is Read Only, cmi.total_time");
_46=false;
break;
case "adl.nav.request":
this.WriteDetailedLog("`1463`");
_47={ev:"Set",k:"nav.request"};
if(this.Activity){
_47.ai=this.Activity.ItemIdentifier;
}
var _48=_42.match(/target\s*=\s*(\S+)\s*}\s*choice/);
if(_48){
_47.tai=_48[1];
_47.tat=Control.Activities.GetActivityFromIdentifier(_48[1]).LearningObject.Title;
_47.v="choice";
}else{
_47.v=_42;
}
this.WriteHistoryLog("",_47);
this.RunTimeData.NavRequest=_42;
break;
case "adl.nav.request_valid.continue":
Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.continue");
break;
case "adl.nav.request_valid.previous":
Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.previous");
break;
case "adl.nav.request_valid.choice":
Debug.AssertError("ERROR - Should never get here...handled above - Element is Read Only, adl.nav.request_valid.choice");
break;
default:
if(_43.indexOf("ssp")===0){
if(SSP_ENABLED){
return this.SSPApi.StoreValue(_41,_42,_43,_44,_45);
}
}
Debug.AssertError("ERROR reached default case in RunTimeApi_StoreValue");
returnData="";
break;
}
return _46;
}
function RunTimeApi_CheckCommentsCollectionLength(_49){
if(this.RunTimeData.Comments.length<=_49){
this.WriteDetailedLog("`1124`"+_49);
this.RunTimeData.Comments[_49]=new ActivityRunTimeComment(null,null,null,null,null);
}
}
function RunTimeApi_CheckInteractionsCollectionLength(_4a){
if(this.RunTimeData.Interactions.length<=_4a){
this.WriteDetailedLog("`1305`"+_4a);
this.RunTimeData.Interactions[_4a]=new ActivityRunTimeInteraction(null,null,null,null,null,null,null,null,null,new Array(),new Array());
}
}
function RunTimeApi_CheckInteractionObjectivesCollectionLength(_4b,_4c){
if(this.RunTimeData.Interactions[_4b].Objectives.length<=_4c){
this.WriteDetailedLog("`1107`"+_4c);
this.RunTimeData.Interactions[_4b].Objectives[_4c]=null;
}
}
function RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength(_4d,_4e){
if(this.RunTimeData.Interactions[_4d].CorrectResponses.length<=_4e){
this.WriteDetailedLog("`984`"+_4e);
this.RunTimeData.Interactions[_4d].CorrectResponses[_4e]=null;
}
}
function RunTimeApi_CheckObjectivesCollectionLength(_4f){
if(this.RunTimeData.Objectives.length<=_4f){
this.WriteDetailedLog("`1346`"+_4f);
this.RunTimeData.Objectives[_4f]=new ActivityRunTimeObjective(null,"unknown","unknown",null,null,null,null,null,null);
}
}
function RunTimeApi_SetErrorState(_50,_51){
if(_50!=SCORM2004_NO_ERROR){
this.WriteDetailedLog("`1285`"+_50+" - "+_51);
}
this.ErrorNumber=_50;
this.ErrorString=SCORM2004_ErrorStrings[_50];
this.ErrorDiagnostic=_51;
}
function RunTimeApi_ClearErrorState(){
this.SetErrorState(SCORM2004_NO_ERROR,"");
}
function RunTimeApi_CheckForInitializeError(arg){
this.WriteDetailedLog("`1412`");
if(this.Initialized){
this.SetErrorState(SCORM2004_ALREADY_INTIAILIZED_ERROR,"Initialize has already been called and may only be called once per session.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR,"Initialize cannot be called after Terminate has already beeen called.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR,"The argument to Initialize must be an empty string (\"\"). The argument '"+arg+"' is invalid.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckForTerminateError(arg){
this.WriteDetailedLog("`1432`");
if(!this.Initialized){
this.SetErrorState(SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR,"Terminate cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR,"Terminate cannot be called after Terminate has already beeen called.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR,"The argument to Terminate must be an empty string (\"\"). The argument '"+arg+"' is invalid.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckForCommitError(arg){
this.WriteDetailedLog("`1496`");
if(!this.Initialized){
this.SetErrorState(SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR,"Commit cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_COMMIT_AFTER_TERMINATION_ERROR,"Commit cannot be called after Terminate has already beeen called.");
return false;
}
if(arg!==""){
this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR,"The argument to Commit must be an empty string (\"\"). The argument '"+arg+"' is invalid.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckMaxLength(_55,_56){
switch(_55){
case "cmi.comments_from_learner.n.comment":
this.CheckLengthAndWarn(_56,4250);
break;
case "cmi.comments_from_learner.n.location":
this.CheckLengthAndWarn(_56,250);
break;
case "cmi.interactions.n.id":
this.CheckLengthAndWarn(_56,4000);
break;
case "cmi.interactions.n.objectives.n.id":
this.CheckLengthAndWarn(_56,4000);
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.CheckLengthAndWarn(_56,7800);
break;
case "cmi.interactions.n.learner_response":
this.CheckLengthAndWarn(_56,7800);
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.CheckLengthAndWarn(_56,500);
break;
case "cmi.learner_preference.language":
this.CheckLengthAndWarn(_56,250);
break;
case "cmi.location":
this.CheckLengthAndWarn(_56,1000);
break;
case "cmi.objectives.n.id":
this.CheckLengthAndWarn(_56,4000);
break;
case "cmi.objectives.n.description":
this.CheckLengthAndWarn(_56,500);
break;
case "cmi.suspend_data":
this.CheckLengthAndWarn(_56,Control.Package.Properties.SuspendDataMaxLength);
break;
default:
break;
}
return;
}
function RunTimeApi_CheckLengthAndWarn(str,len){
if(str.length>len){
this.SetErrorState(SCORM2004_NO_ERROR,"The string was trimmed to fit withing the SPM of "+len+" characters.");
}
return;
}
function RunTimeApi_CheckForGetValueError(_59,_5a,_5b,_5c){
this.WriteDetailedLog("`1453`");
if(!this.Initialized){
this.SetErrorState(SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR,"GetValue cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR,"GetValue cannot be called after Terminate has already beeen called.");
return false;
}
if(_59.length===0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The data model element for GetValue was not specified.");
return false;
}
if(_5b!==""){
if(_5a.indexOf("cmi.comments_from_learner")>=0){
if(_5b>=this.RunTimeData.Comments.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Comments From Learner collection does not have an element at index "+_5b+", the current element count is "+this.RunTimeData.Comments.length+".");
return false;
}
}else{
if(_5a.indexOf("cmi.comments_from_lms")>=0){
if(_5b>=this.RunTimeData.CommentsFromLMS.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Comments From LMS collection does not have an element at index "+_5b+", the current element count is "+this.RunTimeData.CommentsFromLMS.length+".");
return false;
}
}else{
if(_5a.indexOf("cmi.objectives")>=0){
if(_5b>=this.RunTimeData.Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Objectives collection does not have an element at index "+_5b+", the current element count is "+this.RunTimeData.Objectives.length+".");
return false;
}
}else{
if(_5a.indexOf("cmi.interactions")>=0){
if(_5b>=this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Interactions collection does not have an element at index "+_5b+", the current element count is "+this.RunTimeData.Interactions.length+".");
return false;
}
if(_5a.indexOf("cmi.interactions.n.correct_responses")>=0){
if(_5c!==""){
if(_5c>=this.RunTimeData.Interactions[_5b].CorrectResponses.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Correct Responses collection for Interaction #"+_5b+" does not have an element at index "+_5c+", the current element count is "+this.RunTimeData.Interactions[_5b].CorrectResponses.length+".");
return false;
}
}
}else{
if(_5a.indexOf("cmi.interactions.n.objectives")>=0){
if(_5c!==""){
if(_5c>=this.RunTimeData.Interactions[_5b].Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The Objectives collection for Interaction #"+_5b+" does not have an element at index "+_5c+", the current element count is "+this.RunTimeData.Interactions[_5b].Objectives.length+".");
return false;
}
}
}
}
}
}
}
}
}
switch(_5a){
case "cmi._version":
this.WriteDetailedLog("`1606`");
break;
case "cmi.comments_from_learner._children":
this.WriteDetailedLog("`1181`");
break;
case "cmi.comments_from_learner._count":
this.WriteDetailedLog("`1226`");
break;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1156`");
if(this.RunTimeData.Comments[_5b].Comment===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Comment field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1128`");
if(this.RunTimeData.Comments[_5b].Location===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Location field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1113`");
if(this.RunTimeData.Comments[_5b].Timestamp===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The TimeStamp field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.comments_from_lms._children":
this.WriteDetailedLog("`1241`");
break;
case "cmi.comments_from_lms._count":
this.WriteDetailedLog("`1292`");
break;
case "cmi.comments_from_lms.n.comment":
this.WriteDetailedLog("`1242`");
if(this.RunTimeData.CommentsFromLMS[_5b].Comment===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Comment field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.comments_from_lms.n.location":
this.WriteDetailedLog("`1227`");
if(this.RunTimeData.CommentsFromLMS[_5b].Location===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Location field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.comments_from_lms.n.timestamp":
this.WriteDetailedLog("`1207`");
if(this.RunTimeData.CommentsFromLMS[_5b].Timestamp===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Timestamp field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
break;
case "cmi.completion_threshold":
this.WriteDetailedLog("`1362`");
if(this.LearningObject.CompletionThreshold===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The completion threshold for this SCO was not specificed.");
return false;
}
break;
case "cmi.credit":
this.WriteDetailedLog("`1636`");
break;
case "cmi.entry":
this.WriteDetailedLog("`1658`");
break;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The Exit data model element is write-only.");
return false;
case "cmi.interactions._children":
this.WriteDetailedLog("`1324`");
break;
case "cmi.interactions._count":
this.WriteDetailedLog("`1380`");
break;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1417`");
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1381`");
if(this.RunTimeData.Interactions[_5b].Type===null||this.RunTimeData.Interactions[_5b].Type===""){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Type field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.interactions.n.objectives._count":
this.WriteDetailedLog("`1129`");
break;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1182`");
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1294`");
if(this.RunTimeData.Interactions[_5b].Timestamp===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Time Stamp field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.interactions.n.correct_responses._count":
this.WriteDetailedLog("`993`");
break;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`967`");
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1295`");
if(this.RunTimeData.Interactions[_5b].Weighting===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Weighting field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1185`");
if(this.RunTimeData.Interactions[_5b].LearnerResponse===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Learner Response field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1347`");
if(this.RunTimeData.Interactions[_5b].Result===null||this.RunTimeData.Interactions[_5b].Result===""){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Result field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1325`");
if(this.RunTimeData.Interactions[_5b].Latency===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Latency field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1262`");
if(this.RunTimeData.Interactions[_5b].Description===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Description field has not been initialized for the element at index "+_5b);
return false;
}
break;
case "cmi.launch_data":
this.WriteDetailedLog("`1544`");
if(this.LearningObject.DataFromLms===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Launch Data field was not specified for this SCO.");
return false;
}
break;
case "cmi.learner_id":
this.WriteDetailedLog("`1559`");
break;
case "cmi.learner_name":
this.WriteDetailedLog("`1518`");
break;
case "cmi.learner_preference._children":
this.WriteDetailedLog("`1228`");
break;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1184`");
if(this.RunTimeData.AudioLevel===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Audio Level field has not been set for this SCO.");
return false;
}
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1244`");
if(this.RunTimeData.LanguagePreference===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Language Preference field has not been set for this SCO.");
return false;
}
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1114`");
if(this.RunTimeData.DeliverySpeed===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Delivery Speed field has not been set for this SCO.");
return false;
}
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1073`");
if(this.RunTimeData.AudioCaptioning===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Audio Captioning field has not been set for this SCO.");
return false;
}
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
if(this.RunTimeData.Location===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Location field has not been set for this SCO.");
return false;
}
break;
case "cmi.max_time_allowed":
this.WriteDetailedLog("`1437`");
if(this.LearningObject.SequencingData===null||this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl===false){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Max Time Allowed field was not specified in the manifest for this SCO.");
return false;
}
break;
case "cmi.mode":
this.WriteDetailedLog("`1684`");
break;
case "cmi.objectives._children":
this.WriteDetailedLog("`1364`");
break;
case "cmi.objectives._count":
this.WriteDetailedLog("`1421`");
break;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1467`");
break;
case "cmi.objectives.n.score._children":
this.WriteDetailedLog("`1230`");
break;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1283`");
if(this.RunTimeData.Objectives[_5b].ScoreScaled===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Scaled Score field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1331`");
if(this.RunTimeData.Objectives[_5b].ScoreRaw===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Raw Score field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1330`");
if(this.RunTimeData.Objectives[_5b].ScoreMin===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Min Score field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1329`");
if(this.RunTimeData.Objectives[_5b].ScoreMax===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Max Score field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1245`");
if(this.RunTimeData.Objectives[_5b].SuccessStatus===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The SuccessStatus field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1186`");
if(this.RunTimeData.Objectives[_5b].CompletionStatus===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The CompletionStatus field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1210`");
if(this.RunTimeData.Objectives[_5b].ProgressMeasure===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The ProgressMeasure field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1296`");
if(this.RunTimeData.Objectives[_5b].Description===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Description field has not been initialized for the objective at index "+_5b);
return false;
}
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1439`");
if(this.RunTimeData.ProgressMeasure===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Progress Measure field has not been set for this SCO.");
return false;
}
break;
case "cmi.scaled_passing_score":
this.WriteDetailedLog("`1369`");
if(this.LearningObject.GetScaledPassingScore()===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Scaled Passing Score field was not specificed for this SCO.");
return false;
}
break;
case "cmi.score._children":
this.WriteDetailedLog("`1468`");
break;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
if(this.RunTimeData.ScoreScaled===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Scaled Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
if(this.RunTimeData.ScoreRaw===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Raw Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
if(this.RunTimeData.ScoreMax===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Max Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
if(this.RunTimeData.ScoreMin===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Min Score field has not been set for this SCO.");
return false;
}
break;
case "cmi.session_time":
this.WriteDetailedLog("`1521`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The Exit data model element is write-only.");
return false;
break;
case "cmi.success_status":
this.WriteDetailedLog("`1485`");
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1525`");
if(this.RunTimeData.SuspendData===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Suspend Data field has not been set for this SCO.");
return false;
}
break;
case "cmi.time_limit_action":
this.WriteDetailedLog("`1424`");
if(this.LearningObject.TimeLimitAction===null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR,"The Time Limit Action field has not been set for this SCO.");
return false;
}
break;
case "cmi.total_time":
this.WriteDetailedLog("`1564`");
break;
case "adl.nav.request":
this.WriteDetailedLog("`1463`");
break;
case "adl.nav.request_valid.continue":
this.WriteDetailedLog("`1176`");
break;
case "adl.nav.request_valid.previous":
this.WriteDetailedLog("`1177`");
break;
default:
if(_5a.indexOf("adl.nav.request_valid.choice")===0){
this.WriteDetailedLog("`1224`");
return true;
}
if(_5a.indexOf("ssp")===0){
if(SSP_ENABLED){
return this.SSPApi.CheckForGetValueError(_59,_5a,_5b,_5c);
}
}
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_59+"' does not exist.");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_CheckForSetValueError(_5d,_5e,_5f,_60,_61){
this.WriteDetailedLog("`1537`"+_5d+", "+_5e+", "+_5f+", "+_60+", "+_61+") ");
if(!this.Initialized){
this.SetErrorState(SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR,"SetValue cannot be called before Initialize has been called.");
return false;
}
if(this.Terminated){
this.SetErrorState(SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR,"SetValue cannot be called after Terminate has already beeen called.");
return false;
}
if(_5d.length===0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The data model element for SetValue was not specified.");
return false;
}
if(_5d.indexOf("adl.nav.request_valid.choice.{")===0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The adl.nav.request_valid.choice element is read only");
return false;
}
if(_60!==""){
if(_5f.indexOf("cmi.comments_from_learner")>=0){
if(_60>this.RunTimeData.Comments.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Comments From Learner collection elements must be set sequentially, the index "+_60+", is greater than the next available index of "+this.RunTimeData.Comments.length+".");
return false;
}
}else{
if(_5f.indexOf("cmi.comments_from_lms")>=0){
if(_60>this.RunTimeData.CommentsFromLMS.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Comments From LMS collection elements must be set sequentially, the index "+_60+", is greater than the next available index of "+this.RunTimeData.CommentsFromLMS.length+".");
return false;
}
}else{
if(_5f.indexOf("cmi.objectives")>=0){
if(_60>this.RunTimeData.Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Objectives collection elements must be set sequentially, the index "+_60+", is greater than the next available index of "+this.RunTimeData.Objectives.length+".");
return false;
}
}else{
if(_5f.indexOf("cmi.interactions")>=0){
if(_60>this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Interactions collection elements must be set sequentially, the index "+_60+", is greater than the next available index of "+this.RunTimeData.Interactions.length+".");
return false;
}else{
if(_5f.indexOf("cmi.interactions.n.correct_responses")>=0){
if(_60>=this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The Interactions collection elements must be set sequentially, the index "+_60+", is greater than the next available index of "+this.RunTimeData.Interactions.length+".");
return false;
}
if(_61!==""){
if(_61>this.RunTimeData.Interactions[_60].CorrectResponses.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Correct Responses collection elements for Interaction #"+_60+" must be set sequentially the index "+_61+" is greater than the next available index of "+this.RunTimeData.Interactions[_60].CorrectResponses.length+".");
return false;
}
}
}else{
if(_5f.indexOf("cmi.interactions.n.objectives")>=0){
if(_60>=this.RunTimeData.Interactions.length){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The Interactions collection elements must be set sequentially, the index "+_60+", is greater than the next available index of "+this.RunTimeData.Interactions.length+".");
return false;
}
if(_61!==""){
if(_61>this.RunTimeData.Interactions[_60].Objectives.length){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The Objectives collection elements for Interaction #"+_60+" must be set sequentially the index "+_61+" is greater than the next available index of "+this.RunTimeData.Interactions[_60].Objectives.length+".");
return false;
}
}
}
}
}
}
}
}
}
}
var _62;
var i;
switch(_5f){
case "cmi._version":
this.WriteDetailedLog("`1587`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi._version data model element is read-only");
return false;
case "cmi.comments_from_learner._children":
this.WriteDetailedLog("`1155`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_learner._children data model element is read-only");
return false;
case "cmi.comments_from_learner._count":
this.WriteDetailedLog("`1226`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_learner._count data model element is read-only");
return false;
case "cmi.comments_from_learner.n.comment":
this.WriteDetailedLog("`1156`");
if(!this.ValidLocalizedString(_5e,4000)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.comments_from_learner.n.comment data model element is not a valid localized string type (SPM 4000)");
return false;
}
break;
case "cmi.comments_from_learner.n.location":
this.WriteDetailedLog("`1128`");
if(!this.ValidCharString(_5e,250)){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The cmi.comments_from_learner.n.comment data model element is not a valid char string type (SPM 250)");
return false;
}
break;
case "cmi.comments_from_learner.n.timestamp":
this.WriteDetailedLog("`1113`");
if(!this.ValidTime(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.comments_from_learner.n.timestamp data model element is not a valid time");
return false;
}
break;
case "cmi.comments_from_lms._children":
this.WriteDetailedLog("`1241`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms._children data model element is read-only");
return false;
case "cmi.comments_from_lms._count":
this.WriteDetailedLog("`1292`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms._count data model element is read-only");
return false;
case "cmi.comments_from_lms.n.comment":
this.WriteDetailedLog("`1242`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms.comment data model element is read-only");
return false;
case "cmi.comments_from_lms.n.location":
this.WriteDetailedLog("`1227`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms.location data model element is read-only");
return false;
case "cmi.comments_from_lms.n.timestamp":
this.WriteDetailedLog("`1207`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.comments_from_lms.timestamp data model element is read-only");
return false;
case "cmi.completion_status":
this.WriteDetailedLog("`1415`");
if(_5e!=SCORM_STATUS_COMPLETED&&_5e!=SCORM_STATUS_INCOMPLETE&&_5e!=SCORM_STATUS_NOT_ATTEMPTED&&_5e!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The completion_status data model element must be a proper vocabulary element.");
return false;
}
break;
case "cmi.completion_threshold":
this.WriteDetailedLog("`1362`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The completion_threshold data model element is read-only");
return false;
case "cmi.credit":
this.WriteDetailedLog("`1636`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The credit data model element is read-only");
return false;
case "cmi.entry":
this.WriteDetailedLog("`1658`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The entry data model element is read-only");
return false;
case "cmi.exit":
this.WriteDetailedLog("`1683`");
if(_5e!=SCORM_EXIT_TIME_OUT&&_5e!=SCORM_EXIT_SUSPEND&&_5e!=SCORM_EXIT_LOGOUT&&_5e!=SCORM_EXIT_NORMAL&&_5e!=SCORM_EXIT_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The exit data model element must be a proper vocabulary element.");
return false;
}
if(_5e==SCORM_EXIT_LOGOUT){
this.WriteDetailedLog("`349`");
}
break;
case "cmi.interactions._children":
this.WriteDetailedLog("`1324`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions._children element is read-only");
return false;
case "cmi.interactions._count":
this.WriteDetailedLog("`1380`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions._count element is read-only");
return false;
case "cmi.interactions.n.id":
this.WriteDetailedLog("`1417`");
if(!this.ValidLongIdentifier(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".id value of '"+_5e+"' is not a valid long identifier.");
return false;
}
break;
case "cmi.interactions.n.type":
this.WriteDetailedLog("`1381`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(_5e!=SCORM_TRUE_FALSE&&_5e!=SCORM_CHOICE&&_5e!=SCORM_FILL_IN&&_5e!=SCORM_LONG_FILL_IN&&_5e!=SCORM_LIKERT&&_5e!=SCORM_MATCHING&&_5e!=SCORM_PERFORMANCE&&_5e!=SCORM_SEQUENCING&&_5e!=SCORM_NUMERIC&&_5e!=SCORM_OTHER){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".type value of '"+_5e+"' is not a valid interaction type.");
return false;
}
break;
case "cmi.interactions.n.objectives._count":
this.WriteDetailedLog("`1129`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions.objectives._count element is read-only");
return false;
case "cmi.interactions.n.objectives.n.id":
this.WriteDetailedLog("`1182`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidLongIdentifier(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".objectives."+_61+".id value of '"+_5e+"' is not a valid long identifier type.");
return false;
}
for(i=0;i<this.RunTimeData.Interactions[_60].Objectives.length;i++){
if((this.RunTimeData.Interactions[_60].Objectives[i]==_5e)&&(i!=_61)){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Every interaction objective identifier must be unique. The value '"+_5e+"' has already been set in objective #"+i);
return false;
}
}
break;
case "cmi.interactions.n.timestamp":
this.WriteDetailedLog("`1294`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidTime(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".timestamp value of '"+_5e+"' is not a valid time type.");
return false;
}
break;
case "cmi.interactions.n.correct_responses._count":
this.WriteDetailedLog("`993`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The interactions.correct_responses._count element is read-only");
return false;
case "cmi.interactions.n.correct_responses.n.pattern":
this.WriteDetailedLog("`967`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Type===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.type element must be set before a correct response can be set.");
return false;
}
_62=true;
if(RegistrationToDeliver.Package.Properties.ValidateInteractionResponses){
switch(this.RunTimeData.Interactions[_60].Type){
case SCORM_TRUE_FALSE:
if(this.RunTimeData.Interactions[_60].CorrectResponses.length>0&&_61>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"A true-false interaction can only have one correct response.");
return false;
}
_62=this.ValidTrueFalseResponse(_5e);
break;
case SCORM_CHOICE:
_62=this.ValidMultipleChoiceResponse(_5e);
for(i=0;i<this.RunTimeData.Interactions[_60].CorrectResponses.length;i++){
if(this.RunTimeData.Interactions[_60].CorrectResponses[i]==_5e){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Every correct response to a choice interaction must be unique. The value '"+_5e+"' has already been set in correct response #"+i);
return false;
}
}
break;
case SCORM_FILL_IN:
_62=this.ValidFillInResponse(_5e,true);
break;
case SCORM_LONG_FILL_IN:
_62=this.ValidLongFillInResponse(_5e,true);
break;
case SCORM_LIKERT:
if(this.RunTimeData.Interactions[_60].CorrectResponses.length>0&&_61>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"A likert interaction can only have one correct response.");
return false;
}
_62=this.ValidLikeRTResponse(_5e);
break;
case SCORM_MATCHING:
_62=this.ValidMatchingResponse(_5e);
break;
case SCORM_PERFORMANCE:
_62=this.ValidPerformanceResponse(_5e,true);
break;
case SCORM_SEQUENCING:
_62=this.ValidSequencingResponse(_5e);
break;
case SCORM_NUMERIC:
if(this.RunTimeData.Interactions[_60].CorrectResponses.length>0&&_61>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"A numeric interaction can only have one correct response.");
return false;
}
_62=this.ValidNumericResponse(_5e,true);
break;
case SCORM_OTHER:
if(this.RunTimeData.Interactions[_60].CorrectResponses.length>0&&_61>0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"An 'other' interaction can only have one correct response.");
return false;
}
_62=this.ValidOtheresponse(_5e);
break;
}
}
if(!_62){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".correct_responses."+_61+".pattern value of '"+_5e+"' is not a valid correct response to an interaction of type "+this.RunTimeData.Interactions[_60].Type+".");
return false;
}
break;
case "cmi.interactions.n.weighting":
this.WriteDetailedLog("`1295`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".weighting value of '"+_5e+"' is not a valid real number.");
return false;
}
break;
case "cmi.interactions.n.learner_response":
this.WriteDetailedLog("`1158`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(this.RunTimeData.Interactions[_60].Type===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.type element must be set before a learner response can be set.");
return false;
}
_62=true;
if(RegistrationToDeliver.Package.Properties.ValidateInteractionResponses){
switch(this.RunTimeData.Interactions[_60].Type){
case "true-false":
_62=this.ValidTrueFalseResponse(_5e);
break;
case "choice":
_62=this.ValidMultipleChoiceResponse(_5e);
break;
case "fill-in":
_62=this.ValidFillInResponse(_5e,false);
break;
case "long-fill-in":
_62=this.ValidLongFillInResponse(_5e,false);
break;
case "likert":
_62=this.ValidLikeRTResponse(_5e);
break;
case "matching":
_62=this.ValidMatchingResponse(_5e);
break;
case "performance":
_62=this.ValidPerformanceResponse(_5e,false);
break;
case "sequencing":
_62=this.ValidSequencingResponse(_5e);
break;
case "numeric":
_62=this.ValidNumericResponse(_5e,false);
break;
case "other":
_62=this.ValidOtheresponse(_5e);
break;
}
}
if(!_62){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".learner_response value of '"+_5e+"' is not a valid response to an interaction of type "+this.RunTimeData.Interactions[_60].Type+".");
return false;
}
break;
case "cmi.interactions.n.result":
this.WriteDetailedLog("`1347`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(_5e!=SCORM_CORRECT&&_5e!=SCORM_INCORRECT&&_5e!=SCORM_UNANTICIPATED&&_5e!=SCORM_NEUTRAL){
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".result value of '"+_5e+"' is not a valid interaction result.");
return false;
}
}
break;
case "cmi.interactions.n.latency":
this.WriteDetailedLog("`1325`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidTimeInterval(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".latency value of '"+_5e+"' is not a valid timespan.");
return false;
}
break;
case "cmi.interactions.n.description":
case "cmi.interactions.n.text":
this.WriteDetailedLog("`1262`");
if(this.RunTimeData.Interactions[_60]===undefined||this.RunTimeData.Interactions[_60].Id===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The interactions.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidLocalizedString(_5e,250)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.interactions."+_60+".description value of '"+_5e+"' is not a valid localized string SPM 250.");
return false;
}
break;
case "cmi.launch_data":
this.WriteDetailedLog("`1544`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.launch_data element is read-only");
return false;
case "cmi.learner_id":
this.WriteDetailedLog("`1559`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.learner_id element is read-only");
return false;
case "cmi.learner_name":
this.WriteDetailedLog("`1518`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.learner_name element is read-only");
return false;
case "cmi.learner_preference._children":
this.WriteDetailedLog("`1228`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.learner_preference._children element is read-only");
return false;
case "cmi.learner_preference.audio_level":
this.WriteDetailedLog("`1184`");
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.audio_level value of '"+_5e+"' is not a valid real number.");
return false;
}
if(parseFloat(_5e)<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.learner_preference.audio_level value of '"+_5e+"' must be greater than zero.");
return false;
}
break;
case "cmi.learner_preference.language":
this.WriteDetailedLog("`1244`");
if(!this.ValidLanguage(_5e,true)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.language value of '"+_5e+"' is not a valid language.");
return false;
}
break;
case "cmi.learner_preference.delivery_speed":
this.WriteDetailedLog("`1114`");
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.delivery_speed value of '"+_5e+"' is not a valid real number.");
return false;
}
if(parseFloat(_5e)<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.learner_preference.delivery_speed value of '"+_5e+"' must be greater than zero.");
return false;
}
break;
case "cmi.learner_preference.audio_captioning":
this.WriteDetailedLog("`1073`");
if(_5e!="-1"&&_5e!="0"&&_5e!="1"){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.learner_preference.audio_captioning value of '"+_5e+"' must be -1, 0 or 1.");
return false;
}
break;
case "cmi.location":
this.WriteDetailedLog("`1590`");
if(!this.ValidCharString(_5e,1000)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.location value of '"+_5e+"' is not a valid char string SPM 1000.");
return false;
}
break;
case "cmi.max_time_allowed":
this.WriteDetailedLog("`1437`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.max_time_allowed element is read only");
return false;
case "cmi.mode":
this.WriteDetailedLog("`1684`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.mode element is read only");
return false;
case "cmi.objectives._children":
this.WriteDetailedLog("`1364`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.objectives._children element is read only");
return false;
case "cmi.objectives._count":
this.WriteDetailedLog("`1421`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.objectives._count element is read only");
return false;
case "cmi.objectives.n.id":
this.WriteDetailedLog("`1467`");
if(!this.ValidLongIdentifier(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives.n.id value of '"+_5e+"' is not a valid long identifier.");
return false;
}
if(this.RunTimeData.Objectives[_60]!=undefined&&this.RunTimeData.Objectives[_60].Identifier!=null){
if(this.RunTimeData.Objectives[_60].Identifier!==null&&this.RunTimeData.Objectives[_60].Identifier!=_5e){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Objective identifiers may only be set once and may not be overwritten. The objective at index "+_60+" already has the identifier "+this.RunTimeData.Objectives[_60].Identifier);
return false;
}
}
for(i=0;i<this.RunTimeData.Objectives.length;i++){
if((this.RunTimeData.Objectives[i].Identifier==_5e)&&(i!=_60)){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Every objective identifier must be unique. The value '"+_5e+"' has already been set in objective #"+i);
return false;
}
}
break;
case "cmi.objectives.n.score._children":
this.WriteDetailedLog("`1230`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.objectives.n.score._children element is read only");
return false;
case "cmi.objectives.n.score.scaled":
this.WriteDetailedLog("`1283`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".score.scaled value of '"+_5e+"' is not a valid real number.");
return false;
}
if(parseFloat(_5e)<-1||parseFloat(_5e)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.objectives."+_60+".score.scaled value of '"+_5e+"' must be between -1 and 1.");
return false;
}
break;
case "cmi.objectives.n.score.raw":
this.WriteDetailedLog("`1331`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".score.raw value of '"+_5e+"' is not a valid real number.");
return false;
}
break;
case "cmi.objectives.n.score.min":
this.WriteDetailedLog("`1330`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".score.min value of '"+_5e+"' is not a valid real number.");
return false;
}
break;
case "cmi.objectives.n.score.max":
this.WriteDetailedLog("`1329`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".score.max value of '"+_5e+"' is not a valid real number.");
return false;
}
break;
case "cmi.objectives.n.success_status":
this.WriteDetailedLog("`1245`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(_5e!=SCORM_STATUS_PASSED&&_5e!=SCORM_STATUS_FAILED&&_5e!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".success_status value of '"+_5e+"' is not a valid success status.");
return false;
}
break;
case "cmi.objectives.n.completion_status":
this.WriteDetailedLog("`1186`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(_5e!=SCORM_STATUS_COMPLETED&&_5e!=SCORM_STATUS_INCOMPLETE&&_5e!=SCORM_STATUS_NOT_ATTEMPTED&&_5e!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".completion_status value of '"+_5e+"' is not a valid completion status.");
return false;
}
break;
case "cmi.objectives.n.progress_measure":
this.WriteDetailedLog("`1210`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".progress_measure value of '"+_5e+"' is not a valid real number.");
return false;
}
if(parseFloat(_5e)<0||parseFloat(_5e)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.objectives."+_60+".progress_measure value of '"+_5e+"' must be between 0 and 1.");
return false;
}
break;
case "cmi.objectives.n.description":
this.WriteDetailedLog("`1296`");
if(this.RunTimeData.Objectives[_60]===undefined||this.RunTimeData.Objectives[_60].Identifier===null){
this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR,"The objectives.id element must be set before other elements can be set.");
return false;
}
if(!this.ValidLocalizedString(_5e,250)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.objectives."+_60+".description value of '"+_5e+"' is not a valid localized string SPM 250.");
return false;
}
break;
case "cmi.progress_measure":
this.WriteDetailedLog("`1439`");
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.progress_measure value of '"+_5e+"' is not a valid real number.");
return false;
}
if(parseFloat(_5e)<0||parseFloat(_5e)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi.pogress_measure value of '"+_5e+"' must be between 0 and 1.");
return false;
}
break;
case "cmi.scaled_passing_score":
this.WriteDetailedLog("`1369`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.scaled_passing_score element is read only");
return false;
case "cmi.score._children":
this.WriteDetailedLog("`1468`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.score._children element is read only");
return false;
case "cmi.score.scaled":
this.WriteDetailedLog("`1519`");
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.scaled value of '"+_5e+"' is not a valid real number.");
return false;
}
if(parseFloat(_5e)<-1||parseFloat(_5e)>1){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR,"The cmi..score.scaled value of '"+_5e+"' must be between -1 and 1.");
return false;
}
break;
case "cmi.score.raw":
this.WriteDetailedLog("`1574`");
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.raw value of '"+_5e+"' is not a valid real number.");
return false;
}
break;
case "cmi.score.max":
this.WriteDetailedLog("`1572`");
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.raw value of '"+_5e+"' is not a valid real number.");
return false;
}
break;
case "cmi.score.min":
this.WriteDetailedLog("`1573`");
if(!this.ValidReal(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.score.raw value of '"+_5e+"' is not a valid real number.");
return false;
}
break;
case "cmi.session_time":
this.WriteDetailedLog("`1521`");
if(!this.ValidTimeInterval(_5e)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.session_time value of '"+_5e+"' is not a valid time intervals.");
return false;
}
break;
case "cmi.success_status":
this.WriteDetailedLog("`1485`");
if(_5e!=SCORM_STATUS_PASSED&&_5e!=SCORM_STATUS_FAILED&&_5e!=SCORM_STATUS_UNKNOWN){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.success_status value of '"+_5e+"' is not a valid success status.");
return false;
}
break;
case "cmi.suspend_data":
this.WriteDetailedLog("`1525`");
if(!this.ValidCharString(_5e,Control.Package.Properties.SuspendDataMaxLength)){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The cmi.suspend_data value of '"+_5e+"' is not a valid char string SPM"+Control.Package.Properties.SuspendDataMaxLength+".");
return false;
}
break;
case "cmi.time_limit_action":
this.WriteDetailedLog("`1424`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.time_limit_action element is read only");
return false;
case "cmi.total_time":
this.WriteDetailedLog("`1564`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The cmi.total_time element is read only");
return false;
case "adl.nav.request":
this.WriteDetailedLog("`1463`");
if(_5e.substring(0,1)=="{"){
var _64=_5e.substring(0,_5e.indexOf("}")+1);
if(Control.IsTargetValid(_64)===false){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value '"+_64+"' is not a valid target of a choice request.");
return false;
}
if(_5e.indexOf("choice")!=_64.length){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"A target may only be provided for a choice request.");
return false;
}
}else{
if(_5e!=SCORM_RUNTIME_NAV_REQUEST_CONTINUE&&_5e!=SCORM_RUNTIME_NAV_REQUEST_PREVIOUS&&_5e!=SCORM_RUNTIME_NAV_REQUEST_CHOICE&&_5e!=SCORM_RUNTIME_NAV_REQUEST_EXIT&&_5e!=SCORM_RUNTIME_NAV_REQUEST_EXITALL&&_5e!=SCORM_RUNTIME_NAV_REQUEST_ABANDON&&_5e!=SCORM_RUNTIME_NAV_REQUEST_ABANDONALL&&_5e!=SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL&&_5e!=SCORM_RUNTIME_NAV_REQUEST_NONE){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The adl.nav.request value of '"+_5e+"' is not a valid nav request.");
return false;
}
}
break;
case "adl.nav.request_valid.continue":
this.WriteDetailedLog("`1176`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The adl.nav.request_valid.continue element is read only");
return false;
case "adl.nav.request_valid.previous":
this.WriteDetailedLog("`1177`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The adl.nav.request_valid.previous element is read only");
return false;
case "adl.nav.request_valid.choice":
this.WriteDetailedLog("`1224`");
break;
default:
if(_5f.indexOf("ssp")===0){
if(SSP_ENABLED){
return this.SSPApi.CheckForSetValueError(_5d,_5e,_5f,_60,_61);
}
}
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_5d+"' is not defined in SCORM 2004");
return false;
}
this.WriteDetailedLog("`1603`");
return true;
}
function RunTimeApi_ValidCharString(str,_66){
this.WriteDetailedLog("`1486`");
return true;
}
function RunTimeApi_ValidLocalizedString(str,_68){
this.WriteDetailedLog("`1383`");
var _69;
var _6a=new String();
var _6b;
_69=str;
if(str.indexOf("{lang=")===0){
_6b=str.indexOf("}");
if(_6b>0){
_6a=str.substr(0,_6b);
_6a=_6a.replace(/\{lang=/,"");
_6a=_6a.replace(/\}/,"");
if(!this.ValidLanguage(_6a,false)){
return false;
}
if(str.length>=(_6b+2)){
_69=str.substring(_6b+1);
}else{
_69="";
}
}
}
return true;
}
function RunTimeApi_ExtractLanguageDelimiterFromLocalizedString(str){
var _6d;
var _6e="";
if(str.indexOf("{lang=")===0){
_6d=str.indexOf("}");
if(_6d>0){
_6e=str.substr(0,_6d+1);
}
}
return _6e;
}
function RunTimeApi_ValidLanguage(str,_70){
this.WriteDetailedLog("`1529`");
var _71;
if(str.length===0){
if(_70){
return true;
}else{
return false;
}
}
_71=str.split("-");
for(var i=0;i<_71.length;i++){
if(_71[i].length>8){
return false;
}
if(_71[i].length<2){
if(_71[i]!="i"&&_71[i]!="x"){
return false;
}
}
}
var _73=new Iso639LangCodes_LangCodes();
if(!_73.IsValid(_71[0].toLowerCase())){
return false;
}
if(str.length>250){
return false;
}
return true;
}
function RunTimeApi_ValidLongIdentifier(str){
this.WriteDetailedLog("`1402`");
str=str.trim();
if(!this.ValidIdentifier(str)){
return false;
}
return true;
}
function RunTimeApi_ValidShortIdentifier(str){
this.WriteDetailedLog("`1385`");
if(!this.ValidIdentifier(str)){
return false;
}
return true;
}
function RunTimeApi_ValidIdentifier(str){
this.WriteDetailedLog("`1487`");
str=str.trim();
if(str.length===0){
return false;
}
if(str.toLowerCase().indexOf("urn:")===0){
return this.IsValidUrn(str);
}
if(str.search(/\w/)<0){
return false;
}
if(str.search(/[^\w\-\(\)\+\.\:\=\@\;\$\_\!\*\'\%\/]/)>=0){
return false;
}
return true;
}
function RunTimeApi_IsValidUrn(str){
this.WriteDetailedLog("`1575`");
var _78=str.split(":");
var nid=new String("");
var nss="";
if(_78.length>1){
nid=_78[1];
}else{
return false;
}
if(_78.length>2){
nss=_78[2];
}
if(nid.length===0){
return false;
}
if(nid.indexOf(" ")>0||nss.indexOf(" ")>0){
return false;
}
return true;
}
function RunTimeApi_ValidReal(str){
this.WriteDetailedLog("`1595`");
if(str.search(/[^.\d-]/)>-1){
return false;
}
if(str.search("-")>-1){
if(str.indexOf("-",1)>-1){
return false;
}
}
if(str.indexOf(".")!=str.lastIndexOf(".")){
return false;
}
if(str.search(/\d/)<0){
return false;
}
return true;
}
function RunTimeApi_ValidTime(str){
this.WriteDetailedLog("`1596`");
var _7d="";
var _7e="";
var day="";
var _80="";
var _81="";
var _82="";
var _83="";
var _84="";
var _85="";
var _86="";
var _87;
str=new String(str);
var _88=/^(\d\d\d\d)(-(\d\d)(-(\d\d)(T(\d\d)(:(\d\d)(:(\d\d))?)?)?)?)?/;
if(str.search(_88)!==0){
return false;
}
if(str.substr(str.length-1,1).search(/[\-T\:]/)>=0){
return false;
}
var len=str.length;
if(len!=4&&len!=7&&len!=10&&len!=13&&len!=16&&len<19){
return false;
}
if(len>=5){
if(str.substr(4,1)!="-"){
return false;
}
}
if(len>=8){
if(str.substr(7,1)!="-"){
return false;
}
}
if(len>=11){
if(str.substr(10,1)!="T"){
return false;
}
}
if(len>=14){
if(str.substr(13,1)!=":"){
return false;
}
}
if(len>=17){
if(str.substr(16,1)!=":"){
return false;
}
}
var _8a=str.match(_88);
_7d=_8a[1];
_7e=_8a[3];
day=_8a[5];
_80=_8a[7];
_81=_8a[9];
_82=_8a[11];
if(str.length>19){
if(str.length<21){
return false;
}
if(str.substr(19,1)!="."){
return false;
}
_87=str.substr(20,1);
if(_87.search(/\d/)<0){
return false;
}else{
_83+=_87;
}
for(var i=21;i<str.length;i++){
_87=str.substr(i,1);
if((i==21)&&(_87.search(/\d/)===0)){
_83+=_87;
}else{
_84+=_87;
}
}
}
if(_84.length===0){
}else{
if(_84.length==1){
if(_84!="Z"){
return false;
}
}else{
if(_84.length==3){
if(_84.search(/[\+\-]\d\d/)!==0){
return false;
}else{
_85=_84.substr(1,2);
}
}else{
if(_84.length==6){
if(_84.search(/[\+\-]\d\d:\d\d/)!==0){
return false;
}else{
_85=_84.substr(1,2);
_86=_84.substr(4,2);
}
}else{
return false;
}
}
}
}
if(_7d<1970||_7d>2038){
return false;
}
if(_7e!==undefined&&_7e!==""){
_7e=parseInt(_7e,10);
if(_7e<1||_7e>12){
return false;
}
}
if(day!==undefined&&day!==""){
var dtm=new Date(_7d,(_7e-1),day);
if(dtm.getDate()!=day){
return false;
}
}
if(_80!==undefined&&_80!==""){
_80=parseInt(_80,10);
if(_80<0||_80>23){
return false;
}
}
if(_81!==undefined&&_81!==""){
_81=parseInt(_81,10);
if(_81<0||_81>59){
return false;
}
}
if(_82!==undefined&&_82!==""){
_82=parseInt(_82,10);
if(_82<0||_82>59){
return false;
}
}
if(_85!==undefined&&_85!==""){
_85=parseInt(_85,10);
if(_85<0||_85>23){
return false;
}
}
if(_86!==undefined&&_86!==""){
_86=parseInt(_86,10);
if(_86<0||_86>59){
return false;
}
}
return true;
}
function RunTimeApi_ValidTimeInterval(str){
this.WriteDetailedLog("`1445`");
var _8e=/^P(\d+Y)?(\d+M)?(\d+D)?(T(\d+H)?(\d+M)?(\d+(.\d\d?)?S)?)?$/;
if(str=="P"){
return false;
}
if(str.lastIndexOf("T")==(str.length-1)){
return false;
}
if(str.search(_8e)<0){
return false;
}
return true;
}
function RunTimeApi_ValidTrueFalseResponse(str){
this.WriteDetailedLog("`1354`");
var _90=/^(true|false)$/;
if(str.search(_90)<0){
return false;
}
return true;
}
function RunTimeApi_ValidMultipleChoiceResponse(str){
this.WriteDetailedLog("`1268`");
if(str.length===0){
return true;
}
return (this.IsValidArrayOfShortIdentifiers(str,36,true)||this.IsValidCommaDelimitedArrayOfShortIdentifiers(str,36,true));
}
function RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers(str,_93,_94){
this.WriteDetailedLog("`1215`");
var _95=",";
var _96=str.split(_95);
for(var i=0;i<_96.length;i++){
if(!this.ValidShortIdentifier(_96[i])){
return false;
}
if(_94){
for(var j=0;j<_96.length;j++){
if(j!=i){
if(_96[j]==_96[i]){
return false;
}
}
}
}
}
return true;
}
function RunTimeApi_IsValidArrayOfShortIdentifiers(str,_9a,_9b){
this.WriteDetailedLog("`1215`");
var _9c="[,]";
var _9d=str.split(_9c);
for(var i=0;i<_9d.length;i++){
if(!this.ValidShortIdentifier(_9d[i])){
return false;
}
if(_9b){
for(var j=0;j<_9d.length;j++){
if(j!=i){
if(_9d[j]==_9d[i]){
return false;
}
}
}
}
}
return true;
}
function RunTimeApi_IsValidArrayOfLocalizedStrings(str,_a1,_a2){
this.WriteDetailedLog("`1214`");
var _a3="[,]";
var _a4=str.split(_a3);
for(var i=0;i<_a4.length;i++){
if(!this.ValidLocalizedString(_a4[i],0)){
return false;
}
if(_a2){
for(var j=0;j<_a4.length;j++){
if(j!=i){
if(_a4[j]==_a4[i]){
return false;
}
}
}
}
}
return true;
}
function RunTimeApi_ValidFillInResponse(str,_a8){
this.WriteDetailedLog("`1400`");
if(str.length===0){
return true;
}
var _a9=/^\{case_matters=/;
var _aa=/^\{order_matters=/;
var _ab=/^\{lang=[\w\-]+\}\{/;
var _ac=/^\{case_matters=(true|false)\}/;
var _ad=/^\{order_matters=(true|false)\}/;
var _ae=new String(str);
if(_a8){
if(_ae.search(_a9)>=0){
if(_ae.search(_ac)<0){
return false;
}
_ae=_ae.replace(_ac,"");
}
if(_ae.search(_aa)>=0){
if(_ae.search(_ad)<0){
return false;
}
_ae=_ae.replace(_ad,"");
}
if(_ae.search(_a9)>=0){
if(_ae.search(_ac)<0){
return false;
}
_ae=_ae.replace(_ac,"");
}
}
return this.IsValidArrayOfLocalizedStrings(_ae,10,false);
}
function RunTimeApi_ValidLongFillInResponse(str,_b0){
this.WriteDetailedLog("`1336`");
var _b1=/^\{case_matters=/;
var _b2=/^\{case_matters=(true|false)\}/;
var _b3=new String(str);
if(_b0){
if(_b3.search(_b1)>=0){
if(_b3.search(_b2)<0){
return false;
}
_b3=_b3.replace(_b2,"");
}
}
return this.ValidLocalizedString(_b3,4000);
}
function RunTimeApi_ValidLikeRTResponse(str){
this.WriteDetailedLog("`1401`");
return this.ValidShortIdentifier(str);
}
function RunTimeApi_ValidMatchingResponse(str){
this.WriteDetailedLog("`1374`");
var _b6="[,]";
var _b7="[.]";
var _b8;
var _b9;
_b8=str.split(_b6);
for(var i=0;i<_b8.length;i++){
_b9=_b8[i].split(_b7);
if(_b9.length!=2){
return false;
}
if(!this.ValidShortIdentifier(_b9[0])){
return false;
}
if(!this.ValidShortIdentifier(_b9[1])){
return false;
}
}
return true;
}
function RunTimeApi_ValidPerformanceResponse(str,_bc){
this.WriteDetailedLog("`1314`");
var _bd=/^\{order_matters=/;
var _be=/^\{order_matters=(true|false)\}/;
var _bf;
var _c0;
var _c1;
var _c2;
var _c3;
var _c4=new String(str);
if(str.length===0){
return false;
}
if(_bc){
if(_c4.search(_bd)>=0){
if(_c4.search(_be)<0){
return false;
}
_c4=_c4.replace(_be,"");
}
}
_bf=_c4.split("[,]");
if(_bf.length===0){
return false;
}
for(var i=0;i<_bf.length;i++){
_c0=_bf[i];
if(_c0.length===0){
return false;
}
_c1=_c0.split("[.]");
if(_c1.length==2){
_c2=_c1[0];
_c3=_c1[1];
if(_c2.length===0&&_c3===0){
return false;
}
if(_c2.length>0){
if(!this.ValidShortIdentifier(_c2)){
return false;
}
}
}else{
return false;
}
}
return true;
}
function RunTimeApi_ValidSequencingResponse(str){
this.WriteDetailedLog("`1337`");
return this.IsValidArrayOfShortIdentifiers(str,36,false);
}
function RunTimeApi_ValidNumericResponse(str,_c8){
this.WriteDetailedLog("`1384`");
var _c9="[:]";
var _ca=str.split(_c9);
if(_c8){
if(_ca.length>2){
return false;
}
}else{
if(_ca.length>1){
return false;
}
}
for(var i=0;i<_ca.length;i++){
if(!this.ValidReal(_ca[i])){
return false;
}
}
if(_ca.length>=2){
if(_ca[0].length>0&&_ca[1].length>0){
if(parseFloat(_ca[0])>parseFloat(_ca[1])){
return false;
}
}
}
return true;
}
function RunTimeApi_ValidOtheresponse(str){
this.WriteDetailedLog("`1444`");
return true;
}
function RunTimeApi_TranslateBooleanIntoCMI(_cd){
if(_cd===true){
return SCORM_TRUE;
}else{
if(_cd===false){
return SCORM_FALSE;
}else{
return SCORM_UNKNOWN;
}
}
}
function RunTimeApi_GetCompletionStatus(){
if(this.LearningObject.CompletionThreshold!==null){
if(this.RunTimeData.ProgressMeasure!==null){
if(parseFloat(this.RunTimeData.ProgressMeasure)>=parseFloat(this.LearningObject.CompletionThreshold)){
this.WriteDetailedLog("`615`");
return SCORM_STATUS_COMPLETED;
}else{
this.WriteDetailedLog("`569`");
return SCORM_STATUS_INCOMPLETE;
}
}else{
this.WriteDetailedLog("`992`"+this.LearningObject.CompletionThreshold+"`669`");
return SCORM_STATUS_UNKNOWN;
}
}
this.WriteDetailedLog("`623`"+this.RunTimeData.CompletionStatus);
return this.RunTimeData.CompletionStatus;
}
function RunTimeApi_GetSuccessStatus(){
var _ce=this.LearningObject.GetScaledPassingScore();
if(_ce!==null){
if(this.RunTimeData.ScoreScaled!==null){
if(parseFloat(this.RunTimeData.ScoreScaled)>=parseFloat(_ce)){
this.WriteDetailedLog("`696`");
return SCORM_STATUS_PASSED;
}else{
this.WriteDetailedLog("`649`");
return SCORM_STATUS_FAILED;
}
}else{
this.WriteDetailedLog("`570`");
return SCORM_STATUS_UNKNOWN;
}
}
this.WriteDetailedLog("`640`"+this.RunTimeData.SuccessStatus);
return this.RunTimeData.SuccessStatus;
}
function RunTimeApi_InitTrackedTimeStart(_cf){
this.TrackedStartDate=new Date();
this.StartSessionTotalTime=_cf.RunTime.TotalTime;
}
function RunTimeApi_AccumulateTotalTimeTracked(){
this.TrackedEndDate=new Date();
var _d0=Math.round((this.TrackedEndDate-this.TrackedStartDate)/10);
var _d1=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTimeTracked);
var _d2=_d0+_d1;
this.RunTimeData.TotalTimeTracked=ConvertHundredthsToIso8601TimeSpan(_d2);
this.Activity.ActivityEndedDate=this.TrackedEndDate;
var _d3=GetDateFromUtcIso8601Time(this.Activity.GetActivityStartTimestampUtc());
var _d4=GetDateFromUtcIso8601Time(this.Activity.GetAttemptStartTimestampUtc());
this.Activity.SetActivityAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate-_d3)/10));
this.Activity.SetAttemptAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate-_d4)/10));
var _d5=ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationTracked());
var _d6=ConvertHundredthsToIso8601TimeSpan(_d5+_d0);
this.Activity.SetActivityExperiencedDurationTracked(_d6);
var _d7=ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationReported());
var _d8=ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime)-ConvertIso8601TimeSpanToHundredths(this.StartSessionTotalTime);
var _d9=ConvertHundredthsToIso8601TimeSpan(_d7+_d8);
this.Activity.SetActivityExperiencedDurationReported(_d9);
var _da=ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationTracked());
var _db=ConvertHundredthsToIso8601TimeSpan(_da+_d0);
this.Activity.SetAttemptExperiencedDurationTracked(_db);
var _dc=ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationReported());
var _dd=ConvertHundredthsToIso8601TimeSpan(_dc+_d8);
this.Activity.SetAttemptExperiencedDurationReported(_dd);
}
function RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded(_de,_df){
if(this.IsLookAheadSequencerDataDirty==false&&_de!=_df){
this.IsLookAheadSequencerDataDirty=true;
}
}
function RunTimeApi_RunLookAheadSequencerIfNeeded(_e0){
if((Control.Package.Properties.LookaheadSequencerMode!=LOOKAHEAD_SEQUENCER_MODE_REALTIME&&_e0!==true)||Control.Package.Properties.LookaheadSequencerMode==LOOKAHEAD_SEQUENCER_MODE_DISABLE){
return;
}
if(this.RunTimeData!=null){
this.LookAheadSessionClose();
}
if(this.IsLookAheadSequencerDataDirty===true&&!this.IsLookAheadSequencerRunning){
this.IsLookAheadSequencerDataDirty=false;
this.IsLookAheadSequencerRunning=true;
window.setTimeout("Control.EvaluatePossibleNavigationRequests(true);",150);
}
}
var TERMINATION_REQUEST_EXIT="EXIT";
var TERMINATION_REQUEST_EXIT_ALL="EXIT ALL";
var TERMINATION_REQUEST_SUSPEND_ALL="SUSPEND ALL";
var TERMINATION_REQUEST_ABANDON="ABANDON";
var TERMINATION_REQUEST_ABANDON_ALL="ABANDON ALL";
var TERMINATION_REQUEST_EXIT_PARENT="EXIT PARENT";
var TERMINATION_REQUEST_NOT_VALID="INVALID";
var SEQUENCING_REQUEST_START="START";
var SEQUENCING_REQUEST_RESUME_ALL="RESUME ALL";
var SEQUENCING_REQUEST_CONTINUE="CONTINUE";
var SEQUENCING_REQUEST_PREVIOUS="PREVIOUS";
var SEQUENCING_REQUEST_CHOICE="CHOICE";
var SEQUENCING_REQUEST_RETRY="RETRY";
var SEQUENCING_REQUEST_EXIT="EXIT";
var SEQUENCING_REQUEST_NOT_VALID="INVALID";
var RULE_SET_POST_CONDITION="POST_CONDITION";
var RULE_SET_EXIT="EXIT";
var RULE_SET_HIDE_FROM_CHOICE="HIDE_FROM_CHOICE";
var RULE_SET_STOP_FORWARD_TRAVERSAL="STOP_FORWARD_TRAVERSAL";
var RULE_SET_DISABLED="DISABLED";
var RULE_SET_SKIPPED="SKIPPED";
var RULE_SET_SATISFIED="SATISFIED";
var RULE_SET_NOT_SATISFIED="NOT_SATISFIED";
var RULE_SET_COMPLETED="COMPLETED";
var RULE_SET_INCOMPLETE="INCOMPLETE";
var SEQUENCING_RULE_ACTION_SKIP="Skip";
var SEQUENCING_RULE_ACTION_DISABLED="Disabled";
var SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE="Hidden From Choice";
var SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL="Stop Forward Traversal";
var SEQUENCING_RULE_ACTION_EXIT="Exit";
var SEQUENCING_RULE_ACTION_EXIT_PARENT="Exit Parent";
var SEQUENCING_RULE_ACTION_EXIT_ALL="Exit All";
var SEQUENCING_RULE_ACTION_RETRY="Retry";
var SEQUENCING_RULE_ACTION_RETRY_ALL="Retry All";
var SEQUENCING_RULE_ACTION_CONTINUE="Continue";
var SEQUENCING_RULE_ACTION_PREVIOUS="Previous";
var FLOW_DIRECTION_FORWARD="FORWARD";
var FLOW_DIRECTION_BACKWARD="BACKWARD";
var RULE_CONDITION_OPERATOR_NOT="Not";
var RULE_CONDITION_COMBINATION_ALL="All";
var RULE_CONDITION_COMBINATION_ANY="Any";
var RESULT_UNKNOWN="unknown";
var SEQUENCING_RULE_CONDITION_SATISFIED="Satisfied";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN="Objective Status Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN="Objective Measure Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN="Objective Measure Greater Than";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN="Objective Measure Less Than";
var SEQUENCING_RULE_CONDITION_COMPLETED="Completed";
var SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN="Activity Progress Known";
var SEQUENCING_RULE_CONDITION_ATTEMPTED="Attempted";
var SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED="Attempt Limit Exceeded";
var SEQUENCING_RULE_CONDITION_ALWAYS="Always";
var ROLLUP_RULE_ACTION_SATISFIED="Satisfied";
var ROLLUP_RULE_ACTION_NOT_SATISFIED="Not Satisfied";
var ROLLUP_RULE_ACTION_COMPLETED="Completed";
var ROLLUP_RULE_ACTION_INCOMPLETE="Incomplete";
var CHILD_ACTIVITY_SET_ALL="All";
var CHILD_ACTIVITY_SET_ANY="Any";
var CHILD_ACTIVITY_SET_NONE="None";
var CHILD_ACTIVITY_SET_AT_LEAST_COUNT="At Least Count";
var CHILD_ACTIVITY_SET_AT_LEAST_PERCENT="At Least Percent";
var ROLLUP_RULE_CONDITION_SATISFIED="Satisfied";
var ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN="Objective Status Known";
var ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN="Objective Measure Known";
var ROLLUP_RULE_CONDITION_COMPLETED="Completed";
var ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN="Activity Progress Known";
var ROLLUP_RULE_CONDITION_ATTEMPTED="Attempted";
var ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED="Attempt Limit Exceeded";
var ROLLUP_RULE_CONDITION_NEVER="Never";
var ROLLUP_CONSIDERATION_ALWAYS="Always";
var ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED="If Not Suspended";
var ROLLUP_CONSIDERATION_IF_ATTEMPTED="If Attempted";
var ROLLUP_CONSIDERATION_IF_NOT_SKIPPED="If Not Skipped";
var TIMING_NEVER="Never";
var TIMING_ONCE="Once";
var TIMING_ON_EACH_NEW_ATTEMPT="On Each New Attempt";
var CONTROL_CHOICE_EXIT_ERROR_NAV="NB.2.1-8";
var CONTROL_CHOICE_EXIT_ERROR_CHOICE="SB.2.9-7";
var PREVENT_ACTIVATION_ERROR="SB.2.9-6";
var CONSTRAINED_CHOICE_ERROR="SB.2.9-8";
function Sequencer(_e1,_e2){
this.LookAhead=_e1;
this.Activities=_e2;
this.NavigationRequest=null;
this.ChoiceTargetIdentifier=null;
this.SuspendedActivity=null;
this.CurrentActivity=null;
this.Exception=null;
this.ExceptionText=null;
this.GlobalObjectives=new Array();
this.ReturnToLmsInvoked=false;
}
Sequencer.prototype.OverallSequencingProcess=Sequencer_OverallSequencingProcess;
Sequencer.prototype.SetSuspendedActivity=Sequencer_SetSuspendedActivity;
Sequencer.prototype.GetSuspendedActivity=Sequencer_GetSuspendedActivity;
Sequencer.prototype.Start=Sequencer_Start;
Sequencer.prototype.InitialRandomizationAndSelection=Sequencer_InitialRandomizationAndSelection;
Sequencer.prototype.GetCurrentActivity=Sequencer_GetCurrentActivity;
Sequencer.prototype.GetExceptionText=Sequencer_GetExceptionText;
Sequencer.prototype.GetExitAction=Sequencer_GetExitAction;
Sequencer.prototype.EvaluatePossibleNavigationRequests=Sequencer_EvaluatePossibleNavigationRequests;
Sequencer.prototype.InitializePossibleNavigationRequestAbsolutes=Sequencer_InitializePossibleNavigationRequestAbsolutes;
Sequencer.prototype.SetAllDescendentsToDisabled=Sequencer_SetAllDescendentsToDisabled;
Sequencer.prototype.ContentDeliveryEnvironmentActivityDataSubProcess=Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess;
function Sequencer_SetSuspendedActivity(_e3){
this.SuspendedActivity=_e3;
}
function Sequencer_GetSuspendedActivity(_e4){
var _e5=this.SuspendedActivity;
if(_e4!==null&&_e4!==undefined){
this.LogSeq("`1567`"+_e5,_e4);
}
return _e5;
}
function Sequencer_Start(){
if(this.SuspendedActivity===null){
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_START,null,"");
}else{
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_RESUME_ALL,null,"");
}
this.OverallSequencingProcess();
}
function Sequencer_InitialRandomizationAndSelection(){
var _e6=this.LogSeqAudit("`1313`");
if(this.SuspendedActivity===null){
for(var _e7 in this.Activities.ActivityList){
this.SelectChildrenProcess(this.Activities.ActivityList[_e7],_e6);
this.RandomizeChildrenProcess(this.Activities.ActivityList[_e7],false,_e6);
}
}
}
function Sequencer_GetCurrentActivity(){
return this.CurrentActivity;
}
function Sequencer_GetExceptionText(){
if(this.ExceptionText!==null&&this.ExceptionText!==undefined){
return this.ExceptionText;
}else{
return "";
}
}
function Sequencer_GetExitAction(_e8,_e9){
return EXIT_ACTION_DISPLAY_MESSAGE;
}
Sequencer.prototype.NavigationRequestProcess=Sequencer_NavigationRequestProcess;
Sequencer.prototype.SequencingExitActionRulesSubprocess=Sequencer_SequencingExitActionRulesSubprocess;
Sequencer.prototype.SequencingPostConditionRulesSubprocess=Sequencer_SequencingPostConditionRulesSubprocess;
Sequencer.prototype.TerminationRequestProcess=Sequencer_TerminationRequestProcess;
Sequencer.prototype.MeasureRollupProcess=Sequencer_MeasureRollupProcess;
Sequencer.prototype.ObjectiveRollupProcess=Sequencer_ObjectiveRollupProcess;
Sequencer.prototype.ObjectiveRollupUsingDefaultProcess=Sequencer_ObjectiveRollupUsingDefaultProcess;
Sequencer.prototype.ObjectiveRollupUsingMeasureProcess=Sequencer_ObjectiveRollupUsingMeasureProcess;
Sequencer.prototype.ObjectiveRollupUsingRulesProcess=Sequencer_ObjectiveRollupUsingRulesProcess;
Sequencer.prototype.ActivityProgressRollupProcess=Sequencer_ActivityProgressRollupProcess;
Sequencer.prototype.ActivityProgressRollupProcessUsingDefault=Sequencer_ActivityProgressRollupProcessUsingDefault;
Sequencer.prototype.RollupRuleCheckSubprocess=Sequencer_RollupRuleCheckSubprocess;
Sequencer.prototype.EvaluateRollupConditionsSubprocess=Sequencer_EvaluateRollupConditionsSubprocess;
Sequencer.prototype.CheckChildForRollupSubprocess=Sequencer_CheckChildForRollupSubprocess;
Sequencer.prototype.OverallRollupProcess=Sequencer_OverallRollupProcess;
Sequencer.prototype.SelectChildrenProcess=Sequencer_SelectChildrenProcess;
Sequencer.prototype.RandomizeChildrenProcess=Sequencer_RandomizeChildrenProcess;
Sequencer.prototype.FlowTreeTraversalSubprocess=Sequencer_FlowTreeTraversalSubprocess;
Sequencer.prototype.FlowActivityTraversalSubprocess=Sequencer_FlowActivityTraversalSubprocess;
Sequencer.prototype.FlowSubprocess=Sequencer_FlowSubprocess;
Sequencer.prototype.ChoiceActivityTraversalSubprocess=Sequencer_ChoiceActivityTraversalSubprocess;
Sequencer.prototype.StartSequencingRequestProcess=Sequencer_StartSequencingRequestProcess;
Sequencer.prototype.ResumeAllSequencingRequestProcess=Sequencer_ResumeAllSequencingRequestProcess;
Sequencer.prototype.ContinueSequencingRequestProcess=Sequencer_ContinueSequencingRequestProcess;
Sequencer.prototype.PreviousSequencingRequestProcess=Sequencer_PreviousSequencingRequestProcess;
Sequencer.prototype.ChoiceSequencingRequestProcess=Sequencer_ChoiceSequencingRequestProcess;
Sequencer.prototype.ChoiceFlowSubprocess=Sequencer_ChoiceFlowSubprocess;
Sequencer.prototype.ChoiceFlowTreeTraversalSubprocess=Sequencer_ChoiceFlowTreeTraversalSubprocess;
Sequencer.prototype.RetrySequencingRequestProcess=Sequencer_RetrySequencingRequestProcess;
Sequencer.prototype.ExitSequencingRequestProcess=Sequencer_ExitSequencingRequestProcess;
Sequencer.prototype.SequencingRequestProcess=Sequencer_SequencingRequestProcess;
Sequencer.prototype.DeliveryRequestProcess=Sequencer_DeliveryRequestProcess;
Sequencer.prototype.ContentDeliveryEnvironmentProcess=Sequencer_ContentDeliveryEnvironmentProcess;
Sequencer.prototype.ClearSuspendedActivitySubprocess=Sequencer_ClearSuspendedActivitySubprocess;
Sequencer.prototype.LimitConditionsCheckProcess=Sequencer_LimitConditionsCheckProcess;
Sequencer.prototype.SequencingRulesCheckProcess=Sequencer_SequencingRulesCheckProcess;
Sequencer.prototype.SequencingRulesCheckSubprocess=Sequencer_SequencingRulesCheckSubprocess;
Sequencer.prototype.TerminateDescendentAttemptsProcess=Sequencer_TerminateDescendentAttemptsProcess;
Sequencer.prototype.EndAttemptProcess=Sequencer_EndAttemptProcess;
Sequencer.prototype.CheckActivityProcess=Sequencer_CheckActivityProcess;
Sequencer.prototype.EvaluateSequencingRuleCondition=Sequencer_EvaluateSequencingRuleCondition;
Sequencer.prototype.ResetException=Sequencer_ResetException;
Sequencer.prototype.LogSeq=Sequencer_LogSeq;
Sequencer.prototype.LogSeqAudit=Sequencer_LogSeqAudit;
Sequencer.prototype.LogSeqReturn=Sequencer_LogSeqReturn;
Sequencer.prototype.WriteHistoryLog=Sequencer_WriteHistoryLog;
Sequencer.prototype.WriteHistoryReturnValue=Sequencer_WriteHistoryReturnValue;
Sequencer.prototype.SetCurrentActivity=Sequencer_SetCurrentActivity;
Sequencer.prototype.IsCurrentActivityDefined=Sequencer_IsCurrentActivityDefined;
Sequencer.prototype.IsSuspendedActivityDefined=Sequencer_IsSuspendedActivityDefined;
Sequencer.prototype.ClearSuspendedActivity=Sequencer_ClearSuspendedActivity;
Sequencer.prototype.GetRootActivity=Sequencer_GetRootActivity;
Sequencer.prototype.DoesActivityExist=Sequencer_DoesActivityExist;
Sequencer.prototype.GetActivityFromIdentifier=Sequencer_GetActivityFromIdentifier;
Sequencer.prototype.AreActivitiesSiblings=Sequencer_AreActivitiesSiblings;
Sequencer.prototype.FindCommonAncestor=Sequencer_FindCommonAncestor;
Sequencer.prototype.GetActivityPath=Sequencer_GetActivityPath;
Sequencer.prototype.GetPathToAncestorExclusive=Sequencer_GetPathToAncestorExclusive;
Sequencer.prototype.GetPathToAncestorInclusive=Sequencer_GetPathToAncestorInclusive;
Sequencer.prototype.ActivityHasSuspendedChildren=Sequencer_ActivityHasSuspendedChildren;
Sequencer.prototype.CourseIsSingleSco=Sequencer_CourseIsSingleSco;
Sequencer.prototype.TranslateSequencingRuleActionIntoSequencingRequest=Sequencer_TranslateSequencingRuleActionIntoSequencingRequest;
Sequencer.prototype.TranslateSequencingRuleActionIntoTerminationRequest=Sequencer_TranslateSequencingRuleActionIntoTerminationRequest;
Sequencer.prototype.IsActivity1BeforeActivity2=Sequencer_IsActivity1BeforeActivity2;
Sequencer.prototype.GetOrderedListOfActivities=Sequencer_GetOrderedListOfActivities;
Sequencer.prototype.PreOrderTraversal=Sequencer_PreOrderTraversal;
Sequencer.prototype.IsActivityLastOverall=Sequencer_IsActivityLastOverall;
Sequencer.prototype.GetGlobalObjectiveByIdentifier=Sequencer_GetGlobalObjectiveByIdentifier;
Sequencer.prototype.AddGlobalObjective=Sequencer_AddGlobalObjective;
Sequencer.prototype.ResetGlobalObjectives=Sequencer_ResetGlobalObjectives;
Sequencer.prototype.FindActivitiesAffectedByWriteMaps=Sequencer_FindActivitiesAffectedByWriteMaps;
Sequencer.prototype.FindDistinctParentsOfActivitySet=Sequencer_FindDistinctParentsOfActivitySet;
Sequencer.prototype.FindDistinctAncestorsOfActivitySet=Sequencer_FindDistinctAncestorsOfActivitySet;
Sequencer.prototype.GetMinimalSubsetOfActivitiesToRollup=Sequencer_GetMinimalSubsetOfActivitiesToRollup;
Sequencer.prototype.CheckForRelevantSequencingRules=Sequencer_CheckForRelevantSequencingRules;
Sequencer.prototype.DoesThisActivityHaveSequencingRulesRelevantToChoice=Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice;
function Sequencer_ResetException(){
this.Exception=null;
this.ExceptionText=null;
}
function Sequencer_LogSeq(str,_eb){
str=str+"";
if(this.LookAhead===true){
return Debug.WriteLookAheadDetailed(str,_eb);
}else{
return Debug.WriteSequencingDetailed(str,_eb);
}
}
function Sequencer_LogSeqAudit(str,_ed){
str=str+"";
if(this.LookAhead===true){
return Debug.WriteLookAheadAudit(str,_ed);
}else{
return Debug.WriteSequencingAudit(str,_ed);
}
}
function Sequencer_LogSeqReturn(str,_ef){
if(_ef===null||_ef===undefined){
Debug.AssertError("`1553`");
}
str=str+"";
if(this.LookAhead===true){
return _ef.setReturn(str);
}else{
return _ef.setReturn(str);
}
}
function Sequencer_WriteHistoryLog(str,_f1){
HistoryLog.WriteEventDetailed(str,_f1);
}
function Sequencer_WriteHistoryReturnValue(str,_f3){
HistoryLog.WriteEventDetailedReturnValue(str,_f3);
}
function Sequencer_SetCurrentActivity(_f4,_f5){
Debug.AssertError("Parent log not passed.",(_f5===undefined||_f5===null));
this.LogSeq("`1446`"+_f4,_f5);
this.CurrentActivity=_f4;
}
function Sequencer_IsCurrentActivityDefined(_f6){
Debug.AssertError("Parent log not passed.",(_f6===undefined||_f6===null));
var _f7=this.GetCurrentActivity();
var _f8=(_f7!==null);
if(_f8){
this.LogSeq("`1460`",_f6);
}else{
this.LogSeq("`1378`",_f6);
}
return _f8;
}
function Sequencer_IsSuspendedActivityDefined(_f9){
Debug.AssertError("Parent log not passed.",(_f9===undefined||_f9===null));
var _fa=this.GetSuspendedActivity(_f9);
var _fb=(_fa!==null);
if(_fb){
this.LogSeq("`1426`",_f9);
}else{
this.LogSeq("`1355`",_f9);
}
return _fb;
}
function Sequencer_ClearSuspendedActivity(_fc){
Debug.AssertError("Parent log not passed.",(_fc===undefined||_fc===null));
this.LogSeq("`1454`",_fc);
this.SuspendedActivity=null;
}
function Sequencer_GetRootActivity(_fd){
Debug.AssertError("Parent log not passed.",(_fd===undefined||_fd===null));
var _fe=this.Activities.GetRootActivity();
this.LogSeq("`1661`"+_fe,_fd);
return _fe;
}
function Sequencer_DoesActivityExist(_ff,_100){
Debug.AssertError("Parent log not passed.",(_100===undefined||_100===null));
var _101=this.Activities.DoesActivityExist(_ff,_100);
if(_101){
this.LogSeq("`1689`"+_ff+"`1389`",_100);
}else{
this.LogSeq("`1689`"+_ff+"`1255`",_100);
}
return _101;
}
function Sequencer_GetActivityFromIdentifier(_102,_103){
Debug.AssertError("Parent log not passed.",(_103===undefined||_103===null));
var _104=this.Activities.GetActivityFromIdentifier(_102,_103);
if(_104!==null){
this.LogSeq("`1689`"+_102+"`1475`"+_104,_103);
}else{
this.LogSeq("`1689`"+_102+"`1223`",_103);
}
return _104;
}
function Sequencer_AreActivitiesSiblings(_105,_106,_107){
Debug.AssertError("Parent log not passed.",(_107===undefined||_107===null));
if(_105===null||_105===undefined||_106===null||_106===undefined){
return false;
}
var _108=_105.ParentActivity;
var _109=_106.ParentActivity;
var _10a=(_108==_109);
if(_10a){
this.LogSeq("`1700`"+_105+"`1744`"+_106+"`1710`",_107);
}else{
this.LogSeq("`1700`"+_105+"`1744`"+_106+"`1633`",_107);
}
return _10a;
}
function Sequencer_FindCommonAncestor(_10b,_10c,_10d){
Debug.AssertError("Parent log not passed.",(_10d===undefined||_10d===null));
var _10e=new Array();
var _10f=new Array();
if(_10b!==null&&_10b.IsTheRoot()){
this.LogSeq(_10b+"`940`"+_10b+"`1744`"+_10c+"`1746`"+_10b,_10d);
return _10b;
}
if(_10c!==null&&_10c.IsTheRoot()){
this.LogSeq(_10c+"`940`"+_10b+"`1744`"+_10c+"`1746`"+_10c,_10d);
return _10c;
}
if(_10b!==null){
_10e=this.Activities.GetActivityPath(_10b,false);
}
if(_10c!==null){
_10f=this.Activities.GetActivityPath(_10c,false);
}
for(var i=0;i<_10e.length;i++){
for(var j=0;j<_10f.length;j++){
if(_10e[i]==_10f[j]){
this.LogSeq("`1338`"+_10b+"`1744`"+_10c+"`1746`"+_10e[i],_10d);
return _10e[i];
}
}
}
this.LogSeq("`1725`"+_10b+"`1744`"+_10c+"`1388`",_10d);
return null;
}
function Sequencer_GetActivityPath(_112,_113){
return this.Activities.GetActivityPath(_112,_113);
}
function Sequencer_GetPathToAncestorExclusive(_114,_115,_116){
var _117=new Array();
var _118=0;
if(_114!==null&&_115!==null&&_114!==_115){
if(_116===true){
_117[_118]=_114;
_118++;
}
while(_114.ParentActivity!==null&&_114.ParentActivity!==_115){
_114=_114.ParentActivity;
_117[_118]=_114;
_118++;
}
}
return _117;
}
function Sequencer_GetPathToAncestorInclusive(_119,_11a,_11b){
var _11c=new Array();
var _11d=0;
if(_11b==null||_11b==undefined){
_11b===true;
}
_11c[_11d]=_119;
_11d++;
while(_119.ParentActivity!==null&&_119!=_11a){
_119=_119.ParentActivity;
_11c[_11d]=_119;
_11d++;
}
if(_11b===false){
_11c.splice(0,1);
}
return _11c;
}
function Sequencer_ActivityHasSuspendedChildren(_11e,_11f){
Debug.AssertError("Parent log not passed.",(_11f===undefined||_11f===null));
var _120=_11e.GetChildren();
var _121=false;
for(var i=0;i<_120.length;i++){
if(_120[i].IsSuspended()){
_121=true;
}
}
if(_121){
this.LogSeq("`1718`"+_11e+"`1511`",_11f);
}else{
this.LogSeq("`1718`"+_11e+"`1319`",_11f);
}
return _121;
}
function Sequencer_CourseIsSingleSco(){
if(this.Activities.ActivityList.length<=2){
return true;
}else{
return false;
}
}
function Sequencer_TranslateSequencingRuleActionIntoSequencingRequest(_123){
switch(_123){
case SEQUENCING_RULE_ACTION_RETRY:
return SEQUENCING_REQUEST_RETRY;
case SEQUENCING_RULE_ACTION_CONTINUE:
return SEQUENCING_REQUEST_CONTINUE;
case SEQUENCING_RULE_ACTION_PREVIOUS:
return SEQUENCING_REQUEST_PREVIOUS;
default:
Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoSequencingRequest - should never have an untranslatable sequencing request. ruleAction="+_123);
return null;
}
}
function Sequencer_TranslateSequencingRuleActionIntoTerminationRequest(_124){
switch(_124){
case SEQUENCING_RULE_ACTION_EXIT_PARENT:
return TERMINATION_REQUEST_EXIT_PARENT;
case SEQUENCING_RULE_ACTION_EXIT_ALL:
return TERMINATION_REQUEST_EXIT_ALL;
default:
Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoTerminationRequest - should never have an untranslatable sequencing request. ruleAction="+_124);
return null;
}
}
function Sequencer_IsActivity1BeforeActivity2(_125,_126,_127){
Debug.AssertError("Parent log not passed.",(_127===undefined||_127===null));
var _128=this.GetOrderedListOfActivities(_127);
for(var i=0;i<_128.length;i++){
if(_128[i]==_125){
this.LogSeq("`1718`"+_125+"`1512`"+_126,_127);
return true;
}
if(_128[i]==_126){
this.LogSeq("`1718`"+_125+"`1534`"+_126,_127);
return false;
}
}
Debug.AssertError("ERROR IN Sequencer_IsActivity1BeforeActivity2");
return null;
}
function Sequencer_GetOrderedListOfActivities(_12a){
Debug.AssertError("Parent log not passed.",(_12a===undefined||_12a===null));
var list;
var root=this.GetRootActivity(_12a);
list=this.PreOrderTraversal(root);
return list;
}
function Sequencer_PreOrderTraversal(_12d){
var list=new Array();
list[0]=_12d;
var _12f=_12d.GetAvailableChildren();
var _130;
for(var i=0;i<_12f.length;i++){
_130=this.PreOrderTraversal(_12f[i]);
list=list.concat(_130);
}
return list;
}
function Sequencer_IsActivityLastOverall(_132,_133){
Debug.AssertError("Parent log not passed.",(_133===undefined||_133===null));
var _134=this.GetOrderedListOfActivities(_133);
var _135=null;
for(var i=(_134.length-1);i>=0;i--){
if(_134[i].IsAvailable()){
_135=_134[i];
i=-1;
}
}
if(_132==_135){
this.LogSeq("`1718`"+_132+"`1409`",_133);
return true;
}
this.LogSeq("`1718`"+_132+"`1345`",_133);
return false;
}
function Sequencer_GetGlobalObjectiveByIdentifier(_137){
for(var obj in this.GlobalObjectives){
if(this.GlobalObjectives[obj].ID==_137){
return this.GlobalObjectives[obj];
}
}
return null;
}
function Sequencer_AddGlobalObjective(ID,_13a,_13b,_13c,_13d){
var _13e=this.GlobalObjectives.length;
var obj=new GlobalObjective(_13e,ID,_13a,_13b,_13c,_13d);
this.GlobalObjectives[_13e]=obj;
this.GlobalObjectives[_13e].SetDirtyData();
}
function Sequencer_ResetGlobalObjectives(){
var _140;
for(var obj in this.GlobalObjectives){
_140=this.GlobalObjectives[obj];
_140.ResetState();
}
}
function Sequencer_FindActivitiesAffectedByWriteMaps(_142){
var _143=new Array();
var _144;
var _145=_142.GetObjectives();
var _146=new Array();
var i;
var j;
for(i=0;i<_145.length;i++){
_144=_145[i].GetMaps();
for(j=0;j<_144.length;j++){
if(_144[j].WriteSatisfiedStatus===true||_144[j].WriteNormalizedMeasure===true){
_143[_143.length]=_144[j].TargetObjectiveId;
}
}
}
if(_143.length===0){
return _146;
}
var _149;
var _14a;
var _14b;
var _14c;
for(var _14d in this.Activities.ActivityList){
_149=this.Activities.ActivityList[_14d];
if(_149!=_142){
_14a=_149.GetObjectives();
for(var _14e=0;_14e<_14a.length;_14e++){
_14b=_14a[_14e].GetMaps();
for(var map=0;map<_14b.length;map++){
if(_14b[map].ReadSatisfiedStatus===true||_14b[map].ReadNormalizedMeasure===true){
_14c=_14b[map].TargetObjectiveId;
for(var _150=0;_150<_143.length;_150++){
if(_143[_150]==_14c){
_146[_146.length]=_149;
}
}
}
}
}
}
}
return _146;
}
function Sequencer_FindDistinctAncestorsOfActivitySet(_151){
var _152=new Array();
for(var _153=0;_153<_151.length;_153++){
var _154=_151[_153];
if(_154!==null){
var _155=this.GetActivityPath(_154,true);
for(var i=0;i<_155.length;i++){
var _157=true;
for(var j=0;j<_152.length;j++){
if(_155[i]==_152[j]){
_157=false;
break;
}
}
if(_157){
_152[_152.length]=_155[i];
}
}
}
}
return _152;
}
function Sequencer_FindDistinctParentsOfActivitySet(_159){
var _15a=new Array();
var _15b;
var _15c;
for(var _15d in _159){
_15c=true;
_15b=this.Activities.GetParentActivity(_159[_15d]);
if(_15b!==null){
for(var i=0;i<_15a.length;i++){
if(_15a[i]==_15b){
_15c=false;
break;
}
}
if(_15c){
_15a[_15a.length]=_15b;
}
}
}
return _15a;
}
function Sequencer_GetMinimalSubsetOfActivitiesToRollup(_15f,_160){
var _161=new Array();
var _162=new Array();
var _163;
var _164;
var _165;
if(_160!==null){
_161=_161.concat(_160);
}
for(var _166 in _15f){
_164=_15f[_166];
_165=false;
for(var _167 in _161){
if(_161[_167]==_164){
_165=true;
break;
}
}
if(_165===false){
_162[_162.length]=_164;
_163=this.GetActivityPath(_164,true);
_161=_161.concat(_163);
}
}
return _162;
}
function Sequencer_EvaluatePossibleNavigationRequests(_168){
var _169=this.LogSeqAudit("`985`");
var _16a;
var _16b=null;
var _16c;
var _16d;
var id;
for(id in _168){
if(_168[id].WillAlwaysSucceed===true){
_168[id].WillSucceed=true;
}else{
if(_168[id].WillNeverSucceed===true){
_168[id].WillSucceed=false;
_168[id].Exception="NB.2.1-10";
_168[id].ExceptionText=IntegrationImplementation.GetString("Your selection is not permitted. Please select 'Next' or 'Previous' to move through '{0}.'");
}else{
_168[id].WillSucceed=null;
}
}
_168[id].Hidden=false;
_168[id].Disabled=false;
}
this.LogSeq("`788`",_169);
for(id in _168){
if(_168[id].WillSucceed===null){
_16a=this.NavigationRequestProcess(_168[id].NavigationRequest,_168[id].TargetActivityItemIdentifier,_169);
if(_16a.NavigationRequest==NAVIGATION_REQUEST_NOT_VALID){
this.LogSeq("`755`",_169);
_168[id].WillSucceed=false;
_168[id].TargetActivity=this.GetActivityFromIdentifier(_168[id].TargetActivityItemIdentifier,_169);
_168[id].Exception=_16a.Exception;
_168[id].ExceptionText=_16a.ExceptionText;
}else{
this.LogSeq("`723`",_169);
_168[id].WillSucceed=true;
_168[id].TargetActivity=_16a.TargetActivity;
_168[id].SequencingRequest=_16a.SequencingRequest;
_168[id].Exception="";
_168[id].ExceptionText="";
}
}
}
this.LogSeq("`215`",_169);
var _16f=this.GetCurrentActivity();
if(_16f!==null&&_16f.IsActive()===true){
this.LogSeq("`955`",_169);
_16b=this.TerminationRequestProcess(TERMINATION_REQUEST_EXIT,_169);
this.LogSeq("`912`",_169);
if(_16b.TerminationRequest==TERMINATION_REQUEST_NOT_VALID){
this.LogSeq("`717`",_169);
if(_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed){
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed=false;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception=_16b.Exception;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText=_16b.ExceptionText;
}
if(_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed){
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed=false;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].Exception=_16b.Exception;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].ExceptionText=_16b.ExceptionText;
}
if(_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed){
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed=false;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].Exception=_16b.Exception;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].ExceptionText=_16b.ExceptionText;
}
for(id=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;id<_168.length;id++){
if(_168[id].WillSucceed){
_168[id].WillSucceed=false;
_168[id].Exception=_16b.Exception;
_168[id].ExceptionText=terminatonRequestResult.ExceptionText;
}else{
_168[id].TerminationSequencingRequest=_16b.SequencingRequest;
}
}
}
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].TerminationSequencingRequest=_16b.SequencingRequest;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].TerminationSequencingRequest=_16b.SequencingRequest;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].TerminationSequencingRequest=_16b.SequencingRequest;
for(id=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE;id<_168.length;id++){
_168[id].TerminationSequencingRequest=_16b.SequencingRequest;
}
}
this.LogSeq("`659`",_169);
for(id in _168){
if(id>=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE&&_168[id].WillSucceed===true&&_168[id].WillAlwaysSucceed===false&&_168[id].WillNeverSucceed===false){
this.LogSeq("`866`",_169);
var _170=this.CheckActivityProcess(_168[id].TargetActivity,_169);
if(_170===true){
this.LogSeq("`745`",_169);
_168[id].WillSucceed=false;
_168[id].Disabled=true;
this.SetAllDescendentsToDisabled(_168,_168[id].TargetActivity);
}
}
}
this.LogSeq("`677`",_169);
var _171=null;
for(id in _168){
if(_168[id].WillSucceed===true&&_168[id].WillAlwaysSucceed===false&&_168[id].WillNeverSucceed===false){
this.LogSeq("`624`",_169);
if(_168[id].TerminationSequencingRequest!==null){
this.LogSeq("`418`",_169);
if(_171===null){
_16c=this.SequencingRequestProcess(_168[id].TerminationSequencingRequest,null,_169);
}else{
_16c=_171;
}
if(id>=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE){
this.LogSeq("`1036`",_169);
var _172=this.SequencingRulesCheckProcess(_168[id].TargetActivity,RULE_SET_HIDE_FROM_CHOICE,_169);
if(_172!==null){
_168[id].Exception="SB.2.9-3";
_168[id].ExceptionText="The activity "+_168[id].TargetActivity.GetTitle()+" should be hidden and is not a valid selection";
_168[id].Hidden=true;
}
}
}else{
this.LogSeq("`1639`",_169);
this.LogSeq("`718`",_169);
_16c=this.SequencingRequestProcess(_168[id].SequencingRequest,_168[id].TargetActivity,_169);
}
this.LogSeq("`837`",_169);
if(_16c.Exception!==null){
this.LogSeq("`1288`",_169);
_168[id].WillSucceed=false;
_168[id].Exception=_16c.Exception;
_168[id].ExceptionText=_16c.ExceptionText;
_168[id].Hidden=_16c.Hidden;
}else{
if(_16c.DeliveryRequest!==null){
this.LogSeq("`1117`",_169);
_16d=this.DeliveryRequestProcess(_16c.DeliveryRequest,_169);
this.LogSeq("`705`"+_16d.Valid+")",_169);
_168[id].WillSucceed=_16d.Valid;
}
}
}
}
this.LogSeq("`362`",_169);
var _173;
for(id in _168){
if(id>=POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE){
if(_168[id].WillSucceed===false){
_173=_168[id].Exception;
if(_173==CONTROL_CHOICE_EXIT_ERROR_NAV||_173==CONTROL_CHOICE_EXIT_ERROR_CHOICE||_173==PREVENT_ACTIVATION_ERROR||_173==CONSTRAINED_CHOICE_ERROR){
this.LogSeq("`1488`"+id+"`1721`"+_173,_169);
_168[id].Hidden=true;
}
}
}
}
var _174=this.Activities.GetParentActivity(_16f);
if(_174!=null){
if(_174.GetSequencingControlFlow()===true){
this.LogSeq("`430`",_169);
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed=true;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception="";
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText="";
}else{
this.LogSeq("`405`",_169);
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed=false;
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception="SB.2.2-1";
_168[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText="Parent activity does not allow flow traversal";
}
}
this.LogSeqReturn("",_169);
return _168;
}
function Sequencer_SetAllDescendentsToDisabled(_175,_176){
for(var i=0;i<_176.ChildActivities.length;i++){
var _178=Control.FindPossibleChoiceRequestForActivity(_176.ChildActivities[i]);
_178.WillSucceed=false;
_178.Disabled=true;
this.SetAllDescendentsToDisabled(_175,_176.ChildActivities[i]);
}
}
function Sequencer_InitializePossibleNavigationRequestAbsolutes(_179,_17a,_17b){
var _17c=this.LogSeqAudit("`1019`");
this.CheckForRelevantSequencingRules(_17a,false);
var _17d;
var _17e;
var _17f=false;
for(var _180 in _17b){
_17d=_17b[_180];
var _181=this.LogSeqAudit(_17d.StringIdentifier,_17c);
if(_17d.GetSequencingControlChoice()===false){
this.LogSeqAudit("`1312`",_181);
var _182=this.LogSeqAudit("`834`"+_17d.ChildActivities.length+")",_181);
for(var i=0;i<_17d.ChildActivities.length;i++){
_17e=Control.FindPossibleChoiceRequestForActivity(_17d.ChildActivities[i]);
_17e.WillNeverSucceed=true;
this.LogSeqAudit(_17d.ChildActivities[i].StringIdentifier,_182);
}
}
_17f=_17f||(_17d.GetSequencingControlChoiceExit()===true);
this.LogSeqAudit("`1494`"+_17f,_181);
_17e=Control.FindPossibleChoiceRequestForActivity(_17d);
if(_17d.IsDeliverable()===false&&_17d.GetSequencingControlFlow()===false){
this.LogSeqAudit("`356`",_181);
_17e.WillNeverSucceed=true;
}
if(_17d.HasChildActivitiesDeliverableViaFlow===false){
this.LogSeqAudit("`505`",_181);
_17e.WillNeverSucceed=true;
}
if(_17d.HasSeqRulesRelevantToChoice===false&&_17e.WillNeverSucceed===false){
this.LogSeqAudit("`275`",_181);
_17e.WillAlwaysSucceed=true;
}else{
this.LogSeqAudit("`246`",_181);
_17e.WillAlwaysSucceed=false;
}
this.LogSeqAudit("`1597`"+_17e.WillAlwaysSucceed,_181);
this.LogSeqAudit("`1610`"+_17e.WillNeverSucceed,_181);
}
if(_17f===true){
this.LogSeqAudit("`549`",_17c);
for(var id in _179){
_179[id].WillAlwaysSucceed=false;
}
}
}
function Sequencer_CheckForRelevantSequencingRules(_185,_186){
if(_186===true){
_185.HasSeqRulesRelevantToChoice=true;
}else{
if(this.DoesThisActivityHaveSequencingRulesRelevantToChoice(_185)){
_185.HasSeqRulesRelevantToChoice=true;
}else{
_185.HasSeqRulesRelevantToChoice=false;
}
}
var _187=false;
for(var i=0;i<_185.ChildActivities.length;i++){
this.CheckForRelevantSequencingRules(_185.ChildActivities[i],_185.HasSeqRulesRelevantToChoice);
_187=(_187||_185.ChildActivities[i].HasChildActivitiesDeliverableViaFlow);
}
_185.HasChildActivitiesDeliverableViaFlow=(_185.IsDeliverable()||(_185.GetSequencingControlFlow()&&_187));
}
function Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice(_189){
if(_189.GetSequencingControlForwardOnly()===true){
return true;
}
if(_189.GetPreventActivation()===true){
return true;
}
if(_189.GetConstrainedChoice()===true){
return true;
}
if(_189.GetSequencingControlChoiceExit()===false){
return true;
}
var _18a=_189.GetPreConditionRules();
for(var i=0;i<_18a.length;i++){
if(_18a[i].Action==SEQUENCING_RULE_ACTION_DISABLED||_18a[i].Action==SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE||_18a[i].Action==SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL){
return true;
}
}
return false;
}
function Sequencer_ActivityProgressRollupProcess(_18c,_18d){
Debug.AssertError("Calling log not passed.",(_18d===undefined||_18d===null));
var _18e=this.LogSeqAudit("`1170`"+_18c+")",_18d);
var _18f;
this.LogSeq("`336`",_18e);
_18f=this.RollupRuleCheckSubprocess(_18c,RULE_SET_INCOMPLETE,_18e);
this.LogSeq("`849`",_18e);
if(_18f===true){
this.LogSeq("`806`",_18e);
_18c.SetAttemptProgressStatus(true);
this.LogSeq("`770`",_18e);
_18c.SetAttemptCompletionStatus(false);
}
this.LogSeq("`350`",_18e);
_18f=this.RollupRuleCheckSubprocess(_18c,RULE_SET_COMPLETED,_18e);
this.LogSeq("`851`",_18e);
if(_18f===true){
this.LogSeq("`807`",_18e);
_18c.SetAttemptProgressStatus(true);
this.LogSeq("`780`",_18e);
_18c.SetAttemptCompletionStatus(true);
}
if(Sequencer_GetApplicableSetofRollupRules(_18c,RULE_SET_INCOMPLETE).length===0&&Sequencer_GetApplicableSetofRollupRules(_18c,RULE_SET_COMPLETED).length===0){
this.LogSeq("`1167`",_18e);
this.ActivityProgressRollupProcessUsingDefault(_18c,_18e);
}
this.LogSeq("`1063`",_18e);
this.LogSeqReturn("",_18e);
return;
}
function Sequencer_ActivityProgressRollupProcessUsingDefault(_190,_191){
var _192=this.LogSeqAudit("`907`"+_190+")",_191);
var _193;
var _194;
var _195;
this.LogSeq("`1273`",_192);
if(_190.IsALeaf()){
this.LogSeq("`1290`",_192);
this.LogSeqReturn("",_192);
return;
}
this.LogSeq("`1087`",_192);
var _196=_190.GetChildren();
this.LogSeq("`1100`",_192);
var _197=true;
this.LogSeq("`1218`",_192);
var _198=true;
this.LogSeq("`1274`",_192);
var _199=true;
for(var i=0;i<_196.length;i++){
this.LogSeq("`1357`"+_196[i]+"`1720`",_192);
if(_196[i].IsTracked()){
this.LogSeq("`1046`",_192);
_193=_196[i].IsCompleted();
this.LogSeq("`1047`",_192);
_194=_196[i].IsAttempted();
this.LogSeq("`769`",_192);
_195=(_193===false||_194===true);
this.LogSeq("`881`",_192);
if(this.CheckChildForRollupSubprocess(_196[i],ROLLUP_RULE_ACTION_COMPLETED,_192)){
this.LogSeq("`882`",_192);
_198=(_198&&(_193===true));
_199=false;
}
this.LogSeq("`874`",_192);
if(this.CheckChildForRollupSubprocess(_196[i],ROLLUP_RULE_ACTION_INCOMPLETE,_192)){
this.LogSeq("`847`",_192);
_197=(_197&&_195);
_199=false;
}
}
}
if(_199&&Control.Package.Properties.RollupEmptySetToUnknown){
this.LogSeq("`542`"+Control.Package.Properties.RollupEmptySetToUnknown+")",_192);
}else{
this.LogSeq("`1406`",_192);
if(_197===true){
this.LogSeq("`778`",_192);
_190.SetAttemptProgressStatus(true);
this.LogSeq("`746`",_192);
_190.SetAttemptCompletionStatus(false);
}
this.LogSeq("`1427`",_192);
if(_198===true){
this.LogSeq("`779`",_192);
_190.SetAttemptProgressStatus(true);
this.LogSeq("`758`",_192);
_190.SetAttemptCompletionStatus(true);
}
}
this.LogSeqReturn("",_192);
}
function Sequencer_CheckActivityProcess(_19b,_19c){
Debug.AssertError("Calling log not passed.",(_19c===undefined||_19c===null));
var _19d=this.LogSeqAudit("`1392`"+_19b+")",_19c);
this.LogSeq("`313`",_19d);
var _19e=this.SequencingRulesCheckProcess(_19b,RULE_SET_DISABLED,_19d);
this.LogSeq("`783`",_19d);
if(_19e!==null){
this.LogSeq("`721`",_19d);
this.LogSeqReturn("`1749`",_19d);
return true;
}
this.LogSeq("`396`",_19d);
var _19f=this.LimitConditionsCheckProcess(_19b,_19d);
this.LogSeq("`864`",_19d);
if(_19f){
this.LogSeq("`614`",_19d);
this.LogSeqReturn("`1749`",_19d);
return true;
}
this.LogSeq("`752`",_19d);
this.LogSeqReturn("`1745`",_19d);
return false;
}
function Sequencer_CheckChildForRollupSubprocess(_1a0,_1a1,_1a2){
Debug.AssertError("Calling log not passed.",(_1a2===undefined||_1a2===null));
var _1a3=this.LogSeqAudit("`1108`"+_1a0+", "+_1a1+")",_1a2);
var _1a4;
this.LogSeq("`1342`",_1a3);
var _1a5=false;
this.LogSeq("`814`",_1a3);
if(_1a1==ROLLUP_RULE_ACTION_SATISFIED||_1a1==ROLLUP_RULE_ACTION_NOT_SATISFIED){
this.LogSeq("`406`",_1a3);
if(_1a0.GetRollupObjectiveSatisfied()===true){
this.LogSeq("`591`",_1a3);
_1a5=true;
var _1a6=_1a0.GetRequiredForSatisfied();
var _1a7=_1a0.GetRequiredForNotSatisfied();
this.LogSeq("`97`",_1a3);
if((_1a1==ROLLUP_RULE_ACTION_SATISFIED&&_1a6==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)||(_1a1==ROLLUP_RULE_ACTION_NOT_SATISFIED&&_1a7==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)){
this.LogSeq("`278`",_1a3);
if(_1a0.GetAttemptCount()>0&&_1a0.IsSuspended()===true){
this.LogSeq("`1194`",_1a3);
_1a5=false;
}
}else{
this.LogSeq("`1583`",_1a3);
this.LogSeq("`104`",_1a3);
if((_1a1==ROLLUP_RULE_ACTION_SATISFIED&&_1a6==ROLLUP_CONSIDERATION_IF_ATTEMPTED)||(_1a1==ROLLUP_RULE_ACTION_NOT_SATISFIED&&_1a7==ROLLUP_CONSIDERATION_IF_ATTEMPTED)){
this.LogSeq("`679`",_1a3);
if(_1a0.GetAttemptCount()===0){
this.LogSeq("`1137`",_1a3);
_1a5=false;
}
}else{
this.LogSeq("`1551`",_1a3);
this.LogSeq("`98`",_1a3);
if((_1a1==ROLLUP_RULE_ACTION_SATISFIED&&_1a6==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)||(_1a1==ROLLUP_RULE_ACTION_NOT_SATISFIED&&_1a7==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)){
this.LogSeq("`467`",_1a3);
_1a4=this.SequencingRulesCheckProcess(_1a0,RULE_SET_SKIPPED,_1a3);
this.LogSeq("`633`",_1a3);
if(_1a4!==null){
this.LogSeq("`1102`",_1a3);
_1a5=false;
}
}
}
}
}
}
this.LogSeq("`852`",_1a3);
if(_1a1==ROLLUP_RULE_ACTION_COMPLETED||_1a1==ROLLUP_RULE_ACTION_INCOMPLETE){
this.LogSeq("`419`",_1a3);
if(_1a0.RollupProgressCompletion()===true){
this.LogSeq("`592`",_1a3);
_1a5=true;
var _1a8=_1a0.GetRequiredForCompleted();
var _1a9=_1a0.GetRequiredForIncomplete();
this.LogSeq("`106`",_1a3);
if((_1a1==ROLLUP_RULE_ACTION_COMPLETED&&_1a8==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)||(_1a1==ROLLUP_RULE_ACTION_INCOMPLETE&&_1a9==ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)){
this.LogSeq("`279`",_1a3);
if(_1a0.GetAttemptCount()>0&&_1a0.IsSuspended()===true){
this.LogSeq("`1375`",_1a3);
_1a5=false;
}
}else{
this.LogSeq("`1584`",_1a3);
this.LogSeq("`117`",_1a3);
if((_1a1==ROLLUP_RULE_ACTION_COMPLETED&&_1a8==ROLLUP_CONSIDERATION_IF_ATTEMPTED)||(_1a1==ROLLUP_RULE_ACTION_INCOMPLETE&&_1a9==ROLLUP_CONSIDERATION_IF_ATTEMPTED)){
this.LogSeq("`680`",_1a3);
if(_1a0.GetAttemptCount()===0){
this.LogSeq("`1138`",_1a3);
_1a5=false;
}
}else{
this.LogSeq("`1552`",_1a3);
this.LogSeq("`107`",_1a3);
if((_1a1==ROLLUP_RULE_ACTION_COMPLETED&&_1a8==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)||(_1a1==ROLLUP_RULE_ACTION_INCOMPLETE&&_1a9==ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)){
this.LogSeq("`468`",_1a3);
_1a4=this.SequencingRulesCheckProcess(_1a0,RULE_SET_SKIPPED,_1a3);
this.LogSeq("`634`",_1a3);
if(_1a4!==null){
this.LogSeq("`1103`",_1a3);
_1a5=false;
}
}
}
}
}
}
this.LogSeq("`602`",_1a3);
this.LogSeqReturn(_1a5,_1a3);
return _1a5;
}
function Sequencer_ChoiceActivityTraversalSubprocess(_1aa,_1ab,_1ac){
Debug.AssertError("Calling log not passed.",(_1ac===undefined||_1ac===null));
var _1ad=this.LogSeqAudit("`1095`"+_1aa+", "+_1ab+")",_1ac);
var _1ae=null;
var _1af=null;
var _1b0;
this.LogSeq("`981`",_1ad);
if(_1ab==FLOW_DIRECTION_FORWARD){
this.LogSeq("`445`",_1ad);
_1ae=this.SequencingRulesCheckProcess(_1aa,RULE_SET_STOP_FORWARD_TRAVERSAL,_1ad);
this.LogSeq("`731`",_1ad);
if(_1ae!==null){
this.LogSeq("`558`",_1ad);
_1b0=new Sequencer_ChoiceActivityTraversalSubprocessResult(false,"SB.2.4-1",IntegrationImplementation.GetString("You are not allowed to move into {0} yet.",_1aa.GetTitle()));
this.LogSeqReturn(_1b0,_1ad);
return _1b0;
}
this.LogSeq("`611`",_1ad);
_1b0=new Sequencer_ChoiceActivityTraversalSubprocessResult(true,null);
this.LogSeqReturn(_1b0,_1ad);
return _1b0;
}
this.LogSeq("`972`",_1ad);
if(_1ab==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`1105`",_1ad);
if(!_1aa.IsTheRoot()){
_1af=this.Activities.GetParentActivity(_1aa);
this.LogSeq("`584`",_1ad);
if(_1af.GetSequencingControlForwardOnly()){
this.LogSeq("`548`",_1ad);
_1b0=new Sequencer_ChoiceActivityTraversalSubprocessResult(false,"SB.2.4-2",IntegrationImplementation.GetString("You must start {0} at the beginning.",_1af.GetTitle()));
this.LogSeqReturn(_1b0,_1ad);
return _1b0;
}
}else{
this.LogSeq("`1626`",_1ad);
this.LogSeq("`237`",_1ad);
_1b0=new Sequencer_ChoiceActivityTraversalSubprocessResult(false,"SB.2.4-3",IntegrationImplementation.GetString("You have reached the beginning of the course."));
this.LogSeqReturn(_1b0,_1ad);
return _1b0;
}
this.LogSeq("`612`",_1ad);
_1b0=new Sequencer_ChoiceActivityTraversalSubprocessResult(true,null);
this.LogSeqReturn(_1b0,_1ad);
return _1b0;
}
}
function Sequencer_ChoiceActivityTraversalSubprocessResult(_1b1,_1b2,_1b3){
this.Reachable=_1b1;
this.Exception=_1b2;
this.ExceptionText=_1b3;
}
Sequencer_ChoiceActivityTraversalSubprocessResult.prototype.toString=function(){
return "Reachable="+this.Reachable+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_ChoiceFlowSubprocess(_1b4,_1b5,_1b6){
Debug.AssertError("Calling log not passed.",(_1b6===undefined||_1b6===null));
var _1b7=this.LogSeqAudit("`1320`"+_1b4+", "+_1b5+")",_1b6);
this.LogSeq("`128`",_1b7);
var _1b8=this.ChoiceFlowTreeTraversalSubprocess(_1b4,_1b5,_1b7);
this.LogSeq("`732`",_1b7);
if(_1b8===null){
this.LogSeq("`710`",_1b7);
this.LogSeqReturn(_1b4,_1b7);
return _1b4;
}else{
this.LogSeq("`1678`",_1b7);
this.LogSeq("`338`",_1b7);
this.LogSeqReturn(_1b8,_1b7);
return _1b8;
}
}
function Sequencer_ChoiceFlowTreeTraversalSubprocess(_1b9,_1ba,_1bb){
Debug.AssertError("Calling log not passed.",(_1bb===undefined||_1bb===null));
var _1bc=this.LogSeqAudit("`1031`"+_1b9+", "+_1ba+")",_1bb);
var _1bd=this.Activities.GetParentActivity(_1b9);
var _1be=null;
var _1bf=null;
var _1c0=null;
this.LogSeq("`961`",_1bc);
if(_1ba==FLOW_DIRECTION_FORWARD){
this.LogSeq("`74`",_1bc);
if(this.IsActivityLastOverall(_1b9,_1bc)||_1b9.IsTheRoot()===true){
this.LogSeq("`683`",_1bc);
this.LogSeqReturn("`1748`",_1bc);
return null;
}
this.LogSeq("`479`",_1bc);
if(_1bd.IsActivityTheLastAvailableChild(_1b9)){
this.LogSeq("`137`",_1bc);
_1be=this.ChoiceFlowTreeTraversalSubprocess(_1bd,FLOW_DIRECTION_FORWARD,_1bc);
this.LogSeq("`143`",_1bc);
this.LogSeqReturn(_1be,_1bc);
return _1be;
}else{
this.LogSeq("`1627`",_1bc);
this.LogSeq("`301`",_1bc);
_1bf=_1b9.GetNextSibling();
this.LogSeq("`446`",_1bc);
this.LogSeqReturn(_1bf,_1bc);
return _1bf;
}
}
this.LogSeq("`952`",_1bc);
if(_1ba==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`456`",_1bc);
if(_1b9.IsTheRoot()){
this.LogSeq("`684`",_1bc);
this.LogSeqReturn("`1748`",_1bc);
return null;
}
this.LogSeq("`472`",_1bc);
if(_1bd.IsActivityTheFirstAvailableChild(_1b9)){
this.LogSeq("`135`",_1bc);
_1be=this.ChoiceFlowTreeTraversalSubprocess(_1bd,FLOW_DIRECTION_BACKWARD,_1bc);
this.LogSeq("`138`",_1bc);
this.LogSeqReturn(_1be,_1bc);
return _1be;
}else{
this.LogSeq("`1628`",_1bc);
this.LogSeq("`268`",_1bc);
_1c0=_1b9.GetPreviousSibling();
this.LogSeq("`447`",_1bc);
this.LogSeqReturn(_1c0,_1bc);
return _1c0;
}
}
}
function Sequencer_ChoiceSequencingRequestProcess(_1c1,_1c2){
Debug.AssertError("Calling log not passed.",(_1c2===undefined||_1c2===null));
var _1c3=this.LogSeqAudit("`1153`"+_1c1+")",_1c2);
var _1c4=null;
var _1c5;
var _1c6=null;
var _1c7=null;
var _1c8=null;
var _1c9=null;
var _1ca;
var i;
var _1cc;
this.LogSeq("`502`"+_1c1.LearningObject.ItemIdentifier,_1c3);
if(_1c1===null){
this.LogSeq("`448`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-1",IntegrationImplementation.GetString("Your selection is not permitted.  Please select an available menu item to continue."),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
this.LogSeq("`333`",_1c3);
_1c5=this.GetActivityPath(_1c1,true);
this.LogSeq("`1029`",_1c3);
for(i=(_1c5.length-1);i>=0;i--){
this.LogSeq("`794`",_1c3);
if(_1c5[i].IsTheRoot()==false){
this.LogSeq("`262`",_1c3);
if(_1c5[i].IsAvailable===false){
this.LogSeq("`395`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-2","The activity "+_1c1.GetTitle()+" should not be available and is not a valid selection",true);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`247`",_1c3);
_1c6=this.SequencingRulesCheckProcess(_1c5[i],RULE_SET_HIDE_FROM_CHOICE,_1c3);
this.LogSeq("`736`",_1c3);
if(_1c6!==null){
this.LogSeq("`220`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-3","The activity "+_1c1.GetTitle()+" should be hidden and is not a valid selection",true);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`749`",_1c3);
if(!_1c1.IsTheRoot()){
this.LogSeq("`221`",_1c3);
_1c4=this.Activities.GetParentActivity(_1c1);
if(_1c4.GetSequencingControlChoice()===false){
this.LogSeq("`424`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-4",IntegrationImplementation.GetString("The activity '{0}' should be hidden and is not a valid selection.",_1c4.GetTitle()),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`579`",_1c3);
if(this.IsCurrentActivityDefined(_1c3)){
this.LogSeq("`637`",_1c3);
_1c8=this.GetCurrentActivity();
_1c7=this.FindCommonAncestor(_1c8,_1c1,_1c3);
}else{
this.LogSeq("`1707`",_1c3);
this.LogSeq("`373`",_1c3);
_1c7=this.GetRootActivity(_1c3);
}
if(_1c8!==null&&_1c8.LearningObject.ItemIdentifier==_1c1.LearningObject.ItemIdentifier){
this.LogSeq("`503`",_1c3);
this.LogSeq("`938`",_1c3);
}else{
if(this.AreActivitiesSiblings(_1c8,_1c1,_1c3)){
this.LogSeq("`363`",_1c3);
this.LogSeq("`10`",_1c3);
var _1cd=_1c4.GetActivityListBetweenChildren(_1c8,_1c1,false);
this.LogSeq("`830`",_1c3);
if(_1cd.length===0){
this.LogSeq("`427`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to open"),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
this.LogSeq("`449`",_1c3);
if(_1c1.Ordinal>_1c8.Ordinal){
this.LogSeq("`1343`",_1c3);
_1c9=FLOW_DIRECTION_FORWARD;
}else{
this.LogSeq("`1679`",_1c3);
this.LogSeq("`1317`",_1c3);
_1c9=FLOW_DIRECTION_BACKWARD;
_1cd.reverse();
}
this.LogSeq("`1005`",_1c3);
for(i=0;i<_1cd.length;i++){
this.LogSeq("`518`",_1c3);
_1ca=this.ChoiceActivityTraversalSubprocess(_1cd[i],_1c9,_1c3);
this.LogSeq("`711`",_1c3);
if(_1ca.Reachable===false){
this.LogSeq("`140`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,_1ca.Exception,"",false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`1449`",_1c3);
}else{
if(_1c8===null||_1c8.LearningObject.ItemIdentifier==_1c7.LearningObject.ItemIdentifier){
this.LogSeq("`213`",_1c3);
this.LogSeq("`248`",_1c3);
_1c5=this.GetPathToAncestorInclusive(_1c1,_1c7);
this.LogSeq("`1089`",_1c3);
if(_1c5.length===0){
this.LogSeq("`428`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to open"),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
this.LogSeq("`1006`",_1c3);
for(i=_1c5.length-1;i>=0;i--){
this.LogSeq("`525`",_1c3);
_1ca=this.ChoiceActivityTraversalSubprocess(_1c5[i],FLOW_DIRECTION_FORWARD,_1c3);
this.LogSeq("`712`",_1c3);
if(_1ca.Reachable===false){
this.LogSeq("`141`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,_1ca.Exception,_1ca.ExceptionText,false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
this.LogSeq("`19`",_1c3);
if(_1c5[i].IsActive()===false&&_1c5[i].LearningObject.ItemIdentifier!=_1c7.LearningObject.ItemIdentifier&&_1c5[i].GetPreventActivation()===true){
this.LogSeq("`603`"+PREVENT_ACTIVATION_ERROR+"`1554`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,PREVENT_ACTIVATION_ERROR,IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1c5[i].GetTitle()),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`1450`",_1c3);
}else{
if(_1c1.LearningObject.ItemIdentifier==_1c7.LearningObject.ItemIdentifier){
this.LogSeq("`287`",_1c3);
this.LogSeq("`344`",_1c3);
_1c5=this.GetPathToAncestorInclusive(_1c8,_1c7);
this.LogSeq("`1066`",_1c3);
if(_1c5.length===0){
this.LogSeq("`410`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to deliver"),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
this.LogSeq("`990`",_1c3);
for(i=0;i<_1c5.length;i++){
this.LogSeq("`662`",_1c3);
if(i!=(_1c5.length-1)){
this.LogSeq("`196`",_1c3);
if(_1c5[i].GetSequencingControlChoiceExit()===false){
this.LogSeq("`573`"+CONTROL_CHOICE_EXIT_ERROR_CHOICE+"`1554`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,CONTROL_CHOICE_EXIT_ERROR_CHOICE,IntegrationImplementation.GetString("Your selection is not permitted.  Please select 'Next' or 'Previous' to move through '{0}'.",_1c5[i]),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
}
this.LogSeq("`1428`",_1c3);
}else{
this.LogSeq("`289`",_1c3);
this.LogSeq("`345`",_1c3);
_1c5=this.GetPathToAncestorExclusive(_1c8,_1c7,false);
this.LogSeq("`1003`",_1c3);
var _1ce=null;
this.LogSeq("`574`",_1c3);
for(i=0;i<_1c5.length;i++){
this.LogSeq("`664`",_1c3);
if(i!=(_1c5.length-1)){
this.LogSeq("`198`",_1c3);
if(_1c5[i].GetSequencingControlChoiceExit()===false){
this.LogSeq("`575`"+CONTROL_CHOICE_EXIT_ERROR_CHOICE+"`1554`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,CONTROL_CHOICE_EXIT_ERROR_CHOICE,IntegrationImplementation.GetString("You are not allowed to jump out of {0}.",_1c5[i].GetTitle()),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`402`",_1c3);
if(_1ce===null){
this.LogSeq("`733`",_1c3);
if(_1c5[i].GetConstrainedChoice()===true){
this.LogSeq("`925`"+_1c5[i]+"'",_1c3);
_1ce=_1c5[i];
}
}
}
this.LogSeq("`982`",_1c3);
if(_1ce!==null){
this.LogSeq("`469`",_1c3);
if(this.IsActivity1BeforeActivity2(_1ce,_1c1,_1c3)){
this.LogSeq("`529`",_1c3);
_1c9=FLOW_DIRECTION_FORWARD;
}else{
this.LogSeq("`1600`",_1c3);
this.LogSeq("`516`",_1c3);
_1c9=FLOW_DIRECTION_BACKWARD;
}
this.LogSeq("`523`",_1c3);
var _1cf=this.ChoiceFlowSubprocess(_1ce,_1c9,_1c3);
this.LogSeq("`559`",_1c3);
var _1d0=_1cf;
this.LogSeq("`5`",_1c3);
if((!_1d0.IsActivityAnAvailableDescendent(_1c1))&&(_1c1!=_1ce&&_1c1!=_1d0)){
this.LogSeq("`595`"+CONSTRAINED_CHOICE_ERROR+")",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,CONSTRAINED_CHOICE_ERROR,IntegrationImplementation.GetString("You are not allowed to jump out of {0}.",_1ce.GetTitle()),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`243`",_1c3);
_1c5=this.GetPathToAncestorInclusive(_1c1,_1c7);
this.LogSeq("`1068`",_1c3);
if(_1c5.length===0){
this.LogSeq("`412`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-5",IntegrationImplementation.GetString("Nothing to open"),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
this.LogSeq("`305`",_1c3);
if(this.IsActivity1BeforeActivity2(_1c8,_1c1,_1c3)){
this.LogSeq("`974`",_1c3);
for(i=(_1c5.length-1);i>=0;i--){
if(i>0){
this.LogSeq("`234`"+i,_1c3);
_1ca=this.ChoiceActivityTraversalSubprocess(_1c5[i],FLOW_DIRECTION_FORWARD,_1c3);
this.LogSeq("`685`",_1c3);
if(_1ca.Reachable===false){
this.LogSeq("`132`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,_1ca.Exception,_1ca.ExceptionText,false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
this.LogSeq("`15`",_1c3);
if((_1c5[i].IsActive()===false)&&(_1c5[i]!=_1c7)&&(_1c5[i].GetPreventActivation()===true)){
this.LogSeq("`576`"+PREVENT_ACTIVATION_ERROR+"`1554`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,PREVENT_ACTIVATION_ERROR,IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1c5[i].GetTitle()),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
}else{
this.LogSeq("`1653`",_1c3);
this.LogSeq("`975`",_1c3);
for(i=(_1c5.length-1);i>=0;i--){
this.LogSeq("`13`",_1c3);
if((_1c5[i].IsActive()===false)&&(_1c5[i]!=_1c7)&&(_1c5[i].GetPreventActivation()===true)){
this.LogSeq("`577`"+PREVENT_ACTIVATION_ERROR+"`1554`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,PREVENT_ACTIVATION_ERROR,IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_1c5[i].GetTitle()),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
}
this.LogSeq("`1407`",_1c3);
}
}
}
}
this.LogSeq("`926`",_1c3);
if(_1c1.IsALeaf()===true){
this.LogSeq("`492`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(_1c1,null,"",false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
this.LogSeq("`51`",_1c3);
var _1d1=this.FlowSubprocess(_1c1,FLOW_DIRECTION_FORWARD,true,_1c3);
this.LogSeq("`252`",_1c3);
if(_1d1.Deliverable===false){
if(this.LookAhead===false){
this.LogSeq("`646`",_1c3);
this.TerminateDescendentAttemptsProcess(_1c7,_1c3);
this.LogSeq("`839`",_1c3);
this.EndAttemptProcess(_1c7,false,_1c3);
this.LogSeq("`884`",_1c3);
this.SetCurrentActivity(_1c1,_1c3);
}
this.LogSeq("`438`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(null,"SB.2.9-9",IntegrationImplementation.GetString("Please select another item from the menu."),false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}else{
this.LogSeq("`1692`",_1c3);
this.LogSeq("`310`",_1c3);
_1cc=new Sequencer_ChoiceSequencingRequestProcessResult(_1d1.IdentifiedActivity,null,"",false);
this.LogSeqReturn(_1cc,_1c3);
return _1cc;
}
}
function Sequencer_ChoiceSequencingRequestProcessResult(_1d2,_1d3,_1d4,_1d5){
if(_1d5===undefined){
Debug.AssertError("no value passed for hidden");
}
this.DeliveryRequest=_1d2;
this.Exception=_1d3;
this.ExceptionText=_1d4;
this.Hidden=_1d5;
}
Sequencer_ChoiceSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", Hidden="+this.Hidden;
};
function Sequencer_ClearSuspendedActivitySubprocess(_1d6,_1d7){
Debug.AssertError("Calling log not passed.",(_1d7===undefined||_1d7===null));
var _1d8=this.LogSeqAudit("`1109`"+_1d6+")",_1d7);
var _1d9=null;
var _1da=null;
var _1db=null;
this.LogSeq("`604`",_1d8);
if(this.IsSuspendedActivityDefined(_1d8)){
this.LogSeq("`598`",_1d8);
_1da=this.GetSuspendedActivity(_1d8);
_1d9=this.FindCommonAncestor(_1d6,_1da,_1d8);
this.LogSeq("`342`",_1d8);
_1db=this.GetPathToAncestorInclusive(_1da,_1d9);
this.LogSeq("`996`",_1d8);
if(_1db.length>0){
this.LogSeq("`334`",_1d8);
for(var i=0;i<_1db.length;i++){
this.LogSeq("`1075`",_1d8);
if(_1db[i].IsALeaf()){
this.LogSeq("`787`",_1d8);
_1db[i].SetSuspended(false);
}else{
this.LogSeq("`1577`",_1d8);
this.LogSeq("`398`",_1d8);
if(_1db[i].HasSuspendedChildren()===false){
this.LogSeq("`766`",_1d8);
_1db[i].SetSuspended(false);
}
}
}
}
this.LogSeq("`607`",_1d8);
this.ClearSuspendedActivity(_1d8);
}
this.LogSeq("`997`",_1d8);
this.LogSeqReturn("",_1d8);
return;
}
function Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess(_1dd,_1de){
if(_1de===undefined||_1de===null){
_1de=this.LogSeqAudit("Content Delivery Environment Activity Data SubProcess for "+activity.StringIdentifier);
}
var _1df=(Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK||Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
if(_1df){
var _1e0=this.PreviousActivity;
}else{
var _1e0=this.CurrentActivity;
}
var _1e1=this.GetSuspendedActivity(_1de);
var _1e2=this.GetRootActivity(_1de);
var _1e3=null;
var _1e4=false;
this.LogSeq("`208`",_1de);
if(_1e1!=_1dd){
this.LogSeq("`554`",_1de);
this.ClearSuspendedActivitySubprocess(_1dd,_1de);
}
this.LogSeq("`230`",_1de);
this.TerminateDescendentAttemptsProcess(_1dd,_1de);
this.LogSeq("`66`",_1de);
_1e3=this.GetPathToAncestorInclusive(_1dd,_1e2);
this.LogSeq("`1076`",_1de);
var _1e5=ConvertDateToIso8601String(new Date());
for(var i=(_1e3.length-1);i>=0;i--){
this.LogSeq("`1531`"+_1e3[i]+"`1169`",_1de);
if(_1df){
var _1e7=_1e3[i].WasActiveBeforeLaunchOnClick;
}else{
var _1e7=_1e3[i].IsActive();
}
if(_1e7===false){
this.LogSeq("`978`",_1de);
if(_1e3[i].IsTracked()){
this.LogSeq("`114`",_1de);
if(_1e3[i].IsSuspended()){
this.LogSeq("`811`",_1de);
_1e3[i].SetSuspended(false);
}else{
this.LogSeq("`1611`",_1de);
this.LogSeq("`485`",_1de);
_1e3[i].IncrementAttemptCount();
this.LogSeq("`357`",_1de);
if(_1e3[i].GetAttemptCount()==1){
this.LogSeq("`767`",_1de);
_1e3[i].SetActivityProgressStatus(true);
_1e4=true;
}
this.LogSeq("`161`",_1de);
_1e3[i].InitializeForNewAttempt(true,true);
var atts={ev:"AttemptStart",an:_1e3[i].GetAttemptCount(),ai:_1e3[i].ItemIdentifier,at:_1e3[i].LearningObject.Title};
this.WriteHistoryLog("",atts);
_1e3[i].SetAttemptStartTimestampUtc(_1e5);
_1e3[i].SetAttemptAbsoluteDuration("PT0H0M0S");
_1e3[i].SetAttemptExperiencedDurationTracked("PT0H0M0S");
_1e3[i].SetAttemptExperiencedDurationReported("PT0H0M0S");
if(Control.Package.Properties.ResetRunTimeDataTiming==RESET_RT_DATA_TIMING_ON_EACH_NEW_SEQUENCING_ATTEMPT){
if(_1e3[i].IsDeliverable()===true){
if(_1e4===false){
var atts={ev:"ResetRuntime",ai:_1e3[i].ItemIdentifier,at:_1e3[i].LearningObject.Title};
this.WriteHistoryLog("",atts);
}
_1e3[i].RunTime.ResetState();
}
}
this.LogSeq("`797`"+Control.Package.ObjectivesGlobalToSystem+"`941`",_1de);
if(Control.Package.ObjectivesGlobalToSystem===false&&_1e3[i].IsTheRoot()===true){
this.LogSeq("`544`",_1de);
this.ResetGlobalObjectives();
}
}
}
_1e3[i].SetAttemptedDuringThisAttempt();
}
}
}
function Sequencer_ContentDeliveryEnvironmentProcess(_1e9,_1ea){
Debug.AssertError("Calling log not passed.",(_1ea===undefined||_1ea===null));
var _1eb=this.LogSeqAudit("`1125`"+_1e9+")",_1ea);
var _1ec=(Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK||Control.Package.Properties.ScoLaunchType===LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
var _1ed=this.GetCurrentActivity();
var _1ee=this.GetSuspendedActivity(_1eb);
var _1ef=this.GetRootActivity(_1eb);
var _1f0=null;
var _1f1;
this.LogSeq("`200`",_1eb);
if(_1ed!==null&&_1ed.IsActive()){
this.LogSeq("`264`",_1eb);
_1f1=new Sequencer_ContentDeliveryEnvironmentProcessResult(false,"DB.2.1",IntegrationImplementation.GetString("The previous activity must be terminated before a new activity may be attempted"));
this.LogSeqReturn(_1f1,_1eb);
return _1f1;
}
if(!_1ec){
this.ContentDeliveryEnvironmentActivityDataSubProcess(_1e9,_1ea);
}else{
this.LogSeq("`224`",_1eb);
}
this.LogSeq("`66`",_1eb);
_1f0=this.GetPathToAncestorInclusive(_1e9,_1ef);
this.LogSeq("`1076`",_1eb);
for(var i=(_1f0.length-1);i>=0;i--){
if(_1ec){
_1f0[i].WasActiveBeforeLaunchOnClick=_1f0[i].IsActive();
}
this.LogSeq("`1531`"+_1f0[i]+"`1169`",_1eb);
if(_1f0[i].IsActive()===false){
this.LogSeq("`888`",_1eb);
_1f0[i].SetActive(true);
}
}
this.LogSeq("`231`"+_1e9.GetItemIdentifier(),_1eb);
if(_1ec){
this.PreviousActivity=_1ed;
}
this.SetCurrentActivity(_1e9,_1eb);
this.LogSeq("`820`",_1eb);
_1f1=new Sequencer_ContentDeliveryEnvironmentProcessResult(true,null,"");
this.LogSeqReturn(_1f1,_1eb);
Control.DeliverActivity(_1e9);
return _1f1;
}
function Sequencer_ContentDeliveryEnvironmentProcessResult(_1f3,_1f4,_1f5){
this.Valid=_1f3;
this.Exception=_1f4;
this.ExceptionText=_1f5;
}
Sequencer_ContentDeliveryEnvironmentProcessResult.prototype.toString=function(){
return "Valid="+this.Valid+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_ContinueSequencingRequestProcess(_1f6){
Debug.AssertError("Calling log not passed.",(_1f6===undefined||_1f6===null));
var _1f7=this.LogSeqAudit("`1126`",_1f6);
var _1f8;
this.LogSeq("`500`",_1f7);
if(!this.IsCurrentActivityDefined(_1f7)){
this.LogSeq("`422`",_1f7);
_1f8=new Sequencer_ContinueSequencingRequestProcessResult(null,"SB.2.7-1",IntegrationImplementation.GetString("The sequencing session has not begun yet."),false);
this.LogSeqReturn(_1f8,_1f7);
return _1f8;
}
var _1f9=this.GetCurrentActivity();
this.LogSeq("`708`",_1f7);
if(!_1f9.IsTheRoot()){
var _1fa=this.Activities.GetParentActivity(_1f9);
this.LogSeq("`299`",_1f7);
if(_1fa.GetSequencingControlFlow()===false){
this.LogSeq("`585`",_1f7);
_1f8=new Sequencer_ContinueSequencingRequestProcessResult(null,"SB.2.7-2",IntegrationImplementation.GetString("You cannot use 'Next' to enter {0}. Please select a menu item to continue.",_1fa.GetTitle()),false);
this.LogSeqReturn(_1f8,_1f7);
return _1f8;
}
}
this.LogSeq("`136`",_1f7);
var _1fb=this.FlowSubprocess(_1f9,FLOW_DIRECTION_FORWARD,false,_1f7);
this.LogSeq("`988`",_1f7);
if(_1fb.Deliverable===false){
this.LogSeq("`228`",_1f7);
_1f8=new Sequencer_ContinueSequencingRequestProcessResult(null,_1fb.Exception,_1fb.ExceptionText,_1fb.EndSequencingSession);
this.LogSeqReturn(_1f8,_1f7);
return _1f8;
}else{
this.LogSeq("`1705`",_1f7);
this.LogSeq("`319`",_1f7);
_1f8=new Sequencer_ContinueSequencingRequestProcessResult(_1fb.IdentifiedActivity,null,"",false);
this.LogSeqReturn(_1f8,_1f7);
return _1f8;
}
}
function Sequencer_ContinueSequencingRequestProcessResult(_1fc,_1fd,_1fe,_1ff){
Debug.AssertError("Invalid endSequencingSession ("+_1ff+") passed to ContinueSequencingRequestProcessResult.",(_1ff!=true&&_1ff!=false));
this.DeliveryRequest=_1fc;
this.Exception=_1fd;
this.ExceptionText=_1fe;
this.EndSequencingSession=_1ff;
}
Sequencer_ContinueSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", EndSequencingSession="+this.EndSequencingSession;
};
function Sequencer_DeliveryRequestProcess(_200,_201){
Debug.AssertError("Calling log not passed.",(_201===undefined||_201===null));
var _202=this.LogSeqAudit("`1322`"+_200+")",_201);
var _203;
var _204;
this.LogSeq("`872`"+_200+"`953`",_202);
if(!_200.IsALeaf()){
this.LogSeq("`581`",_202);
_204=new Sequencer_DeliveryRequestProcessResult(false,"DB.1.1-1",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_200.GetTitle()));
this.LogSeqReturn(_204,_202);
return _204;
}
this.LogSeq("`207`",_202);
var _205=this.GetActivityPath(_200,true);
this.LogSeq("`836`",_202);
if(_205.length===0){
this.LogSeq("`582`",_202);
_204=new Sequencer_DeliveryRequestProcessResult(false,"DB.1.1-2",IntegrationImplementation.GetString("Nothing to open"));
this.LogSeqReturn(_204,_202);
return _204;
}
this.LogSeq("`528`",_202);
for(var i=0;i<_205.length;i++){
this.LogSeq("`857`"+_205[i],_202);
_203=this.CheckActivityProcess(_205[i],_202);
this.LogSeq("`900`",_202);
if(_203===true){
this.LogSeq("`563`",_202);
_204=new Sequencer_DeliveryRequestProcessResult(false,"DB.1.1-3",IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'",_200.GetTitle()));
this.LogSeqReturn(_204,_202);
return _204;
}
}
this.LogSeq("`658`",_202);
_204=new Sequencer_DeliveryRequestProcessResult(true,null,"");
this.LogSeqReturn(_204,_202);
return _204;
}
function Sequencer_DeliveryRequestProcessResult(_207,_208,_209){
this.Valid=_207;
this.Exception=_208;
this.ExceptionText=_209;
}
Sequencer_DeliveryRequestProcessResult.prototype.toString=function(){
return "Valid="+this.Valid+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_EndAttemptProcess(_20a,_20b,_20c,_20d){
Debug.AssertError("Calling log not passed.",(_20c===undefined||_20c===null));
if(_20d===undefined||_20d===null){
_20d=false;
}
var _20e=this.LogSeqAudit("`1470`"+_20a+", "+_20b+")",_20c);
this.LogSeq("`1493`"+_20a.GetItemIdentifier()+"`1682`",_20e);
var i;
var _210=new Array();
if(_20a.IsALeaf()){
this.LogSeq("`1013`",_20e);
if(_20a.IsTracked()&&_20a.WasLaunchedThisSession()){
this.LogSeq("`862`",_20e);
_20a.TransferRteDataToActivity();
this.LogSeq("`312`",_20e);
if(_20a.IsSuspended()===false){
this.LogSeq("`284`",_20e);
if(_20a.IsCompletionSetByContent()===false){
this.LogSeq("`245`",_20e);
if(_20a.GetAttemptProgressStatus()===false){
this.LogSeq("`743`",_20e);
_20a.SetAttemptProgressStatus(true);
this.LogSeq("`715`",_20e);
_20a.SetAttemptCompletionStatus(true);
_20a.WasAutoCompleted=true;
}
}
this.LogSeq("`297`",_20e);
if(_20a.IsObjectiveSetByContent()===false){
this.LogSeq("`596`",_20e);
var _211=_20a.GetPrimaryObjective();
this.LogSeq("`192`",_20e);
if(_211.GetProgressStatus(_20a,false)===false){
this.LogSeq("`667`",_20e);
_211.SetProgressStatus(true,false,_20a);
this.LogSeq("`657`",_20e);
_211.SetSatisfiedStatus(true,false,_20a);
_20a.WasAutoSatisfied=true;
}
}
}
}
}else{
this.LogSeq("`1220`",_20e);
this.LogSeq("`109`",_20e);
if(this.ActivityHasSuspendedChildren(_20a,_20e)){
this.LogSeq("`833`",_20e);
_20a.SetSuspended(true);
}else{
this.LogSeq("`1709`",_20e);
this.LogSeq("`819`",_20e);
_20a.SetSuspended(false);
}
}
if(_20d===false){
this.LogSeq("`462`",_20e);
_20a.SetActive(false);
}
var _212;
if(_20b===false){
this.LogSeq("`250`",_20e);
_212=this.OverallRollupProcess(_20a,_20e);
}else{
this.LogSeq("`527`",_20e);
_210[0]=_20a;
}
this.LogSeq("`235`",_20e);
var _213=this.FindActivitiesAffectedByWriteMaps(_20a);
var _214=this.FindDistinctParentsOfActivitySet(_213);
if(_20b===false){
this.LogSeq("`457`",_20e);
var _215=this.GetMinimalSubsetOfActivitiesToRollup(_214,_212);
for(i=0;i<_215.length;i++){
if(_215[i]!==null){
this.OverallRollupProcess(_215[i],_20e);
}
}
}else{
this.LogSeq("`218`",_20e);
_210=_210.concat(_214);
}
if(this.LookAhead===false&&_20d===false){
this.RandomizeChildrenProcess(_20a,true,_20e);
}
this.LogSeq("`1302`",_20e);
this.LogSeqReturn("",_20e);
return _210;
}
function Sequencer_EvaluateRollupConditionsSubprocess(_216,_217,_218){
Debug.AssertError("Calling log not passed.",(_218===undefined||_218===null));
var _219=this.LogSeqAudit("`1033`"+_216+", "+_217+")",_218);
var _21a;
var _21b;
this.LogSeq("`387`",_219);
var _21c=new Array();
var i;
this.LogSeq("`791`",_219);
for(i=0;i<_217.Conditions.length;i++){
this.LogSeq("`36`",_219);
_21a=Sequencer_EvaluateRollupRuleCondition(_216,_217.Conditions[i]);
this.LogSeq("`369`",_219);
if(_217.Conditions[i].Operator==RULE_CONDITION_OPERATOR_NOT&&_21a!=RESULT_UNKNOWN){
this.LogSeq("`1136`",_219);
_21a=(!_21a);
}
this.LogSeq("`968`"+_21a+"`532`",_219);
_21c[_21c.length]=_21a;
}
this.LogSeq("`308`",_219);
if(_21c.length===0){
this.LogSeq("`691`",_219);
return RESULT_UNKNOWN;
}
this.LogSeq("`1101`"+_217.ConditionCombination+"`285`",_219);
if(_217.ConditionCombination==RULE_CONDITION_COMBINATION_ANY){
_21b=false;
for(i=0;i<_21c.length;i++){
_21b=Sequencer_LogicalOR(_21b,_21c[i]);
}
}else{
_21b=true;
for(i=0;i<_21c.length;i++){
_21b=Sequencer_LogicalAND(_21b,_21c[i]);
}
}
this.LogSeq("`497`",_219);
this.LogSeqReturn(_21b,_219);
return _21b;
}
function Sequencer_EvaluateRollupRuleCondition(_21e,_21f){
var _220=null;
switch(_21f.Condition){
case ROLLUP_RULE_CONDITION_SATISFIED:
_220=_21e.IsSatisfied("");
break;
case ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
_220=_21e.IsObjectiveStatusKnown("",false);
break;
case ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
_220=_21e.IsObjectiveMeasureKnown("",false);
break;
case ROLLUP_RULE_CONDITION_COMPLETED:
_220=_21e.IsCompleted("",false);
break;
case ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
_220=_21e.IsActivityProgressKnown("",false);
break;
case ROLLUP_RULE_CONDITION_ATTEMPTED:
_220=_21e.IsAttempted();
break;
case ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
_220=_21e.IsAttemptLimitExceeded();
break;
case ROLLUP_RULE_CONDITION_NEVER:
_220=false;
break;
default:
this.LogSeq("`1359`",logParent);
break;
}
return _220;
}
function Sequencer_ExitSequencingRequestProcess(_221){
Debug.AssertError("Calling log not passed.",(_221===undefined||_221===null));
var _222=this.LogSeqAudit("`1211`",_221);
var _223;
this.LogSeq("`490`",_222);
if(!this.IsCurrentActivityDefined(_222)){
this.LogSeq("`512`",_222);
_223=new Sequencer_ExitSequencingRequestProcessResult(false,"SB.2.11-1",IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed until the sequencing session has begun."));
this.LogSeqReturn(_223,_222);
return _223;
}
var _224=this.GetCurrentActivity();
this.LogSeq("`323`",_222);
if(_224.IsActive()){
this.LogSeq("`513`",_222);
_223=new Sequencer_ExitSequencingRequestProcessResult(false,"SB.2.11-2",IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed while an activity is still active."));
this.LogSeqReturn(_223,_222);
return _223;
}
this.LogSeq("`762`",_222);
if(_224.IsTheRoot()||this.CourseIsSingleSco()===true){
this.LogSeq("`219`",_222);
_223=new Sequencer_ExitSequencingRequestProcessResult(true,null,"");
this.LogSeqReturn(_223,_222);
return _223;
}
this.LogSeq("`556`",_222);
_223=new Sequencer_ExitSequencingRequestProcessResult(false,null,"");
this.LogSeqReturn(_223,_222);
return _223;
}
function Sequencer_ExitSequencingRequestProcessResult(_225,_226,_227){
Debug.AssertError("Invalid endSequencingSession ("+_225+") passed to ExitSequencingRequestProcessResult.",(_225!=true&&_225!=false));
this.EndSequencingSession=_225;
this.Exception=_226;
this.ExceptionText=_227;
}
Sequencer_ExitSequencingRequestProcessResult.prototype.toString=function(){
return "EndSequencingSession="+this.EndSequencingSession+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_FlowActivityTraversalSubprocess(_228,_229,_22a,_22b){
Debug.AssertError("Calling log not passed.",(_22b===undefined||_22b===null));
var _22c=this.LogSeqAudit("`1130`"+_228+", "+_229+", "+_22a+")",_22b);
var _22d;
var _22e;
var _22f;
var _230;
var _231;
var _232=this.Activities.GetParentActivity(_228);
this.LogSeq("`458`",_22c);
if(_232.GetSequencingControlFlow()===false){
this.LogSeq("`388`",_22c);
_231=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_228,"SB.2.2-1",IntegrationImplementation.GetString("Please select a menu item to continue with {0}.",_232.GetTitle()),false);
this.LogSeqReturn(_231,_22c);
return _231;
}
this.LogSeq("`535`",_22c);
_22d=this.SequencingRulesCheckProcess(_228,RULE_SET_SKIPPED,_22c);
this.LogSeq("`358`",_22c);
if(_22d!==null){
this.LogSeq("`185`",_22c);
_22e=this.FlowTreeTraversalSubprocess(_228,_229,_22a,false,_22c);
this.LogSeq("`635`",_22c);
if(_22e.NextActivity===null){
this.LogSeq("`157`",_22c);
_231=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_228,_22e.Exception,_22e.ExceptionText,_22e.EndSequencingSession);
this.LogSeqReturn(_231,_22c);
return _231;
}else{
this.LogSeq("`1676`",_22c);
this.LogSeq("`67`",_22c);
if(_22a==FLOW_DIRECTION_BACKWARD&&_22e.TraversalDirection==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`35`",_22c);
_22f=this.FlowActivityTraversalSubprocess(_22e.NextActivity,_22e.TraversalDirection,null,_22c);
}else{
this.LogSeq("`1624`",_22c);
this.LogSeq("`9`",_22c);
_22f=this.FlowActivityTraversalSubprocess(_22e.NextActivity,_229,_22a,_22c);
}
this.LogSeq("`232`",_22c);
_231=_22f;
this.LogSeqReturn(_231,_22c);
return _231;
}
}
this.LogSeq("`565`",_22c);
_230=this.CheckActivityProcess(_228,_22c);
this.LogSeq("`923`",_22c);
if(_230===true){
this.LogSeq("`389`",_22c);
_231=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_228,"SB.2.2-2",IntegrationImplementation.GetString("'{0}' is not available at this time.  Please select another menu item to continue.",_228.GetTitle()),false);
this.LogSeqReturn(_231,_22c);
return _231;
}
this.LogSeq("`280`",_22c);
if(_228.IsALeaf()===false){
this.LogSeq("`158`",_22c);
_22e=this.FlowTreeTraversalSubprocess(_228,_229,null,true,_22c);
this.LogSeq("`636`",_22c);
if(_22e.NextActivity===null){
this.LogSeq("`159`",_22c);
_231=new Sequencer_FlowActivityTraversalSubprocessReturnObject(false,_228,_22e.Exception,_22e.ExceptionText,_22e.EndSequencingSession);
this.LogSeqReturn(_231,_22c);
return _231;
}else{
this.LogSeq("`1677`",_22c);
this.LogSeq("`44`",_22c);
if(_229==FLOW_DIRECTION_BACKWARD&&_22e.TraversalDirection==FLOW_DIRECTION_FORWARD){
this.LogSeq("`22`",_22c);
_22f=this.FlowActivityTraversalSubprocess(_22e.NextActivity,FLOW_DIRECTION_FORWARD,FLOW_DIRECTION_BACKWARD,_22c);
}else{
this.LogSeq("`1625`",_22c);
this.LogSeq("`29`",_22c);
_22f=this.FlowActivityTraversalSubprocess(_22e.NextActivity,_229,null,_22c);
}
this.LogSeq("`227`",_22c);
_231=_22f;
this.LogSeqReturn(_231,_22c);
return _231;
}
}
this.LogSeq("`359`",_22c);
_231=new Sequencer_FlowActivityTraversalSubprocessReturnObject(true,_228,null,"",false);
this.LogSeqReturn(_231,_22c);
return _231;
}
function Sequencer_FlowActivityTraversalSubprocessReturnObject(_233,_234,_235,_236,_237){
Debug.AssertError("Invalid endSequencingSession ("+_237+") passed to FlowActivityTraversalSubprocessReturnObject.",(_237!=true&&_237!=false));
this.Deliverable=_233;
this.NextActivity=_234;
this.Exception=_235;
this.ExceptionText=_236;
this.EndSequencingSession=_237;
}
Sequencer_FlowActivityTraversalSubprocessReturnObject.prototype.toString=function(){
return "Deliverable="+this.Deliverable+", NextActivity="+this.NextActivity+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", EndSequencingSession="+this.EndSequencingSession;
};
function Sequencer_FlowSubprocess(_238,_239,_23a,_23b){
Debug.AssertError("Calling log not passed.",(_23b===undefined||_23b===null));
var _23c=this.LogSeqAudit("`1506`"+_238+", "+_239+", "+_23a+")",_23b);
var _23d;
this.LogSeq("`508`",_23c);
var _23e=_238;
this.LogSeq("`4`",_23c);
var _23f=this.FlowTreeTraversalSubprocess(_23e,_239,null,_23a,_23c);
this.LogSeq("`491`",_23c);
if(_23f.NextActivity===null){
this.LogSeq("`205`",_23c);
_23d=new Sequencer_FlowSubprocessResult(_23e,false,_23f.Exception,_23f.ExceptionText,_23f.EndSequencingSession);
this.LogSeqReturn(_23d,_23c);
return _23d;
}else{
this.LogSeq("`1704`",_23c);
this.LogSeq("`557`",_23c);
_23e=_23f.NextActivity;
this.LogSeq("`48`",_23c);
var _240=this.FlowActivityTraversalSubprocess(_23e,_239,null,_23c);
this.LogSeq("`17`",_23c);
_23d=new Sequencer_FlowSubprocessResult(_240.NextActivity,_240.Deliverable,_240.Exception,_240.ExceptionText,_240.EndSequencingSession);
this.LogSeqReturn(_23d,_23c);
return _23d;
}
}
function Sequencer_FlowSubprocessResult(_241,_242,_243,_244,_245){
Debug.AssertError("Invalid endSequencingSession ("+_245+") passed to FlowSubprocessResult.",(_245!=true&&_245!=false));
this.IdentifiedActivity=_241;
this.Deliverable=_242;
this.Exception=_243;
this.ExceptionText=_244;
this.EndSequencingSession=_245;
}
Sequencer_FlowSubprocessResult.prototype.toString=function(){
return "IdentifiedActivity="+this.IdentifiedActivity+", Deliverable="+this.Deliverable+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", EndSequencingSession="+this.EndSequencingSession;
};
function Sequencer_FlowTreeTraversalSubprocess(_246,_247,_248,_249,_24a){
Debug.AssertError("Calling log not passed.",(_24a===undefined||_24a===null));
var _24b=this.LogSeqAudit("`1232`"+_246+", "+_247+", "+_248+", "+_249+")",_24a);
var _24c;
var _24d;
var _24e;
var _24f;
var _250;
var _251;
var _252=this.Activities.GetParentActivity(_246);
this.LogSeq("`1196`",_24b);
_24c=false;
this.LogSeq("`24`",_24b);
if(_248!==null&&_248==FLOW_DIRECTION_BACKWARD&&_252.IsActivityTheLastAvailableChild(_246)){
this.LogSeq("`1149`",_24b);
_247=FLOW_DIRECTION_BACKWARD;
this.LogSeq("`552`",_24b);
_246=_252.GetFirstAvailableChild();
this.LogSeq("`1168`",_24b);
_24c=true;
}
this.LogSeq("`980`",_24b);
if(_247==FLOW_DIRECTION_FORWARD){
this.LogSeq("`266`",_24b);
if((this.IsActivityLastOverall(_246,_24b))||(_249===false&&_246.IsTheRoot()===true)){
this.LogSeq("`572`",_24b);
this.TerminateDescendentAttemptsProcess(this.Activities.GetRootActivity(),_24b);
this.LogSeq("`174`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,null,null,true);
this.LogSeqReturn(_251,_24b);
return _251;
}
this.LogSeq("`763`",_24b);
if(_246.IsALeaf()||_249===false){
this.LogSeq("`478`",_24b);
if(_252.IsActivityTheLastAvailableChild(_246)){
this.LogSeq("`28`",_24b);
_24d=this.FlowTreeTraversalSubprocess(_252,FLOW_DIRECTION_FORWARD,null,false,_24b);
this.LogSeq("`225`",_24b);
_251=_24d;
this.LogSeqReturn(_251,_24b);
return _251;
}else{
this.LogSeq("`1620`",_24b);
this.LogSeq("`298`",_24b);
_24e=_246.GetNextSibling();
this.LogSeq("`201`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_24e,_247,null,"",false);
this.LogSeqReturn(_251,_24b);
return _251;
}
}else{
this.LogSeq("`1150`",_24b);
this.LogSeq("`392`",_24b);
_24f=_246.GetAvailableChildren();
if(_24f.length>0){
this.LogSeq("`332`"+_24f[0]+"); Traversal Direction: traversal direction ("+_247+"); Exception: n/a )",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_24f[0],_247,null,"",false);
this.LogSeqReturn(_251,_24b);
return _251;
}else{
this.LogSeq("`1621`",_24b);
this.LogSeq("`421`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-2",IntegrationImplementation.GetString("The activity '{0}' does not have any available children to deliver.",_246.GetTitle()),false);
this.LogSeqReturn(_251,_24b);
return _251;
}
}
}
this.LogSeq("`971`",_24b);
if(_247==FLOW_DIRECTION_BACKWARD){
this.LogSeq("`465`",_24b);
if(_246.IsTheRoot()){
this.LogSeq("`437`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-3",IntegrationImplementation.GetString("You have reached the beginning of the course."),false);
this.LogSeqReturn(_251,_24b);
return _251;
}
this.LogSeq("`764`",_24b);
if(_246.IsALeaf()||_249===false){
this.LogSeq("`337`",_24b);
if(_24c===false){
this.LogSeq("`317`",_24b);
if(_252.GetSequencingControlForwardOnly()===true){
this.LogSeq("`393`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-4",IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.",_252.GetTitle()),false);
this.LogSeqReturn(_251,_24b);
return _251;
}
}
this.LogSeq("`471`",_24b);
if(_252.IsActivityTheFirstAvailableChild(_246)){
this.LogSeq("`25`",_24b);
_24d=this.FlowTreeTraversalSubprocess(_252,FLOW_DIRECTION_BACKWARD,null,false,_24b);
this.LogSeq("`226`",_24b);
_251=_24d;
this.LogSeqReturn(_251,_24b);
return _251;
}else{
this.LogSeq("`1622`",_24b);
this.LogSeq("`267`",_24b);
_250=_246.GetPreviousSibling();
this.LogSeq("`808`"+_250+"`1535`"+_247+"`1632`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_250,_247,null,"",false);
this.LogSeqReturn(_251,_24b);
return _251;
}
}else{
this.LogSeq("`1088`",_24b);
this.LogSeq("`376`",_24b);
_24f=_246.GetAvailableChildren();
if(_24f.length>0){
this.LogSeq("`668`",_24b);
if(_246.GetSequencingControlForwardOnly()===true){
this.LogSeq("`49`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_24f[0],FLOW_DIRECTION_FORWARD,null,"",false);
this.LogSeqReturn(_251,_24b);
return _251;
}else{
this.LogSeq("`1585`",_24b);
this.LogSeq("`43`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(_24f[_24f.length-1],FLOW_DIRECTION_BACKWARD,null,"",false);
this.LogSeqReturn(_251,_24b);
return _251;
}
}else{
this.LogSeq("`1623`",_24b);
this.LogSeq("`408`",_24b);
_251=new Sequencer_FlowTreeTraversalSubprocessReturnObject(null,null,"SB.2.1-2",IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.",_252.GetTitle()),false);
this.LogSeqReturn(_251,_24b);
return _251;
}
}
}
}
function Sequencer_FlowTreeTraversalSubprocessReturnObject(_253,_254,_255,_256,_257){
Debug.AssertError("Invalid endSequencingSession ("+_257+") passed to FlowTreeTraversalSubprocessReturnObject.",(_257!=true&&_257!=false));
this.NextActivity=_253;
this.TraversalDirection=_254;
this.Exception=_255;
this.ExceptionText=_256;
this.EndSequencingSession=_257;
}
Sequencer_FlowTreeTraversalSubprocessReturnObject.prototype.toString=function(){
return "NextActivity="+this.NextActivity+", TraversalDirection="+this.TraversalDirection+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", EndSequencingSession="+this.EndSequencingSession;
};
function Sequencer_LimitConditionsCheckProcess(_258,_259){
Debug.AssertError("Calling log not passed.",(_259===undefined||_259===null));
var _25a=this.LogSeqAudit("`1265`"+_258+")",_259);
this.LogSeq("`384`",_25a);
if(_258.IsTracked()===false){
this.LogSeq("`296`",_25a);
this.LogSeqReturn("`1745`",_25a);
return false;
}
this.LogSeq("`144`",_25a);
if(_258.IsActive()||_258.IsSuspended()){
this.LogSeq("`687`",_25a);
this.LogSeqReturn("`1745`",_25a);
return false;
}
this.LogSeq("`714`",_25a);
if(_258.GetLimitConditionAttemptControl()===true){
this.LogSeq("`89`",_25a);
var _25b=_258.GetAttemptCount();
var _25c=_258.GetLimitConditionAttemptLimit();
if(_258.GetActivityProgressStatus()===true&&(_25b>=_25c)){
this.LogSeq("`429`",_25a);
this.LogSeqReturn("`1749`",_25a);
return true;
}
}
this.LogSeq("`543`",_25a);
this.LogSeq("`417`",_25a);
this.LogSeqReturn("`1745`",_25a);
return false;
}
function Sequencer_MeasureRollupProcess(_25d,_25e){
Debug.AssertError("Calling log not passed.",(_25e===undefined||_25e===null));
var _25f=this.LogSeqAudit("`1372`"+_25d+")",_25e);
this.LogSeq("`956`",_25f);
var _260=0;
this.LogSeq("`1341`",_25f);
var _261=false;
this.LogSeq("`1039`",_25f);
var _262=0;
this.LogSeq("`1057`",_25f);
var _263=null;
var i;
this.LogSeq("`626`",_25f);
var _263=_25d.GetPrimaryObjective();
this.LogSeq("`1099`",_25f);
if(_263!==null){
this.LogSeq("`1165`",_25f);
var _265=_25d.GetChildren();
var _266=null;
var _267;
var _268;
var _269;
for(i=0;i<_265.length;i++){
this.LogSeq("`555`"+_265[i].IsTracked(),_25f);
if(_265[i].IsTracked()){
this.LogSeq("`979`",_25f);
_266=null;
this.LogSeq("`1166`",_25f);
var _266=_265[i].GetPrimaryObjective();
this.LogSeq("`957`",_25f);
if(_266!==null){
this.LogSeq("`545`",_25f);
_268=_265[i].GetRollupObjectiveMeasureWeight();
_262+=_268;
this.LogSeq("`600`",_25f);
if(_266.GetMeasureStatus(_265[i],false)===true){
this.LogSeq("`121`",_25f);
_269=_266.GetNormalizedMeasure(_265[i],false);
this.LogSeq("`827`"+_269+"`1452`"+_268,_25f);
_261=true;
_260+=(_269*_268);
}
}else{
this.LogSeq("`1581`",_25f);
this.LogSeq("`495`",_25f);
Debug.AssertError("Measure Rollup Process encountered an activity with no primary objective.");
this.LogSeqReturn("",_25f);
return;
}
}
}
this.LogSeq("`1237`",_25f);
if(_261===false||_262==0){
this.LogSeq("`103`"+_262+")",_25f);
_263.SetMeasureStatus(false,_25d);
}else{
this.LogSeq("`1670`",_25f);
this.LogSeq("`678`",_25f);
_263.SetMeasureStatus(true,_25d);
this.LogSeq("`487`"+_260+"`1377`"+_262+"`1734`"+(_260/_262),_25f);
var _26a=(_260/_262);
_26a=RoundToPrecision(_26a,7);
_263.SetNormalizedMeasure(_26a,_25d);
}
this.LogSeq("`1191`",_25f);
this.LogSeqReturn("",_25f);
return;
}
this.LogSeq("`539`",_25f);
this.LogSeqReturn("",_25f);
return;
}
function Sequencer_NavigationRequestProcess(_26b,_26c,_26d){
Debug.AssertError("Calling log not passed.",(_26d===undefined||_26d===null));
var _26e=this.LogSeqAudit("`1298`"+_26b+", "+_26c+")",_26d);
var _26f=this.GetCurrentActivity();
var _270=null;
if(_26f!==null){
_270=_26f.ParentActivity;
}
var _271="";
if(_270!==null){
_271=_270.GetTitle();
}
var _272;
switch(_26b){
case NAVIGATION_REQUEST_START:
this.LogSeq("`1162`",_26e);
this.LogSeq("`463`",_26e);
if(!this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`209`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,null,SEQUENCING_REQUEST_START,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1663`",_26e);
this.LogSeq("`176`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-1",null,IntegrationImplementation.GetString("The sequencing session has already been started."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_RESUME_ALL:
this.LogSeq("`1037`",_26e);
this.LogSeq("`464`",_26e);
if(!this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`335`",_26e);
if(this.IsSuspendedActivityDefined(_26e)){
this.LogSeq("`170`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,null,SEQUENCING_REQUEST_RESUME_ALL,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1599`",_26e);
this.LogSeq("`163`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-3",null,IntegrationImplementation.GetString("There is no suspended activity to resume."));
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1664`",_26e);
this.LogSeq("`177`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-1",null,IntegrationImplementation.GetString("The sequencing session has already been started."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_CONTINUE:
this.LogSeq("`1079`",_26e);
this.LogSeq("`480`",_26e);
if(!this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`178`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-1",null,IntegrationImplementation.GetString("Cannot continue until the sequencing session has begun."));
this.LogSeqReturn(_272,_26e);
return _272;
}
this.LogSeq("`40`",_26e);
if((!_26f.IsTheRoot())&&(_270.LearningObject.SequencingData.ControlFlow===true)){
this.LogSeq("`212`",_26e);
if(_26f.IsActive()){
this.LogSeq("`183`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_CONTINUE,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1613`",_26e);
this.LogSeq("`186`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,null,SEQUENCING_REQUEST_CONTINUE,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1665`",_26e);
this.LogSeq("`34`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-4",null,IntegrationImplementation.GetString("Please select a menu item to continue with {0}.",_271));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_PREVIOUS:
this.LogSeq("`1080`",_26e);
this.LogSeq("`481`",_26e);
if(!this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`184`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("Cannot move backwards until the sequencing session has begun."));
this.LogSeqReturn(_272,_26e);
return _272;
}
this.LogSeq("`239`",_26e);
if(!_26f.IsTheRoot()){
this.LogSeq("`12`",_26e);
if(_270.LearningObject.SequencingData.ControlFlow===true&&_270.LearningObject.SequencingData.ControlForwardOnly===false){
this.LogSeq("`202`",_26e);
if(_26f.IsActive()){
this.LogSeq("`171`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_PREVIOUS,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1578`",_26e);
this.LogSeq("`179`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,null,SEQUENCING_REQUEST_PREVIOUS,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1614`",_26e);
this.LogSeq("`100`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-5",null,IntegrationImplementation.GetString("Please select a menu item to continue with {0}.",_270.GetTitle()));
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1666`",_26e);
this.LogSeq("`50`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-6",null,IntegrationImplementation.GetString("You have reached the beginning of the course."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_FORWARD:
this.LogSeq("`798`",_26e);
this.LogSeq("`187`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-7",null,IntegrationImplementation.GetString("The 'Forward' navigation request is not supported, try using 'Continue'."));
this.LogSeqReturn(_272,_26e);
return _272;
case NAVIGATION_REQUEST_BACKWARD:
this.LogSeq("`790`",_26e);
this.LogSeq("`188`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-7",null,IntegrationImplementation.GetString("The 'Backward' navigation request is not supported, try using 'Previous'."));
this.LogSeqReturn(_272,_26e);
return _272;
case NAVIGATION_REQUEST_CHOICE:
this.LogSeq("`1097`",_26e);
this.LogSeq("`195`",_26e);
if(this.DoesActivityExist(_26c,_26e)){
var _273=this.GetActivityFromIdentifier(_26c,_26e);
var _274=this.Activities.GetParentActivity(_273);
if(_273.IsAvailable()===false){
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-7",null,IntegrationImplementation.GetString("The activity '{0}' was not selected to be delivered in this attempt.",_273));
this.LogSeqReturn(_272,_26e);
return _272;
}
this.LogSeq("`2`",_26e);
if(_273.IsTheRoot()||_274.LearningObject.SequencingData.ControlChoice===true){
this.LogSeq("`443`",_26e);
if(!this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`59`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,null,SEQUENCING_REQUEST_CHOICE,null,_273,"");
this.LogSeqReturn(_272,_26e);
return _272;
}
this.LogSeq("`399`",_26e);
if(!this.AreActivitiesSiblings(_26f,_273,_26e)){
this.LogSeq("`365`",_26e);
var _275=this.FindCommonAncestor(_26f,_273,_26e);
this.LogSeq("`1`",_26e);
var _276=this.GetPathToAncestorExclusive(_26f,_275,true);
this.LogSeq("`930`",_26e);
if(_276.length>0){
this.LogSeq("`96`",_26e);
for(var i=0;i<_276.length;i++){
if(_276[i].GetItemIdentifier()==_275.GetItemIdentifier()){
break;
}
this.LogSeq("`216`"+_276[i].LearningObject.ItemIdentifier+")",_26e);
if(_276[i].IsActive()===true&&_276[i].LearningObject.SequencingData.ControlChoiceExit===false){
this.LogSeq("`172`"+CONTROL_CHOICE_EXIT_ERROR_NAV+"`1495`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,CONTROL_CHOICE_EXIT_ERROR_NAV,null,IntegrationImplementation.GetString("You must complete '{0}' before you can select another item.",_276[i]));
this.LogSeqReturn(_272,_26e);
return _272;
}
}
}else{
this.LogSeq("`1548`",_26e);
this.LogSeq("`145`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-9",null,IntegrationImplementation.GetString("Nothing to open"));
this.LogSeqReturn(_272,_26e);
return _272;
}
}
this.LogSeq("`46`",_26e);
if(_26f.IsActive()&&_26f.GetSequencingControlChoiceExit()===false){
this.LogSeq("`223`"+CONTROL_CHOICE_EXIT_ERROR_NAV+"`1513`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,CONTROL_CHOICE_EXIT_ERROR_NAV,null,IntegrationImplementation.GetString("You are not allowed to jump out of {0}.",_26f.GetTitle()));
return _272;
}
this.LogSeq("`204`",_26e);
if(_26f.IsActive()){
this.LogSeq("`57`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_CHOICE,null,_273,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1580`",_26e);
this.LogSeq("`61`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,null,SEQUENCING_REQUEST_CHOICE,null,_273,"");
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1615`",_26e);
this.LogSeq("`99`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-10",null,IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.",_274.GetTitle()));
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1667`",_26e);
this.LogSeq("`87`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-11",null,IntegrationImplementation.GetString("The activity you selected ({0}) does not exist.",_26c));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_EXIT:
this.LogSeq("`1163`",_26e);
this.LogSeq("`507`",_26e);
if(this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`292`",_26e);
if(_26f.IsActive()){
this.LogSeq("`193`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_EXIT,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1616`",_26e);
this.LogSeq("`75`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-12",null,IntegrationImplementation.GetString("The Exit navigation request is invalid because the current activity ({0}) is no longer active.",_26f.GetTitle()));
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1668`",_26e);
this.LogSeq("`173`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The Exit navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_EXIT_ALL:
this.LogSeq("`1081`",_26e);
this.LogSeq("`269`",_26e);
if(this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`194`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_EXIT_ALL,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1669`",_26e);
this.LogSeq("`180`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The Exit All navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_ABANDON:
this.LogSeq("`1078`",_26e);
this.LogSeq("`506`",_26e);
if(this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`286`",_26e);
if(_26f.IsActive()){
this.LogSeq("`182`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_ABANDON,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1598`",_26e);
this.LogSeq("`153`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-12",null,IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because the current activity '{0}' is no longer active.",_26f.GetTitle()));
this.LogSeqReturn(_272,_26e);
return _272;
}
}else{
this.LogSeq("`1612`",_26e);
this.LogSeq("`166`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_ABANDON_ALL:
this.LogSeq("`998`",_26e);
this.LogSeq("`277`",_26e);
if(this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`167`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_ABANDON_ALL,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1640`",_26e);
this.LogSeq("`162`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("You cannot use 'Abandon All' if no item is currently open."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
case NAVIGATION_REQUEST_SUSPEND_ALL:
this.LogSeq("`999`",_26e);
this.LogSeq("`538`",_26e);
if(this.IsCurrentActivityDefined(_26e)){
this.LogSeq("`168`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(_26b,TERMINATION_REQUEST_SUSPEND_ALL,SEQUENCING_REQUEST_EXIT,null,null,"");
this.LogSeqReturn(_272,_26e);
return _272;
}else{
this.LogSeq("`1641`",_26e);
this.LogSeq("`169`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-2",null,IntegrationImplementation.GetString("The 'Suspend All' navigation request is invalid because there is no current activity."));
this.LogSeqReturn(_272,_26e);
return _272;
}
break;
default:
this.LogSeq("`94`",_26e);
_272=new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID,null,null,"NB.2.1-13",null,IntegrationImplementation.GetString("Undefined Navigation Request"));
this.LogSeqReturn(_272,_26e);
return _272;
}
}
function Sequencer_NavigationRequestProcessResult(_278,_279,_27a,_27b,_27c,_27d){
this.NavigationRequest=_278;
this.TerminationRequest=_279;
this.SequencingRequest=_27a;
this.Exception=_27b;
this.TargetActivity=_27c;
this.ExceptionText=_27d;
}
Sequencer_NavigationRequestProcessResult.prototype.toString=function(){
return "NavigationRequest="+this.NavigationRequest+", TerminationRequest="+this.TerminationRequest+", SequencingRequest="+this.SequencingRequest+", Exception="+this.Exception+", TargetActivity="+this.TargetActivity+", ExceptionText="+this.ExceptionText;
};
function Sequencer_ObjectiveRollupProcess(_27e,_27f){
Debug.AssertError("Calling log not passed.",(_27f===undefined||_27f===null));
var _280=this.LogSeqAudit("`1351`"+_27e+")",_27f);
this.LogSeq("`1061`",_280);
var _281=null;
this.LogSeq("`628`",_280);
var _281=_27e.GetPrimaryObjective();
this.LogSeq("`1058`",_280);
if(_281!==null){
this.LogSeq("`690`",_280);
if(_281.GetSatisfiedByMeasure()===true){
this.LogSeq("`867`",_280);
this.ObjectiveRollupUsingMeasureProcess(_27e,_280);
this.LogSeq("`1134`",_280);
this.LogSeqReturn("",_280);
return;
}
this.LogSeq("`590`",_280);
if(Sequencer_GetApplicableSetofRollupRules(_27e,RULE_SET_SATISFIED).length>0||Sequencer_GetApplicableSetofRollupRules(_27e,RULE_SET_NOT_SATISFIED).length>0){
this.LogSeq("`879`",_280);
this.ObjectiveRollupUsingRulesProcess(_27e,_280);
this.LogSeq("`1135`",_280);
this.LogSeqReturn("",_280);
return;
}
this.LogSeq("`386`",_280);
this.ObjectiveRollupUsingDefaultProcess(_27e,_280);
this.LogSeq("`1193`",_280);
this.LogSeqReturn("",_280);
return;
}else{
this.LogSeq("`1671`",_280);
this.LogSeq("`482`",_280);
this.LogSeqReturn("",_280);
return;
}
}
function Sequencer_ObjectiveRollupUsingDefaultProcess(_282,_283){
Debug.AssertError("Calling log not passed.",(_283===undefined||_283===null));
var _284=this.LogSeqAudit("`1020`"+_282+")",_283);
var _285;
var _286;
var _287;
this.LogSeq("`1238`",_284);
if(_282.IsALeaf()){
this.LogSeq("`1249`",_284);
this.LogSeqReturn("",_284);
return;
}
this.LogSeq("`1026`",_284);
var _288=null;
var i;
this.LogSeq("`619`",_284);
var _288=_282.GetPrimaryObjective();
this.LogSeq("`1082`",_284);
var _28a=_282.GetChildren();
this.LogSeq("`1042`",_284);
var _28b=true;
this.LogSeq("`1118`",_284);
var _28c=true;
this.LogSeq("`1272`",_284);
var _28d=true;
for(i=0;i<_28a.length;i++){
this.LogSeq("`1356`"+_28a[i]+"`1555`"+_28a[i].IsTracked(),_284);
if(_28a[i].IsTracked()){
this.LogSeq("`1250`"+(i+1)+" - "+_28a[i],_284);
this.LogSeq("`1043`",_284);
_285=_28a[i].IsSatisfied();
this.LogSeq("`1044`",_284);
_286=_28a[i].IsAttempted();
this.LogSeq("`728`",_284);
_287=(_285===false||_286===true);
this.LogSeq("`1550`"+_285+"`1711`"+_286+"`1695`"+_287,_284);
if(this.CheckChildForRollupSubprocess(_28a[i],ROLLUP_RULE_ACTION_SATISFIED,_284)){
this.LogSeq("`893`",_284);
_28c=(_28c&&(_285===true));
_28d=false;
}
if(this.CheckChildForRollupSubprocess(_28a[i],ROLLUP_RULE_ACTION_NOT_SATISFIED,_284)){
this.LogSeq("`777`",_284);
_28b=(_28b&&_287);
_28d=false;
}
}
}
if(_28d&&Control.Package.Properties.RollupEmptySetToUnknown){
this.LogSeq("`542`"+Control.Package.Properties.RollupEmptySetToUnknown+")",_284);
}else{
this.LogSeq("`1002`"+_28b+")",_284);
if(_28b===true){
this.LogSeq("`673`",_284);
_288.SetProgressStatus(true,false,_282);
this.LogSeq("`655`",_284);
_288.SetSatisfiedStatus(false,false,_282);
}
this.LogSeq("`1085`"+_28c+")",_284);
if(_28c===true){
this.LogSeq("`656`",_284);
_288.SetProgressStatus(true,false,_282);
this.LogSeq("`644`",_284);
_288.SetSatisfiedStatus(true,false,_282);
}
}
this.LogSeqReturn("",_284);
}
function Sequencer_ObjectiveRollupUsingMeasureProcess(_28e,_28f){
Debug.AssertError("Calling log not passed.",(_28f===undefined||_28f===null));
var _290=this.LogSeqAudit("`1021`"+_28e+")",_28f);
this.LogSeq("`1025`",_290);
var _291=null;
this.LogSeq("`616`",_290);
var _291=_28e.GetPrimaryObjective();
this.LogSeq("`1058`",_290);
if(_291!==null){
this.LogSeq("`127`",_290);
if(_291.GetSatisfiedByMeasure()===true){
this.LogSeq("`303`",_290);
if(_291.GetMeasureStatus(_28e,false)===false){
this.LogSeq("`627`",_290);
_291.SetProgressStatus(false,false,_28e);
}else{
this.LogSeq("`1582`",_290);
this.LogSeq("`130`",_290);
if(_28e.IsActive()===false||_28e.GetMeasureSatisfactionIfActive()===true){
this.LogSeq("`105`",_290);
if(_291.GetNormalizedMeasure(_28e,false)>=_291.GetMinimumSatisfiedNormalizedMeasure()){
this.LogSeq("`609`",_290);
_291.SetProgressStatus(true,false,_28e);
this.LogSeq("`605`",_290);
_291.SetSatisfiedStatus(true,false,_28e);
}else{
this.LogSeq("`1508`",_290);
this.LogSeq("`610`",_290);
_291.SetProgressStatus(true,false,_28e);
this.LogSeq("`601`",_290);
_291.SetSatisfiedStatus(false,false,_28e);
}
}else{
this.LogSeq("`1549`",_290);
this.LogSeq("`270`",_290);
_291.SetProgressStatus(false,false,_28e);
}
}
}
this.LogSeq("`915`",_290);
this.LogSeqReturn("",_290);
return;
}else{
this.LogSeq("`1671`",_290);
this.LogSeq("`391`",_290);
this.LogSeqReturn("",_290);
return;
}
}
function Sequencer_ObjectiveRollupUsingRulesProcess(_292,_293){
Debug.AssertError("Calling log not passed.",(_293===undefined||_293===null));
var _294=this.LogSeqAudit("`1054`"+_292+")",_293);
var _295;
this.LogSeq("`1040`",_294);
var _296=null;
this.LogSeq("`617`",_294);
var _296=_292.GetPrimaryObjective();
this.LogSeq("`1059`",_294);
if(_296!==null){
this.LogSeq("`294`",_294);
_295=this.RollupRuleCheckSubprocess(_292,RULE_SET_NOT_SATISFIED,_294);
this.LogSeq("`800`",_294);
if(_295===true){
this.LogSeq("`651`",_294);
_296.SetProgressStatus(true,false,_292);
this.LogSeq("`631`",_294);
_296.SetSatisfiedStatus(false,false,_292);
}
this.LogSeq("`327`",_294);
_295=this.RollupRuleCheckSubprocess(_292,RULE_SET_SATISFIED,_294);
this.LogSeq("`801`",_294);
if(_295===true){
this.LogSeq("`652`",_294);
_296.SetProgressStatus(true,false,_292);
this.LogSeq("`642`",_294);
_296.SetSatisfiedStatus(true,false,_292);
}
this.LogSeq("`946`",_294);
this.LogSeqReturn("",_294);
return;
}else{
this.LogSeq("`1672`",_294);
this.LogSeq("`431`",_294);
this.LogSeqReturn("",_294);
return;
}
}
function Sequencer_OverallRollupProcess(_297,_298){
Debug.AssertError("Calling log not passed.",(_298===undefined||_298===null));
var _299=this.LogSeqAudit("`1373`"+_297+")",_298);
this.LogSeq("`256`",_299);
var _29a=this.GetActivityPath(_297,true);
this.LogSeq("`1121`",_299);
if(_29a.length===0){
this.LogSeq("`894`",_299);
this.LogSeqReturn("",_299);
return;
}
this.LogSeq("`1048`",_299);
var _29b;
var _29c;
var _29d;
var _29e;
var _29f;
var _2a0;
var _2a1;
var _2a2;
var _2a3;
var _2a4;
var _2a5;
var _2a6;
var _2a7;
var _2a8=new Array();
var _2a9=false;
for(var i=0;i<_29a.length;i++){
if(!_29a[i].IsALeaf()){
_29a[i].RollupDurations();
}
if(_2a9){
continue;
}
_29b=_29a[i].GetPrimaryObjective();
_29c=_29b.GetMeasureStatus(_29a[i],false);
_29d=_29b.GetNormalizedMeasure(_29a[i],false);
_29e=_29b.GetProgressStatus(_29a[i],false);
_29f=_29b.GetSatisfiedStatus(_29a[i],false);
_2a0=_29a[i].GetAttemptProgressStatus();
_2a1=_29a[i].GetAttemptCompletionStatus();
this.LogSeq("`551`",_299);
if(!_29a[i].IsALeaf()){
this.LogSeq("`564`",_299);
this.MeasureRollupProcess(_29a[i],_299);
}
this.LogSeq("`730`",_299);
this.ObjectiveRollupProcess(_29a[i],_299);
this.LogSeq("`781`",_299);
this.ActivityProgressRollupProcess(_29a[i],_299);
_2a2=_29b.GetMeasureStatus(_29a[i],false);
_2a3=_29b.GetNormalizedMeasure(_29a[i],false);
_2a4=_29b.GetProgressStatus(_29a[i],false);
_2a5=_29b.GetSatisfiedStatus(_29a[i],false);
_2a6=_29a[i].GetAttemptProgressStatus();
_2a7=_29a[i].GetAttemptCompletionStatus();
if(!this.LookAhead&&_29a[i].IsTheRoot()){
if(_2a6!=_2a0||_2a7!=_2a1){
var _2ab=(_2a6?(_2a7?SCORM_STATUS_COMPLETED:SCORM_STATUS_INCOMPLETE):SCORM_STATUS_NOT_ATTEMPTED);
this.WriteHistoryLog("",{ev:"Rollup Completion",v:_2ab,ai:_29a[i].ItemIdentifier});
}
if(_2a4!=_29e||_2a5!=_29f){
var _2ac=(_2a4?(_2a5?SCORM_STATUS_PASSED:SCORM_STATUS_FAILED):SCORM_STATUS_UNKNOWN);
this.WriteHistoryLog("",{ev:"Rollup Satisfaction",v:_2ac,ai:_29a[i].ItemIdentifier});
}
}
if(_2a5!=_29f){
_29a[i].WasAutoSatisfied=_297.WasAutoSatisfied;
}
if(_2a7!=_2a1){
_29a[i].WasAutoCompleted=_297.WasAutoCompleted;
}
if(i>0&&_2a2==_29c&&_2a3==_29d&&_2a4==_29e&&_2a5==_29f&&_2a6==_2a0&&_2a7==_2a1){
this.LogSeq("`903`",_299);
_2a9=true;
}else{
this.LogSeq("`868`",_299);
_2a8[_2a8.length]=_29a[i];
}
}
this.LogSeq("`1275`",_299);
this.LogSeqReturn("",_299);
return _2a8;
}
function Sequencer_OverallSequencingProcess(_2ad){
try{
var _2ae=null;
var _2af=null;
var _2b0=null;
var _2b1=null;
var _2b2=null;
this.ResetException();
var _2b3=this.LogSeqAudit("`1352`");
this.LogSeq("`1404`"+this.NavigationRequest,_2b3);
if(this.NavigationRequest===null){
var _2b4=this.GetExitAction(this.GetCurrentActivity(),_2b3);
this.LogSeq("`1038`"+_2b4,_2b3);
var _2b5="";
if(_2b4==EXIT_ACTION_EXIT_CONFIRMATION||_2b4==EXIT_ACTION_DISPLAY_MESSAGE){
var _2b6=Control.Activities.GetRootActivity();
var _2b7=(_2b6.IsCompleted()||_2b6.IsSatisfied());
if(_2b7===true){
_2b5=IntegrationImplementation.GetString("The course is now complete. Please make a selection to continue.");
}else{
_2b5=IntegrationImplementation.GetString("Please make a selection.");
}
}
switch(_2b4){
case (EXIT_ACTION_EXIT_NO_CONFIRMATION):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
break;
case (EXIT_ACTION_EXIT_CONFIRMATION):
if(confirm("Would you like to exit the course now?")){
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL,null,"");
}else{
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_2b5);
}
break;
case (EXIT_ACTION_GO_TO_NEXT_SCO):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_CONTINUE,null,"");
break;
case (EXIT_ACTION_DISPLAY_MESSAGE):
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE,null,_2b5);
break;
case (EXIT_ACTION_DO_NOTHING):
this.NavigationRequest=null;
break;
case (EXIT_ACTION_REFRESH_PAGE):
Control.RefreshPage();
break;
}
}
if(this.NavigationRequest==null){
this.LogSeqReturn("`1399`",_2b3);
return;
}
if(this.NavigationRequest.Type==NAVIGATION_REQUEST_DISPLAY_MESSAGE){
this.LogSeq("`689`",_2b3);
this.NavigationRequest=new NavigationRequest(NAVIGATION_REQUEST_EXIT,null,"");
}
if(this.NavigationRequest.Type==NAVIGATION_REQUEST_EXIT_PLAYER){
this.LogSeq("`813`",_2b3);
Control.ExitScormPlayer("Sequencer");
return;
}
this.LogSeq("`756`",_2b3);
var _2b8=this.NavigationRequestProcess(this.NavigationRequest.Type,this.NavigationRequest.TargetActivity,_2b3);
this.LogSeq("`625`",_2b3);
if(_2b8.NavigationRequest==NAVIGATION_REQUEST_NOT_VALID){
this.LogSeq("`725`",_2b3);
this.Exception=_2b8.Exception;
this.ExceptionText=_2b8.ExceptionText;
this.LogSeq("`846`",_2b3);
this.LogSeqReturn("`1745`",_2b3);
return false;
}
_2ae=_2b8.TerminationRequest;
_2af=_2b8.SequencingRequest;
_2b0=_2b8.TargetActivity;
this.LogSeq("`368`",_2b3);
if(_2ae!==null){
this.LogSeq("`706`",_2b3);
var _2b9=this.TerminationRequestProcess(_2ae,_2b3);
this.LogSeq("`599`",_2b3);
if(_2b9.TerminationRequest==TERMINATION_REQUEST_NOT_VALID){
this.LogSeq("`698`",_2b3);
this.Exception=_2b9.Exception;
this.ExceptionText=_2b9.ExceptionText;
this.LogSeq("`822`",_2b3);
this.LogSeqReturn("`1745`",_2b3);
return false;
}
this.LogSeq("`699`",_2b3);
if(_2b9.SequencingRequest!==null){
this.LogSeq("`39`",_2b3);
_2af=_2b9.SequencingRequest;
}
}
this.LogSeq("`1056`",_2b3);
if(_2af!==null){
this.LogSeq("`726`",_2b3);
var _2ba=this.SequencingRequestProcess(_2af,_2b0,_2b3);
this.LogSeq("`608`",_2b3);
if(_2ba.SequencingRequest==SEQUENCING_REQUEST_NOT_VALID){
this.LogSeq("`707`",_2b3);
this.Exception=_2ba.Exception;
this.ExceptionText=_2ba.ExceptionText;
this.LogSeq("`823`",_2b3);
this.LogSeqReturn("`1745`",_2b3);
return false;
}
this.LogSeq("`534`",_2b3);
if(_2ba.EndSequencingSession===true){
this.LogSeq("`76`",_2b3);
Control.ExitScormPlayer("Sequencer");
this.LogSeqReturn("",_2b3);
return;
}
this.LogSeq("`583`",_2b3);
if(_2ba.DeliveryRequest===null){
this.LogSeq("`824`",_2b3);
this.Exception="OP.1.4";
this.ExceptionText=IntegrationImplementation.GetString("Please make a selection.");
this.LogSeqReturn("",_2b3);
return;
}
this.LogSeq("`571`",_2b3);
_2b1=_2ba.DeliveryRequest;
}
this.LogSeq("`1098`",_2b3);
if(_2b1!==null){
this.LogSeq("`776`",_2b3);
var _2bb=this.DeliveryRequestProcess(_2b1,_2b3);
this.LogSeq("`629`",_2b3);
if(_2bb.Valid===false){
this.LogSeq("`727`",_2b3);
this.Exception="OP.1.5";
this.ExceptionText=IntegrationImplementation.GetString("Please make a selection.");
this.LogSeq("`825`",_2b3);
this.LogSeqReturn("`1745`",_2b3);
return false;
}
this.LogSeq("`650`",_2b3);
this.ContentDeliveryEnvironmentProcess(_2b1,_2b3);
}
this.LogSeq("`944`",_2b3);
this.LogSeqReturn("",_2b3);
return;
}
catch(error){
var _2bc="Error in OverallSequencingProcess for SCORM 2004 3rd Edition: ";
if(typeof RegistrationToDeliver!="undefined"&&typeof RegistrationToDeliver.Id!="undefined"){
_2bc=_2bc+"RegistrationId: "+RegistrationToDeliver.Id+", ";
}
Control.Comm.LogOnServer(_2bc,error);
throw error;
}
}
function Sequencer_PreviousSequencingRequestProcess(_2bd){
Debug.AssertError("Calling log not passed.",(_2bd===undefined||_2bd===null));
var _2be=this.LogSeqAudit("`1131`",_2bd);
var _2bf;
this.LogSeq("`501`",_2be);
if(!this.IsCurrentActivityDefined(_2be)){
this.LogSeq("`409`",_2be);
_2bf=new Sequencer_PreviousSequencingRequestProcessResult(null,"SB.2.8-1",IntegrationImplementation.GetString("You cannot use 'Previous' at this time."),false);
this.LogSeqReturn(_2bf,_2be);
return _2bf;
}
var _2c0=this.GetCurrentActivity();
this.LogSeq("`709`",_2be);
if(!_2c0.IsTheRoot()){
var _2c1=this.Activities.GetParentActivity(_2c0);
this.LogSeq("`300`",_2be);
if(_2c1.GetSequencingControlFlow()===false){
this.LogSeq("`593`",_2be);
_2bf=new Sequencer_PreviousSequencingRequestProcessResult(null,"SB.2.8-2",IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.",_2c1.GetTitle()),false);
this.LogSeqReturn(_2bf,_2be);
return _2bf;
}
}
this.LogSeq("`131`",_2be);
var _2c2=this.FlowSubprocess(_2c0,FLOW_DIRECTION_BACKWARD,false,_2be);
this.LogSeq("`989`",_2be);
if(_2c2.Deliverable===false){
this.LogSeq("`229`",_2be);
_2bf=new Sequencer_PreviousSequencingRequestProcessResult(null,_2c2.Exception,_2c2.ExceptionText,_2c2.EndSequencingSession);
this.LogSeqReturn(_2bf,_2be);
return _2bf;
}else{
this.LogSeq("`1706`",_2be);
this.LogSeq("`324`",_2be);
_2bf=new Sequencer_PreviousSequencingRequestProcessResult(_2c2.IdentifiedActivity,null,"",false);
this.LogSeqReturn(_2bf,_2be);
return _2bf;
}
}
function Sequencer_PreviousSequencingRequestProcessResult(_2c3,_2c4,_2c5,_2c6){
Debug.AssertError("Invalid endSequencingSession ("+_2c6+") passed to PreviousSequencingRequestProcessResult.",(_2c6!=true&&_2c6!=false));
this.DeliveryRequest=_2c3;
this.Exception=_2c4;
this.ExceptionText=_2c5;
this.EndSequencingSession=_2c6;
}
Sequencer_PreviousSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_RandomizeChildrenProcess(_2c7,_2c8,_2c9){
Debug.AssertError("Calling log not passed.",(_2c9===undefined||_2c9===null));
var _2ca=this.LogSeqAudit("`1335`"+_2c7+")",_2c9);
var _2cb;
this.LogSeq("`537`",_2ca);
if(_2c7.IsALeaf()){
this.LogSeq("`1197`",_2ca);
this.LogSeqReturn("",_2ca);
return;
}
this.LogSeq("`155`",_2ca);
if(_2c7.IsActive()===true||_2c7.IsSuspended()===true){
this.LogSeq("`1198`",_2ca);
this.LogSeqReturn("",_2ca);
return;
}
var _2cc=_2c7.GetRandomizationTiming();
switch(_2cc){
case TIMING_NEVER:
this.LogSeq("`853`",_2ca);
this.LogSeq("`1199`",_2ca);
break;
case TIMING_ONCE:
this.LogSeq("`860`",_2ca);
this.LogSeq("`782`",_2ca);
if(_2c7.GetRandomizedChildren()===false){
this.LogSeq("`441`",_2ca);
if(_2c7.GetActivityProgressStatus()===false){
this.LogSeq("`861`",_2ca);
if(_2c7.GetRandomizeChildren()===true){
this.LogSeq("`568`",_2ca);
_2cb=Sequencer_RandomizeArray(_2c7.GetAvailableChildren());
_2c7.SetAvailableChildren(_2cb);
_2c7.SetRandomizedChildren(true);
}
}
}
this.LogSeq("`1200`",_2ca);
break;
case TIMING_ON_EACH_NEW_ATTEMPT:
this.LogSeq("`695`",_2ca);
this.LogSeq("`875`",_2ca);
if(_2c7.GetRandomizeChildren()===true){
this.LogSeq("`586`",_2ca);
_2cb=Sequencer_RandomizeArray(_2c7.GetAvailableChildren());
_2c7.SetAvailableChildren(_2cb);
_2c7.SetRandomizedChildren(true);
if(_2c8===true){
Control.RedrawChildren(_2c7);
}
}
this.LogSeq("`1201`",_2ca);
break;
default:
this.LogSeq("`832`",_2ca);
break;
}
this.LogSeqReturn("",_2ca);
return;
}
function Sequencer_RandomizeArray(ary){
var _2ce=ary.length;
var orig;
var swap;
for(var i=0;i<_2ce;i++){
var _2d2=Math.floor(Math.random()*_2ce);
orig=ary[i];
swap=ary[_2d2];
ary[i]=swap;
ary[_2d2]=orig;
}
return ary;
}
function Sequencer_ResumeAllSequencingRequestProcess(_2d3){
Debug.AssertError("Calling log not passed.",(_2d3===undefined||_2d3===null));
var _2d4=this.LogSeqAudit("`1096`",_2d3);
var _2d5;
this.LogSeq("`499`",_2d4);
if(this.IsCurrentActivityDefined(_2d4)){
this.LogSeq("`400`",_2d4);
_2d5=new Sequencer_ResumeAllSequencingRequestProcessResult(null,"SB.2.6-1",IntegrationImplementation.GetString("A 'Resume All' sequencing request cannot be processed while there is a current activity defined."));
this.LogSeqReturn(_2d5,_2d4);
return _2d5;
}
this.LogSeq("`397`",_2d4);
if(!this.IsSuspendedActivityDefined(_2d4)){
this.LogSeq("`401`",_2d4);
_2d5=new Sequencer_ResumeAllSequencingRequestProcessResult(null,"SB.2.6-2",IntegrationImplementation.GetString("There is no suspended activity to resume."));
this.LogSeqReturn(_2d5,_2d4);
return _2d5;
}
this.LogSeq("`58`",_2d4);
var _2d6=this.GetSuspendedActivity(_2d4);
_2d5=new Sequencer_ResumeAllSequencingRequestProcessResult(_2d6,null,"");
this.LogSeqReturn(_2d5,_2d4);
return _2d5;
}
function Sequencer_ResumeAllSequencingRequestProcessResult(_2d7,_2d8,_2d9){
this.DeliveryRequest=_2d7;
this.Exception=_2d8;
this.ExceptionText=_2d9;
}
Sequencer_ResumeAllSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_RetrySequencingRequestProcess(_2da){
Debug.AssertError("Calling log not passed.",(_2da===undefined||_2da===null));
var _2db=this.LogSeqAudit("`1187`",_2da);
var _2dc;
var _2dd;
this.LogSeq("`488`",_2db);
if(!this.IsCurrentActivityDefined(_2db)){
this.LogSeq("`433`",_2db);
_2dc=new Sequencer_RetrySequencingRequestProcessResult(null,"SB.2.10-1",IntegrationImplementation.GetString("You cannot use 'Resume All' while the current item is open."));
this.LogSeqReturn(_2dc,_2db);
return _2dc;
}
var _2de=this.GetCurrentActivity();
this.LogSeq("`101`",_2db);
if(_2de.IsActive()||_2de.IsSuspended()){
this.LogSeq("`434`",_2db);
_2dc=new Sequencer_RetrySequencingRequestProcessResult(null,"SB.2.10-2",IntegrationImplementation.GetString("A 'Retry' sequencing request cannot be processed while there is an active or suspended activity."));
this.LogSeqReturn(_2dc,_2db);
return _2dc;
}
this.LogSeq("`970`",_2db);
if(!_2de.IsALeaf()){
this.LogSeq("`372`",_2db);
flowSubProcessResult=this.FlowSubprocess(_2de,FLOW_DIRECTION_FORWARD,true,_2db);
this.LogSeq("`949`",_2db);
if(flowSubProcessResult.Deliverable===false){
this.LogSeq("`407`",_2db);
_2dc=new Sequencer_RetrySequencingRequestProcessResult(null,"SB.2.10-3",IntegrationImplementation.GetString("You cannot 'Retry' this item because: {1}",_2de.GetTitle(),flowSubProcessResult.ExceptionText));
this.LogSeqReturn(_2dc,_2db);
return _2dc;
}else{
this.LogSeq("`1643`",_2db);
this.LogSeq("`322`",_2db);
_2dc=new Sequencer_RetrySequencingRequestProcessResult(flowSubProcessResult.IdentifiedActivity,null,"");
this.LogSeqReturn(_2dc,_2db);
return _2dc;
}
}else{
this.LogSeq("`1690`",_2db);
this.LogSeq("`489`",_2db);
_2dc=new Sequencer_RetrySequencingRequestProcessResult(_2de,null,"");
this.LogSeqReturn(_2dc,_2db);
return _2dc;
}
}
function Sequencer_RetrySequencingRequestProcessResult(_2df,_2e0,_2e1){
this.DeliveryRequest=_2df;
this.Exception=_2e0;
this.ExceptionText=_2e1;
}
Sequencer_RetrySequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function Sequencer_RollupRuleCheckSubprocess(_2e2,_2e3,_2e4){
Debug.AssertError("Calling log not passed.",(_2e4===undefined||_2e4===null));
var _2e5=this.LogSeqAudit("`1267`"+_2e2+", "+_2e3+")",_2e4);
var _2e6;
var _2e7;
var _2e8;
var _2e9;
var _2ea=0;
var _2eb=0;
var _2ec=0;
this.LogSeq("`331`",_2e5);
var _2ed=Sequencer_GetApplicableSetofRollupRules(_2e2,_2e3);
if(_2ed.length>0){
this.LogSeq("`214`",_2e5);
_2e6=_2e2.GetChildren();
this.LogSeq("`1139`",_2e5);
for(var i=0;i<_2ed.length;i++){
this.LogSeq("`747`",_2e5);
contributingChldren=new Array();
_2ea=0;
_2eb=0;
_2ec=0;
this.LogSeq("`1120`",_2e5);
for(var j=0;j<_2e6.length;j++){
this.LogSeq("`969`",_2e5);
if(_2e6[j].IsTracked()===true){
this.LogSeq("`236`",_2e5);
_2e7=this.CheckChildForRollupSubprocess(_2e6[j],_2ed[i].Action,_2e5);
this.LogSeq("`748`",_2e5);
if(_2e7===true){
this.LogSeq("`156`",_2e5);
_2e8=this.EvaluateRollupConditionsSubprocess(_2e6[j],_2ed[i],_2e5);
this.LogSeq("`309`",_2e5);
if(_2e8==RESULT_UNKNOWN){
this.LogSeq("`720`",_2e5);
_2ec++;
if(_2ed[i].ChildActivitySet==CHILD_ACTIVITY_SET_ALL||_2ed[i].ChildActivitySet==CHILD_ACTIVITY_SET_NONE){
j=_2e6.length;
}
}else{
this.LogSeq("`1509`",_2e5);
this.LogSeq("`681`",_2e5);
if(_2e8===true){
this.LogSeq("`771`",_2e5);
_2ea++;
if(_2ed[i].ChildActivitySet==CHILD_ACTIVITY_SET_ANY||_2ed[i].ChildActivitySet==CHILD_ACTIVITY_SET_NONE){
j=_2e6.length;
}
}else{
this.LogSeq("`1510`",_2e5);
this.LogSeq("`761`",_2e5);
_2eb++;
if(_2ed[i].ChildActivitySet==CHILD_ACTIVITY_SET_ALL){
j=_2e6.length;
}
}
}
}
}
}
switch(_2ed[i].ChildActivitySet){
case CHILD_ACTIVITY_SET_ALL:
this.LogSeq("`933`",_2e5);
this.LogSeq("`540`",_2e5);
if(_2eb===0&&_2ec===0){
this.LogSeq("`1140`",_2e5);
_2e9=true;
}
break;
case CHILD_ACTIVITY_SET_ANY:
this.LogSeq("`935`",_2e5);
this.LogSeq("`692`",_2e5);
if(_2ea>0){
this.LogSeq("`1141`",_2e5);
_2e9=true;
}
break;
case CHILD_ACTIVITY_SET_NONE:
this.LogSeq("`921`",_2e5);
this.LogSeq("`546`",_2e5);
if(_2ea===0&&_2ec===0){
this.LogSeq("`1142`",_2e5);
_2e9=true;
}
break;
case CHILD_ACTIVITY_SET_AT_LEAST_COUNT:
this.LogSeq("`815`",_2e5);
this.LogSeq("`271`",_2e5);
if(_2ea>=_2ed[i].MinimumCount){
this.LogSeq("`1143`",_2e5);
_2e9=true;
}
break;
case CHILD_ACTIVITY_SET_AT_LEAST_PERCENT:
this.LogSeq("`792`",_2e5);
this.LogSeq("`118`",_2e5);
var _2f0=(_2ea/(_2ea+_2eb+_2ec));
if(_2f0>=_2ed[i].MinimumPercent){
this.LogSeq("`1144`",_2e5);
_2e9=true;
}
break;
default:
break;
}
this.LogSeq("`1145`",_2e5);
if(_2e9===true){
this.LogSeq("`265`",_2e5);
this.LogSeqReturn("`1749`",_2e5);
return true;
}
}
}
this.LogSeq("`420`",_2e5);
this.LogSeqReturn("`1745`",_2e5);
return false;
}
function Sequencer_GetApplicableSetofRollupRules(_2f1,_2f2){
var _2f3=new Array();
var _2f4=_2f1.GetRollupRules();
for(var i=0;i<_2f4.length;i++){
switch(_2f2){
case RULE_SET_SATISFIED:
if(_2f4[i].Action==ROLLUP_RULE_ACTION_SATISFIED){
_2f3[_2f3.length]=_2f4[i];
}
break;
case RULE_SET_NOT_SATISFIED:
if(_2f4[i].Action==ROLLUP_RULE_ACTION_NOT_SATISFIED){
_2f3[_2f3.length]=_2f4[i];
}
break;
case RULE_SET_COMPLETED:
if(_2f4[i].Action==ROLLUP_RULE_ACTION_COMPLETED){
_2f3[_2f3.length]=_2f4[i];
}
break;
case RULE_SET_INCOMPLETE:
if(_2f4[i].Action==ROLLUP_RULE_ACTION_INCOMPLETE){
_2f3[_2f3.length]=_2f4[i];
}
break;
}
}
return _2f3;
}
function Sequencer_SelectChildrenProcess(_2f6,_2f7){
Debug.AssertError("Calling log not passed.",(_2f7===undefined||_2f7===null));
var _2f8=this.LogSeqAudit("`1386`"+_2f6+")",_2f7);
this.LogSeq("`561`",_2f8);
if(_2f6.IsALeaf()){
this.LogSeq("`1251`",_2f8);
this.LogSeqReturn("",_2f8);
return;
}
this.LogSeq("`175`",_2f8);
if(_2f6.IsActive()===true||_2f6.IsSuspended()===true){
this.LogSeq("`1252`",_2f8);
this.LogSeqReturn("",_2f8);
return;
}
var _2f9=_2f6.GetSelectionTiming();
switch(_2f9){
case TIMING_NEVER:
this.LogSeq("`886`",_2f8);
this.LogSeq("`1253`",_2f8);
break;
case TIMING_ONCE:
this.LogSeq("`895`",_2f8);
this.LogSeq("`817`",_2f8);
if(_2f6.GetSelectedChildren()===false){
this.LogSeq("`440`",_2f8);
if(_2f6.GetActivityProgressStatus()===false){
this.LogSeq("`772`",_2f8);
if(_2f6.GetSelectionCountStatus()===true){
this.LogSeq("`887`",_2f8);
var _2fa=new Array();
var _2fb=_2f6.GetChildren();
var _2fc=_2f6.GetSelectionCount();
if(_2fc<_2fb.length){
var _2fd=Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_2fc,0,_2fb.length-1);
this.LogSeq("`869`",_2f8);
for(var i=0;i<_2fd.length;i++){
this.LogSeq("`536`",_2f8);
this.LogSeq("`339`",_2f8);
_2fa[i]=_2fb[_2fd[i]];
}
}else{
_2fa=_2fb;
}
this.LogSeq("`773`",_2f8);
_2f6.SetAvailableChildren(_2fa);
_2f6.SetSelectedChildren(true);
}
}
}
this.LogSeq("`1254`",_2f8);
break;
case TIMING_ON_EACH_NEW_ATTEMPT:
this.LogSeq("`738`",_2f8);
this.LogSeq("`896`",_2f8);
break;
default:
this.LogSeq("`841`",_2f8);
break;
}
this.LogSeqReturn("",_2f8);
}
function Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_2ff,_300,_301){
if(_2ff===null||_2ff===undefined||_2ff<_300){
_2ff=_300;
}
if(_2ff>_301){
_2ff=_301;
}
var _302=new Array(_2ff);
var _303;
var _304;
for(var i=0;i<_2ff;i++){
_304=true;
while(_304){
_303=Sequencer_GetRandomNumberWithinRange(_300,_301);
_304=Sequencer_IsNumberAlreadyInArray(_303,_302);
}
_302[i]=_303;
}
_302.sort();
return _302;
}
function Sequencer_GetRandomNumberWithinRange(_306,_307){
var diff=_307-_306;
return Math.floor(Math.random()*(diff+_306+1));
}
function Sequencer_IsNumberAlreadyInArray(_309,_30a){
for(var i=0;i<_30a.length;i++){
if(_30a[i]==_309){
return true;
}
}
return false;
}
function Sequencer_SequencingExitActionRulesSubprocess(_30c){
Debug.AssertError("Calling log not passed.",(_30c===undefined||_30c===null));
var _30d=this.LogSeqAudit("`1055`",_30c);
this.LogSeq("`249`",_30d);
var _30e=this.GetCurrentActivity();
var _30f=this.Activities.GetParentActivity(_30e);
var _310;
if(_30f!==null){
_310=this.GetActivityPath(_30f,true);
}else{
_310=this.GetActivityPath(_30e,true);
}
this.LogSeq("`1219`",_30d);
var _311=null;
var _312=null;
this.LogSeq("`307`",_30d);
for(var i=(_310.length-1);i>=0;i--){
this.LogSeq("`553`",_30d);
_312=this.SequencingRulesCheckProcess(_310[i],RULE_SET_EXIT,_30d);
this.LogSeq("`739`",_30d);
if(_312!==null){
this.LogSeq("`415`",_30d);
_311=_310[i];
this.LogSeq("`1533`",_30d);
break;
}
}
this.LogSeq("`1202`",_30d);
if(_311!==null){
this.LogSeq("`352`",_30d);
this.TerminateDescendentAttemptsProcess(_311,_30d);
this.LogSeq("`466`",_30d);
this.EndAttemptProcess(_311,false,_30d);
this.LogSeq("`348`",_30d);
this.SetCurrentActivity(_311,_30d);
}
this.LogSeq("`963`",_30d);
this.LogSeqReturn("",_30d);
return;
}
function Sequencer_SequencingPostConditionRulesSubprocess(_314){
Debug.AssertError("Calling log not passed.",(_314===undefined||_314===null));
var _315=this.LogSeqAudit("`994`",_314);
var _316;
this.LogSeq("`340`",_315);
var _317=this.GetCurrentActivity();
if(_317.IsSuspended()){
this.LogSeq("`897`",_315);
_316=new Sequencer_SequencingPostConditionRulesSubprocessResult(null,null);
this.LogSeqReturn(_316,_315);
return _316;
}
this.LogSeq("`190`",_315);
var _318=this.SequencingRulesCheckProcess(_317,RULE_SET_POST_CONDITION,_315);
this.LogSeq("`765`",_315);
if(_318!==null){
this.LogSeq("`587`",_315);
if(_318==SEQUENCING_RULE_ACTION_RETRY||_318==SEQUENCING_RULE_ACTION_CONTINUE||_318==SEQUENCING_RULE_ACTION_PREVIOUS){
this.LogSeq("`47`",_315);
_316=new Sequencer_SequencingPostConditionRulesSubprocessResult(this.TranslateSequencingRuleActionIntoSequencingRequest(_318),null);
this.LogSeqReturn(_316,_315);
return _316;
}
this.LogSeq("`620`",_315);
if(_318==SEQUENCING_RULE_ACTION_EXIT_PARENT||_318==SEQUENCING_RULE_ACTION_EXIT_ALL){
this.LogSeq("`85`",_315);
_316=new Sequencer_SequencingPostConditionRulesSubprocessResult(null,this.TranslateSequencingRuleActionIntoTerminationRequest(_318));
this.LogSeqReturn(_316,_315);
return _316;
}
this.LogSeq("`751`",_315);
if(_318==SEQUENCING_RULE_ACTION_RETRY_ALL){
this.LogSeq("`30`",_315);
_316=new Sequencer_SequencingPostConditionRulesSubprocessResult(SEQUENCING_REQUEST_RETRY,TERMINATION_REQUEST_EXIT_ALL);
this.LogSeqReturn(_316,_315);
return _316;
}
}
this.LogSeq("`484`",_315);
_316=new Sequencer_SequencingPostConditionRulesSubprocessResult(null,null);
this.LogSeqReturn(_316,_315);
return _316;
}
function Sequencer_SequencingPostConditionRulesSubprocessResult(_319,_31a){
this.TerminationRequest=_31a;
this.SequencingRequest=_319;
}
Sequencer_SequencingPostConditionRulesSubprocessResult.prototype.toString=function(){
return "TerminationRequest="+this.TerminationRequest+", SequencingRequest="+this.SequencingRequest;
};
function Sequencer_SequencingRequestProcess(_31b,_31c,_31d){
Debug.AssertError("Calling log not passed.",(_31d===undefined||_31d===null));
var _31e=this.LogSeqAudit("`1286`"+_31b+", "+_31c+")",_31d);
var _31f;
switch(_31b){
case SEQUENCING_REQUEST_START:
this.LogSeq("`1122`",_31e);
this.LogSeq("`950`",_31e);
var _320=this.StartSequencingRequestProcess(_31e);
this.LogSeq("`694`",_31e);
if(_320.Exception!==null){
this.LogSeq("`81`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_320.Exception,_320.ExceptionText,false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}else{
this.LogSeq("`1644`",_31e);
this.LogSeq("`122`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(_31b,_320.DeliveryRequest,_320.EndSequencingSession,null,"",false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
break;
case SEQUENCING_REQUEST_RESUME_ALL:
this.LogSeq("`1028`",_31e);
this.LogSeq("`883`",_31e);
var _321=this.ResumeAllSequencingRequestProcess(_31e);
this.LogSeq("`645`",_31e);
if(_321.Exception!==null){
this.LogSeq("`71`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_321.Exception,_321.ExceptionText,false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}else{
this.LogSeq("`1645`",_31e);
this.LogSeq("`108`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(_31b,_321.DeliveryRequest,null,null,"",false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
break;
case SEQUENCING_REQUEST_EXIT:
this.LogSeq("`1147`",_31e);
this.LogSeq("`959`",_31e);
var _322=this.ExitSequencingRequestProcess(_31e);
this.LogSeq("`700`",_31e);
if(_322.Exception!==null){
this.LogSeq("`83`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_322.Exception,_322.ExceptionText,false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}else{
this.LogSeq("`1646`",_31e);
this.LogSeq("`125`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(_31b,null,_322.EndSequencingSession,null,"",false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
break;
case SEQUENCING_REQUEST_RETRY:
this.LogSeq("`1123`",_31e);
this.LogSeq("`951`",_31e);
var _323=this.RetrySequencingRequestProcess(_31e);
if(_323.Exception!==null){
this.LogSeq("`82`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_323.Exception,_323.ExceptionText,false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}else{
this.LogSeq("`1647`",_31e);
this.LogSeq("`116`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(_31b,_323.DeliveryRequest,null,null,"",false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
break;
case SEQUENCING_REQUEST_CONTINUE:
this.LogSeq("`1064`",_31e);
this.LogSeq("`904`",_31e);
var _324=this.ContinueSequencingRequestProcess(_31e);
this.LogSeq("`660`",_31e);
if(_324.Exception!==null){
this.LogSeq("`27`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,_324.EndSequencingSession,_324.Exception,_324.ExceptionText,false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}else{
this.LogSeq("`1648`",_31e);
this.LogSeq("`112`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(_31b,_324.DeliveryRequest,_324.EndSequencingSession,null,"",false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
break;
case SEQUENCING_REQUEST_PREVIOUS:
this.LogSeq("`1065`",_31e);
this.LogSeq("`905`",_31e);
var _325=this.PreviousSequencingRequestProcess(_31e);
this.LogSeq("`661`",_31e);
if(_325.Exception!==null){
this.LogSeq("`73`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,_325.EndSequencingSession,_325.Exception,_325.ExceptionText,false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}else{
this.LogSeq("`1649`",_31e);
this.LogSeq("`113`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(_31b,_325.DeliveryRequest,_325.EndSequencingSession,null,"",false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
break;
case SEQUENCING_REQUEST_CHOICE:
this.LogSeq("`1104`",_31e);
this.LogSeq("`937`",_31e);
var _326=this.ChoiceSequencingRequestProcess(_31c,_31e);
this.LogSeq("`682`",_31e);
if(_326.Exception!==null){
this.LogSeq("`77`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,_326.Exception,_326.ExceptionText,_326.Hidden);
this.LogSeqReturn(_31f,_31e);
return _31f;
}else{
this.LogSeq("`1650`",_31e);
this.LogSeq("`120`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(_31b,_326.DeliveryRequest,null,null,"",_326.Hidden);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
break;
}
this.LogSeq("`150`",_31e);
_31f=new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID,null,null,"SB.2.12-1","The sequencing request ("+_31b+") is not recognized.",false);
this.LogSeqReturn(_31f,_31e);
return _31f;
}
function Sequencer_SequencingRequestProcessResult(_327,_328,_329,_32a,_32b,_32c){
Debug.AssertError("undefined hidden value",(_32c===undefined));
Debug.AssertError("Invalid endSequencingSession ("+_329+") passed to SequencingRequestProcessResult.",(_329!=null&&_329!=true&&_329!=false));
this.SequencingRequest=_327;
this.DeliveryRequest=_328;
this.EndSequencingSession=_329;
this.Exception=_32a;
this.ExceptionText=_32b;
this.Hidden=_32c;
}
Sequencer_SequencingRequestProcessResult.prototype.toString=function(){
return "SequencingRequest="+this.SequencingRequest+", DeliveryRequest="+this.DeliveryRequest+", EndSequencingSession="+this.EndSequencingSession+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", Hidden="+this.Hidden;
};
function Sequencer_SequencingRulesCheckProcess(_32d,_32e,_32f){
Debug.AssertError("Calling log not passed.",(_32f===undefined||_32f===null));
var _330=this.LogSeqAudit("`1269`"+_32d+", "+_32e+")",_32f);
var _331;
var _332=Sequencer_GetApplicableSetofSequencingRules(_32d,_32e);
this.LogSeq("`304`",_330);
if(_332.length>0){
this.LogSeq("`191`",_330);
this.LogSeq("`1203`",_330);
for(var i=0;i<_332.length;i++){
this.LogSeq("`416`",_330);
_331=this.SequencingRulesCheckSubprocess(_32d,_332[i],_330);
this.LogSeq("`795`",_330);
if(_331===true){
this.LogSeq("`211`",_330);
this.LogSeqReturn(_332[i].Action,_330);
return _332[i].Action;
}
}
}
this.LogSeq("`460`",_330);
this.LogSeqReturn("`1748`",_330);
return null;
}
function Sequencer_GetApplicableSetofSequencingRules(_334,_335){
var _336=new Array();
if(_335==RULE_SET_POST_CONDITION){
_336=_334.GetPostConditionRules();
}else{
if(_335==RULE_SET_EXIT){
_336=_334.GetExitRules();
}else{
var _337=_334.GetPreConditionRules();
for(var i=0;i<_337.length;i++){
switch(_335){
case RULE_SET_HIDE_FROM_CHOICE:
if(_337[i].Action==SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE){
_336[_336.length]=_337[i];
}
break;
case RULE_SET_STOP_FORWARD_TRAVERSAL:
if(_337[i].Action==SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL){
_336[_336.length]=_337[i];
}
break;
case RULE_SET_DISABLED:
if(_337[i].Action==SEQUENCING_RULE_ACTION_DISABLED){
_336[_336.length]=_337[i];
}
break;
case RULE_SET_SKIPPED:
if(_337[i].Action==SEQUENCING_RULE_ACTION_SKIP){
_336[_336.length]=_337[i];
}
break;
default:
Debug.AssertError("ERROR - invalid sequencing rule set - "+_335);
return null;
}
}
}
}
return _336;
}
function Sequencer_SequencingRulesCheckSubprocess(_339,rule,_33b){
Debug.AssertError("Calling log not passed.",(_33b===undefined||_33b===null));
var _33c=this.LogSeqAudit("`1160`"+_339+", "+rule+")",_33b);
this.LogSeq("`326`",_33c);
var _33d=new Array();
var _33e;
var _33f;
var i;
this.LogSeq("`741`",_33c);
for(i=0;i<rule.RuleConditions.length;i++){
this.LogSeq("`102`",_33c);
_33e=this.EvaluateSequencingRuleCondition(_339,rule.RuleConditions[i],_33c);
this.LogSeq("`703`",_33c);
if(rule.RuleConditions[i].Operator==RULE_CONDITION_OPERATOR_NOT){
this.LogSeq("`666`",_33c);
if(_33e!="unknown"){
_33e=(!_33e);
}
}
this.LogSeq("`291`",_33c);
_33d[_33d.length]=_33e;
}
this.LogSeq("`375`",_33c);
if(_33d.length===0){
this.LogSeq("`613`",_33c);
this.LogSeqReturn(RESULT_UNKNOWN,_33c);
return RESULT_UNKNOWN;
}
this.LogSeq("`62`",_33c);
if(rule.ConditionCombination==RULE_CONDITION_COMBINATION_ANY){
_33f=false;
for(i=0;i<_33d.length;i++){
_33f=Sequencer_LogicalOR(_33f,_33d[i]);
}
}else{
_33f=true;
for(i=0;i<_33d.length;i++){
_33f=Sequencer_LogicalAND(_33f,_33d[i]);
}
}
this.LogSeq("`621`",_33c);
this.LogSeqReturn(_33f,_33c);
return _33f;
}
function Sequencer_EvaluateSequencingRuleCondition(_341,_342,_343){
Debug.AssertError("Calling log not passed.",(_343===undefined||_343===null));
var _344=this.LogSeqAudit("`1311`"+_341+", "+_342+")",_343);
var _345=null;
switch(_342.Condition){
case SEQUENCING_RULE_CONDITION_SATISFIED:
_345=_341.IsSatisfied(_342.ReferencedObjective,true);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
_345=_341.IsObjectiveStatusKnown(_342.ReferencedObjective,true);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
_345=_341.IsObjectiveMeasureKnown(_342.ReferencedObjective,true);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN:
_345=_341.IsObjectiveMeasureGreaterThan(_342.ReferencedObjective,_342.MeasureThreshold,true);
break;
case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN:
_345=_341.IsObjectiveMeasureLessThan(_342.ReferencedObjective,_342.MeasureThreshold,true);
break;
case SEQUENCING_RULE_CONDITION_COMPLETED:
_345=_341.IsCompleted(_342.ReferencedObjective,true);
break;
case SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
_345=_341.IsActivityProgressKnown(_342.ReferencedObjective,true);
break;
case SEQUENCING_RULE_CONDITION_ATTEMPTED:
_345=_341.IsAttempted();
break;
case SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
_345=_341.IsAttemptLimitExceeded();
break;
case SEQUENCING_RULE_CONDITION_ALWAYS:
_345=true;
break;
default:
Debug.AssertError("ERROR - Encountered unsupported rule condition - "+_342);
_345=RESULT_UNKNOWN;
break;
}
_344.setReturn(_345+"",_344);
return _345;
}
function Sequencer_LogicalOR(_346,_347){
if(_346==RESULT_UNKNOWN){
if(_347===true){
return true;
}else{
return RESULT_UNKNOWN;
}
}else{
if(_347==RESULT_UNKNOWN){
if(_346===true){
return true;
}else{
return RESULT_UNKNOWN;
}
}else{
return (_346||_347);
}
}
}
function Sequencer_LogicalAND(_348,_349){
if(_348==RESULT_UNKNOWN){
if(_349===false){
return false;
}else{
return RESULT_UNKNOWN;
}
}else{
if(_349==RESULT_UNKNOWN){
if(_348===false){
return false;
}else{
return RESULT_UNKNOWN;
}
}else{
return (_348&&_349);
}
}
}
function Sequencer_StartSequencingRequestProcess(_34a){
Debug.AssertError("Calling log not passed.",(_34a===undefined||_34a===null));
var _34b=this.LogSeqAudit("`1216`",_34a);
var _34c;
this.LogSeq("`498`",_34b);
if(this.IsCurrentActivityDefined(_34b)){
this.LogSeq("`455`",_34b);
_34c=new Sequencer_StartSequencingRequestProcessResult(null,"SB.2.5-1",IntegrationImplementation.GetString("You cannot 'Start' an item that is already open."),false);
this.LogSeqReturn(_34c,_34b);
return _34c;
}
var _34d=this.GetRootActivity(_34b);
this.LogSeq("`318`",_34b);
if(_34d.IsALeaf()){
this.LogSeq("`240`",_34b);
_34c=new Sequencer_StartSequencingRequestProcessResult(_34d,null,"",false);
this.LogSeqReturn(_34c,_34b);
return _34c;
}else{
if(Control.Package.Properties.AlwaysFlowToFirstSco===true||Control.Package.Properties.ShowCourseStructure==false){
this.LogSeq("`315`",_34b);
this.LogSeq("`1049`",_34b);
var _34e=this.GetOrderedListOfActivities(_34b);
this.LogSeq("`924`",_34b);
for(var _34f in _34e){
if(_34e[_34f].IsDeliverable()===true){
_34c=new Sequencer_StartSequencingRequestProcessResult(_34e[_34f],null,"",false);
this.LogSeqReturn(_34c,_34b);
return _34c;
}
}
_34c=new Sequencer_StartSequencingRequestProcessResult(null,"SB.2.5-2.5","There are no deliverable activities in this course.",false);
this.LogSeqReturn(_34c,_34b);
return _34c;
}else{
this.LogSeq("`1691`",_34b);
this.LogSeq("`164`",_34b);
var _350=this.FlowSubprocess(_34d,FLOW_DIRECTION_FORWARD,true,_34b);
this.LogSeq("`973`",_34b);
if(_350.Deliverable===false){
this.LogSeq("`233`",_34b);
_34c=new Sequencer_StartSequencingRequestProcessResult(null,_350.Exception,_350.ExceptionText,_350.EndSequencingSession);
this.LogSeqReturn(_34c,_34b);
return _34c;
}else{
this.LogSeq("`1652`",_34b);
this.LogSeq("`325`",_34b);
_34c=new Sequencer_StartSequencingRequestProcessResult(_350.IdentifiedActivity,null,"",false);
this.LogSeqReturn(_34c,_34b);
return _34c;
}
}
}
}
function Sequencer_StartSequencingRequestProcessResult(_351,_352,_353,_354){
Debug.AssertError("Invalid endSequencingSession ("+_354+") passed to StartSequencingRequestProcessResult.",(_354!=true&&_354!=false));
this.DeliveryRequest=_351;
this.Exception=_352;
this.ExceptionText=_353;
this.EndSequencingSession=_354;
}
Sequencer_StartSequencingRequestProcessResult.prototype.toString=function(){
return "DeliveryRequest="+this.DeliveryRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText+", EndSequencingSession="+this.EndSequencingSession;
};
function Sequencer_TerminateDescendentAttemptsProcess(_355,_356){
Debug.AssertError("Calling log not passed.",(_356===undefined||_356===null));
var _357=this.LogSeqAudit("`1115`"+_355+")",_356);
this.LogSeq("`688`"+this.GetCurrentActivity()+"`1376`"+_355+")",_357);
var _358=this.FindCommonAncestor(_355,this.GetCurrentActivity(),_357);
this.LogSeq("`152`"+_358+"`964`",_357);
var _359=this.GetPathToAncestorExclusive(this.GetCurrentActivity(),_358,false);
var _35a=new Array();
this.LogSeq("`526`",_357);
if(_359.length>0){
this.LogSeq("`1051`",_357);
for(var i=0;i<_359.length;i++){
this.LogSeq("`474`"+_359[i].LearningObject.ItemIdentifier,_357);
_35a=_35a.concat(this.EndAttemptProcess(_359[i],true,_357));
}
}
this.LogSeq("`742`",_357);
var _35c=this.GetMinimalSubsetOfActivitiesToRollup(_35a,null);
for(var _35d in _35c){
this.OverallRollupProcess(_35c[_35d],_357);
}
this.LogSeq("`1012`",_357);
this.LogSeqReturn("",_357);
return;
}
function Sequencer_TerminationRequestProcess(_35e,_35f){
Debug.AssertError("Calling log not passed.",(_35f===undefined||_35f===null));
var _360=this.LogSeqAudit("`1287`"+_35e+")",_35f);
var _361;
var _362=this.GetCurrentActivity();
var _363=this.Activities.GetParentActivity(_362);
var _364=this.GetRootActivity(_360);
var _365;
var _366=null;
var _367=false;
this.LogSeq("`367`",_360);
if(!this.IsCurrentActivityDefined(_360)){
this.LogSeq("`381`",_360);
_361=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-1",IntegrationImplementation.GetString("You cannot use 'Terminate' because no item is currently open."));
this.LogSeqReturn(_361,_360);
return _361;
}
this.LogSeq("`88`",_360);
if((_35e==TERMINATION_REQUEST_EXIT||_35e==TERMINATION_REQUEST_ABANDON)&&(_362.IsActive()===false)){
this.LogSeq("`382`",_360);
_361=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-2",IntegrationImplementation.GetString("The current activity has already been terminated."));
this.LogSeqReturn(_361,_360);
return _361;
}
switch(_35e){
case TERMINATION_REQUEST_EXIT:
this.LogSeq("`1151`",_360);
this.LogSeq("`383`",_360);
this.EndAttemptProcess(_362,false,_360);
this.LogSeq("`241`",_360);
this.SequencingExitActionRulesSubprocess(_360);
this.LogSeq("`1629`",_360);
var _368;
do{
this.LogSeq("`1106`",_360);
_368=false;
this.LogSeq("`588`"+this.GetCurrentActivity()+")",_360);
_366=this.SequencingPostConditionRulesSubprocess(_360);
this.LogSeq("`473`",_360);
if(_366.TerminationRequest==TERMINATION_REQUEST_EXIT_ALL){
this.LogSeq("`906`",_360);
_35e=TERMINATION_REQUEST_EXIT_ALL;
this.LogSeq("`674`",_360);
_367=true;
break;
}
this.LogSeq("`53`",_360);
if(_366.TerminationRequest==TERMINATION_REQUEST_EXIT_PARENT){
this.LogSeq("`281`",_360);
if(this.GetCurrentActivity()!==null&&this.GetCurrentActivity().IsTheRoot()===false){
this.LogSeq("`675`",_360);
this.SetCurrentActivity(this.Activities.GetParentActivity(this.GetCurrentActivity()),_360);
this.LogSeq("`774`",_360);
this.EndAttemptProcess(this.GetCurrentActivity(),false,_360);
this.LogSeq("`494`",_360);
_368=true;
}else{
this.LogSeq("`1586`",_360);
this.LogSeq("`355`",_360);
_361=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-4",IntegrationImplementation.GetString("An 'Exit Parent' sequencing request cannot be processed on the root of the activity tree."));
this.LogSeqReturn(_361,_360);
return _361;
}
}else{
this.LogSeq("`1630`",_360);
this.LogSeq("`8`",_360);
if(this.GetCurrentActivity()!==null&&this.GetCurrentActivity().IsTheRoot()===true&&_366.SequencingRequest!=SEQUENCING_REQUEST_RETRY){
this.LogSeq("`404`",_360);
_361=new Sequencer_TerminationRequestProcessResult(_35e,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_361,_360);
return _361;
}
}
this.LogSeq("`910`"+_368+")",_360);
}while(_368!==false);
if(!_367){
this.LogSeq("`54`",_360);
_361=new Sequencer_TerminationRequestProcessResult(_35e,_366.SequencingRequest,null,"");
this.LogSeqReturn(_361,_360);
return _361;
break;
}
case TERMINATION_REQUEST_EXIT_ALL:
this.LogSeq("`1071`",_360);
this.LogSeq("`238`",_360);
if(_362.IsActive()){
this.LogSeq("`818`",_360);
this.EndAttemptProcess(_362,false,_360);
}
this.LogSeq("`589`",_360);
this.TerminateDescendentAttemptsProcess(_364,_360);
this.LogSeq("`740`",_360);
this.EndAttemptProcess(_364,false,_360);
this.LogSeq("`353`",_360);
this.SetCurrentActivity(_364,_360);
this.LogSeq("`3`",_360);
if(_366!==null&&_366.SequencingRequest!==null){
this.LogSeq("`451`",_360);
_361=new Sequencer_TerminationRequestProcessResult(_35e,_366.SequencingRequest,null,"");
this.LogSeqReturn(_361,_360);
return _361;
}else{
this.LogSeq("`1030`",_360);
_361=new Sequencer_TerminationRequestProcessResult(_35e,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_361,_360);
return _361;
}
break;
case TERMINATION_REQUEST_SUSPEND_ALL:
this.LogSeq("`1008`",_360);
this.LogSeq("`45`",_360);
if((Control.Package.Properties.InvokeRollupAtSuspendAll===true||this.ReturnToLmsInvoked)&&_362.IsActive()){
this.LogSeq("`510`",_360);
this.EndAttemptProcess(_362,false,_360,true);
}
if(_362.IsActive()||_362.IsSuspended()){
this.LogSeq("`1090`",_360);
this.OverallRollupProcess(_362,_360);
this.LogSeq("`855`",_360);
this.SetSuspendedActivity(_362);
}else{
this.LogSeq("`1681`",_360);
this.LogSeq("`258`",_360);
if(!_362.IsTheRoot()){
this.LogSeq("`676`",_360);
this.SetSuspendedActivity(_363);
}else{
this.LogSeq("`1631`",_360);
this.LogSeq("`263`",_360);
Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-3","The suspend all termination request failed because there is no activity to suspend");
}
}
this.LogSeq("`273`",_360);
_365=this.GetActivityPath(this.GetSuspendedActivity(_360),true);
this.LogSeq("`1091`",_360);
if(_365.length===0){
this.LogSeq("`274`",_360);
_361=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-5",IntegrationImplementation.GetString("Nothing to suspend"));
this.LogSeqReturn(_361,_360);
return _361;
}
this.LogSeq("`1009`",_360);
for(var i=0;i<_365.length;i++){
this.LogSeq("`639`"+_365[i].GetItemIdentifier()+")",_360);
_365[i].SetActive(false);
this.LogSeq("`856`",_360);
_365[i].SetSuspended(true);
}
this.LogSeq("`354`",_360);
this.SetCurrentActivity(_364,_360);
this.LogSeq("`160`",_360);
_361=new Sequencer_TerminationRequestProcessResult(_35e,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_361,_360);
return _361;
break;
case TERMINATION_REQUEST_ABANDON:
this.LogSeq("`1092`",_360);
this.LogSeq("`809`",_360);
_362.SetActive(false);
this.LogSeq("`459`",_360);
_361=new Sequencer_TerminationRequestProcessResult(_35e,null,null,"");
this.LogSeqReturn(_361,_360);
return _361;
break;
case TERMINATION_REQUEST_ABANDON_ALL:
this.LogSeq("`1010`",_360);
this.LogSeq("`282`",_360);
_365=this.GetActivityPath(_362,true);
this.LogSeq("`1093`",_360);
if(_365.length===0){
this.LogSeq("`283`",_360);
_361=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-6",IntegrationImplementation.GetString("Nothing to close"));
this.LogSeqReturn(_361,_360);
return _361;
}
this.LogSeq("`1011`",_360);
for(var i=0;i<_365.length;i++){
this.LogSeq("`870`",_360);
_365[i].SetActive(false);
}
this.LogSeq("`360`",_360);
this.SetCurrentActivity(_364,_360);
this.LogSeq("`165`",_360);
_361=new Sequencer_TerminationRequestProcessResult(_35e,SEQUENCING_REQUEST_EXIT,null,"");
this.LogSeqReturn(_361,_360);
return _361;
break;
default:
this.LogSeq("`255`",_360);
_361=new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID,null,"TB.2.3-7",IntegrationImplementation.GetString("The 'Termination' request {0} is not recognized.",_35e));
this.LogSeqReturn(_361,_360);
return _361;
break;
}
}
function Sequencer_TerminationRequestProcessResult(_36a,_36b,_36c,_36d){
this.TerminationRequest=_36a;
this.SequencingRequest=_36b;
this.Exception=_36c;
this.ExceptionText=_36d;
}
Sequencer_TerminationRequestProcessResult.prototype.toString=function(){
return "TerminationRequest="+this.TerminationRequest+", SequencingRequest="+this.SequencingRequest+", Exception="+this.Exception+", ExceptionText="+this.ExceptionText;
};
function SSPApi(_36e,_36f){
this.MaxSSPStorage=parseInt(_36e,10);
this.ApiInstance=_36f;
}
SSPApi.prototype.InitializeBuckets=SSPApi_InitializeBuckets;
SSPApi.prototype.CheckForGetValueError=SSPApi_CheckForGetValueError;
SSPApi.prototype.CheckForSetValueError=SSPApi_CheckForSetValueError;
SSPApi.prototype.RetrieveGetValueData=SSPApi_RetrieveGetValueData;
SSPApi.prototype.StoreValue=SSPApi_StoreValue;
SSPApi.prototype.GetBucketById=SSPApi_GetBucketById;
SSPApi.prototype.GetBucketByIndex=SSPApi_GetBucketByIndex;
SSPApi.prototype.GetAccessibleBucketCount=SSPApi_GetAccessibleBucketCount;
SSPApi.prototype.GetDelimiterValues=SSPApi_GetDelimiterValues;
SSPApi.prototype.RemoveDelimitersFromElementName=SSPApi_RemoveDelimitersFromElementName;
SSPApi.prototype.RemoveDelimitersFromValue=SSPApi_RemoveDelimitersFromValue;
SSPApi.prototype.GetDelimiterValues=SSPApi_GetDelimiterValues;
SSPApi.prototype.GetCurrentSCOItemIdentifier=SSPApi_GetCurrentSCOItemIdentifier;
SSPApi.prototype.AllocateBucket=SSPApi_AllocateBucket;
SSPApi.prototype.GetStorageAllowedByLms=SSPApi_GetStorageAllowedByLms;
SSPApi.prototype.ResetBucketsForActivity=SSPApi_ResetBucketsForActivity;
SSPApi.prototype.SetErrorState=SSPApi_SetErrorState;
SSPApi.prototype.WriteDetailedLog=SSPApi_WriteDetailedLog;
function SSPApi_InitializeBuckets(){
var _370;
var _371;
var _372;
for(var i=0;i<Control.SSPBuckets.length;i++){
_370=Control.SSPBuckets[i];
if(_370.AllocationSuccess==SSP_ALLOCATION_SUCCESS_NOT_ATTEMPTED){
_371=this.GetStorageAllowedByLms(_370.SizeMin,_370.SizeRequested);
if(_371==null){
_372=SSP_ALLOCATION_SUCCESS_FAILURE;
}else{
if(_371==_370.SizeMin){
_372=SSP_ALLOCATION_SUCCESS_MINIMUM;
}else{
if(_371==_370.SizeRequested){
_372=SSP_ALLOCATION_SUCCESS_REQUESTED;
}else{
Debug.AssertError("Invalid allocation");
}
}
}
_370.AllocationSuccess=_372;
}
}
}
function SSPApi_CheckForGetValueError(_374,_375,_376,_377){
var _378=this.RemoveDelimitersFromElementName(_375);
var _379=this.GetDelimiterValues(_374);
var _37a;
var _37b;
var size;
if(_376!==""){
var _37d=this.GetAccessibleBucketCount();
if(_376>=_37d){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The SSP Bucket collection does not have an element at index "+_376+", the current element count is "+_37d+".");
return false;
}
}
switch(_378){
case "ssp._count":
this.WriteDetailedLog("`1560`");
break;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The ssp.allocate data model element is write-only.");
return false;
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
break;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
break;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
break;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
_37a=this.GetBucketByIndex(_376);
_37b=_379["offset"];
size=_379["size"];
if(_37a.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_37b!=null){
_37b=new String(_37b);
if(_37b.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_37b=parseInt(_37b,10);
if(_37b%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_37b>=_37a.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_37a.SizeAllocated()+" bytes of storage. Bytes started at offset "+_37b+"were requested.");
return false;
}
}
if(size!=null){
size=new String(size);
if(size.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be a valid even integer greater than 0.");
return false;
}
size=parseInt(size,10);
if(size%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be an even integer.");
return false;
}
if((_37b+size)>=_37a.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Requested data exceeds available data. This bucket currently has allocated "+_37a.SizeAllocated()+" bytes of storage. "+size+" bytes starting at offset "+_37b+" were requested. Size + Offset = "+(size+_37b));
return false;
}
}
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The ssp.n.appendData data model element is write-only.");
return false;
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
if(_379["bucketID"]==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_37a=this.GetBucketById(_379["bucketID"],true);
if(_37a==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_379["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
_37b=_379["offset"];
size=_379["size"];
if(_37a.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_37b!=null){
_37b=new String(_37b);
if(_37b.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_37b=parseInt(_37b,10);
if(_37b%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_37b>=_37a.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_37a.SizeAllocated()+" bytes of storage. Bytes starting at offset "+_37b+" were requested.");
return false;
}
}
if(size!=null){
size=new String(size);
if(size.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be a valid even integer greater than 0.");
return false;
}
size=parseInt(size,10);
if(size%2!=0){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"The value for size must be an even integer.");
return false;
}
if((_37b+size)>=_37a.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Requested data exceeds available data. This bucket currently has allocated "+_37a.SizeAllocated()+" bytes of storage. "+size+" bytes started at offset "+_37b+" were requested. Size + Offset = "+(size+_37b));
return false;
}
}
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
var _37e=_379["bucketID"];
if(_37e==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_37a=this.GetBucketById(_37e,true);
if(_37a==null){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_379["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
if(_37a.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR,"Bucket improperly declared.");
}
break;
case "ssp.appendData":
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR,"The ssp.appendData data model element is write-only.");
return false;
break;
default:
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_374+"' does not exist.");
return false;
break;
}
this.WriteDetailedLog("`1547`");
return true;
}
function SSPApi_CheckForSetValueError(_37f,_380,_381,_382,_383){
var _384=this.RemoveDelimitersFromElementName(_381);
var _385=this.GetDelimiterValues(_380);
_380=this.RemoveDelimitersFromValue(_380);
var _386;
var _387;
var _388;
if(_382!==""){
var _389=this.GetAccessibleBucketCount();
if(_382>=_389){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The SSP Bucket collection does not have an element at index "+_382+", the current element count is "+_389+".");
return false;
}
}
switch(_384){
case "ssp._count":
this.WriteDetailedLog("`1560`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp._count data model element is read-only");
return false;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
var _38a=_385["bucketID"];
var _38b=_385["minimum"];
var _38c=_385["requested"];
var _38d=_385["reducible"];
var _38e=_385["persistence"];
var type=_385["type"];
if(_38a==null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The bucketID delimiter must be included in calls to ssp.allocate.");
return false;
}
_38a=new String(_38a);
if(_38a.length>4000){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The bucketID can only have a maximum of 4000 characters.");
return false;
}
if(_38c==null){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The requested delimiter must be included in calls to ssp.allocate.");
return false;
}
_38c=new String(_38c);
if(_38c.search(/\D/)>=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested must be a valid integer greater than or equal to 0.");
return false;
}
_38c=parseInt(_38c,10);
if(_38c<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested must be greater than or equal to 0.");
return false;
}
if(_38c%2!=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested must be an even number.");
return false;
}
var _390=(Math.pow(2,32)-1);
if(_38c>_390){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for requested is bigger than the max size this LMS allows of "+_390+".");
return false;
}
if(_38b!=null){
_38b=new String(_38b);
if(_38b.search(/\D/)>=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum must be a valid integer greater than or equal to 0.");
return false;
}
_38b=parseInt(_38b,10);
if(_38b<0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum must be greater than or equal to 0.");
return false;
}
if(_38b%2!=0){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum must be an even number.");
return false;
}
if(_38b>_390){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The value for minimum is bigger than the max size this LMS allows of "+_390+".");
return false;
}
if(_38b>_38c){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The minimum requested amount of storage ("+_38b+") cannot be greater than the requested amount ("+_38c+").");
return false;
}
}
if(_38d!=null){
_38d=new String(_38d);
if(_38d!="true"&&_38d!="false"){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The reducible delimiter ('"+_38d+"') must be 'true' or 'false'.");
return false;
}
}
if(_38e!=null){
_38e=new String(_38e);
if(_38e!=SSP_PERSISTENCE_LEARNER&&_38e!=SSP_PERSISTENCE_COURSE&&_38e!=SSP_PERSISTENCE_SESSION){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The persistence delimiter ('"+_38e+"') must be "+SSP_PERSISTENCE_SESSION+", '"+SSP_PERSISTENCE_COURSE+"' or '"+SSP_PERSISTENCE_LEARNER+"'.");
return false;
}
}
type=new String(type);
if(type.length>3000){
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR,"The bucket type can only have a maximum of 3000 characters.");
return false;
}
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.n.allocation_success data model element is read-only");
return false;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.n.bucket_id data model element is read-only");
return false;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.n.bucket_state data model element is read-only");
return false;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
_388=this.GetBucketByIndex(_382);
_387=_385["offset"];
if(_388.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_387!=null){
_387=new String(_387);
if(_387.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_387=parseInt(_387,10);
if(_387%2!=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_387>=_388.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_388.SizeAllocated()+" bytes of storage. Setting bytes started at offset "+_387+" was requested.");
return false;
}
if(_387>=_388.CurrentlyUsedStorage()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket not packed. There are currently "+_388.CurrentlyUsedStorage()+" bytes of data stored in this bucket. The offset must be "+"less than this value.");
return false;
}
}else{
_387=0;
}
_386=_387+(_380.length*2);
if(_386>_388.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_380.length*2)+" bytes (each character is 2 bytes). Added to an offset of "+_387+" bytes, gives a total size of "+_386+", which is greater than the allocated size of this bucket ("+_388.SizeAllocated()+" bytes).");
return false;
}
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
_388=this.GetBucketByIndex(_382);
if(_388.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
_386=_388.CurrentlyUsedStorage()+(_380.length*2);
if(_386>_388.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_380.length*2)+" bytes (each character is 2 bytes). Added to the current value of size "+_388.CurrentlyUsedStorage()+" bytes, gives a total size of "+_386+", which is greater than the allocated size of this bucket ("+_388.SizeAllocated()+" bytes).");
return false;
}
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
if(_385["bucketID"]==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_388=this.GetBucketById(_385["bucketID"],true);
if(_388==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_385["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
_387=_385["offset"];
if(_388.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
if(_387!=null){
_387=new String(_387);
if(_387.search(/\D/)>=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be a valid even integer greater than 0.");
return false;
}
_387=parseInt(_387,10);
if(_387%2!=0){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"The value for offset must be an even integer.");
return false;
}
if(_387>=_388.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Offset exceeds bucket size. This bucket currently has allocated "+_388.SizeAllocated()+" bytes of storage. Setting bytes started at offset "+_387+" was requested.");
return false;
}
if(_387>=_388.CurrentlyUsedStorage()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket not packed. There are currently "+_388.CurrentlyUsedStorage()+" bytes of data stored in this bucket. The offset must be "+"less than this value.");
return false;
}
}else{
_387=0;
}
_386=_387+(_380.length*2);
if(_386>_388.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_380.length*2)+" bytes (each character is 2 bytes). Added to an offset of "+_387+" bytes, gives a total size of "+_386+", which is greater than the allocated size of this bucket ("+_388.SizeAllocated()+" bytes).");
return false;
}
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR,"The ssp.bucket_state data model element is read-only");
return false;
case "ssp.appendData":
this.WriteDetailedLog("`1483`");
if(_385["bucketID"]==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
return false;
}
_388=this.GetBucketById(_385["bucketID"],true);
if(_388==null){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket does not exist. The bucketID '"+new String(_385["bucketID"])+"' is not declared or is not visible to this SCO.");
return false;
}
if(_388.AllocationSuccess==SSP_ALLOCATION_SUCCESS_FAILURE){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket improperly declared.");
return false;
}
_386=_388.CurrentlyUsedStorage()+(_380.length*2);
if(_386>_388.SizeAllocated()){
this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR,"Bucket size exceeded. The value sent has a length of "+(_380.length*2)+" bytes (each character is 2 bytes). Added to the current value of size "+_388.CurrentlyUsedStorage()+" bytes, gives a total size of "+_386+", which is greater than the allocated size of this bucket ("+_388.SizeAllocated()+" bytes).");
return false;
}
break;
default:
this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR,"The data model element '"+_37f+"' does not exist.");
return false;
break;
}
this.WriteDetailedLog("`1547`");
return true;
}
function SSPApi_RetrieveGetValueData(_391,_392,_393,_394){
var _395=this.RemoveDelimitersFromElementName(_392);
var _396=this.GetDelimiterValues(_391);
var _397="";
switch(_395){
case "ssp._count":
this.WriteDetailedLog("`1560`");
_397=this.GetAccessibleBucketCount();
break;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
Debug.AssertError("ERROR - Element is Write Only, ssp.allocate");
blnReturn=false;
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
var _398=this.GetBucketByIndex(_393);
_397=_398.AllocationSuccess;
break;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
_398=this.GetBucketByIndex(_393);
_397=_398.Id;
break;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
_398=this.GetBucketByIndex(_393);
_397=_398.GetBucketState();
break;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
_398=this.GetBucketByIndex(_393);
_397=_398.GetData(_396["offset"],_396["size"]);
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
Debug.AssertError("ERROR - Element is Write Only, ssp.n.appendData");
blnReturn=false;
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
_398=this.GetBucketById(_396["bucketID"],true);
_397=_398.GetData(_396["offset"],_396["size"]);
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
_398=this.GetBucketById(_396["bucketID"],true);
_397=_398.GetBucketState();
break;
case "ssp.appendData":
Debug.AssertError("ERROR - Element is Write Only, ssp.appendData");
blnReturn=false;
break;
default:
Debug.AssertError("ERROR - Unrecognized data model element:"+_395);
blnReturn=false;
break;
}
return _397;
}
function SSPApi_StoreValue(_399,_39a,_39b,_39c,_39d){
var _39e=this.RemoveDelimitersFromElementName(_39b);
var _39f=this.GetDelimiterValues(_39a);
_39a=this.RemoveDelimitersFromValue(_39a);
var _3a0=true;
switch(_39e){
case "ssp._count":
this.WriteDetailedLog("`1560`");
Debug.AssertError("ERROR - Element is Read Only, ssp._count");
_3a0=false;
break;
case "ssp.allocate":
this.WriteDetailedLog("`1522`");
this.AllocateBucket(_39f["bucketID"],_39f["minimum"],_39f["requested"],_39f["reducible"],_39f["persistence"],_39f["type"]);
_3a0=true;
break;
case "ssp.n.allocation_success":
this.WriteDetailedLog("`1297`");
Debug.AssertError("ERROR - Element is Read Only, ssp._count");
_3a0=false;
break;
case "ssp.n.id":
this.WriteDetailedLog("`1592`");
case "ssp.n.bucket_id":
this.WriteDetailedLog("`1469`");
Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
_3a0=false;
break;
case "ssp.n.bucket_state":
this.WriteDetailedLog("`1396`");
Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_state");
_3a0=false;
break;
case "ssp.n.data":
this.WriteDetailedLog("`1561`");
bucket=this.GetBucketByIndex(_39c);
bucket.WriteData(_39f["offset"],_39a);
break;
case "ssp.n.appendData":
this.WriteDetailedLog("`1441`");
bucket=this.GetBucketByIndex(_39c);
bucket.AppendData(_39a);
break;
case "ssp.data":
this.WriteDetailedLog("`1591`");
bucket=this.GetBucketById(_39f["bucketID"],true);
bucket.WriteData(_39f["offset"],_39a);
break;
case "ssp.bucket_state":
this.WriteDetailedLog("`1440`");
Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
_3a0=false;
break;
case "ssp.appendData":
this.WriteDetailedLog("`1483`");
bucket=this.GetBucketById(_39f["bucketID"],true);
bucket.AppendData(_39a);
break;
default:
Debug.AssertError("ERROR - Unrecognized data model element:"+_39e);
_3a0=false;
break;
}
return _3a0;
}
function SSPApi_GetBucketById(_3a1,_3a2){
var _3a3=null;
for(var _3a4 in Control.SSPBuckets){
if((_3a2==false)||Control.SSPBuckets[_3a4].IsVisible(this.GetCurrentSCOItemIdentifier())){
if(Control.SSPBuckets[_3a4].Id==_3a1){
return Control.SSPBuckets[_3a4];
}
}
}
return _3a3;
}
function SSPApi_GetBucketByIndex(_3a5){
var _3a6=null;
i=0;
for(var _3a7 in Control.SSPBuckets){
if(Control.SSPBuckets[_3a7].IsVisible(this.GetCurrentSCOItemIdentifier())){
if(i==_3a5){
return Control.SSPBuckets[_3a7];
}
i++;
}
}
return _3a6;
}
function SSPApi_GetAccessibleBucketCount(){
var _3a8=0;
for(var _3a9 in Control.SSPBuckets){
if(Control.SSPBuckets[_3a9].IsVisible(this.GetCurrentSCOItemIdentifier())){
_3a8++;
}
}
return _3a8;
}
function SSPApi_RemoveDelimitersFromElementName(_3aa){
var _3ab;
var _3ac;
_3aa=new String(_3aa);
_3ac=_3aa;
_3ab=_3aa.indexOf("{");
if(_3ab>0){
_3ac=_3aa.substr(0,_3ab-1);
}
return _3ac.toString();
}
function SSPApi_RemoveDelimitersFromValue(_3ad){
var _3ae=/^\{\w+=[^\s\}]+\}/;
_3ad=new String(_3ad);
while(_3ad.match(_3ae)){
_3ad=_3ad.replace(_3ae,"");
}
return _3ad;
}
function SSPApi_GetDelimiterValues(_3af){
var _3b0=/\{\w+=[^\s\}]+\}/g;
var _3b1=_3af.match(_3b0);
var _3b2=new Array();
if(_3b1!=null){
for(var i=0;i<_3b1.length;i++){
var _3b4=_3b1[i].slice(1,-1);
var _3b5=_3b4.split("=");
_3b2[_3b5[0]]=[_3b5[1]];
}
}
return _3b2;
}
function SSPApi_GetCurrentSCOItemIdentifier(){
return Control.Sequencer.GetCurrentActivity().ItemIdentifier;
}
function SSPApi_AllocateBucket(_3b6,_3b7,_3b8,_3b9,_3ba,type){
var _3bc=this.GetBucketById(_3b6,false);
var _3bd;
if(_3b7==undefined||type=="minimum"){
_3b7=0;
}
if(_3b9==undefined||type=="reducible"){
redicible=false;
}
if(_3ba==undefined||type=="persistence"){
_3ba="learner";
}
if(type==undefined||type=="undefined"){
type="";
}
if(_3bc!=null){
if(_3bc.SizeMin!=_3b7||_3bc.SizeRequested!=_3b8||_3bc.Reducible!=_3b9||_3bc.Persistence!=_3ba||_3bc.BucketType!=type){
_3bd=Control.SSPBuckets.length;
Control.SSPBuckets[_3bd]=new SSPBucket(_3bd,_3b6,type,_3ba,_3b7,_3b8,_3b9,this.GetCurrentSCOItemIdentifier(),SSP_ALLOCATION_SUCCESS_FAILURE,"");
Control.SSPBuckets[_3bd].SetDirtyData();
}
}else{
var _3be=this.GetStorageAllowedByLms(_3b7,_3b8);
var _3bf;
if(_3be==null){
_3bf=SSP_ALLOCATION_SUCCESS_FAILURE;
}else{
if(_3be==_3b7){
_3bf=SSP_ALLOCATION_SUCCESS_MINIMUM;
}else{
if(_3be==_3b8){
_3bf=SSP_ALLOCATION_SUCCESS_REQUESTED;
}else{
Debug.AssertError("Invalid allocation");
}
}
}
_3bd=Control.SSPBuckets.length;
Control.SSPBuckets[_3bd]=new SSPBucket(_3bd,_3b6,type,_3ba,_3b7,_3b8,_3b9,(_3ba==SSP_PERSISTENCE_SESSION?this.GetCurrentSCOItemIdentifier():""),_3bf,"");
Control.SSPBuckets[_3bd].SetDirtyData();
}
}
function SSPApi_GetStorageAllowedByLms(_3c0,_3c1){
_3c0=parseInt(_3c0,10);
_3c1=parseInt(_3c1,10);
var _3c2=0;
for(var i=0;i<Control.SSPBuckets.length;i++){
_3c2+=Control.SSPBuckets[i].SizeAllocated();
}
if((_3c2+_3c1)<=this.MaxSSPStorage){
return _3c1;
}else{
if(_3c0>0&&((_3c2+_3c0)<=this.MaxSSPStorage)){
return _3c0;
}else{
return null;
}
}
}
function SSPApi_ResetBucketsForActivity(_3c4){
var _3c5;
for(var i=0;i<Control.SSPBuckets.length;i++){
_3c5=Control.SSPBuckets[i];
if(_3c5.LocalActivityId==_3c4&&_3c5.Persistence==SSP_PERSISTENCE_SESSION){
_3c5.ResetData();
}
}
}
function SSPApi_SetErrorState(_3c7,_3c8){
this.ApiInstance.SetErrorState(_3c7,_3c8);
}
function SSPApi_WriteDetailedLog(str){
this.ApiInstance.WriteDetailedLog(str);
}

